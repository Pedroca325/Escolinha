package javax.inject;

public interface Provider<T> {
    T get();
}
