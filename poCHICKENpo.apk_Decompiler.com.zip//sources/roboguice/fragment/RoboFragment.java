package roboguice.fragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.View;
import roboguice.RoboGuice;

public abstract class RoboFragment extends Fragment {
    public void onCreate(Bundle savedInstanceState) {
        RoboFragment.super.onCreate(savedInstanceState);
        RoboGuice.getInjector(getActivity()).injectMembersWithoutViews(this);
    }

    public void onViewCreated(View view, Bundle savedInstanceState) {
        RoboFragment.super.onViewCreated(view, savedInstanceState);
        RoboGuice.getInjector(getActivity()).injectViewMembers((Fragment) this);
    }
}
