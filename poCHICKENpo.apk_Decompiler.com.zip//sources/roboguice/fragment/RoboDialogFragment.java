package roboguice.fragment;

import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.view.View;
import roboguice.RoboGuice;

public abstract class RoboDialogFragment extends DialogFragment {
    public void onCreate(Bundle savedInstanceState) {
        RoboDialogFragment.super.onCreate(savedInstanceState);
        RoboGuice.getInjector(getActivity()).injectMembersWithoutViews(this);
    }

    public void onViewCreated(View view, Bundle savedInstanceState) {
        RoboDialogFragment.super.onViewCreated(view, savedInstanceState);
        RoboGuice.getInjector(getActivity()).injectViewMembers((Fragment) this);
    }
}
