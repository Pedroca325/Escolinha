package roboguice.service.event;

public class OnStartEvent {
}
