package roboguice.activity.event;

public class OnDestroyEvent {
}
