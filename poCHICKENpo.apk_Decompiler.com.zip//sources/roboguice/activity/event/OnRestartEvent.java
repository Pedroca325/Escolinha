package roboguice.activity.event;

public class OnRestartEvent {
}
