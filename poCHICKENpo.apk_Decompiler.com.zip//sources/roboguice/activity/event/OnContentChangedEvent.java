package roboguice.activity.event;

public class OnContentChangedEvent {
}
