package roboguice.activity.event;

public class OnNewIntentEvent {
}
