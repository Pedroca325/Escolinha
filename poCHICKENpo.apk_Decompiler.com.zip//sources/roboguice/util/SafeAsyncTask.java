package roboguice.util;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import java.io.InterruptedIOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.FutureTask;

public abstract class SafeAsyncTask<ResultT> implements Callable<ResultT> {
    protected static final Executor DEFAULT_EXECUTOR = Executors.newFixedThreadPool(25);
    public static final int DEFAULT_POOL_SIZE = 25;
    protected Executor executor;
    protected FutureTask<Void> future;
    protected Handler handler;
    protected StackTraceElement[] launchLocation;

    public SafeAsyncTask() {
        this.executor = DEFAULT_EXECUTOR;
    }

    public SafeAsyncTask(Handler handler2) {
        this.handler = handler2;
        this.executor = DEFAULT_EXECUTOR;
    }

    public SafeAsyncTask(Executor executor2) {
        this.executor = executor2;
    }

    public SafeAsyncTask(Handler handler2, Executor executor2) {
        this.handler = handler2;
        this.executor = executor2;
    }

    public FutureTask<Void> future() {
        this.future = new FutureTask<>(newTask());
        return this.future;
    }

    public SafeAsyncTask<ResultT> executor(Executor executor2) {
        this.executor = executor2;
        return this;
    }

    public Executor executor() {
        return this.executor;
    }

    public SafeAsyncTask<ResultT> handler(Handler handler2) {
        this.handler = handler2;
        return this;
    }

    public Handler handler() {
        return this.handler;
    }

    public void execute() {
        execute(Thread.currentThread().getStackTrace());
    }

    /* access modifiers changed from: protected */
    public void execute(StackTraceElement[] launchLocation2) {
        this.launchLocation = launchLocation2;
        this.executor.execute(future());
    }

    public boolean cancel(boolean mayInterruptIfRunning) {
        if (this.future != null) {
            return this.future.cancel(mayInterruptIfRunning);
        }
        throw new UnsupportedOperationException("You cannot cancel this task before calling future()");
    }

    /* access modifiers changed from: protected */
    public void onPreExecute() throws Exception {
    }

    /* access modifiers changed from: protected */
    public void onSuccess(ResultT resultt) throws Exception {
    }

    /* access modifiers changed from: protected */
    public void onInterrupted(Exception e) {
        onException(e);
    }

    /* access modifiers changed from: protected */
    public void onException(Exception e) throws RuntimeException {
        onThrowable(e);
    }

    /* access modifiers changed from: protected */
    public void onThrowable(Throwable t) throws RuntimeException {
        Log.e("roboguice", "Throwable caught during background processing", t);
    }

    /* access modifiers changed from: protected */
    public void onFinally() throws RuntimeException {
    }

    /* access modifiers changed from: protected */
    public Task<ResultT> newTask() {
        return new Task<>(this);
    }

    public static class Task<ResultT> implements Callable<Void> {
        protected Handler handler;
        protected SafeAsyncTask<ResultT> parent;

        public Task(SafeAsyncTask<ResultT> parent2) {
            this.parent = parent2;
            this.handler = parent2.handler != null ? parent2.handler : new Handler(Looper.getMainLooper());
        }

        public Void call() throws Exception {
            try {
                doPreExecute();
                doSuccess(doCall());
                doFinally();
                return null;
            } catch (Exception e) {
                try {
                    doException(e);
                } catch (Exception f) {
                    Ln.e(f);
                } catch (Throwable th) {
                    doFinally();
                    throw th;
                }
                doFinally();
                return null;
            } catch (Throwable t) {
                try {
                    doThrowable(t);
                } catch (Exception f2) {
                    Ln.e(f2);
                }
                doFinally();
                return null;
            }
        }

        /* access modifiers changed from: protected */
        public void doPreExecute() throws Exception {
            postToUiThreadAndWait(new Callable<Object>() {
                public Object call() throws Exception {
                    Task.this.parent.onPreExecute();
                    return null;
                }
            });
        }

        /* access modifiers changed from: protected */
        public ResultT doCall() throws Exception {
            return this.parent.call();
        }

        /* access modifiers changed from: protected */
        public void doSuccess(final ResultT r) throws Exception {
            postToUiThreadAndWait(new Callable<Object>() {
                public Object call() throws Exception {
                    Task.this.parent.onSuccess(r);
                    return null;
                }
            });
        }

        /* access modifiers changed from: protected */
        public void doException(final Exception e) throws Exception {
            if (this.parent.launchLocation != null) {
                ArrayList<StackTraceElement> stack = new ArrayList<>(Arrays.asList(e.getStackTrace()));
                stack.addAll(Arrays.asList(this.parent.launchLocation));
                e.setStackTrace((StackTraceElement[]) stack.toArray(new StackTraceElement[stack.size()]));
            }
            postToUiThreadAndWait(new Callable<Object>() {
                public Object call() throws Exception {
                    if ((e instanceof InterruptedException) || (e instanceof InterruptedIOException)) {
                        Task.this.parent.onInterrupted(e);
                        return null;
                    }
                    Task.this.parent.onException(e);
                    return null;
                }
            });
        }

        /* access modifiers changed from: protected */
        public void doThrowable(final Throwable e) throws Exception {
            if (this.parent.launchLocation != null) {
                ArrayList<StackTraceElement> stack = new ArrayList<>(Arrays.asList(e.getStackTrace()));
                stack.addAll(Arrays.asList(this.parent.launchLocation));
                e.setStackTrace((StackTraceElement[]) stack.toArray(new StackTraceElement[stack.size()]));
            }
            postToUiThreadAndWait(new Callable<Object>() {
                public Object call() throws Exception {
                    Task.this.parent.onThrowable(e);
                    return null;
                }
            });
        }

        /* access modifiers changed from: protected */
        public void doFinally() throws Exception {
            postToUiThreadAndWait(new Callable<Object>() {
                public Object call() throws Exception {
                    Task.this.parent.onFinally();
                    return null;
                }
            });
        }

        /* access modifiers changed from: protected */
        public void postToUiThreadAndWait(final Callable c) throws Exception {
            final CountDownLatch latch = new CountDownLatch(1);
            final Exception[] exceptions = new Exception[1];
            this.handler.post(new Runnable() {
                public void run() {
                    try {
                        c.call();
                    } catch (Exception e) {
                        exceptions[0] = e;
                    } finally {
                        latch.countDown();
                    }
                }
            });
            latch.await();
            if (exceptions[0] != null) {
                throw exceptions[0];
            }
        }
    }
}
