package roboguice.config;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlarmManager;
import android.app.Application;
import android.app.KeyguardManager;
import android.app.NotificationManager;
import android.app.SearchManager;
import android.app.Service;
import android.content.ContentResolver;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.hardware.SensorManager;
import android.location.LocationManager;
import android.media.AudioManager;
import android.net.ConnectivityManager;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Handler;
import android.os.PowerManager;
import android.os.Vibrator;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.view.LayoutInflater;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import com.google.inject.AbstractModule;
import com.google.inject.Key;
import com.google.inject.Provider;
import com.google.inject.TypeLiteral;
import com.google.inject.matcher.Matchers;
import com.google.inject.name.Names;
import java.lang.annotation.Annotation;
import roboguice.activity.RoboActivity;
import roboguice.event.EventManager;
import roboguice.event.ObservesTypeListener;
import roboguice.event.eventListener.factory.EventListenerThreadingDecorator;
import roboguice.inject.AccountManagerProvider;
import roboguice.inject.AssetManagerProvider;
import roboguice.inject.ContentResolverProvider;
import roboguice.inject.ContextScope;
import roboguice.inject.ContextScopedSystemServiceProvider;
import roboguice.inject.ContextSingleton;
import roboguice.inject.ExtrasListener;
import roboguice.inject.FragmentManagerProvider;
import roboguice.inject.HandlerProvider;
import roboguice.inject.NullProvider;
import roboguice.inject.PreferenceListener;
import roboguice.inject.ResourceListener;
import roboguice.inject.ResourcesProvider;
import roboguice.inject.SharedPreferencesProvider;
import roboguice.inject.SystemServiceProvider;
import roboguice.inject.ViewListener;
import roboguice.service.RoboService;
import roboguice.util.Ln;
import roboguice.util.Strings;

public class DefaultRoboModule extends AbstractModule {
    protected static final Class accountManagerClass;
    protected static final Class fragmentManagerClass;
    protected Application application;
    protected ContextScope contextScope;
    protected ResourceListener resourceListener;
    protected ViewListener viewListener;

    static {
        Class c = null;
        try {
            c = Class.forName("android.support.v4.app.FragmentManager");
        } catch (Throwable th) {
        }
        fragmentManagerClass = c;
        Class c2 = null;
        try {
            c2 = Class.forName("android.accounts.AccountManager");
        } catch (Throwable th2) {
        }
        accountManagerClass = c2;
    }

    public DefaultRoboModule(Application application2, ContextScope contextScope2, ViewListener viewListener2, ResourceListener resourceListener2) {
        this.application = application2;
        this.contextScope = contextScope2;
        this.viewListener = viewListener2;
        this.resourceListener = resourceListener2;
    }

    /* access modifiers changed from: protected */
    public void configure() {
        Provider<Context> contextProvider = getProvider(Context.class);
        ExtrasListener extrasListener = new ExtrasListener(contextProvider);
        PreferenceListener preferenceListener = new PreferenceListener(contextProvider, this.application, this.contextScope);
        EventListenerThreadingDecorator observerThreadingDecorator = new EventListenerThreadingDecorator();
        String androidId = Settings.Secure.getString(this.application.getContentResolver(), "android_id");
        try {
            bind(PackageInfo.class).toInstance(this.application.getPackageManager().getPackageInfo(this.application.getPackageName(), 0));
            if (Strings.notEmpty(androidId)) {
                bindConstant().annotatedWith((Annotation) Names.named("android_id")).to(androidId);
            }
            bind(ViewListener.class).toInstance(this.viewListener);
            bind(PreferenceListener.class).toInstance(preferenceListener);
            bindScope(ContextSingleton.class, this.contextScope);
            bind(ContextScope.class).toInstance(this.contextScope);
            bind(AssetManager.class).toProvider(AssetManagerProvider.class);
            bind(Context.class).toProvider(Key.get(new TypeLiteral<NullProvider<Context>>() {
            })).in((Class<? extends Annotation>) ContextSingleton.class);
            bind(Activity.class).toProvider(Key.get(new TypeLiteral<NullProvider<Activity>>() {
            })).in((Class<? extends Annotation>) ContextSingleton.class);
            bind(RoboActivity.class).toProvider(Key.get(new TypeLiteral<NullProvider<RoboActivity>>() {
            })).in((Class<? extends Annotation>) ContextSingleton.class);
            bind(Service.class).toProvider(Key.get(new TypeLiteral<NullProvider<Service>>() {
            })).in((Class<? extends Annotation>) ContextSingleton.class);
            bind(RoboService.class).toProvider(Key.get(new TypeLiteral<NullProvider<RoboService>>() {
            })).in((Class<? extends Annotation>) ContextSingleton.class);
            bind(SharedPreferences.class).toProvider(SharedPreferencesProvider.class);
            bind(Resources.class).toProvider(ResourcesProvider.class);
            bind(ContentResolver.class).toProvider(ContentResolverProvider.class);
            bind(Application.class).toInstance(this.application);
            bind(EventListenerThreadingDecorator.class).toInstance(observerThreadingDecorator);
            bind(Handler.class).toProvider(HandlerProvider.class);
            bind(LocationManager.class).toProvider(new SystemServiceProvider("location"));
            bind(WindowManager.class).toProvider(new SystemServiceProvider("window"));
            bind(ActivityManager.class).toProvider(new SystemServiceProvider("activity"));
            bind(PowerManager.class).toProvider(new SystemServiceProvider("power"));
            bind(AlarmManager.class).toProvider(new SystemServiceProvider("alarm"));
            bind(NotificationManager.class).toProvider(new SystemServiceProvider("notification"));
            bind(KeyguardManager.class).toProvider(new SystemServiceProvider("keyguard"));
            bind(Vibrator.class).toProvider(new SystemServiceProvider("vibrator"));
            bind(ConnectivityManager.class).toProvider(new SystemServiceProvider("connectivity"));
            bind(WifiManager.class).toProvider(new SystemServiceProvider("wifi"));
            bind(InputMethodManager.class).toProvider(new SystemServiceProvider("input_method"));
            bind(SensorManager.class).toProvider(new SystemServiceProvider("sensor"));
            bind(TelephonyManager.class).toProvider(new SystemServiceProvider("phone"));
            bind(AudioManager.class).toProvider(new SystemServiceProvider("audio"));
            bind(LayoutInflater.class).toProvider(new ContextScopedSystemServiceProvider(contextProvider, "layout_inflater"));
            bind(SearchManager.class).toProvider(new ContextScopedSystemServiceProvider(contextProvider, "search"));
            bindListener(Matchers.any(), this.resourceListener);
            bindListener(Matchers.any(), extrasListener);
            bindListener(Matchers.any(), this.viewListener);
            bindListener(Matchers.any(), preferenceListener);
            bindListener(Matchers.any(), new ObservesTypeListener(getProvider(EventManager.class), observerThreadingDecorator));
            requestInjection(observerThreadingDecorator);
            requestStaticInjection(Ln.class);
            if (fragmentManagerClass != null) {
                bind(fragmentManagerClass).toProvider(FragmentManagerProvider.class);
            }
            if (Build.VERSION.SDK_INT >= 5) {
                bind(accountManagerClass).toProvider(AccountManagerProvider.class);
            }
        } catch (PackageManager.NameNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
}
