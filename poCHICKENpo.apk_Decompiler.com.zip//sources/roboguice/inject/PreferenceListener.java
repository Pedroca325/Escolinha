package roboguice.inject;

import android.app.Application;
import android.content.Context;
import android.preference.PreferenceActivity;
import com.google.inject.MembersInjector;
import com.google.inject.Provider;
import com.google.inject.spi.TypeListener;
import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.util.ArrayList;

public class PreferenceListener implements TypeListener {
    protected Application application;
    protected Provider<Context> contextProvider;
    protected ArrayList<PreferenceMembersInjector<?>> preferencesForInjection = new ArrayList<>();
    protected ContextScope scope;

    public PreferenceListener(Provider<Context> contextProvider2, Application application2, ContextScope scope2) {
        this.contextProvider = contextProvider2;
        this.application = application2;
        this.scope = scope2;
    }

    /* JADX WARNING: type inference failed for: r11v0, types: [com.google.inject.TypeLiteral<I>, com.google.inject.TypeLiteral] */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public <I> void hear(com.google.inject.TypeLiteral<I> r11, com.google.inject.spi.TypeEncounter<I> r12) {
        /*
            r10 = this;
            java.lang.Class r7 = r11.getRawType()
        L_0x0004:
            java.lang.Class<java.lang.Object> r0 = java.lang.Object.class
            if (r7 == r0) goto L_0x0049
            java.lang.reflect.Field[] r6 = r7.getDeclaredFields()
            int r9 = r6.length
            r8 = 0
        L_0x000e:
            if (r8 >= r9) goto L_0x0044
            r2 = r6[r8]
            java.lang.Class<roboguice.inject.InjectPreference> r0 = roboguice.inject.InjectPreference.class
            boolean r0 = r2.isAnnotationPresent(r0)
            if (r0 == 0) goto L_0x0041
            int r0 = r2.getModifiers()
            boolean r0 = java.lang.reflect.Modifier.isStatic(r0)
            if (r0 == 0) goto L_0x002c
            java.lang.UnsupportedOperationException r0 = new java.lang.UnsupportedOperationException
            java.lang.String r1 = "Preferences may not be statically injected"
            r0.<init>(r1)
            throw r0
        L_0x002c:
            roboguice.inject.PreferenceListener$PreferenceMembersInjector r0 = new roboguice.inject.PreferenceListener$PreferenceMembersInjector
            com.google.inject.Provider<android.content.Context> r3 = r10.contextProvider
            java.lang.Class<roboguice.inject.InjectPreference> r1 = roboguice.inject.InjectPreference.class
            java.lang.annotation.Annotation r4 = r2.getAnnotation(r1)
            roboguice.inject.InjectPreference r4 = (roboguice.inject.InjectPreference) r4
            roboguice.inject.ContextScope r5 = r10.scope
            r1 = r10
            r0.<init>(r2, r3, r4, r5)
            r12.register(r0)
        L_0x0041:
            int r8 = r8 + 1
            goto L_0x000e
        L_0x0044:
            java.lang.Class r7 = r7.getSuperclass()
            goto L_0x0004
        L_0x0049:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: roboguice.inject.PreferenceListener.hear(com.google.inject.TypeLiteral, com.google.inject.spi.TypeEncounter):void");
    }

    public void registerPreferenceForInjection(PreferenceMembersInjector<?> injector) {
        this.preferencesForInjection.add(injector);
    }

    public void injectPreferenceViews() {
        for (int i = this.preferencesForInjection.size() - 1; i >= 0; i--) {
            this.preferencesForInjection.remove(i).reallyInjectMembers();
        }
    }

    class PreferenceMembersInjector<T> implements MembersInjector<T> {
        protected InjectPreference annotation;
        protected Provider<Context> contextProvider;
        protected Field field;
        protected WeakReference<T> instanceRef;
        protected ContextScope scope;

        public PreferenceMembersInjector(Field field2, Provider<Context> contextProvider2, InjectPreference annotation2, ContextScope scope2) {
            this.field = field2;
            this.annotation = annotation2;
            this.contextProvider = contextProvider2;
            this.scope = scope2;
        }

        public void injectMembers(T instance) {
            this.instanceRef = new WeakReference<>(instance);
            PreferenceListener.this.registerPreferenceForInjection(this);
        }

        public void reallyInjectMembers() {
            T instance = this.instanceRef.get();
            if (instance != null) {
                Object value = null;
                try {
                    value = ((PreferenceActivity) this.contextProvider.get()).findPreference(this.annotation.value());
                    if (value != null || !Nullable.notNullable(this.field)) {
                        this.field.setAccessible(true);
                        this.field.set(instance, value);
                        return;
                    }
                    throw new NullPointerException(String.format("Can't inject null value into %s.%s when field is not @Nullable", new Object[]{this.field.getDeclaringClass(), this.field.getName()}));
                } catch (IllegalAccessException e) {
                    throw new RuntimeException(e);
                } catch (IllegalArgumentException e2) {
                    Object[] objArr = new Object[4];
                    objArr[0] = value != null ? value.getClass() : "(null)";
                    objArr[1] = value;
                    objArr[2] = this.field.getType();
                    objArr[3] = this.field.getName();
                    throw new IllegalArgumentException(String.format("Can't assign %s value %s to %s field %s", objArr));
                }
            }
        }
    }
}
