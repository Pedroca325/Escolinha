package roboguice.inject;

import com.google.inject.Provider;

public class NullProvider<T> implements Provider<T> {
    public T get() {
        return null;
    }
}
