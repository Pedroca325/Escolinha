package roboguice.inject;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import com.google.inject.Injector;
import com.google.inject.Key;
import com.google.inject.MembersInjector;
import com.google.inject.Provider;
import com.google.inject.spi.TypeListener;
import com.google.inject.util.Types;
import java.lang.reflect.Field;
import java.lang.reflect.Type;
import roboguice.RoboGuice;

public class ExtrasListener implements TypeListener {
    protected Provider<Context> contextProvider;

    public ExtrasListener(Provider<Context> contextProvider2) {
        this.contextProvider = contextProvider2;
    }

    /* JADX WARNING: type inference failed for: r9v0, types: [com.google.inject.TypeLiteral<I>, com.google.inject.TypeLiteral] */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public <I> void hear(com.google.inject.TypeLiteral<I> r9, com.google.inject.spi.TypeEncounter<I> r10) {
        /*
            r8 = this;
            java.lang.Class r1 = r9.getRawType()
        L_0x0004:
            java.lang.Class<java.lang.Object> r5 = java.lang.Object.class
            if (r1 == r5) goto L_0x0046
            java.lang.reflect.Field[] r0 = r1.getDeclaredFields()
            int r4 = r0.length
            r3 = 0
        L_0x000e:
            if (r3 >= r4) goto L_0x0041
            r2 = r0[r3]
            java.lang.Class<roboguice.inject.InjectExtra> r5 = roboguice.inject.InjectExtra.class
            boolean r5 = r2.isAnnotationPresent(r5)
            if (r5 == 0) goto L_0x003e
            int r5 = r2.getModifiers()
            boolean r5 = java.lang.reflect.Modifier.isStatic(r5)
            if (r5 == 0) goto L_0x002c
            java.lang.UnsupportedOperationException r5 = new java.lang.UnsupportedOperationException
            java.lang.String r6 = "Extras may not be statically injected"
            r5.<init>(r6)
            throw r5
        L_0x002c:
            roboguice.inject.ExtrasListener$ExtrasMembersInjector r6 = new roboguice.inject.ExtrasListener$ExtrasMembersInjector
            com.google.inject.Provider<android.content.Context> r7 = r8.contextProvider
            java.lang.Class<roboguice.inject.InjectExtra> r5 = roboguice.inject.InjectExtra.class
            java.lang.annotation.Annotation r5 = r2.getAnnotation(r5)
            roboguice.inject.InjectExtra r5 = (roboguice.inject.InjectExtra) r5
            r6.<init>(r2, r7, r5)
            r10.register(r6)
        L_0x003e:
            int r3 = r3 + 1
            goto L_0x000e
        L_0x0041:
            java.lang.Class r1 = r1.getSuperclass()
            goto L_0x0004
        L_0x0046:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: roboguice.inject.ExtrasListener.hear(com.google.inject.TypeLiteral, com.google.inject.spi.TypeEncounter):void");
    }

    protected static class ExtrasMembersInjector<T> implements MembersInjector<T> {
        protected InjectExtra annotation;
        protected Provider<Context> contextProvider;
        protected Field field;

        public ExtrasMembersInjector(Field field2, Provider<Context> contextProvider2, InjectExtra annotation2) {
            this.field = field2;
            this.contextProvider = contextProvider2;
            this.annotation = annotation2;
        }

        public void injectMembers(T instance) {
            Context context = this.contextProvider.get();
            if (!(context instanceof Activity)) {
                throw new UnsupportedOperationException(String.format("Extras may not be injected into contexts that are not Activities (error in class %s)", new Object[]{this.contextProvider.get().getClass().getSimpleName()}));
            }
            Activity activity = (Activity) context;
            String id = this.annotation.value();
            Bundle extras = activity.getIntent().getExtras();
            if (extras != null && extras.containsKey(id)) {
                Object value = convert(this.field, extras.get(id), RoboGuice.getBaseApplicationInjector(activity.getApplication()));
                if (value != null || !Nullable.notNullable(this.field)) {
                    this.field.setAccessible(true);
                    try {
                        this.field.set(instance, value);
                    } catch (IllegalAccessException e) {
                        throw new RuntimeException(e);
                    } catch (IllegalArgumentException e2) {
                        Object[] objArr = new Object[4];
                        objArr[0] = value != null ? value.getClass() : "(null)";
                        objArr[1] = value;
                        objArr[2] = this.field.getType();
                        objArr[3] = this.field.getName();
                        throw new IllegalArgumentException(String.format("Can't assign %s value %s to %s field %s", objArr));
                    }
                } else {
                    throw new NullPointerException(String.format("Can't inject null value into %s.%s when field is not @Nullable", new Object[]{this.field.getDeclaringClass(), this.field.getName()}));
                }
            } else if (!this.annotation.optional()) {
                throw new IllegalStateException(String.format("Can't find the mandatory extra identified by key [%s] on field %s.%s", new Object[]{id, this.field.getDeclaringClass(), this.field.getName()}));
            }
        }

        /* access modifiers changed from: protected */
        public Object convert(Field field2, Object value, Injector injector) {
            if (value == null || field2.getType().isPrimitive()) {
                return value;
            }
            Key<?> key = Key.get((Type) Types.newParameterizedType(ExtraConverter.class, value.getClass(), field2.getType()));
            if (injector.getBindings().containsKey(key)) {
                value = ((ExtraConverter) injector.getInstance(key)).convert(value);
            }
            return value;
        }
    }
}
