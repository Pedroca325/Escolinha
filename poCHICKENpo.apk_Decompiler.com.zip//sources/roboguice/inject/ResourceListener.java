package roboguice.inject;

import android.app.Application;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Movie;
import android.graphics.drawable.Drawable;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import com.google.inject.MembersInjector;
import com.google.inject.spi.TypeListener;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

public class ResourceListener implements TypeListener {
    protected Application application;

    public ResourceListener(Application application2) {
        this.application = application2;
    }

    /* JADX WARNING: type inference failed for: r9v0, types: [com.google.inject.TypeLiteral<I>, com.google.inject.TypeLiteral] */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public <I> void hear(com.google.inject.TypeLiteral<I> r9, com.google.inject.spi.TypeEncounter<I> r10) {
        /*
            r8 = this;
            java.lang.Class r1 = r9.getRawType()
        L_0x0004:
            java.lang.Class<java.lang.Object> r5 = java.lang.Object.class
            if (r1 == r5) goto L_0x003e
            java.lang.reflect.Field[] r0 = r1.getDeclaredFields()
            int r4 = r0.length
            r3 = 0
        L_0x000e:
            if (r3 >= r4) goto L_0x0039
            r2 = r0[r3]
            java.lang.Class<roboguice.inject.InjectResource> r5 = roboguice.inject.InjectResource.class
            boolean r5 = r2.isAnnotationPresent(r5)
            if (r5 == 0) goto L_0x0036
            int r5 = r2.getModifiers()
            boolean r5 = java.lang.reflect.Modifier.isStatic(r5)
            if (r5 != 0) goto L_0x0036
            roboguice.inject.ResourceListener$ResourceMembersInjector r6 = new roboguice.inject.ResourceListener$ResourceMembersInjector
            android.app.Application r7 = r8.application
            java.lang.Class<roboguice.inject.InjectResource> r5 = roboguice.inject.InjectResource.class
            java.lang.annotation.Annotation r5 = r2.getAnnotation(r5)
            roboguice.inject.InjectResource r5 = (roboguice.inject.InjectResource) r5
            r6.<init>(r2, r7, r5)
            r10.register(r6)
        L_0x0036:
            int r3 = r3 + 1
            goto L_0x000e
        L_0x0039:
            java.lang.Class r1 = r1.getSuperclass()
            goto L_0x0004
        L_0x003e:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: roboguice.inject.ResourceListener.hear(com.google.inject.TypeLiteral, com.google.inject.spi.TypeEncounter):void");
    }

    public void requestStaticInjection(Class<?>... types) {
        Class<?>[] arr$ = types;
        int len$ = arr$.length;
        for (int i$ = 0; i$ < len$; i$++) {
            for (Class<?> c = arr$[i$]; c != Object.class; c = c.getSuperclass()) {
                for (Field field : c.getDeclaredFields()) {
                    if (Modifier.isStatic(field.getModifiers()) && field.isAnnotationPresent(InjectResource.class)) {
                        new ResourceMembersInjector(field, this.application, (InjectResource) field.getAnnotation(InjectResource.class)).injectMembers(null);
                    }
                }
            }
        }
    }

    protected static class ResourceMembersInjector<T> implements MembersInjector<T> {
        protected InjectResource annotation;
        protected Application application;
        protected Field field;

        public ResourceMembersInjector(Field field2, Application application2, InjectResource annotation2) {
            this.field = field2;
            this.application = application2;
            this.annotation = annotation2;
        }

        public void injectMembers(T instance) {
            Object value = null;
            try {
                Resources resources = this.application.getResources();
                int id = getId(resources, this.annotation);
                Class<?> t = this.field.getType();
                if (String.class.isAssignableFrom(t)) {
                    value = resources.getString(id);
                } else if (Boolean.TYPE.isAssignableFrom(t) || Boolean.class.isAssignableFrom(t)) {
                    value = Boolean.valueOf(resources.getBoolean(id));
                } else if (ColorStateList.class.isAssignableFrom(t)) {
                    value = resources.getColorStateList(id);
                } else if (Integer.TYPE.isAssignableFrom(t) || Integer.class.isAssignableFrom(t)) {
                    value = Integer.valueOf(resources.getInteger(id));
                } else if (Drawable.class.isAssignableFrom(t)) {
                    value = resources.getDrawable(id);
                } else if (String[].class.isAssignableFrom(t)) {
                    value = resources.getStringArray(id);
                } else if (int[].class.isAssignableFrom(t) || Integer[].class.isAssignableFrom(t)) {
                    value = resources.getIntArray(id);
                } else if (Animation.class.isAssignableFrom(t)) {
                    value = AnimationUtils.loadAnimation(this.application, id);
                } else if (Movie.class.isAssignableFrom(t)) {
                    value = resources.getMovie(id);
                }
                if (value != null || !Nullable.notNullable(this.field)) {
                    this.field.setAccessible(true);
                    this.field.set(instance, value);
                    return;
                }
                throw new NullPointerException(String.format("Can't inject null value into %s.%s when field is not @Nullable", new Object[]{this.field.getDeclaringClass(), this.field.getName()}));
            } catch (IllegalAccessException e) {
                throw new RuntimeException(e);
            } catch (IllegalArgumentException e2) {
                Object[] objArr = new Object[4];
                objArr[0] = value != null ? value.getClass() : "(null)";
                objArr[1] = value;
                objArr[2] = this.field.getType();
                objArr[3] = this.field.getName();
                throw new IllegalArgumentException(String.format("Can't assign %s value %s to %s field %s", objArr));
            }
        }

        /* access modifiers changed from: protected */
        public int getId(Resources resources, InjectResource annotation2) {
            int id = annotation2.value();
            return id >= 0 ? id : resources.getIdentifier(annotation2.name(), (String) null, (String) null);
        }
    }
}
