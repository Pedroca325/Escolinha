package roboguice.inject;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import com.google.inject.MembersInjector;
import com.google.inject.Provider;
import com.google.inject.spi.TypeEncounter;
import com.google.inject.spi.TypeListener;
import java.lang.annotation.Annotation;
import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.WeakHashMap;
import javax.inject.Singleton;

@Singleton
public class ViewListener implements TypeListener {
    protected static Class fragmentClass;
    protected static Method fragmentFindFragmentByIdMethod;
    protected static Method fragmentFindFragmentByTagMethod;
    protected static Method fragmentGetViewMethod;
    protected static Class fragmentManagerClass;

    static {
        fragmentClass = null;
        fragmentManagerClass = null;
        fragmentGetViewMethod = null;
        fragmentFindFragmentByIdMethod = null;
        fragmentFindFragmentByTagMethod = null;
        try {
            fragmentClass = Class.forName("android.support.v4.app.Fragment");
            fragmentManagerClass = Class.forName("android.support.v4.app.FragmentManager");
            fragmentGetViewMethod = fragmentClass.getDeclaredMethod("getView", new Class[0]);
            fragmentFindFragmentByIdMethod = fragmentManagerClass.getMethod("findFragmentById", new Class[]{Integer.TYPE});
            fragmentFindFragmentByTagMethod = fragmentManagerClass.getMethod("findFragmentByTag", new Class[]{Object.class});
        } catch (Throwable th) {
        }
    }

    /* JADX WARNING: type inference failed for: r8v0, types: [com.google.inject.TypeLiteral<I>, com.google.inject.TypeLiteral] */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public <I> void hear(com.google.inject.TypeLiteral<I> r8, com.google.inject.spi.TypeEncounter<I> r9) {
        /*
            r7 = this;
            java.lang.Class r1 = r8.getRawType()
        L_0x0004:
            java.lang.Class<java.lang.Object> r5 = java.lang.Object.class
            if (r1 == r5) goto L_0x00d8
            java.lang.reflect.Field[] r0 = r1.getDeclaredFields()
            int r4 = r0.length
            r3 = 0
        L_0x000e:
            if (r3 >= r4) goto L_0x00d2
            r2 = r0[r3]
            java.lang.Class<roboguice.inject.InjectView> r5 = roboguice.inject.InjectView.class
            boolean r5 = r2.isAnnotationPresent(r5)
            if (r5 == 0) goto L_0x0071
            int r5 = r2.getModifiers()
            boolean r5 = java.lang.reflect.Modifier.isStatic(r5)
            if (r5 == 0) goto L_0x002c
            java.lang.UnsupportedOperationException r5 = new java.lang.UnsupportedOperationException
            java.lang.String r6 = "Views may not be statically injected"
            r5.<init>(r6)
            throw r5
        L_0x002c:
            java.lang.Class<android.view.View> r5 = android.view.View.class
            java.lang.Class r6 = r2.getType()
            boolean r5 = r5.isAssignableFrom(r6)
            if (r5 != 0) goto L_0x0040
            java.lang.UnsupportedOperationException r5 = new java.lang.UnsupportedOperationException
            java.lang.String r6 = "You may only use @InjectView on fields descended from type View"
            r5.<init>(r6)
            throw r5
        L_0x0040:
            java.lang.Class<android.content.Context> r5 = android.content.Context.class
            java.lang.Class r6 = r2.getDeclaringClass()
            boolean r5 = r5.isAssignableFrom(r6)
            if (r5 == 0) goto L_0x0060
            java.lang.Class<android.app.Activity> r5 = android.app.Activity.class
            java.lang.Class r6 = r2.getDeclaringClass()
            boolean r5 = r5.isAssignableFrom(r6)
            if (r5 != 0) goto L_0x0060
            java.lang.UnsupportedOperationException r5 = new java.lang.UnsupportedOperationException
            java.lang.String r6 = "You may only use @InjectView in Activity contexts"
            r5.<init>(r6)
            throw r5
        L_0x0060:
            roboguice.inject.ViewListener$ViewMembersInjector r5 = new roboguice.inject.ViewListener$ViewMembersInjector
            java.lang.Class<roboguice.inject.InjectView> r6 = roboguice.inject.InjectView.class
            java.lang.annotation.Annotation r6 = r2.getAnnotation(r6)
            r5.<init>(r2, r6, r9)
            r9.register(r5)
        L_0x006e:
            int r3 = r3 + 1
            goto L_0x000e
        L_0x0071:
            java.lang.Class<roboguice.inject.InjectFragment> r5 = roboguice.inject.InjectFragment.class
            boolean r5 = r2.isAnnotationPresent(r5)
            if (r5 == 0) goto L_0x006e
            int r5 = r2.getModifiers()
            boolean r5 = java.lang.reflect.Modifier.isStatic(r5)
            if (r5 == 0) goto L_0x008b
            java.lang.UnsupportedOperationException r5 = new java.lang.UnsupportedOperationException
            java.lang.String r6 = "Fragments may not be statically injected"
            r5.<init>(r6)
            throw r5
        L_0x008b:
            java.lang.Class r5 = fragmentClass
            if (r5 == 0) goto L_0x00a3
            java.lang.Class r5 = fragmentClass
            java.lang.Class r6 = r2.getType()
            boolean r5 = r5.isAssignableFrom(r6)
            if (r5 != 0) goto L_0x00a3
            java.lang.UnsupportedOperationException r5 = new java.lang.UnsupportedOperationException
            java.lang.String r6 = "You may only use @InjectFragment on fields descended from type Fragment"
            r5.<init>(r6)
            throw r5
        L_0x00a3:
            java.lang.Class<android.content.Context> r5 = android.content.Context.class
            java.lang.Class r6 = r2.getDeclaringClass()
            boolean r5 = r5.isAssignableFrom(r6)
            if (r5 == 0) goto L_0x00c3
            java.lang.Class<android.app.Activity> r5 = android.app.Activity.class
            java.lang.Class r6 = r2.getDeclaringClass()
            boolean r5 = r5.isAssignableFrom(r6)
            if (r5 != 0) goto L_0x00c3
            java.lang.UnsupportedOperationException r5 = new java.lang.UnsupportedOperationException
            java.lang.String r6 = "You may only use @InjectFragment in Activity contexts"
            r5.<init>(r6)
            throw r5
        L_0x00c3:
            roboguice.inject.ViewListener$ViewMembersInjector r5 = new roboguice.inject.ViewListener$ViewMembersInjector
            java.lang.Class<roboguice.inject.InjectFragment> r6 = roboguice.inject.InjectFragment.class
            java.lang.annotation.Annotation r6 = r2.getAnnotation(r6)
            r5.<init>(r2, r6, r9)
            r9.register(r5)
            goto L_0x006e
        L_0x00d2:
            java.lang.Class r1 = r1.getSuperclass()
            goto L_0x0004
        L_0x00d8:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: roboguice.inject.ViewListener.hear(com.google.inject.TypeLiteral, com.google.inject.spi.TypeEncounter):void");
    }

    public static class ViewMembersInjector<T> implements MembersInjector<T> {
        protected static WeakHashMap<Object, ArrayList<ViewMembersInjector<?>>> viewMembersInjectors = new WeakHashMap<>();
        protected Provider<Activity> activityProvider;
        protected Annotation annotation;
        protected Field field;
        protected Provider fragmentManagerProvider;
        protected WeakReference<T> instanceRef;

        public ViewMembersInjector(Field field2, Annotation annotation2, TypeEncounter<T> typeEncounter) {
            this.field = field2;
            this.annotation = annotation2;
            this.activityProvider = typeEncounter.getProvider((Class<T>) Activity.class);
            if (ViewListener.fragmentManagerClass != null) {
                this.fragmentManagerProvider = typeEncounter.getProvider((Class<T>) ViewListener.fragmentManagerClass);
            }
        }

        public void injectMembers(T instance) {
            Object key;
            synchronized (ViewMembersInjector.class) {
                Object activity = (Activity) this.activityProvider.get();
                if (ViewListener.fragmentClass == null || !ViewListener.fragmentClass.isInstance(instance)) {
                    key = activity;
                } else {
                    key = instance;
                }
                if (key != null) {
                    ArrayList<ViewMembersInjector<?>> injectors = viewMembersInjectors.get(key);
                    if (injectors == null) {
                        injectors = new ArrayList<>();
                        viewMembersInjectors.put(key, injectors);
                    }
                    injectors.add(this);
                    this.instanceRef = new WeakReference<>(instance);
                }
            }
        }

        public void reallyInjectMembers(Object activityOrFragment) {
            if (this.annotation instanceof InjectView) {
                reallyInjectMemberViews(activityOrFragment);
            } else {
                reallyInjectMemberFragments(activityOrFragment);
            }
        }

        /* access modifiers changed from: protected */
        public void reallyInjectMemberViews(Object activityOrFragment) {
            View view;
            Object obj = (ViewListener.fragmentClass == null || !ViewListener.fragmentClass.isInstance(activityOrFragment)) ? this.instanceRef.get() : activityOrFragment;
            if (obj != null) {
                if (!(activityOrFragment instanceof Context) || (activityOrFragment instanceof Activity)) {
                    View view2 = null;
                    try {
                        InjectView injectView = (InjectView) this.annotation;
                        int id = injectView.value();
                        if (id >= 0) {
                            view = (ViewListener.fragmentClass == null || !ViewListener.fragmentClass.isInstance(activityOrFragment)) ? ((Activity) activityOrFragment).findViewById(id) : ((View) ViewListener.fragmentGetViewMethod.invoke(activityOrFragment, new Object[0])).findViewById(id);
                        } else {
                            view = (ViewListener.fragmentClass == null || !ViewListener.fragmentClass.isInstance(activityOrFragment)) ? ((Activity) activityOrFragment).getWindow().getDecorView().findViewWithTag(injectView.tag()) : ((View) ViewListener.fragmentGetViewMethod.invoke(activityOrFragment, new Object[0])).findViewWithTag(injectView.tag());
                        }
                        if (view != null || !Nullable.notNullable(this.field)) {
                            this.field.setAccessible(true);
                            this.field.set(obj, view);
                            return;
                        }
                        throw new NullPointerException(String.format("Can't inject null value into %s.%s when field is not @Nullable", new Object[]{this.field.getDeclaringClass(), this.field.getName()}));
                    } catch (IllegalAccessException e) {
                        throw new RuntimeException(e);
                    } catch (InvocationTargetException e2) {
                        throw new RuntimeException(e2);
                    } catch (IllegalArgumentException f) {
                        Object[] objArr = new Object[4];
                        objArr[0] = view2 != null ? view2.getClass() : "(null)";
                        objArr[1] = view2;
                        objArr[2] = this.field.getType();
                        objArr[3] = this.field.getName();
                        throw new IllegalArgumentException(String.format("Can't assign %s value %s to %s field %s", objArr), f);
                    }
                } else {
                    throw new UnsupportedOperationException("Can't inject view into a non-Activity context");
                }
            }
        }

        /* access modifiers changed from: protected */
        public void reallyInjectMemberFragments(Object activityOrFragment) {
            Object fragment;
            T instance = this.instanceRef.get();
            if (instance != null) {
                if (!(activityOrFragment instanceof Context) || (activityOrFragment instanceof Activity)) {
                    Object obj = null;
                    try {
                        InjectFragment injectFragment = (InjectFragment) this.annotation;
                        int id = injectFragment.value();
                        if (id >= 0) {
                            fragment = ViewListener.fragmentFindFragmentByIdMethod.invoke(this.fragmentManagerProvider.get(), new Object[]{Integer.valueOf(id)});
                        } else {
                            fragment = ViewListener.fragmentFindFragmentByTagMethod.invoke(this.fragmentManagerProvider.get(), new Object[]{injectFragment.tag()});
                        }
                        if (fragment != null || !Nullable.notNullable(this.field)) {
                            this.field.setAccessible(true);
                            this.field.set(instance, fragment);
                            return;
                        }
                        throw new NullPointerException(String.format("Can't inject null value into %s.%s when field is not @Nullable", new Object[]{this.field.getDeclaringClass(), this.field.getName()}));
                    } catch (IllegalAccessException e) {
                        throw new RuntimeException(e);
                    } catch (InvocationTargetException e2) {
                        throw new RuntimeException(e2);
                    } catch (IllegalArgumentException f) {
                        Object[] objArr = new Object[4];
                        objArr[0] = obj != null ? obj.getClass() : "(null)";
                        objArr[1] = obj;
                        objArr[2] = this.field.getType();
                        objArr[3] = this.field.getName();
                        throw new IllegalArgumentException(String.format("Can't assign %s value %s to %s field %s", objArr), f);
                    }
                } else {
                    throw new UnsupportedOperationException("Can't inject fragment into a non-Activity context");
                }
            }
        }

        protected static void injectViews(Object activityOrFragment) {
            synchronized (ViewMembersInjector.class) {
                ArrayList<ViewMembersInjector<?>> injectors = viewMembersInjectors.get(activityOrFragment);
                if (injectors != null) {
                    Iterator i$ = injectors.iterator();
                    while (i$.hasNext()) {
                        i$.next().reallyInjectMembers(activityOrFragment);
                    }
                }
            }
        }
    }
}
