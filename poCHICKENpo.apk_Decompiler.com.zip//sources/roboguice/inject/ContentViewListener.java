package roboguice.inject;

import android.app.Activity;
import android.content.Context;
import com.google.inject.Inject;
import roboguice.activity.event.OnCreateEvent;
import roboguice.event.Observes;

@ContextSingleton
public class ContentViewListener {
    @Inject
    protected Activity activity;

    public void optionallySetContentView(@Observes OnCreateEvent ignored) {
        for (Class cls = this.activity.getClass(); cls != Context.class; cls = cls.getSuperclass()) {
            ContentView annotation = (ContentView) cls.getAnnotation(ContentView.class);
            if (annotation != null) {
                this.activity.setContentView(annotation.value());
                return;
            }
        }
    }
}
