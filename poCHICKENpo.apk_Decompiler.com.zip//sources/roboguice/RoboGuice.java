package roboguice;

import android.app.Application;
import android.content.Context;
import com.google.inject.Guice;
import com.google.inject.Injector;
import com.google.inject.Module;
import com.google.inject.Stage;
import com.google.inject.spi.DefaultElementVisitor;
import com.google.inject.spi.Element;
import com.google.inject.spi.Elements;
import com.google.inject.spi.StaticInjectionRequest;
import java.util.ArrayList;
import java.util.WeakHashMap;
import roboguice.config.DefaultRoboModule;
import roboguice.event.EventManager;
import roboguice.inject.ContextScope;
import roboguice.inject.ContextScopedRoboInjector;
import roboguice.inject.ResourceListener;
import roboguice.inject.RoboInjector;
import roboguice.inject.ViewListener;

public class RoboGuice {
    public static Stage DEFAULT_STAGE = Stage.PRODUCTION;
    protected static WeakHashMap<Application, Injector> injectors = new WeakHashMap<>();
    protected static int modulesResourceId = 0;
    protected static WeakHashMap<Application, ResourceListener> resourceListeners = new WeakHashMap<>();
    protected static WeakHashMap<Application, ViewListener> viewListeners = new WeakHashMap<>();

    private RoboGuice() {
    }

    public static Injector getBaseApplicationInjector(Application application) {
        Injector rtrn = injectors.get(application);
        if (rtrn != null) {
            return rtrn;
        }
        synchronized (RoboGuice.class) {
            Injector rtrn2 = injectors.get(application);
            if (rtrn2 != null) {
                return rtrn2;
            }
            Injector baseApplicationInjector = setBaseApplicationInjector(application, DEFAULT_STAGE);
            return baseApplicationInjector;
        }
    }

    public static Injector setBaseApplicationInjector(final Application application, Stage stage, Module... modules) {
        Injector rtrn;
        for (Element element : Elements.getElements(modules)) {
            element.acceptVisitor(new DefaultElementVisitor<Void>() {
                public Void visit(StaticInjectionRequest element) {
                    RoboGuice.getResourceListener(application).requestStaticInjection(element.getType());
                    return null;
                }
            });
        }
        synchronized (RoboGuice.class) {
            rtrn = Guice.createInjector(stage, modules);
            injectors.put(application, rtrn);
        }
        return rtrn;
    }

    public static void setModulesResourceId(int modulesResourceId2) {
        modulesResourceId = modulesResourceId2;
    }

    public static Injector setBaseApplicationInjector(Application application, Stage stage) {
        String[] moduleNames;
        Injector rtrn;
        synchronized (RoboGuice.class) {
            int id = modulesResourceId;
            if (id == 0) {
                id = application.getResources().getIdentifier("roboguice_modules", "array", application.getPackageName());
            }
            if (id > 0) {
                moduleNames = application.getResources().getStringArray(id);
            } else {
                moduleNames = new String[0];
            }
            ArrayList<Module> modules = new ArrayList<>();
            modules.add(newDefaultRoboModule(application));
            try {
                for (String name : moduleNames) {
                    Class<? extends U> asSubclass = Class.forName(name).asSubclass(Module.class);
                    try {
                        modules.add(asSubclass.getDeclaredConstructor(new Class[]{Context.class}).newInstance(new Object[]{application}));
                    } catch (NoSuchMethodException e) {
                        modules.add(asSubclass.newInstance());
                    }
                }
                rtrn = setBaseApplicationInjector(application, stage, (Module[]) modules.toArray(new Module[modules.size()]));
                injectors.put(application, rtrn);
            } catch (Exception e2) {
                throw new RuntimeException(e2);
            }
        }
        return rtrn;
    }

    public static RoboInjector getInjector(Context context) {
        Application application = (Application) context.getApplicationContext();
        return new ContextScopedRoboInjector(context, getBaseApplicationInjector(application), getViewListener(application));
    }

    public static <T> T injectMembers(Context context, T t) {
        getInjector(context).injectMembers(t);
        return t;
    }

    public static DefaultRoboModule newDefaultRoboModule(Application application) {
        return new DefaultRoboModule(application, new ContextScope(application), getViewListener(application), getResourceListener(application));
    }

    protected static ResourceListener getResourceListener(Application application) {
        ResourceListener resourceListener;
        ResourceListener resourceListener2 = resourceListeners.get(application);
        if (resourceListener2 == null) {
            synchronized (RoboGuice.class) {
                if (resourceListener2 == null) {
                    try {
                        resourceListener = new ResourceListener(application);
                    } catch (Throwable th) {
                        th = th;
                        throw th;
                    }
                    try {
                        resourceListeners.put(application, resourceListener);
                        resourceListener2 = resourceListener;
                    } catch (Throwable th2) {
                        th = th2;
                        ResourceListener resourceListener3 = resourceListener;
                        throw th;
                    }
                }
            }
        }
        return resourceListener2;
    }

    protected static ViewListener getViewListener(Application application) {
        ViewListener viewListener;
        ViewListener viewListener2 = viewListeners.get(application);
        if (viewListener2 == null) {
            synchronized (RoboGuice.class) {
                if (viewListener2 == null) {
                    try {
                        viewListener = new ViewListener();
                    } catch (Throwable th) {
                        th = th;
                        throw th;
                    }
                    try {
                        viewListeners.put(application, viewListener);
                        viewListener2 = viewListener;
                    } catch (Throwable th2) {
                        th = th2;
                        ViewListener viewListener3 = viewListener;
                        throw th;
                    }
                }
            }
        }
        return viewListener2;
    }

    public static void destroyInjector(Context context) {
        ((EventManager) getInjector(context).getInstance(EventManager.class)).destroy();
        injectors.remove(context);
    }

    public static class util {
        private util() {
        }

        public static void reset() {
            RoboGuice.injectors.clear();
            RoboGuice.resourceListeners.clear();
            RoboGuice.viewListeners.clear();
        }
    }
}
