package roboguice.event;

import android.content.Context;
import com.google.inject.Inject;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import roboguice.event.eventListener.ObserverMethodListener;
import roboguice.inject.ContextSingleton;

@ContextSingleton
public class EventManager {
    @Inject
    protected Context context;
    protected Map<Class<?>, Set<EventListener<?>>> registrations = new HashMap();

    public <T> void registerObserver(Class<T> event, EventListener listener) {
        Set<EventListener<?>> observers = this.registrations.get(event);
        if (observers == null) {
            observers = Collections.synchronizedSet(new LinkedHashSet());
            this.registrations.put(event, observers);
        }
        observers.add(listener);
    }

    public <T> void registerObserver(Object instance, Method method, Class<T> event) {
        registerObserver(event, new ObserverMethodListener(instance, method));
    }

    public <T> void unregisterObserver(Class<T> event, EventListener<T> listener) {
        Set<EventListener<?>> observers = this.registrations.get(event);
        if (observers != null) {
            synchronized (observers) {
                Iterator<EventListener<?>> iterator = observers.iterator();
                while (true) {
                    if (iterator.hasNext()) {
                        if (iterator.next() == listener) {
                            iterator.remove();
                            break;
                        }
                    } else {
                        break;
                    }
                }
            }
        }
    }

    public <T> void unregisterObserver(Object instance, Class<T> event) {
        Set<EventListener<?>> observers = this.registrations.get(event);
        if (observers != null) {
            synchronized (observers) {
                Iterator<EventListener<?>> iterator = observers.iterator();
                while (true) {
                    if (!iterator.hasNext()) {
                        break;
                    }
                    EventListener listener = iterator.next();
                    if ((listener instanceof ObserverMethodListener) && ((ObserverMethodListener) listener).getInstance() == instance) {
                        iterator.remove();
                        break;
                    }
                }
            }
        }
    }

    public void fire(Object event) {
        Set<EventListener<?>> observers = this.registrations.get(event.getClass());
        if (observers != null) {
            synchronized (observers) {
                for (EventListener<?> observer : observers) {
                    observer.onEvent(event);
                }
            }
        }
    }

    public void destroy() {
        for (Map.Entry<Class<?>, Set<EventListener<?>>> e : this.registrations.entrySet()) {
            e.getValue().clear();
        }
        this.registrations.clear();
    }
}
