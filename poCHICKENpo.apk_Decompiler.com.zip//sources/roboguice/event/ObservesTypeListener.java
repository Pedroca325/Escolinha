package roboguice.event;

import com.google.inject.Provider;
import com.google.inject.spi.InjectionListener;
import com.google.inject.spi.TypeEncounter;
import com.google.inject.spi.TypeListener;
import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import roboguice.event.eventListener.ObserverMethodListener;
import roboguice.event.eventListener.factory.EventListenerThreadingDecorator;

public class ObservesTypeListener implements TypeListener {
    protected Provider<EventManager> eventManagerProvider;
    protected EventListenerThreadingDecorator observerThreadingDecorator;

    public ObservesTypeListener(Provider<EventManager> eventManagerProvider2, EventListenerThreadingDecorator observerThreadingDecorator2) {
        this.eventManagerProvider = eventManagerProvider2;
        this.observerThreadingDecorator = observerThreadingDecorator2;
    }

    /* JADX WARNING: type inference failed for: r11v0, types: [com.google.inject.TypeLiteral<I>, com.google.inject.TypeLiteral] */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public <I> void hear(com.google.inject.TypeLiteral<I> r11, com.google.inject.spi.TypeEncounter<I> r12) {
        /*
            r10 = this;
            java.lang.Class r2 = r11.getRawType()
        L_0x0004:
            java.lang.Class<java.lang.Object> r9 = java.lang.Object.class
            if (r2 == r9) goto L_0x003c
            java.lang.reflect.Method[] r0 = r2.getDeclaredMethods()
            int r6 = r0.length
            r3 = 0
        L_0x000e:
            if (r3 >= r6) goto L_0x0018
            r8 = r0[r3]
            r10.findContextObserver(r8, r12)
            int r3 = r3 + 1
            goto L_0x000e
        L_0x0018:
            java.lang.Class[] r0 = r2.getInterfaces()
            int r6 = r0.length
            r3 = 0
            r4 = r3
        L_0x001f:
            if (r4 >= r6) goto L_0x0037
            r5 = r0[r4]
            java.lang.reflect.Method[] r1 = r5.getDeclaredMethods()
            int r7 = r1.length
            r3 = 0
        L_0x0029:
            if (r3 >= r7) goto L_0x0033
            r8 = r1[r3]
            r10.findContextObserver(r8, r12)
            int r3 = r3 + 1
            goto L_0x0029
        L_0x0033:
            int r3 = r4 + 1
            r4 = r3
            goto L_0x001f
        L_0x0037:
            java.lang.Class r2 = r2.getSuperclass()
            goto L_0x0004
        L_0x003c:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: roboguice.event.ObservesTypeListener.hear(com.google.inject.TypeLiteral, com.google.inject.spi.TypeEncounter):void");
    }

    /* access modifiers changed from: protected */
    public <I> void findContextObserver(Method method, TypeEncounter<I> iTypeEncounter) {
        Annotation[][] parameterAnnotations = method.getParameterAnnotations();
        for (int i = 0; i < parameterAnnotations.length; i++) {
            Annotation[] annotationArray = parameterAnnotations[i];
            Class<?> parameterType = method.getParameterTypes()[i];
            for (Annotation annotation : annotationArray) {
                if (annotation.annotationType().equals(Observes.class)) {
                    registerContextObserver(iTypeEncounter, method, parameterType, ((Observes) annotation).value());
                }
            }
        }
    }

    /* access modifiers changed from: protected */
    public <I, T> void registerContextObserver(TypeEncounter<I> iTypeEncounter, Method method, Class<T> parameterType, EventThread threadType) {
        checkMethodParameters(method);
        iTypeEncounter.register((InjectionListener<? super I>) new ContextObserverMethodInjector(this.eventManagerProvider, this.observerThreadingDecorator, method, parameterType, threadType));
    }

    /* access modifiers changed from: protected */
    public void checkMethodParameters(Method method) {
        if (method.getParameterTypes().length > 1) {
            throw new RuntimeException("Annotation @Observes must only annotate one parameter, which must be the only parameter in the listener method.");
        }
    }

    public static class ContextObserverMethodInjector<I, T> implements InjectionListener<I> {
        protected Class<T> event;
        protected Provider<EventManager> eventManagerProvider;
        protected Method method;
        protected EventListenerThreadingDecorator observerThreadingDecorator;
        protected EventThread threadType;

        public ContextObserverMethodInjector(Provider<EventManager> eventManagerProvider2, EventListenerThreadingDecorator observerThreadingDecorator2, Method method2, Class<T> event2, EventThread threadType2) {
            this.observerThreadingDecorator = observerThreadingDecorator2;
            this.eventManagerProvider = eventManagerProvider2;
            this.method = method2;
            this.event = event2;
            this.threadType = threadType2;
        }

        public void afterInjection(I i) {
            this.eventManagerProvider.get().registerObserver(this.event, this.observerThreadingDecorator.decorate(this.threadType, new ObserverMethodListener(i, this.method)));
        }
    }
}
