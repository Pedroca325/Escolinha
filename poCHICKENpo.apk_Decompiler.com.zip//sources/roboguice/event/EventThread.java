package roboguice.event;

public enum EventThread {
    CURRENT,
    UI,
    BACKGROUND
}
