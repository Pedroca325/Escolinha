package roboguice.test.shadow;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.shadows.ShadowActivity;
import java.io.FileDescriptor;
import java.io.PrintWriter;

@Implements(FragmentActivity.class)
public class ShadowFragmentActivity extends ShadowActivity {
    @Implementation
    public FragmentManager getSupportFragmentManager() {
        return new FragmentManager() {
            public void addOnBackStackChangedListener(FragmentManager.OnBackStackChangedListener onBackStackChangedListener) {
            }

            public FragmentTransaction beginTransaction() {
                return new FragmentTransaction() {
                    public FragmentTransaction add(Fragment fragment, String s) {
                        return null;
                    }

                    public FragmentTransaction add(int i, Fragment fragment) {
                        return null;
                    }

                    public FragmentTransaction add(int i, Fragment fragment, String s) {
                        return null;
                    }

                    public FragmentTransaction replace(int i, Fragment fragment) {
                        return null;
                    }

                    public FragmentTransaction replace(int i, Fragment fragment, String s) {
                        return null;
                    }

                    public FragmentTransaction remove(Fragment fragment) {
                        return null;
                    }

                    public FragmentTransaction hide(Fragment fragment) {
                        return null;
                    }

                    public FragmentTransaction show(Fragment fragment) {
                        return null;
                    }

                    public FragmentTransaction detach(Fragment fragment) {
                        return null;
                    }

                    public FragmentTransaction attach(Fragment fragment) {
                        return null;
                    }

                    public boolean isEmpty() {
                        return false;
                    }

                    public FragmentTransaction setCustomAnimations(int i, int i1) {
                        return null;
                    }

                    public FragmentTransaction setTransition(int i) {
                        return null;
                    }

                    public FragmentTransaction setTransitionStyle(int i) {
                        return null;
                    }

                    public FragmentTransaction addToBackStack(String s) {
                        return null;
                    }

                    public boolean isAddToBackStackAllowed() {
                        return false;
                    }

                    public FragmentTransaction disallowAddToBackStack() {
                        return null;
                    }

                    public FragmentTransaction setBreadCrumbTitle(int i) {
                        return null;
                    }

                    public FragmentTransaction setBreadCrumbTitle(CharSequence charSequence) {
                        return null;
                    }

                    public FragmentTransaction setBreadCrumbShortTitle(int i) {
                        return null;
                    }

                    public FragmentTransaction setBreadCrumbShortTitle(CharSequence charSequence) {
                        return null;
                    }

                    public int commit() {
                        return 0;
                    }

                    public int commitAllowingStateLoss() {
                        return 0;
                    }

                    public FragmentTransaction setCustomAnimations(int i, int i1, int i2, int i3) {
                        return this;
                    }
                };
            }

            public boolean executePendingTransactions() {
                return false;
            }

            public Fragment findFragmentById(int i) {
                return null;
            }

            public Fragment findFragmentByTag(String s) {
                return null;
            }

            public void popBackStack() {
            }

            public boolean popBackStackImmediate() {
                return false;
            }

            public void popBackStack(String s, int i) {
            }

            public boolean popBackStackImmediate(String s, int i) {
                return false;
            }

            public void popBackStack(int i, int i1) {
            }

            public boolean popBackStackImmediate(int i, int i1) {
                return false;
            }

            public int getBackStackEntryCount() {
                return 0;
            }

            public FragmentManager.BackStackEntry getBackStackEntryAt(int i) {
                return null;
            }

            public void removeOnBackStackChangedListener(FragmentManager.OnBackStackChangedListener onBackStackChangedListener) {
            }

            public void putFragment(Bundle bundle, String s, Fragment fragment) {
            }

            public Fragment getFragment(Bundle bundle, String s) {
                return null;
            }

            public Fragment.SavedState saveFragmentInstanceState(Fragment fragment) {
                return null;
            }

            public void dump(String s, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strings) {
            }
        };
    }
}
