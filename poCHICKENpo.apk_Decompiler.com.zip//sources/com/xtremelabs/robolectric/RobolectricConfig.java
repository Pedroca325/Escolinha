package com.xtremelabs.robolectric;

import android.app.Application;
import com.xtremelabs.robolectric.internal.ClassNameResolver;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class RobolectricConfig {
    private final File androidManifestFile;
    private int applicationFlags;
    private String applicationName;
    private final File assetsDirectory;
    private boolean manifestIsParsed;
    private int minSdkVersion;
    private boolean minSdkVersionSpecified;
    private String packageName;
    private String processName;
    private String rClassName;
    private final List<ReceiverAndIntentFilter> receivers;
    private final File resourceDirectory;
    private int sdkVersion;
    private boolean sdkVersionSpecified;
    private boolean strictI18n;

    public RobolectricConfig(File baseDir) {
        this(new File(baseDir, "AndroidManifest.xml"), new File(baseDir, "res"), new File(baseDir, "assets"));
    }

    public RobolectricConfig(File androidManifestFile2, File resourceDirectory2) {
        this(androidManifestFile2, resourceDirectory2, new File(resourceDirectory2.getParent(), "assets"));
    }

    public RobolectricConfig(File androidManifestFile2, File resourceDirectory2, File assetsDirectory2) {
        this.manifestIsParsed = false;
        this.sdkVersionSpecified = true;
        this.minSdkVersionSpecified = true;
        this.receivers = new ArrayList();
        this.strictI18n = false;
        this.androidManifestFile = androidManifestFile2;
        this.resourceDirectory = resourceDirectory2;
        this.assetsDirectory = assetsDirectory2;
    }

    public String getRClassName() throws Exception {
        parseAndroidManifest();
        return this.rClassName;
    }

    public void validate() throws FileNotFoundException {
        if (!this.androidManifestFile.exists() || !this.androidManifestFile.isFile()) {
            throw new FileNotFoundException(this.androidManifestFile.getAbsolutePath() + " not found or not a file; it should point to your project's AndroidManifest.xml");
        } else if (!getResourceDirectory().exists() || !getResourceDirectory().isDirectory()) {
            throw new FileNotFoundException(getResourceDirectory().getAbsolutePath() + " not found or not a directory; it should point to your project's res directory");
        }
    }

    private void parseAndroidManifest() {
        if (!this.manifestIsParsed) {
            try {
                Document manifestDocument = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(this.androidManifestFile);
                this.packageName = getTagAttributeText(manifestDocument, "manifest", "package");
                this.rClassName = this.packageName + ".R";
                this.applicationName = getTagAttributeText(manifestDocument, "application", "android:name");
                Integer minSdkVer = getTagAttributeIntValue(manifestDocument, "uses-sdk", "android:minSdkVersion");
                Integer sdkVer = getTagAttributeIntValue(manifestDocument, "uses-sdk", "android:targetSdkVersion");
                if (minSdkVer == null) {
                    this.minSdkVersion = 10;
                    this.minSdkVersionSpecified = false;
                } else {
                    this.minSdkVersion = minSdkVer.intValue();
                }
                if (sdkVer == null) {
                    this.sdkVersion = 10;
                    this.sdkVersionSpecified = false;
                } else {
                    this.sdkVersion = sdkVer.intValue();
                }
                this.processName = getTagAttributeText(manifestDocument, "application", "android:process");
                if (this.processName == null) {
                    this.processName = this.packageName;
                }
                parseApplicationFlags(manifestDocument);
                parseReceivers(manifestDocument, this.packageName);
            } catch (Exception e) {
            }
            this.manifestIsParsed = true;
        }
    }

    private void parseReceivers(Document manifestDocument, String packageName2) {
        Node application = manifestDocument.getElementsByTagName("application").item(0);
        if (application != null) {
            for (Node receiverNode : getChildrenTags(application, "receiver")) {
                Node namedItem = receiverNode.getAttributes().getNamedItem("android:name");
                if (namedItem != null) {
                    String receiverName = namedItem.getTextContent();
                    if (receiverName.startsWith(".")) {
                        receiverName = packageName2 + receiverName;
                    }
                    for (Node intentFilterNode : getChildrenTags(receiverNode, "intent-filter")) {
                        List<String> actions = new ArrayList<>();
                        for (Node actionNode : getChildrenTags(intentFilterNode, "action")) {
                            Node nameNode = actionNode.getAttributes().getNamedItem("android:name");
                            if (nameNode != null) {
                                actions.add(nameNode.getTextContent());
                            }
                        }
                        this.receivers.add(new ReceiverAndIntentFilter(receiverName, actions));
                    }
                }
            }
        }
    }

    private List<Node> getChildrenTags(Node node, String tagName) {
        List<Node> children = new ArrayList<>();
        for (int i = 0; i < node.getChildNodes().getLength(); i++) {
            Node childNode = node.getChildNodes().item(i);
            if (childNode.getNodeName().equalsIgnoreCase(tagName)) {
                children.add(childNode);
            }
        }
        return children;
    }

    private void parseApplicationFlags(Document manifestDocument) {
        this.applicationFlags = getApplicationFlag(manifestDocument, "android:allowBackup", 32768);
        this.applicationFlags += getApplicationFlag(manifestDocument, "android:allowClearUserData", 64);
        this.applicationFlags += getApplicationFlag(manifestDocument, "android:allowTaskReparenting", 32);
        this.applicationFlags += getApplicationFlag(manifestDocument, "android:debuggable", 2);
        this.applicationFlags += getApplicationFlag(manifestDocument, "android:hasCode", 4);
        this.applicationFlags += getApplicationFlag(manifestDocument, "android:killAfterRestore", 65536);
        this.applicationFlags += getApplicationFlag(manifestDocument, "android:persistent", 8);
        this.applicationFlags += getApplicationFlag(manifestDocument, "android:resizeable", 4096);
        this.applicationFlags += getApplicationFlag(manifestDocument, "android:restoreAnyVersion", 131072);
        this.applicationFlags += getApplicationFlag(manifestDocument, "android:largeScreens", 2048);
        this.applicationFlags += getApplicationFlag(manifestDocument, "android:normalScreens", 1024);
        this.applicationFlags += getApplicationFlag(manifestDocument, "android:anyDensity", 8192);
        this.applicationFlags += getApplicationFlag(manifestDocument, "android:smallScreens", 512);
        this.applicationFlags += getApplicationFlag(manifestDocument, "android:testOnly", 256);
        this.applicationFlags += getApplicationFlag(manifestDocument, "android:vmSafeMode", 16384);
    }

    private int getApplicationFlag(Document doc, String attribute, int attributeValue) {
        if ("true".equalsIgnoreCase(getTagAttributeText(doc, "application", attribute))) {
            return attributeValue;
        }
        return 0;
    }

    private Integer getTagAttributeIntValue(Document doc, String tag, String attribute) {
        return getTagAttributeIntValue(doc, tag, attribute, (Integer) null);
    }

    private Integer getTagAttributeIntValue(Document doc, String tag, String attribute, Integer defaultValue) {
        String valueString = getTagAttributeText(doc, tag, attribute);
        if (valueString != null) {
            return Integer.valueOf(Integer.parseInt(valueString));
        }
        return defaultValue;
    }

    public String getApplicationName() {
        parseAndroidManifest();
        return this.applicationName;
    }

    public String getPackageName() {
        parseAndroidManifest();
        return this.packageName;
    }

    public int getMinSdkVersion() {
        parseAndroidManifest();
        return this.minSdkVersion;
    }

    public int getSdkVersion() {
        parseAndroidManifest();
        return this.sdkVersion;
    }

    public int getApplicationFlags() {
        parseAndroidManifest();
        return this.applicationFlags;
    }

    public String getProcessName() {
        parseAndroidManifest();
        return this.processName;
    }

    public File getResourceDirectory() {
        return this.resourceDirectory;
    }

    public File getAssetsDirectory() {
        return this.assetsDirectory;
    }

    public int getReceiverCount() {
        parseAndroidManifest();
        return this.receivers.size();
    }

    public String getReceiverClassName(int receiverIndex) {
        parseAndroidManifest();
        return this.receivers.get(receiverIndex).getBroadcastReceiverClassName();
    }

    public List<String> getReceiverIntentFilterActions(int receiverIndex) {
        parseAndroidManifest();
        return this.receivers.get(receiverIndex).getIntentFilterActions();
    }

    public boolean getStrictI18n() {
        return this.strictI18n;
    }

    public void setStrictI18n(boolean strict) {
        this.strictI18n = strict;
    }

    private static String getTagAttributeText(Document doc, String tag, String attribute) {
        NodeList elementsByTagName = doc.getElementsByTagName(tag);
        for (int i = 0; i < elementsByTagName.getLength(); i++) {
            Node namedItem = elementsByTagName.item(i).getAttributes().getNamedItem(attribute);
            if (namedItem != null) {
                return namedItem.getTextContent();
            }
        }
        return null;
    }

    private static Application newApplicationInstance(String packageName2, String applicationName2) {
        try {
            return (Application) new ClassNameResolver(packageName2, applicationName2).resolve().newInstance();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        RobolectricConfig that = (RobolectricConfig) o;
        if (this.androidManifestFile == null ? that.androidManifestFile != null : !this.androidManifestFile.equals(that.androidManifestFile)) {
            return false;
        }
        if (getAssetsDirectory() == null ? that.getAssetsDirectory() != null : !getAssetsDirectory().equals(that.getAssetsDirectory())) {
            return false;
        }
        if (getResourceDirectory() != null) {
            if (getResourceDirectory().equals(that.getResourceDirectory())) {
                return true;
            }
        } else if (that.getResourceDirectory() == null) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        int result;
        int i;
        int i2 = 0;
        if (this.androidManifestFile != null) {
            result = this.androidManifestFile.hashCode();
        } else {
            result = 0;
        }
        int i3 = result * 31;
        if (getResourceDirectory() != null) {
            i = getResourceDirectory().hashCode();
        } else {
            i = 0;
        }
        int i4 = (i3 + i) * 31;
        if (getAssetsDirectory() != null) {
            i2 = getAssetsDirectory().hashCode();
        }
        return i4 + i2;
    }

    public int getRealSdkVersion() {
        parseAndroidManifest();
        if (this.sdkVersionSpecified) {
            return this.sdkVersion;
        }
        if (this.minSdkVersionSpecified) {
            return this.minSdkVersion;
        }
        return this.sdkVersion;
    }

    private static class ReceiverAndIntentFilter {
        private final String broadcastReceiverClassName;
        private final List<String> intentFilterActions;

        public ReceiverAndIntentFilter(String broadcastReceiverClassName2, List<String> intentFilterActions2) {
            this.broadcastReceiverClassName = broadcastReceiverClassName2;
            this.intentFilterActions = intentFilterActions2;
        }

        public String getBroadcastReceiverClassName() {
            return this.broadcastReceiverClassName;
        }

        public List<String> getIntentFilterActions() {
            return this.intentFilterActions;
        }
    }
}
