package com.xtremelabs.robolectric;

import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import com.xtremelabs.robolectric.internal.ClassNameResolver;
import com.xtremelabs.robolectric.res.RobolectricPackageManager;
import com.xtremelabs.robolectric.shadows.ShadowApplication;
import org.w3c.dom.Document;

public class ApplicationResolver {
    RobolectricConfig config;

    public ApplicationResolver(RobolectricConfig config2) {
        this.config = config2;
    }

    public Application resolveApplication() {
        Application application;
        String applicationName = this.config.getApplicationName();
        String packageName = this.config.getPackageName();
        if (applicationName != null) {
            application = newApplicationInstance(packageName, applicationName);
        } else {
            application = new Application();
        }
        ShadowApplication shadowApplication = Robolectric.shadowOf(application);
        shadowApplication.setPackageName(packageName);
        shadowApplication.setPackageManager(new RobolectricPackageManager(application, this.config));
        registerBroadcastReceivers(shadowApplication);
        return application;
    }

    private void registerBroadcastReceivers(ShadowApplication shadowApplication) {
        for (int i = 0; i < this.config.getReceiverCount(); i++) {
            IntentFilter filter = new IntentFilter();
            for (String action : this.config.getReceiverIntentFilterActions(i)) {
                filter.addAction(action);
            }
            shadowApplication.registerReceiver((BroadcastReceiver) Robolectric.newInstanceOf(replaceLastDotWith$IfInnerStaticClass(this.config.getReceiverClassName(i))), filter);
        }
    }

    private String replaceLastDotWith$IfInnerStaticClass(String receiverClassName) {
        String[] splits = receiverClassName.split("\\.");
        if (!splits[splits.length - 1].matches("[A-Z][a-zA-Z]*") || !splits[splits.length - 2].matches("[A-Z][a-zA-Z]*")) {
            return receiverClassName;
        }
        int lastDotIndex = receiverClassName.lastIndexOf(".");
        StringBuffer buffer = new StringBuffer(receiverClassName);
        buffer.setCharAt(lastDotIndex, '$');
        return buffer.toString();
    }

    private String getTagAttributeText(Document doc, String tag, String attribute) {
        return doc.getElementsByTagName(tag).item(0).getAttributes().getNamedItem(attribute).getTextContent();
    }

    private Application newApplicationInstance(String packageName, String applicationName) {
        try {
            return (Application) new ClassNameResolver(packageName, applicationName).resolve().newInstance();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
