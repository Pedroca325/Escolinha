package com.xtremelabs.robolectric.res;

import org.w3c.dom.Node;

public class BoolResourceLoader extends XTagXmlResourceLoader implements ResourceValueConverter {
    private static final String BOOL = "bool";
    private final ResourceReferenceResolver<Boolean> boolResolver = new ResourceReferenceResolver<>(BOOL);

    public BoolResourceLoader(ResourceExtractor resourceExtractor) {
        super(resourceExtractor, BOOL);
    }

    public boolean getValue(int resourceId) {
        String resourceIdDebugString = String.valueOf(String.valueOf(resourceId)) + " (" + "0x" + Integer.toHexString(resourceId) + ")";
        String resourceName = this.resourceExtractor.getResourceName(resourceId);
        if (resourceName == null) {
            throw new IllegalArgumentException("No such resource: " + resourceId);
        }
        Boolean value = this.boolResolver.getValue(resourceName);
        if (value != null) {
            return value.booleanValue();
        }
        throw new IllegalArgumentException("Got resource name " + resourceName + " from id " + resourceIdDebugString + ", but found no resource by that name");
    }

    public boolean getValue(String resourceName, boolean isSystem) {
        Integer resourceId = this.resourceExtractor.getResourceId(resourceName, isSystem);
        if (resourceName != null) {
            return getValue(resourceId.intValue());
        }
        throw new IllegalArgumentException("No such resource (" + isSystem + "): " + resourceName);
    }

    public Object convertRawValue(String rawValue) {
        String rawValue2 = rawValue.toLowerCase();
        if ("true".equals(rawValue2)) {
            return true;
        }
        if ("false".equals(rawValue2)) {
            return false;
        }
        if (Integer.parseInt(rawValue2) == 0) {
            return false;
        }
        return true;
    }

    /* access modifiers changed from: protected */
    public void processNode(Node node, String name, boolean isSystem) {
        this.boolResolver.processResource(name, node.getTextContent(), this, isSystem);
    }
}
