package com.xtremelabs.robolectric.res;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class PluralResourceLoader extends XpathResourceXmlLoader implements ResourceValueConverter {
    Map<String, PluralRules> plurals = new HashMap();
    private StringResourceLoader stringResourceLoader;

    public PluralResourceLoader(ResourceExtractor resourceExtractor, StringResourceLoader stringResourceLoader2) {
        super(resourceExtractor, "/resources/plurals");
        this.stringResourceLoader = stringResourceLoader2;
    }

    public String getValue(int resourceId, int quantity) {
        Plural p;
        PluralRules rules = this.plurals.get(this.resourceExtractor.getResourceName(resourceId));
        if (rules == null || (p = rules.find(quantity)) == null) {
            return null;
        }
        return p.string;
    }

    /* access modifiers changed from: protected */
    public void processNode(Node node, String name, boolean isSystem) throws XPathExpressionException {
        NodeList childNodes = (NodeList) XPathFactory.newInstance().newXPath().compile("item").evaluate(node, XPathConstants.NODESET);
        PluralRules rules = new PluralRules();
        for (int j = 0; j < childNodes.getLength(); j++) {
            Node childNode = childNodes.item(j);
            String value = childNode.getTextContent();
            String quantity = childNode.getAttributes().getNamedItem("quantity").getTextContent();
            if (value.startsWith("@")) {
                rules.add(new Plural(quantity, this.stringResourceLoader.getValue(value.substring(1), isSystem)));
            } else {
                rules.add(new Plural(quantity, value));
            }
        }
        this.plurals.put("plurals/" + name, rules);
    }

    public Object convertRawValue(String rawValue) {
        return rawValue;
    }

    static class PluralRules {
        List<Plural> plurals = new ArrayList();

        PluralRules() {
        }

        /* access modifiers changed from: package-private */
        public Plural find(int quantity) {
            for (Plural p : this.plurals) {
                if (p.num == quantity) {
                    return p;
                }
            }
            for (Plural p2 : this.plurals) {
                if (p2.num == -1) {
                    return p2;
                }
            }
            return null;
        }

        /* access modifiers changed from: package-private */
        public void add(Plural p) {
            this.plurals.add(p);
        }
    }

    static class Plural {
        final int num;
        final String quantity;
        final String string;

        Plural(String quantity2, String string2) {
            this.quantity = quantity2;
            this.string = string2;
            if ("zero".equals(quantity2)) {
                this.num = 0;
            } else if ("one".equals(quantity2)) {
                this.num = 1;
            } else if ("two".equals(quantity2)) {
                this.num = 2;
            } else if ("other".equals(quantity2)) {
                this.num = -1;
            } else {
                this.num = -1;
            }
        }
    }
}
