package com.xtremelabs.robolectric.res;

public interface ResourceValueConverter {
    Object convertRawValue(String str);
}
