package com.xtremelabs.robolectric.res;

import java.io.File;
import org.w3c.dom.Document;

public abstract class XmlLoader {
    protected ResourceExtractor resourceExtractor;
    protected boolean strictI18n = false;

    /* access modifiers changed from: protected */
    public abstract void processResourceXml(File file, Document document, boolean z) throws Exception;

    public XmlLoader(ResourceExtractor resourceExtractor2) {
        this.resourceExtractor = resourceExtractor2;
    }

    public void setStrictI18n(boolean strict) {
        this.strictI18n = strict;
    }
}
