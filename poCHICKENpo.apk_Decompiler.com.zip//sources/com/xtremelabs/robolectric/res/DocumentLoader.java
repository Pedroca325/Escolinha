package com.xtremelabs.robolectric.res;

import java.io.File;
import java.io.FileFilter;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;

public class DocumentLoader {
    private final DocumentBuilderFactory documentBuilderFactory;
    private FileFilter xmlFileFilter = new FileFilter() {
        public boolean accept(File file) {
            return file.getName().endsWith(".xml");
        }
    };
    private final XmlLoader[] xmlLoaders;

    public DocumentLoader(XmlLoader... xmlLoaders2) {
        this.xmlLoaders = xmlLoaders2;
        this.documentBuilderFactory = DocumentBuilderFactory.newInstance();
        this.documentBuilderFactory.setNamespaceAware(true);
        this.documentBuilderFactory.setIgnoringComments(true);
        this.documentBuilderFactory.setIgnoringElementContentWhitespace(true);
    }

    public void loadResourceXmlDirs(File... resourceXmlDirs) throws Exception {
        loadResourceXmlDirs(false, resourceXmlDirs);
    }

    public void loadResourceXmlDirs(boolean isSystem, File... resourceXmlDirs) throws Exception {
        for (File resourceXmlDir : resourceXmlDirs) {
            loadResourceXmlDir(resourceXmlDir, isSystem);
        }
    }

    public void loadResourceXmlDir(File resourceXmlDir) throws Exception {
        loadResourceXmlDir(resourceXmlDir, false);
    }

    public void loadSystemResourceXmlDir(File resourceXmlDir) throws Exception {
        loadResourceXmlDir(resourceXmlDir, true);
    }

    private void loadResourceXmlDir(File resourceXmlDir, boolean isSystem) throws Exception {
        if (!resourceXmlDir.exists()) {
            throw new RuntimeException("no such directory " + resourceXmlDir);
        }
        for (File file : resourceXmlDir.listFiles(this.xmlFileFilter)) {
            loadResourceXmlFile(file, isSystem);
        }
    }

    private void loadResourceXmlFile(File file, boolean isSystem) throws Exception {
        for (XmlLoader xmlLoader : this.xmlLoaders) {
            xmlLoader.processResourceXml(file, parse(file), isSystem);
        }
    }

    private Document parse(File xmlFile) throws Exception {
        return this.documentBuilderFactory.newDocumentBuilder().parse(xmlFile);
    }
}
