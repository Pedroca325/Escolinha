package com.xtremelabs.robolectric.res;

import android.content.res.XmlResourceParser;
import br.com.tectoy.pochickenpo.core.Constants;
import com.xtremelabs.robolectric.shadows.ShadowMediaRecorder;
import com.xtremelabs.robolectric.shadows.ShadowVideoView;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.xmlpull.v1.XmlPullParserException;

public class XmlFileLoader extends XmlLoader {
    public static final String[] AVAILABLE_FEATURES = {"http://xmlpull.org/v1/doc/features.html#process-namespaces", "http://xmlpull.org/v1/doc/features.html#report-namespace-prefixes"};
    public static final String[] UNAVAILABLE_FEATURES = {"http://xmlpull.org/v1/doc/features.html#process-docdecl", "http://xmlpull.org/v1/doc/features.html#validation"};
    private Map<String, Document> mXmlDocuments = new HashMap();

    public static boolean isAndroidSupportedFeature(String name) {
        if (name == null) {
            return false;
        }
        for (String feature : AVAILABLE_FEATURES) {
            if (feature.equals(name)) {
                return true;
            }
        }
        return false;
    }

    public XmlFileLoader(ResourceExtractor resourceExtractor) {
        super(resourceExtractor);
    }

    /* access modifiers changed from: protected */
    public void processResourceXml(File xmlFile, Document document, boolean isSystem) throws Exception {
        this.mXmlDocuments.put("xml/" + xmlFile.getName().replace(".xml", ""), document);
    }

    public XmlResourceParser getXml(int resourceId) {
        return getXml(this.resourceExtractor.getResourceName(resourceId));
    }

    public XmlResourceParser getXml(String key) {
        Document document = this.mXmlDocuments.get(key);
        if (document == null) {
            return null;
        }
        return new XmlResourceParserImpl(document);
    }

    final class XmlResourceParserImpl implements XmlResourceParser {
        private Node currentNode;
        private final Document document;
        private boolean mDecNextDepth = false;
        private int mDepth = 0;
        private int mEventType = 0;
        private boolean mStarted = false;

        XmlResourceParserImpl(Document document2) {
            this.document = document2;
        }

        public void setFeature(String name, boolean state) throws XmlPullParserException {
            if (!XmlFileLoader.isAndroidSupportedFeature(name) || !state) {
                throw new XmlPullParserException("Unsupported feature: " + name);
            }
        }

        public boolean getFeature(String name) {
            return XmlFileLoader.isAndroidSupportedFeature(name);
        }

        public void setProperty(String name, Object value) throws XmlPullParserException {
            throw new XmlPullParserException("setProperty() not supported");
        }

        public Object getProperty(String name) {
            return null;
        }

        public void setInput(Reader in) throws XmlPullParserException {
            throw new XmlPullParserException("setInput() not supported");
        }

        public void setInput(InputStream inputStream, String inputEncoding) throws XmlPullParserException {
            throw new XmlPullParserException("setInput() not supported");
        }

        public void defineEntityReplacementText(String entityName, String replacementText) throws XmlPullParserException {
            throw new XmlPullParserException("defineEntityReplacementText() not supported");
        }

        public String getNamespacePrefix(int pos) throws XmlPullParserException {
            throw new XmlPullParserException("getNamespacePrefix() not supported");
        }

        public String getInputEncoding() {
            return null;
        }

        public String getNamespace(String prefix) {
            throw new RuntimeException("getNamespaceCount() not supported");
        }

        public int getNamespaceCount(int depth) throws XmlPullParserException {
            throw new XmlPullParserException("getNamespaceCount() not supported");
        }

        public String getPositionDescription() {
            return "Binary XML file line #" + getLineNumber();
        }

        public String getNamespaceUri(int pos) throws XmlPullParserException {
            throw new XmlPullParserException("getNamespaceUri() not supported");
        }

        public int getColumnNumber() {
            return -1;
        }

        public int getDepth() {
            return this.mDepth;
        }

        public String getText() {
            if (this.currentNode == null) {
                return "";
            }
            return this.currentNode.getTextContent();
        }

        public int getLineNumber() {
            return -1;
        }

        public int getEventType() throws XmlPullParserException {
            return this.mEventType;
        }

        /* access modifiers changed from: package-private */
        public boolean isWhitespace(String text) throws XmlPullParserException {
            if (text != null && text.split("\\s").length == 0) {
                return true;
            }
            return false;
        }

        public boolean isWhitespace() throws XmlPullParserException {
            return isWhitespace(getText());
        }

        public String getPrefix() {
            throw new RuntimeException("getPrefix not supported");
        }

        public char[] getTextCharacters(int[] holderForStartAndLength) {
            String txt = getText();
            char[] chars = null;
            if (txt == null) {
                return chars;
            }
            holderForStartAndLength[0] = 0;
            holderForStartAndLength[1] = txt.length();
            char[] chars2 = new char[txt.length()];
            txt.getChars(0, txt.length(), chars2, 0);
            return chars2;
        }

        public String getNamespace() {
            String namespace;
            if (this.currentNode == null || (namespace = this.currentNode.getNamespaceURI()) == null) {
                return "";
            }
            return namespace;
        }

        public String getName() {
            if (this.currentNode == null) {
                return "";
            }
            return this.currentNode.getNodeName();
        }

        /* access modifiers changed from: package-private */
        public Node getAttributeAt(int index) {
            if (this.currentNode == null) {
                throw new IndexOutOfBoundsException(String.valueOf(index));
            }
            NamedNodeMap map = this.currentNode.getAttributes();
            if (index < map.getLength()) {
                return map.item(index);
            }
            throw new IndexOutOfBoundsException(String.valueOf(index));
        }

        /* access modifiers changed from: package-private */
        public Node getAttribute(String namespace, String name) {
            if (this.currentNode == null) {
                return null;
            }
            return this.currentNode.getAttributes().getNamedItem(name);
        }

        public String getAttributeNamespace(int index) {
            Node attr = getAttributeAt(index);
            if (attr == null) {
                return null;
            }
            return attr.getNamespaceURI();
        }

        public String getAttributeName(int index) {
            try {
                return getAttributeAt(index).getNodeName();
            } catch (IndexOutOfBoundsException e) {
                return null;
            }
        }

        public String getAttributePrefix(int index) {
            throw new RuntimeException("getAttributePrefix not supported");
        }

        public boolean isEmptyElementTag() throws XmlPullParserException {
            return false;
        }

        public int getAttributeCount() {
            if (this.currentNode == null) {
                return -1;
            }
            return this.currentNode.getAttributes().getLength();
        }

        public String getAttributeValue(int index) {
            return getAttributeAt(index).getNodeValue();
        }

        public String getAttributeType(int index) {
            return "CDATA";
        }

        public boolean isAttributeDefault(int index) {
            return false;
        }

        public int nextToken() throws XmlPullParserException, IOException {
            return next();
        }

        public String getAttributeValue(String namespace, String name) {
            Node attr = getAttribute(namespace, name);
            if (attr == null) {
                return null;
            }
            return attr.getNodeValue();
        }

        public int next() throws XmlPullParserException, IOException {
            if (!this.mStarted) {
                this.mStarted = true;
                return 0;
            } else if (this.mEventType == 1) {
                return 1;
            } else {
                int ev = nativeNext();
                if (this.mDecNextDepth) {
                    this.mDepth--;
                    this.mDecNextDepth = false;
                }
                switch (ev) {
                    case 2:
                        this.mDepth++;
                        break;
                    case 3:
                        this.mDecNextDepth = true;
                        break;
                }
                this.mEventType = ev;
                if (ev != 1) {
                    return ev;
                }
                close();
                return ev;
            }
        }

        private int nativeNext() throws XmlPullParserException {
            switch (this.mEventType) {
                case ShadowVideoView.STOP /*0*/:
                    this.currentNode = this.document.getDocumentElement();
                    return 2;
                case 1:
                    throw new IllegalArgumentException("END_DOCUMENT should not be found here.");
                case 2:
                    if (this.currentNode.hasChildNodes()) {
                        return processNextNodeType(this.currentNode.getFirstChild());
                    }
                    return 3;
                case 3:
                    return navigateToNextNode(this.currentNode);
                case 4:
                    return navigateToNextNode(this.currentNode);
                case ShadowMediaRecorder.STATE_RECORDING /*5*/:
                    throw new IllegalArgumentException("CDSECT is not handled by Android");
                case ShadowMediaRecorder.STATE_RELEASED /*6*/:
                    throw new IllegalArgumentException("ENTITY_REF is not handled by Android");
                case 7:
                    throw new IllegalArgumentException("IGNORABLE_WHITESPACE");
                case Constants.CLICK_MIN_CANTO:
                    throw new IllegalArgumentException("PROCESSING_INSTRUCTION");
                case 9:
                    throw new IllegalArgumentException("COMMENT is not handled by Android");
                case 10:
                    throw new IllegalArgumentException("DOCDECL is not handled by Android");
                default:
                    throw new RuntimeException("Roboletric-> Uknown XML event type: " + this.mEventType);
            }
        }

        /* access modifiers changed from: package-private */
        public int processNextNodeType(Node node) throws XmlPullParserException {
            switch (node.getNodeType()) {
                case 1:
                    this.currentNode = node;
                    return 2;
                case 2:
                    throw new IllegalArgumentException("ATTRIBUTE_NODE");
                case 3:
                    if (isWhitespace(node.getNodeValue())) {
                        return navigateToNextNode(node);
                    }
                    this.currentNode = node;
                    return 4;
                case 4:
                    return navigateToNextNode(node);
                case ShadowMediaRecorder.STATE_RECORDING /*5*/:
                    throw new IllegalArgumentException("ENTITY_REFERENCE_NODE");
                case ShadowMediaRecorder.STATE_RELEASED /*6*/:
                    throw new IllegalArgumentException("ENTITY_NODE");
                case 7:
                    throw new IllegalArgumentException("DOCUMENT_TYPE_NODE");
                case Constants.CLICK_MIN_CANTO:
                    return navigateToNextNode(node);
                case 9:
                    throw new IllegalArgumentException("DOCUMENT_NODE");
                case 10:
                    throw new IllegalArgumentException("DOCUMENT_TYPE_NODE");
                case 11:
                    throw new IllegalArgumentException("DOCUMENT_FRAGMENT_NODE");
                case 12:
                    throw new IllegalArgumentException("DOCUMENT_TYPE_NODE");
                default:
                    throw new RuntimeException("Roboletric -> Unknown node type: " + node.getNodeType() + ".");
            }
        }

        /* access modifiers changed from: package-private */
        public int navigateToNextNode(Node node) throws XmlPullParserException {
            Node nextNode = node.getNextSibling();
            if (nextNode != null) {
                return processNextNodeType(nextNode);
            }
            if (this.document.getDocumentElement().equals(node)) {
                this.currentNode = null;
                return 1;
            }
            this.currentNode = node.getParentNode();
            return 3;
        }

        public void require(int type, String namespace, String name) throws XmlPullParserException, IOException {
            if (type != getEventType() || ((namespace != null && !namespace.equals(getNamespace())) || (name != null && !name.equals(getName())))) {
                throw new XmlPullParserException("expected " + TYPES[type] + getPositionDescription());
            }
        }

        public String nextText() throws XmlPullParserException, IOException {
            if (getEventType() != 2) {
                throw new XmlPullParserException(String.valueOf(getPositionDescription()) + ": parser must be on START_TAG to read next text", this, (Throwable) null);
            }
            int eventType = next();
            if (eventType == 4) {
                String text = getText();
                if (next() == 3) {
                    return text;
                }
                throw new XmlPullParserException(String.valueOf(getPositionDescription()) + ": event TEXT it must be immediately followed by END_TAG", this, (Throwable) null);
            } else if (eventType == 3) {
                return "";
            } else {
                throw new XmlPullParserException(String.valueOf(getPositionDescription()) + ": parser must be on START_TAG or TEXT to read text", this, (Throwable) null);
            }
        }

        public int nextTag() throws XmlPullParserException, IOException {
            int eventType = next();
            if (eventType == 4 && isWhitespace()) {
                eventType = next();
            }
            if (eventType == 2 || eventType == 3) {
                return eventType;
            }
            throw new XmlPullParserException("Expected start or end tag. Found: " + eventType, this, (Throwable) null);
        }

        public int getAttributeNameResource(int index) {
            throw new RuntimeException("Not implemented yet");
        }

        public int getAttributeListValue(String namespace, String attribute, String[] options, int defaultValue) {
            Node attr = getAttribute(namespace, attribute);
            if (attr == null) {
                return 0;
            }
            int index = Arrays.asList(options).indexOf(attr.getNodeValue());
            if (index != -1) {
                return index;
            }
            return defaultValue;
        }

        public boolean getAttributeBooleanValue(String namespace, String attribute, boolean defaultValue) {
            Node attr = getAttribute(namespace, attribute);
            return attr == null ? defaultValue : Boolean.parseBoolean(attr.getNodeValue());
        }

        public int getAttributeResourceValue(String namespace, String attribute, int defaultValue) {
            throw new RuntimeException("Not implemented yet");
        }

        public int getAttributeIntValue(String namespace, String attribute, int defaultValue) {
            Node attr = getAttribute(namespace, attribute);
            if (attr == null) {
                return defaultValue;
            }
            try {
                return Integer.parseInt(attr.getNodeValue());
            } catch (NumberFormatException e) {
                return defaultValue;
            }
        }

        public int getAttributeUnsignedIntValue(String namespace, String attribute, int defaultValue) {
            int value = getAttributeIntValue(namespace, attribute, defaultValue);
            return value < 0 ? defaultValue : value;
        }

        public float getAttributeFloatValue(String namespace, String attribute, float defaultValue) {
            Node attr = getAttribute(namespace, attribute);
            if (attr == null) {
                return defaultValue;
            }
            try {
                return Float.parseFloat(attr.getNodeValue());
            } catch (NumberFormatException e) {
                return defaultValue;
            }
        }

        public int getAttributeListValue(int idx, String[] options, int defaultValue) {
            try {
                int index = Arrays.asList(options).indexOf(getAttributeValue(idx));
                return index == -1 ? defaultValue : index;
            } catch (IndexOutOfBoundsException e) {
                return defaultValue;
            }
        }

        public boolean getAttributeBooleanValue(int idx, boolean defaultValue) {
            try {
                return Boolean.parseBoolean(getAttributeValue(idx));
            } catch (IndexOutOfBoundsException e) {
                return defaultValue;
            }
        }

        public int getAttributeResourceValue(int idx, int defaultValue) {
            throw new RuntimeException("Not implemented yet");
        }

        public int getAttributeIntValue(int idx, int defaultValue) {
            try {
                return Integer.parseInt(getAttributeValue(idx));
            } catch (IndexOutOfBoundsException | NumberFormatException e) {
                return defaultValue;
            }
        }

        public int getAttributeUnsignedIntValue(int idx, int defaultValue) {
            int value = getAttributeIntValue(idx, defaultValue);
            return value < 0 ? defaultValue : value;
        }

        public float getAttributeFloatValue(int idx, float defaultValue) {
            try {
                return Float.parseFloat(getAttributeValue(idx));
            } catch (IndexOutOfBoundsException | NumberFormatException e) {
                return defaultValue;
            }
        }

        public String getIdAttribute() {
            Node attr = getAttribute((String) null, "id");
            if (attr == null) {
                return null;
            }
            return attr.getNodeValue();
        }

        public String getClassAttribute() {
            Node attr = getAttribute((String) null, "class");
            if (attr == null) {
                return null;
            }
            return attr.getNodeValue();
        }

        public int getIdAttributeResourceValue(int defaultValue) {
            String id = getIdAttribute();
            if (id == null) {
                return defaultValue;
            }
            try {
                return Integer.parseInt(id);
            } catch (NumberFormatException e) {
                return defaultValue;
            }
        }

        public int getStyleAttribute() {
            Node attr = getAttribute((String) null, "style");
            if (attr == null) {
                return 0;
            }
            try {
                return Integer.parseInt(attr.getNodeValue());
            } catch (NumberFormatException e) {
                return 0;
            }
        }

        public void close() {
        }

        /* access modifiers changed from: protected */
        public void finalize() throws Throwable {
            close();
        }
    }
}
