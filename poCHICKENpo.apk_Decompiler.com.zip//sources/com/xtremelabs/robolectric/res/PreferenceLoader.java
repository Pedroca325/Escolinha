package com.xtremelabs.robolectric.res;

import android.content.Context;
import android.preference.Preference;
import android.preference.PreferenceGroup;
import android.preference.PreferenceScreen;
import android.util.AttributeSet;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.tester.android.util.TestAttributeSet;
import com.xtremelabs.robolectric.util.I18nException;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class PreferenceLoader extends XmlLoader {
    private Map<String, PreferenceNode> prefNodesByResourceName = new HashMap();

    public PreferenceLoader(ResourceExtractor resourceExtractor) {
        super(resourceExtractor);
    }

    /* access modifiers changed from: protected */
    public void processResourceXml(File xmlFile, Document document, boolean isSystem) throws Exception {
        PreferenceNode topLevelNode = new PreferenceNode("top-level", new HashMap());
        processChildren(document.getChildNodes(), topLevelNode);
        this.prefNodesByResourceName.put("xml/" + xmlFile.getName().replace(".xml", ""), topLevelNode.getChildren().get(0));
    }

    private void processChildren(NodeList childNodes, PreferenceNode parent) {
        for (int i = 0; i < childNodes.getLength(); i++) {
            processNode(childNodes.item(i), parent);
        }
    }

    private void processNode(Node node, PreferenceNode parent) {
        String name = node.getNodeName();
        NamedNodeMap attributes = node.getAttributes();
        Map<String, String> attrMap = new HashMap<>();
        if (attributes != null) {
            int length = attributes.getLength();
            for (int i = 0; i < length; i++) {
                Node attr = attributes.item(i);
                attrMap.put(attr.getNodeName(), attr.getNodeValue());
            }
        }
        if (!name.startsWith("#")) {
            PreferenceNode prefNode = new PreferenceNode(name, attrMap);
            if (parent != null) {
                parent.addChild(prefNode);
            }
            processChildren(node.getChildNodes(), prefNode);
        }
    }

    public PreferenceScreen inflatePreferences(Context context, int resourceId) {
        return inflatePreferences(context, this.resourceExtractor.getResourceName(resourceId));
    }

    public PreferenceScreen inflatePreferences(Context context, String key) {
        try {
            return (PreferenceScreen) this.prefNodesByResourceName.get(key).inflate(context, (Preference) null);
        } catch (I18nException e) {
            throw e;
        } catch (Exception e2) {
            throw new RuntimeException("error inflating " + key, e2);
        }
    }

    public class PreferenceNode {
        private final Map<String, String> attributes;
        private List<PreferenceNode> children = new ArrayList();
        private String name;

        public PreferenceNode(String name2, Map<String, String> attributes2) {
            this.name = name2;
            this.attributes = attributes2;
        }

        public List<PreferenceNode> getChildren() {
            return this.children;
        }

        public void addChild(PreferenceNode prefNode) {
            this.children.add(prefNode);
        }

        public Preference inflate(Context context, Preference parent) throws Exception {
            Preference preference = create(context, (PreferenceGroup) parent);
            for (PreferenceNode child : this.children) {
                child.inflate(context, preference);
            }
            return preference;
        }

        private Preference create(Context context, PreferenceGroup parent) throws Exception {
            Preference preference = constructPreference(context, parent);
            if (!(parent == null || parent == preference)) {
                parent.addPreference(preference);
            }
            return preference;
        }

        private Preference constructPreference(Context context, PreferenceGroup parent) throws Exception {
            Class<? extends Preference> clazz = pickViewClass();
            if (clazz.equals(PreferenceScreen.class)) {
                return (Preference) Robolectric.newInstanceOf(PreferenceScreen.class);
            }
            try {
                TestAttributeSet attributeSet = new TestAttributeSet(this.attributes);
                if (PreferenceLoader.this.strictI18n) {
                    attributeSet.validateStrictI18n();
                }
                return (Preference) clazz.getConstructor(new Class[]{Context.class, AttributeSet.class}).newInstance(new Object[]{context, attributeSet});
            } catch (NoSuchMethodException e) {
                try {
                    return (Preference) clazz.getConstructor(new Class[]{Context.class}).newInstance(new Object[]{context});
                } catch (NoSuchMethodException e2) {
                    return (Preference) clazz.getConstructor(new Class[]{Context.class, String.class}).newInstance(new Object[]{context, ""});
                }
            }
        }

        private Class<? extends Preference> pickViewClass() {
            Class<? extends Preference> clazz = loadClass(this.name);
            if (clazz == null) {
                clazz = loadClass("android.preference." + this.name);
            }
            if (clazz != null) {
                return clazz;
            }
            throw new RuntimeException("couldn't find preference class " + this.name);
        }

        private Class<? extends Preference> loadClass(String className) {
            try {
                return getClass().getClassLoader().loadClass(className);
            } catch (ClassNotFoundException e) {
                return null;
            }
        }
    }
}
