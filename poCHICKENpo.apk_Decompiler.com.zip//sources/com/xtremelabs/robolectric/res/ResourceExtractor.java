package com.xtremelabs.robolectric.res;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.HashMap;
import java.util.Map;

public class ResourceExtractor {
    private Map<String, Integer> localResourceStringToId = new HashMap();
    private Map<Integer, String> resourceIdToString = new HashMap();
    private Map<String, Integer> systemResourceStringToId = new HashMap();

    public void addLocalRClass(Class rClass) throws Exception {
        addRClass(rClass, false);
    }

    public void addSystemRClass(Class rClass) throws Exception {
        addRClass(rClass, true);
    }

    private void addRClass(Class rClass, boolean isSystemRClass) throws Exception {
        for (Class innerClass : rClass.getClasses()) {
            for (Field field : innerClass.getDeclaredFields()) {
                if (field.getType().equals(Integer.TYPE) && Modifier.isStatic(field.getModifiers())) {
                    String section = innerClass.getSimpleName();
                    String name = String.valueOf(section) + "/" + field.getName();
                    int value = field.getInt((Object) null);
                    if (isSystemRClass) {
                        name = "android:" + name;
                    }
                    if (section.equals("styleable")) {
                        continue;
                    } else {
                        if (isSystemRClass) {
                            this.systemResourceStringToId.put(name, Integer.valueOf(value));
                        } else {
                            this.localResourceStringToId.put(name, Integer.valueOf(value));
                        }
                        if (this.resourceIdToString.containsKey(Integer.valueOf(value))) {
                            throw new RuntimeException(String.valueOf(value) + " is already defined with name: " + this.resourceIdToString.get(Integer.valueOf(value)) + " can't also call it: " + name);
                        }
                        this.resourceIdToString.put(Integer.valueOf(value), name);
                    }
                }
            }
        }
    }

    public Integer getResourceId(String resourceName) {
        if (resourceName.contains("android:")) {
            return getResourceId(resourceName, true);
        }
        return getResourceId(resourceName, false);
    }

    public Integer getLocalResourceId(String value) {
        return getResourceId(value, false);
    }

    public Integer getResourceId(String resourceName, boolean isSystemResource) {
        if (resourceName == null) {
            return null;
        }
        if (resourceName.equals("@null")) {
            return 0;
        }
        if (resourceName.startsWith("@+id")) {
            resourceName = resourceName.substring(2);
        } else if (resourceName.startsWith("@+android:id")) {
            resourceName = resourceName.substring(2);
        } else if (resourceName.startsWith("@")) {
            resourceName = resourceName.substring(1);
        }
        if (isSystemResource) {
            return this.systemResourceStringToId.get(resourceName);
        }
        return this.localResourceStringToId.get(resourceName);
    }

    public String getResourceName(int resourceId) {
        return this.resourceIdToString.get(Integer.valueOf(resourceId));
    }
}
