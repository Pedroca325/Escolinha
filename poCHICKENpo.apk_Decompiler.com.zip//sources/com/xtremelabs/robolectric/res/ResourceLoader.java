package com.xtremelabs.robolectric.res;

import android.R;
import android.content.Context;
import android.content.res.XmlResourceParser;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.preference.PreferenceScreen;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.res.ViewLoader;
import com.xtremelabs.robolectric.util.I18nException;
import com.xtremelabs.robolectric.util.PropertiesHelper;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.util.HashSet;
import java.util.Properties;
import java.util.Set;

public class ResourceLoader {
    private static final FileFilter DRAWABLE_DIR_FILE_FILTER = new FileFilter() {
        public boolean accept(File file) {
            return ResourceLoader.isDrawableDirectory(file.getPath());
        }
    };
    private static final FileFilter LAYOUT_DIR_FILE_FILTER = new FileFilter() {
        public boolean accept(File file) {
            return ResourceLoader.isLayoutDirectory(file.getPath());
        }
    };
    private static final FileFilter MENU_DIR_FILE_FILTER = new FileFilter() {
        public boolean accept(File file) {
            return ResourceLoader.isMenuDirectory(file.getPath());
        }
    };
    private static File resourceDir;
    private File assetsDir;
    private final AttrResourceLoader attrResourceLoader;
    private final BoolResourceLoader boolResourceLoader;
    private final ColorResourceLoader colorResourceLoader;
    private final DimenResourceLoader dimenResourceLoader;
    private final DrawableResourceLoader drawableResourceLoader;
    private final IntegerResourceLoader integerResourceLoader;
    private boolean isInitialized;
    private MenuLoader menuLoader;
    private final Set<Integer> ninePatchDrawableIds;
    private final PluralResourceLoader pluralResourceLoader;
    private PreferenceLoader preferenceLoader;
    private Class rClass;
    private final RawResourceLoader rawResourceLoader;
    private final ResourceExtractor resourceExtractor;
    private int sdkVersion;
    private boolean strictI18n;
    private final StringArrayResourceLoader stringArrayResourceLoader;
    private final StringResourceLoader stringResourceLoader;
    private ViewLoader viewLoader;
    private XmlFileLoader xmlFileLoader;

    public ResourceLoader(int sdkVersion2, Class rClass2, File resourceDir2, File assetsDir2) throws Exception {
        this.isInitialized = false;
        this.strictI18n = false;
        this.ninePatchDrawableIds = new HashSet();
        this.sdkVersion = sdkVersion2;
        this.assetsDir = assetsDir2;
        this.rClass = rClass2;
        this.resourceExtractor = new ResourceExtractor();
        this.resourceExtractor.addLocalRClass(rClass2);
        this.resourceExtractor.addSystemRClass(R.class);
        this.stringResourceLoader = new StringResourceLoader(this.resourceExtractor);
        this.pluralResourceLoader = new PluralResourceLoader(this.resourceExtractor, this.stringResourceLoader);
        this.stringArrayResourceLoader = new StringArrayResourceLoader(this.resourceExtractor, this.stringResourceLoader);
        this.colorResourceLoader = new ColorResourceLoader(this.resourceExtractor);
        this.attrResourceLoader = new AttrResourceLoader(this.resourceExtractor);
        this.drawableResourceLoader = new DrawableResourceLoader(this.resourceExtractor, resourceDir2);
        this.rawResourceLoader = new RawResourceLoader(this.resourceExtractor, resourceDir2);
        this.dimenResourceLoader = new DimenResourceLoader(this.resourceExtractor);
        this.integerResourceLoader = new IntegerResourceLoader(this.resourceExtractor);
        this.boolResourceLoader = new BoolResourceLoader(this.resourceExtractor);
        resourceDir = resourceDir2;
    }

    public void setStrictI18n(boolean strict) {
        this.strictI18n = strict;
        if (this.viewLoader != null) {
            this.viewLoader.setStrictI18n(strict);
        }
        if (this.menuLoader != null) {
            this.menuLoader.setStrictI18n(strict);
        }
        if (this.preferenceLoader != null) {
            this.preferenceLoader.setStrictI18n(strict);
        }
        if (this.xmlFileLoader != null) {
            this.xmlFileLoader.setStrictI18n(strict);
        }
    }

    public boolean getStrictI18n() {
        return this.strictI18n;
    }

    private void init() {
        if (!this.isInitialized) {
            try {
                if (resourceDir != null) {
                    this.viewLoader = new ViewLoader(this.resourceExtractor, this.attrResourceLoader);
                    this.menuLoader = new MenuLoader(this.resourceExtractor, this.attrResourceLoader);
                    this.preferenceLoader = new PreferenceLoader(this.resourceExtractor);
                    this.xmlFileLoader = new XmlFileLoader(this.resourceExtractor);
                    this.viewLoader.setStrictI18n(this.strictI18n);
                    this.menuLoader.setStrictI18n(this.strictI18n);
                    this.preferenceLoader.setStrictI18n(this.strictI18n);
                    this.xmlFileLoader.setStrictI18n(this.strictI18n);
                    File systemResourceDir = getSystemResourceDir(getPathToAndroidResources());
                    File localValueResourceDir = getValueResourceDir(resourceDir, (String) null, true);
                    File systemValueResourceDir = getValueResourceDir(systemResourceDir, (String) null, false);
                    File preferenceDir = getPreferenceResourceDir(resourceDir);
                    loadStringResources(localValueResourceDir, systemValueResourceDir);
                    loadPluralsResources(localValueResourceDir, systemValueResourceDir);
                    loadValueResources(localValueResourceDir, systemValueResourceDir);
                    loadDimenResources(localValueResourceDir, systemValueResourceDir);
                    loadIntegerResource(localValueResourceDir, systemValueResourceDir);
                    loadViewResources(systemResourceDir, resourceDir);
                    loadMenuResources(resourceDir);
                    loadDrawableResources(resourceDir);
                    loadPreferenceResources(preferenceDir);
                    loadXmlFileResources(preferenceDir);
                    listNinePatchResources(this.ninePatchDrawableIds, resourceDir);
                } else {
                    this.viewLoader = null;
                    this.menuLoader = null;
                    this.preferenceLoader = null;
                    this.xmlFileLoader = null;
                }
                this.isInitialized = true;
            } catch (I18nException e) {
                throw e;
            } catch (Exception e2) {
                throw new RuntimeException(e2);
            }
        }
    }

    public void reloadValuesResouces(String qualifiers) {
        File systemResourceDir = getSystemResourceDir(getPathToAndroidResources());
        File localValueResourceDir = getValueResourceDir(resourceDir, qualifiers, true);
        File systemValueResourceDir = getValueResourceDir(systemResourceDir, (String) null, false);
        File preferenceDir = getPreferenceResourceDir(resourceDir);
        try {
            loadStringResources(localValueResourceDir, systemValueResourceDir);
            loadPluralsResources(localValueResourceDir, systemValueResourceDir);
            loadValueResources(localValueResourceDir, systemValueResourceDir);
            loadDimenResources(localValueResourceDir, systemValueResourceDir);
            loadIntegerResource(localValueResourceDir, systemValueResourceDir);
            loadMenuResources(resourceDir);
            loadPreferenceResources(preferenceDir);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private File getSystemResourceDir(String pathToAndroidResources) {
        if (pathToAndroidResources != null) {
            return new File(pathToAndroidResources);
        }
        return null;
    }

    private void loadStringResources(File localResourceDir, File systemValueResourceDir) throws Exception {
        loadValueResourcesFromDirs(new DocumentLoader(this.stringResourceLoader), localResourceDir, systemValueResourceDir);
    }

    private void loadPluralsResources(File localResourceDir, File systemValueResourceDir) throws Exception {
        loadValueResourcesFromDirs(new DocumentLoader(this.pluralResourceLoader), localResourceDir, systemValueResourceDir);
    }

    private void loadValueResources(File localResourceDir, File systemValueResourceDir) throws Exception {
        loadValueResourcesFromDirs(new DocumentLoader(this.stringArrayResourceLoader, this.colorResourceLoader, this.attrResourceLoader), localResourceDir, systemValueResourceDir);
    }

    private void loadDimenResources(File localResourceDir, File systemValueResourceDir) throws Exception {
        loadValueResourcesFromDirs(new DocumentLoader(this.dimenResourceLoader), localResourceDir, systemValueResourceDir);
    }

    private void loadIntegerResource(File localResourceDir, File systemValueResourceDir) throws Exception {
        loadValueResourcesFromDirs(new DocumentLoader(this.integerResourceLoader), localResourceDir, systemValueResourceDir);
    }

    private void loadViewResources(File systemResourceDir, File xmlResourceDir) throws Exception {
        DocumentLoader viewDocumentLoader = new DocumentLoader(this.viewLoader);
        loadLayoutResourceXmlSubDirs(viewDocumentLoader, xmlResourceDir, false);
        loadLayoutResourceXmlSubDirs(viewDocumentLoader, systemResourceDir, true);
    }

    private void loadMenuResources(File xmlResourceDir) throws Exception {
        loadMenuResourceXmlDirs(new DocumentLoader(this.menuLoader), xmlResourceDir);
    }

    private void loadDrawableResources(File xmlResourceDir) throws Exception {
        loadDrawableResourceXmlDirs(new DocumentLoader(this.drawableResourceLoader), xmlResourceDir);
    }

    private void loadPreferenceResources(File xmlResourceDir) throws Exception {
        if (xmlResourceDir.exists()) {
            new DocumentLoader(this.preferenceLoader).loadResourceXmlDir(xmlResourceDir);
        }
    }

    private void loadXmlFileResources(File xmlResourceDir) throws Exception {
        if (xmlResourceDir.exists()) {
            new DocumentLoader(this.xmlFileLoader).loadResourceXmlDir(xmlResourceDir);
        }
    }

    private void loadLayoutResourceXmlSubDirs(DocumentLoader layoutDocumentLoader, File xmlResourceDir, boolean isSystem) throws Exception {
        if (xmlResourceDir != null) {
            layoutDocumentLoader.loadResourceXmlDirs(isSystem, xmlResourceDir.listFiles(LAYOUT_DIR_FILE_FILTER));
        }
    }

    private void loadMenuResourceXmlDirs(DocumentLoader menuDocumentLoader, File xmlResourceDir) throws Exception {
        if (xmlResourceDir != null) {
            menuDocumentLoader.loadResourceXmlDirs(xmlResourceDir.listFiles(MENU_DIR_FILE_FILTER));
        }
    }

    private void loadDrawableResourceXmlDirs(DocumentLoader drawableResourceLoader2, File xmlResourceDir) throws Exception {
        if (xmlResourceDir != null) {
            drawableResourceLoader2.loadResourceXmlDirs(xmlResourceDir.listFiles(DRAWABLE_DIR_FILE_FILTER));
        }
    }

    private void loadValueResourcesFromDirs(DocumentLoader documentLoader, File localValueResourceDir, File systemValueResourceDir) throws Exception {
        loadValueResourcesFromDir(documentLoader, localValueResourceDir);
        loadSystemResourceXmlDir(documentLoader, systemValueResourceDir);
    }

    private void loadValueResourcesFromDir(DocumentLoader documentloader, File xmlResourceDir) throws Exception {
        if (xmlResourceDir != null) {
            documentloader.loadResourceXmlDir(xmlResourceDir);
        }
    }

    private void loadSystemResourceXmlDir(DocumentLoader documentLoader, File stringResourceDir) throws Exception {
        if (stringResourceDir != null) {
            documentLoader.loadSystemResourceXmlDir(stringResourceDir);
        }
    }

    private File getValueResourceDir(File xmlResourceDir, String qualifiers, boolean isLocal) {
        String valuesDir = "values";
        if (qualifiers != null && !qualifiers.isEmpty() && isLocal) {
            valuesDir = String.valueOf(valuesDir) + "-" + qualifiers;
        }
        File result = xmlResourceDir != null ? new File(xmlResourceDir, valuesDir) : null;
        if (result != null && result.exists()) {
            return result;
        }
        throw new RuntimeException("Couldn't find value resource directory: " + result.getAbsolutePath());
    }

    private File getPreferenceResourceDir(File xmlResourceDir) {
        if (xmlResourceDir != null) {
            return new File(xmlResourceDir, "xml");
        }
        return null;
    }

    private String getPathToAndroidResources() {
        String resourcePath = getAndroidResourcePathFromLocalProperties();
        if (resourcePath != null) {
            return resourcePath;
        }
        String resourcePath2 = getAndroidResourcePathFromSystemEnvironment();
        if (resourcePath2 != null) {
            return resourcePath2;
        }
        String resourcePath3 = getAndroidResourcePathFromSystemProperty();
        if (resourcePath3 != null) {
            return resourcePath3;
        }
        String resourcePath4 = getAndroidResourcePathByExecingWhichAndroid();
        if (resourcePath4 != null) {
            return resourcePath4;
        }
        System.out.println("WARNING: Unable to find path to Android SDK");
        return null;
    }

    private String getAndroidResourcePathFromLocalProperties() {
        File localPropertiesFile = new File(resourceDir.getParentFile(), "local.properties");
        if (!localPropertiesFile.exists()) {
            localPropertiesFile = new File("local.properties");
        }
        if (localPropertiesFile.exists()) {
            Properties localProperties = new Properties();
            try {
                localProperties.load(new FileInputStream(localPropertiesFile));
                PropertiesHelper.doSubstitutions(localProperties);
                String sdkPath = localProperties.getProperty("sdk.dir");
                if (sdkPath != null) {
                    return getResourcePathFromSdkPath(sdkPath);
                }
            } catch (IOException e) {
            }
        }
        return null;
    }

    private String getAndroidResourcePathFromSystemEnvironment() {
        String resourcePath = System.getenv().get("ANDROID_HOME");
        if (resourcePath != null) {
            return new File(resourcePath, getAndroidResourceSubPath()).toString();
        }
        return null;
    }

    private String getAndroidResourcePathFromSystemProperty() {
        String resourcePath = System.getProperty("android.sdk.path");
        if (resourcePath != null) {
            return new File(resourcePath, getAndroidResourceSubPath()).toString();
        }
        return null;
    }

    private String getAndroidResourcePathByExecingWhichAndroid() {
        try {
            String sdkPath = new BufferedReader(new InputStreamReader(Runtime.getRuntime().exec(new String[]{"which", "android"}).getInputStream())).readLine();
            if (sdkPath != null && sdkPath.endsWith("tools/android")) {
                return getResourcePathFromSdkPath(sdkPath.substring(0, sdkPath.indexOf("tools/android")));
            }
        } catch (IOException e) {
        }
        return null;
    }

    private String getResourcePathFromSdkPath(String sdkPath) {
        File androidResourcePath = new File(sdkPath, getAndroidResourceSubPath());
        if (androidResourcePath.exists()) {
            return androidResourcePath.toString();
        }
        return null;
    }

    private String getAndroidResourceSubPath() {
        return "platforms/android-" + this.sdkVersion + "/data/res";
    }

    static boolean isLayoutDirectory(String path) {
        return path.contains(String.valueOf(File.separator) + "layout");
    }

    static boolean isDrawableDirectory(String path) {
        return path.contains(String.valueOf(File.separator) + "drawable");
    }

    static boolean isMenuDirectory(String path) {
        return path.contains(String.valueOf(File.separator) + "menu");
    }

    protected ResourceLoader(StringResourceLoader stringResourceLoader2) {
        this.isInitialized = false;
        this.strictI18n = false;
        this.ninePatchDrawableIds = new HashSet();
        this.resourceExtractor = new ResourceExtractor();
        this.stringResourceLoader = stringResourceLoader2;
        this.pluralResourceLoader = null;
        this.viewLoader = null;
        this.stringArrayResourceLoader = null;
        this.attrResourceLoader = null;
        this.colorResourceLoader = null;
        this.drawableResourceLoader = null;
        this.rawResourceLoader = null;
        this.dimenResourceLoader = null;
        this.integerResourceLoader = null;
        this.boolResourceLoader = null;
    }

    public static ResourceLoader getFrom(Context context) {
        ResourceLoader resourceLoader = Robolectric.shadowOf(context.getApplicationContext()).getResourceLoader();
        resourceLoader.init();
        return resourceLoader;
    }

    public String getNameForId(int viewId) {
        init();
        return this.resourceExtractor.getResourceName(viewId);
    }

    public View inflateView(Context context, int resource, ViewGroup viewGroup) {
        init();
        return this.viewLoader.inflateView(context, resource, (View) viewGroup);
    }

    public int getColorValue(int id) {
        init();
        return this.colorResourceLoader.getValue(id);
    }

    public String getStringValue(int id) {
        init();
        return this.stringResourceLoader.getValue(id);
    }

    public String getPluralStringValue(int id, int quantity) {
        init();
        return this.pluralResourceLoader.getValue(id, quantity);
    }

    public float getDimenValue(int id) {
        init();
        return this.dimenResourceLoader.getValue(id);
    }

    public int getIntegerValue(int id) {
        init();
        return this.integerResourceLoader.getValue(id);
    }

    public boolean getBooleanValue(int id) {
        init();
        return this.boolResourceLoader.getValue(id);
    }

    public XmlResourceParser getXml(int id) {
        init();
        return this.xmlFileLoader.getXml(id);
    }

    public boolean isDrawableXml(int resourceId) {
        init();
        return this.drawableResourceLoader.isXml(resourceId);
    }

    public boolean isAnimatableXml(int resourceId) {
        init();
        return this.drawableResourceLoader.isAnimationDrawable(resourceId);
    }

    public int[] getDrawableIds(int resourceId) {
        init();
        return this.drawableResourceLoader.getDrawableIds(resourceId);
    }

    public Drawable getXmlDrawable(int resourceId) {
        return this.drawableResourceLoader.getXmlDrawable(resourceId);
    }

    public Drawable getAnimDrawable(int resourceId) {
        return getInnerRClassDrawable(resourceId, "$anim", AnimationDrawable.class);
    }

    public Drawable getColorDrawable(int resourceId) {
        return getInnerRClassDrawable(resourceId, "$color", ColorDrawable.class);
    }

    private Drawable getInnerRClassDrawable(int drawableResourceId, String suffix, Class returnClass) {
        Class rClass2 = Robolectric.shadowOf(Robolectric.application).getResourceLoader().getLocalRClass();
        if (rClass2 == null) {
            return null;
        }
        try {
            Class animClass = Class.forName(String.valueOf(rClass2.getCanonicalName()) + suffix);
            try {
                for (Field field : animClass.getDeclaredFields()) {
                    if (field.getInt(animClass) == drawableResourceId) {
                        return (Drawable) returnClass.newInstance();
                    }
                }
            } catch (Exception e) {
            }
            return null;
        } catch (ClassNotFoundException e2) {
            return null;
        }
    }

    public boolean isNinePatchDrawable(int drawableResourceId) {
        return this.ninePatchDrawableIds.contains(Integer.valueOf(drawableResourceId));
    }

    private void listNinePatchResources(Set<Integer> resourceIds, File dir) {
        File[] files = dir.listFiles();
        if (files != null) {
            for (File f : files) {
                if (!f.isDirectory() || !isDrawableDirectory(f.getPath())) {
                    String name = f.getName();
                    if (name.endsWith(".9.png")) {
                        resourceIds.add(this.resourceExtractor.getResourceId("@drawable/" + name.split("\\.9\\.png$")[0]));
                    }
                } else {
                    listNinePatchResources(resourceIds, f);
                }
            }
        }
    }

    public InputStream getRawValue(int id) {
        init();
        return this.rawResourceLoader.getValue(id);
    }

    public String[] getStringArrayValue(int id) {
        init();
        return this.stringArrayResourceLoader.getArrayValue(id);
    }

    public void inflateMenu(Context context, int resource, Menu root) {
        init();
        this.menuLoader.inflateMenu(context, resource, root);
    }

    public PreferenceScreen inflatePreferences(Context context, int resourceId) {
        init();
        return this.preferenceLoader.inflatePreferences(context, resourceId);
    }

    public File getAssetsBase() {
        return this.assetsDir;
    }

    public Class getLocalRClass() {
        return this.rClass;
    }

    public void setLocalRClass(Class clazz) {
        this.rClass = clazz;
    }

    public ResourceExtractor getResourceExtractor() {
        return this.resourceExtractor;
    }

    public ViewLoader.ViewNode getLayoutViewNode(String layoutName) {
        return this.viewLoader.viewNodesByLayoutName.get(layoutName);
    }

    public void setLayoutQualifierSearchPath(String... locations) {
        init();
        this.viewLoader.setLayoutQualifierSearchPath(locations);
    }

    public static File getResourceDir() {
        return resourceDir;
    }
}
