package com.xtremelabs.robolectric.res;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class StringArrayResourceLoader extends XpathResourceXmlLoader {
    Map<String, String[]> stringArrayValues = new HashMap();
    private StringResourceLoader stringResourceLoader;

    public StringArrayResourceLoader(ResourceExtractor resourceExtractor, StringResourceLoader stringResourceLoader2) {
        super(resourceExtractor, "/resources/string-array");
        this.stringResourceLoader = stringResourceLoader2;
    }

    public String[] getArrayValue(int resourceId) {
        return this.stringArrayValues.get(this.resourceExtractor.getResourceName(resourceId));
    }

    /* access modifiers changed from: protected */
    public void processNode(Node node, String name, boolean isSystem) throws XPathExpressionException {
        NodeList childNodes = (NodeList) XPathFactory.newInstance().newXPath().compile("item").evaluate(node, XPathConstants.NODESET);
        List<String> arrayValues = new ArrayList<>();
        for (int j = 0; j < childNodes.getLength(); j++) {
            String value = childNodes.item(j).getTextContent();
            if (value.startsWith("@")) {
                arrayValues.add(this.stringResourceLoader.getValue(value.substring(1), isSystem));
            } else {
                arrayValues.add(value);
            }
        }
        this.stringArrayValues.put(String.valueOf(isSystem ? "android:" : "") + "array/" + name, (String[]) arrayValues.toArray(new String[arrayValues.size()]));
    }
}
