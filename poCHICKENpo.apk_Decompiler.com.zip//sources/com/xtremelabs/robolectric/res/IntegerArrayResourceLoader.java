package com.xtremelabs.robolectric.res;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class IntegerArrayResourceLoader extends XpathResourceXmlLoader {
    private final Map<String, Integer[]> integerArrayValues = new HashMap();
    private final IntegerResourceLoader integerResourceLoader;

    public IntegerArrayResourceLoader(ResourceExtractor resourceExtractor, IntegerResourceLoader integerResourceLoader2) {
        super(resourceExtractor, "/resources/integer-array");
        this.integerResourceLoader = integerResourceLoader2;
    }

    public int[] getArrayValue(int resourceId) {
        Integer[] values = this.integerArrayValues.get(this.resourceExtractor.getResourceName(resourceId));
        int[] results = new int[values.length];
        for (int i = 0; i < values.length; i++) {
            results[i] = values[i].intValue();
        }
        return results;
    }

    /* access modifiers changed from: protected */
    public void processNode(Node node, String name, boolean isSystem) throws XPathExpressionException {
        NodeList childNodes = (NodeList) XPathFactory.newInstance().newXPath().compile("item").evaluate(node, XPathConstants.NODESET);
        List<Integer> arrayValues = new ArrayList<>();
        for (int j = 0; j < childNodes.getLength(); j++) {
            String value = childNodes.item(j).getTextContent();
            if (value.startsWith("@")) {
                arrayValues.add(Integer.valueOf(this.integerResourceLoader.getValue(value.substring(1), isSystem)));
            } else {
                arrayValues.add(Integer.valueOf(Integer.parseInt(value)));
            }
        }
        this.integerArrayValues.put(String.valueOf(isSystem ? "android:" : "") + "array/" + name, (Integer[]) arrayValues.toArray(new Integer[arrayValues.size()]));
    }
}
