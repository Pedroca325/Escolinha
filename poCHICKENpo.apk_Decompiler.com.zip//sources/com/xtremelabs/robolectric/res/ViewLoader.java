package com.xtremelabs.robolectric.res;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.FrameLayout;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.tester.android.util.TestAttributeSet;
import com.xtremelabs.robolectric.util.I18nException;
import java.io.File;
import java.io.FileFilter;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class ViewLoader extends XmlLoader {
    /* access modifiers changed from: private */
    public AttrResourceLoader attrResourceLoader;
    private List<String> qualifierSearchPath;
    protected Map<String, ViewNode> viewNodesByLayoutName = new HashMap();

    public ViewLoader(ResourceExtractor resourceExtractor, AttrResourceLoader attrResourceLoader2) {
        super(resourceExtractor);
        this.attrResourceLoader = attrResourceLoader2;
        setLayoutQualifierSearchPath(loadLayoutQualifierPath());
    }

    /* access modifiers changed from: protected */
    public void processResourceXml(File xmlFile, Document document, boolean isSystem) throws Exception {
        ViewNode topLevelNode = new ViewNode("top-level", new HashMap(), isSystem);
        processChildren(document.getChildNodes(), topLevelNode);
        String layoutName = String.valueOf(xmlFile.getParentFile().getName()) + "/" + xmlFile.getName().replace(".xml", "");
        if (isSystem) {
            layoutName = "android:" + layoutName;
        }
        this.viewNodesByLayoutName.put(layoutName, topLevelNode.getChildren().get(0));
    }

    private void processChildren(NodeList childNodes, ViewNode parent) {
        for (int i = 0; i < childNodes.getLength(); i++) {
            processNode(childNodes.item(i), parent);
        }
    }

    private void processNode(Node node, ViewNode parent) {
        String name = node.getNodeName();
        NamedNodeMap attributes = node.getAttributes();
        Map<String, String> attrMap = new HashMap<>();
        if (attributes != null) {
            int length = attributes.getLength();
            for (int i = 0; i < length; i++) {
                Node attr = attributes.item(i);
                attrMap.put(attr.getNodeName(), attr.getNodeValue());
            }
        }
        if (name.equals("requestFocus")) {
            parent.attributes.put("android:focus", "true");
            parent.requestFocusOverride = true;
        } else if (!name.startsWith("#")) {
            ViewNode viewNode = new ViewNode(name, attrMap, parent.isSystem);
            if (parent != null) {
                parent.addChild(viewNode);
            }
            processChildren(node.getChildNodes(), viewNode);
        }
    }

    public View inflateView(Context context, String key) {
        return inflateView(context, key, (View) null);
    }

    public View inflateView(Context context, String key, View parent) {
        return inflateView(context, key, (Map<String, String>) null, parent);
    }

    public View inflateView(Context context, int resourceId, View parent) {
        return inflateView(context, this.resourceExtractor.getResourceName(resourceId), parent);
    }

    /* access modifiers changed from: private */
    public View inflateView(Context context, String layoutName, Map<String, String> attributes, View parent) {
        ViewNode viewNode = getViewNodeByLayoutName(layoutName);
        if (viewNode == null) {
            throw new RuntimeException("Could not find layout " + layoutName);
        }
        if (attributes != null) {
            try {
                for (Map.Entry<String, String> entry : attributes.entrySet()) {
                    if (!entry.getKey().equals("layout")) {
                        viewNode.attributes.put(entry.getKey(), entry.getValue());
                    }
                }
            } catch (I18nException e) {
                throw e;
            } catch (Exception e2) {
                throw new RuntimeException("error inflating " + layoutName, e2);
            }
        }
        return viewNode.inflate(context, parent);
    }

    private ViewNode getViewNodeByLayoutName(String layoutName) {
        if (layoutName.startsWith("layout") && !this.qualifierSearchPath.isEmpty()) {
            String rawLayoutName = layoutName.substring(layoutName.lastIndexOf("/") + 1, layoutName.length());
            for (String location : this.qualifierSearchPath) {
                ViewNode foundNode = this.viewNodesByLayoutName.get("layout-" + location + "/" + rawLayoutName);
                if (foundNode != null) {
                    return foundNode;
                }
            }
        }
        return this.viewNodesByLayoutName.get(layoutName);
    }

    public void setLayoutQualifierSearchPath(String... locations) {
        if (locations == null || locations.length == 0) {
            locations = loadLayoutQualifierPath();
        }
        this.qualifierSearchPath = Arrays.asList(locations);
    }

    private String[] loadLayoutQualifierPath() {
        File[] layoutsDir = ResourceLoader.getResourceDir().listFiles(new FileFilter() {
            public boolean accept(File file) {
                return ResourceLoader.isLayoutDirectory(file.getPath());
            }
        });
        List<String> dirs = new ArrayList<>();
        for (File f : layoutsDir) {
            String layoutName = f.getName();
            if (!"layout".equals(layoutName)) {
                dirs.add(layoutName.replace("layout-", ""));
            }
        }
        String[] locations = new String[dirs.size()];
        for (int i = 0; i < dirs.size(); i++) {
            locations[i] = dirs.get(i);
        }
        return locations;
    }

    public class ViewNode {
        /* access modifiers changed from: private */
        public final Map<String, String> attributes;
        private List<ViewNode> children = new ArrayList();
        boolean isSystem = false;
        private String name;
        boolean requestFocusOverride = false;

        public ViewNode(String name2, Map<String, String> attributes2, boolean isSystem2) {
            this.name = name2;
            this.attributes = attributes2;
            this.isSystem = isSystem2;
        }

        public List<ViewNode> getChildren() {
            return this.children;
        }

        public void addChild(ViewNode viewNode) {
            this.children.add(viewNode);
        }

        public View inflate(Context context, View parent) throws Exception {
            View view = create(context, (ViewGroup) parent);
            for (ViewNode child : this.children) {
                child.inflate(context, view);
            }
            invokeOnFinishInflate(view);
            return view;
        }

        private void invokeOnFinishInflate(View view) throws NoSuchMethodException, IllegalAccessException, InvocationTargetException {
            Method onFinishInflate = View.class.getDeclaredMethod("onFinishInflate", new Class[0]);
            onFinishInflate.setAccessible(true);
            onFinishInflate.invoke(view, new Object[0]);
        }

        private View create(Context context, ViewGroup parent) throws Exception {
            if (this.name.equals("include")) {
                return ViewLoader.this.inflateView(context, this.attributes.get("layout").substring(1), this.attributes, parent);
            }
            if (this.name.equals("merge")) {
                return parent;
            }
            if (this.name.equals("fragment")) {
                View fragment = constructFragment(context);
                addToParent(parent, fragment);
                return fragment;
            }
            applyFocusOverride(parent);
            View view = constructView(context);
            addToParent(parent, view);
            Robolectric.shadowOf(view).applyFocus();
            return view;
        }

        private FrameLayout constructFragment(Context context) throws InstantiationException, IllegalAccessException, InvocationTargetException, NoSuchMethodException {
            TestAttributeSet attributeSet = new TestAttributeSet(this.attributes, ViewLoader.this.resourceExtractor, ViewLoader.this.attrResourceLoader, View.class, this.isSystem);
            if (ViewLoader.this.strictI18n) {
                attributeSet.validateStrictI18n();
            }
            Fragment fragment = loadFragmentClass(this.attributes.get("android:name")).getConstructor(new Class[0]).newInstance(new Object[0]);
            if (!(context instanceof FragmentActivity)) {
                throw new RuntimeException("Cannot inflate a fragment unless the activity is a FragmentActivity");
            }
            String tag = attributeSet.getAttributeValue("android", "tag");
            int id = attributeSet.getAttributeResourceValue("android", "id", 0);
            ((FragmentActivity) context).getSupportFragmentManager().beginTransaction().add(id, fragment, tag).commit();
            View view = fragment.getView();
            FrameLayout container = new FrameLayout(context);
            container.setId(id);
            container.addView(view);
            return container;
        }

        private void addToParent(ViewGroup parent, View view) {
            if (parent != null && parent != view) {
                parent.addView(view);
            }
        }

        private View constructView(Context context) throws InstantiationException, IllegalAccessException, InvocationTargetException, NoSuchMethodException {
            Class<? extends View> clazz = pickViewClass();
            try {
                TestAttributeSet attributeSet = new TestAttributeSet(this.attributes, ViewLoader.this.resourceExtractor, ViewLoader.this.attrResourceLoader, clazz, this.isSystem);
                if (ViewLoader.this.strictI18n) {
                    attributeSet.validateStrictI18n();
                }
                return (View) clazz.getConstructor(new Class[]{Context.class, AttributeSet.class}).newInstance(new Object[]{context, attributeSet});
            } catch (NoSuchMethodException e) {
                try {
                    return (View) clazz.getConstructor(new Class[]{Context.class}).newInstance(new Object[]{context});
                } catch (NoSuchMethodException e2) {
                    return (View) clazz.getConstructor(new Class[]{Context.class, String.class}).newInstance(new Object[]{context, ""});
                }
            }
        }

        private Class<? extends View> pickViewClass() {
            Class<? extends View> clazz = loadViewClass(this.name);
            if (clazz == null) {
                clazz = loadViewClass("android.view." + this.name);
            }
            if (clazz == null) {
                clazz = loadViewClass("android.widget." + this.name);
            }
            if (clazz == null) {
                clazz = loadViewClass("android.webkit." + this.name);
            }
            if (clazz == null) {
                clazz = loadViewClass("com.google.android.maps." + this.name);
            }
            if (clazz != null) {
                return clazz;
            }
            throw new RuntimeException("couldn't find view class " + this.name);
        }

        private Class loadClass(String className) {
            try {
                return getClass().getClassLoader().loadClass(className);
            } catch (ClassNotFoundException e) {
                return null;
            }
        }

        private Class<? extends View> loadViewClass(String className) {
            return loadClass(className);
        }

        private Class<? extends Fragment> loadFragmentClass(String className) {
            return loadClass(className);
        }

        public void applyFocusOverride(ViewParent parent) {
            if (this.requestFocusOverride) {
                ViewParent viewParent = parent;
                while (true) {
                    View ancestor = (View) viewParent;
                    if (ancestor.getParent() == null) {
                        ancestor.clearFocus();
                        return;
                    }
                    viewParent = ancestor.getParent();
                }
            }
        }
    }
}
