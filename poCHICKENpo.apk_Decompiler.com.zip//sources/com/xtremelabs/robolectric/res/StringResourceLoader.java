package com.xtremelabs.robolectric.res;

import org.w3c.dom.Node;

public class StringResourceLoader extends XpathResourceXmlLoader implements ResourceValueConverter {
    private ResourceReferenceResolver<String> stringResolver = new ResourceReferenceResolver<>("string");

    public StringResourceLoader(ResourceExtractor resourceExtractor) {
        super(resourceExtractor, "/resources/string");
    }

    public String getValue(int resourceId) {
        return this.stringResolver.getValue(this.resourceExtractor.getResourceName(resourceId));
    }

    public String getValue(String resourceName, boolean isSystem) {
        return getValue(this.resourceExtractor.getResourceId(resourceName, isSystem).intValue());
    }

    /* access modifiers changed from: protected */
    public void processNode(Node node, String name, boolean isSystem) {
        this.stringResolver.processResource(name, node.getTextContent(), this, isSystem);
    }

    public Object convertRawValue(String rawValue) {
        return rawValue;
    }
}
