package com.xtremelabs.robolectric.res;

import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.StateListDrawable;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.shadows.ShadowStateListDrawable;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class DrawableResourceLoader extends XmlLoader {
    private static final Map<String, Integer> stateMap = new HashMap();
    protected Map<String, Document> documents = new HashMap();
    protected File resourceDirectory;

    static {
        stateMap.put("android:state_selected", 16842913);
        stateMap.put("android:state_pressed", 16842919);
        stateMap.put("android:state_focused", 16842908);
        stateMap.put("android:state_checkable", 16842911);
        stateMap.put("android:state_checked", 16842912);
        stateMap.put("android:state_enabled", 16842910);
        stateMap.put("android:state_window_focused", 16842909);
    }

    public DrawableResourceLoader(ResourceExtractor extractor, File resourceDirectory2) {
        super(extractor);
        this.resourceDirectory = resourceDirectory2;
    }

    public boolean isXml(int resourceId) {
        return this.documents.containsKey(this.resourceExtractor.getResourceName(resourceId));
    }

    public Drawable getXmlDrawable(int resId) {
        if (!isXml(resId)) {
            return null;
        }
        Document xmlDoc = this.documents.get(this.resourceExtractor.getResourceName(resId));
        NodeList nodes = xmlDoc.getElementsByTagName("selector");
        if (nodes != null && nodes.getLength() > 0) {
            return buildStateListDrawable(xmlDoc);
        }
        NodeList nodes2 = xmlDoc.getElementsByTagName("layer-list");
        if (nodes2 != null && nodes2.getLength() > 0) {
            return new LayerDrawable((Drawable[]) null);
        }
        NodeList nodes3 = xmlDoc.getElementsByTagName("animation-list");
        if (nodes3 == null || nodes3.getLength() <= 0) {
            return null;
        }
        return new AnimationDrawable();
    }

    /* access modifiers changed from: protected */
    public void processResourceXml(File xmlFile, Document document, boolean isSystem) throws Exception {
        String name = toResourceName(xmlFile);
        if (!this.documents.containsKey(name)) {
            if (isSystem) {
                name = "android:" + name;
            }
            this.documents.put(name, document);
        }
    }

    private String toResourceName(File xmlFile) {
        try {
            return xmlFile.getCanonicalPath().replaceAll("[/\\\\\\\\]", "/").replaceAll("^.*?/res/", "").replaceAll("\\..+$", "");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /* access modifiers changed from: protected */
    public int[] getDrawableIds(int resourceId) {
        String resourceName = this.resourceExtractor.getResourceName(resourceId);
        NodeList items = this.documents.get(resourceName).getElementsByTagName("item");
        int[] drawableIds = new int[items.getLength()];
        for (int i = 0; i < items.getLength(); i++) {
            if (resourceName.startsWith("android:")) {
                drawableIds[i] = -1;
            } else {
                Node drawableName = items.item(i).getAttributes().getNamedItem("android:drawable");
                if (drawableName != null) {
                    drawableIds[i] = this.resourceExtractor.getResourceId(drawableName.getNodeValue()).intValue();
                }
            }
        }
        return drawableIds;
    }

    public boolean isAnimationDrawable(int resourceId) {
        return "animation-list".equals(this.documents.get(this.resourceExtractor.getResourceName(resourceId)).getDocumentElement().getLocalName());
    }

    private StateListDrawable buildStateListDrawable(Document d) {
        StateListDrawable drawable = new StateListDrawable();
        ShadowStateListDrawable shDrawable = Robolectric.shadowOf(drawable);
        NodeList items = d.getElementsByTagName("item");
        for (int i = 0; i < items.getLength(); i++) {
            Node node = items.item(i);
            Node drawableName = node.getAttributes().getNamedItem("android:drawable");
            if (drawableName != null) {
                shDrawable.addState(getStateId(node), this.resourceExtractor.getResourceId(drawableName.getNodeValue()).intValue());
            }
        }
        return drawable;
    }

    private int getStateId(Node node) {
        NamedNodeMap attrs = node.getAttributes();
        for (String state : stateMap.keySet()) {
            if (attrs.getNamedItem(state) != null) {
                return stateMap.get(state).intValue();
            }
        }
        return 16842914;
    }
}
