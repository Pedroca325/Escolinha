package com.xtremelabs.robolectric.res;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class ResourceReferenceResolver<T> {
    private Map<String, T> attributeNamesToValues = new HashMap();
    private String prefix;
    private Map<String, List<String>> unresolvedReferences = new HashMap();

    ResourceReferenceResolver(String prefix2) {
        this.prefix = prefix2;
    }

    public T getValue(String resourceName) {
        return this.attributeNamesToValues.get(resourceName);
    }

    public void processResource(String name, String rawValue, ResourceValueConverter loader, boolean isSystem) {
        String valuePointer = String.valueOf(this.prefix) + "/" + name;
        if (rawValue.startsWith("@" + this.prefix) || rawValue.startsWith("@android:" + this.prefix)) {
            addAttributeReference(rawValue, valuePointer);
            return;
        }
        if (isSystem) {
            valuePointer = "android:" + valuePointer;
        }
        addAttribute(valuePointer, loader.convertRawValue(rawValue));
    }

    public void addAttribute(String valuePointer, T value) {
        this.attributeNamesToValues.put(valuePointer, value);
        resolveUnresolvedReferences(valuePointer, value);
    }

    private void resolveUnresolvedReferences(String attributeName, T value) {
        List<String> references = this.unresolvedReferences.remove(attributeName);
        if (references != null) {
            for (String reference : references) {
                this.attributeNamesToValues.put(reference, value);
            }
        }
    }

    private void addUnresolvedReference(String valuePointer, String attributeName) {
        List<String> references = this.unresolvedReferences.get(attributeName);
        if (references == null) {
            references = new ArrayList<>();
            this.unresolvedReferences.put(attributeName, references);
        }
        references.add(valuePointer);
    }

    private void addAttributeReference(String rawValue, String valuePointer) {
        String attributeName = rawValue.substring(1);
        T value = this.attributeNamesToValues.get(attributeName);
        if (value == null) {
            addUnresolvedReference(valuePointer, attributeName);
        } else {
            this.attributeNamesToValues.put(valuePointer, value);
        }
    }
}
