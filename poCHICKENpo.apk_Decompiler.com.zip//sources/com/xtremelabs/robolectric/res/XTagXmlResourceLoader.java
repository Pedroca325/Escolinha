package com.xtremelabs.robolectric.res;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public abstract class XTagXmlResourceLoader extends XmlLoader {
    private static List<String> xPathXmlFiles = new ArrayList(6);
    private String tag;

    /* access modifiers changed from: protected */
    public abstract void processNode(Node node, String str, boolean z);

    static {
        xPathXmlFiles.add("values/attrs");
        xPathXmlFiles.add("values/colors");
        xPathXmlFiles.add("values/strings");
        xPathXmlFiles.add("values/string_arrays");
        xPathXmlFiles.add("values/plurals");
        xPathXmlFiles.add("values/dimens");
    }

    public XTagXmlResourceLoader(ResourceExtractor resourceExtractor, String tag2) {
        super(resourceExtractor);
        this.tag = tag2;
    }

    /* access modifiers changed from: protected */
    public void processResourceXml(File xmlFile, Document document, boolean isSystem) throws Exception {
        if (!xPathXmlFiles.contains(toResourceName(xmlFile))) {
            NodeList items = document.getElementsByTagName(this.tag);
            for (int i = 0; i < items.getLength(); i++) {
                Node node = items.item(i);
                processNode(node, node.getAttributes().getNamedItem("name").getNodeValue(), isSystem);
            }
        }
    }

    private String toResourceName(File xmlFile) {
        try {
            return xmlFile.getCanonicalPath().replaceAll("[/\\\\\\\\]", "/").replaceAll("^.*?/res/", "").replaceAll("\\..+$", "");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
