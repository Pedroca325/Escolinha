package com.xtremelabs.robolectric.res;

import android.view.View;
import java.io.File;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class AttrResourceLoader extends XmlLoader {
    Map<String, String> classAttrEnumToValue = new HashMap();
    Set<String> knownClassAttrs = new HashSet();

    public AttrResourceLoader(ResourceExtractor resourceExtractor) {
        super(resourceExtractor);
    }

    /* access modifiers changed from: protected */
    public void processResourceXml(File xmlFile, Document document, boolean isSystem) throws Exception {
        NodeList stringNodes = (NodeList) XPathFactory.newInstance().newXPath().compile("/resources/declare-styleable/attr/enum").evaluate(document, XPathConstants.NODESET);
        for (int i = 0; i < stringNodes.getLength(); i++) {
            Node node = stringNodes.item(i);
            String viewName = node.getParentNode().getParentNode().getAttributes().getNamedItem("name").getNodeValue();
            String enumName = node.getParentNode().getAttributes().getNamedItem("name").getNodeValue();
            String name = node.getAttributes().getNamedItem("name").getNodeValue();
            this.classAttrEnumToValue.put(key(viewName, enumName, name, isSystem), node.getAttributes().getNamedItem("value").getNodeValue());
            this.knownClassAttrs.add(key(viewName, enumName, isSystem));
        }
    }

    public String convertValueToEnum(Class<? extends View> viewClass, String namespace, String attrName, String attrValue) {
        boolean isSystem = "android".equals(namespace);
        return this.classAttrEnumToValue.get(key(findKnownAttrClass(attrName, viewClass, isSystem), attrName, attrValue, isSystem));
    }

    public boolean hasAttributeFor(Class<? extends View> viewClass, String namespace, String attrName) {
        return findKnownAttrClass(attrName, viewClass, "android".equals(namespace)) != null;
    }

    private String findKnownAttrClass(String attrName, Class<?> cls, boolean isSystem) {
        Class<? super Object> clazz;
        while (clazz != null) {
            String className = clazz.getName();
            if (isSystem) {
                className = clazz.getSimpleName();
            }
            if (this.knownClassAttrs.contains(key(className, attrName, isSystem))) {
                return className;
            }
            Class<? super Object> superclass = clazz.getSuperclass();
            clazz = cls;
            clazz = superclass;
        }
        return null;
    }

    private String key(String viewName, String attrName, String name, boolean isSystem) {
        return String.valueOf(key(viewName, attrName, isSystem)) + "#" + name;
    }

    private String key(String viewName, String attrName, boolean isSystem) {
        return String.valueOf(isSystem ? "android:" : "") + viewName + "#" + attrName;
    }
}
