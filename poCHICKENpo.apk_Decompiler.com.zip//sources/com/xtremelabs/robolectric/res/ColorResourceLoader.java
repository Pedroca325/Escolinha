package com.xtremelabs.robolectric.res;

import java.util.HashMap;
import java.util.Map;
import org.w3c.dom.Node;

public class ColorResourceLoader extends XpathResourceXmlLoader implements ResourceValueConverter {
    private static Map<String, Integer> androidColors = new HashMap();
    private ResourceReferenceResolver<Integer> colorResolver = new ResourceReferenceResolver<>("color");

    static {
        androidColors.put("black", -16777216);
        androidColors.put("darkgray", -12303292);
        androidColors.put("gray", -7829368);
        androidColors.put("lightgray", -3355444);
        androidColors.put("white", -1);
        androidColors.put("red", -65536);
        androidColors.put("green", -16711936);
        androidColors.put("blue", -16776961);
        androidColors.put("yellow", -256);
        androidColors.put("cyan", -16711681);
        androidColors.put("magenta", -65281);
    }

    public ColorResourceLoader(ResourceExtractor resourceExtractor) {
        super(resourceExtractor, "/resources/color");
    }

    public int getValue(int colorId) {
        Integer colorResolverValue;
        String resourceName = this.resourceExtractor.getResourceName(colorId);
        if (resourceName == null || (colorResolverValue = this.colorResolver.getValue(resourceName)) == null) {
            return -1;
        }
        return colorResolverValue.intValue();
    }

    /* access modifiers changed from: protected */
    public void processNode(Node node, String name, boolean isSystem) {
        this.colorResolver.processResource(name, node.getTextContent(), this, isSystem);
    }

    public Integer convertRawValue(String rawValue) {
        if (rawValue.startsWith("#")) {
            return Integer.valueOf((int) Long.parseLong(rawValue.substring(1), 16));
        }
        if (androidColors.containsKey(rawValue)) {
            return androidColors.get(rawValue);
        }
        return null;
    }
}
