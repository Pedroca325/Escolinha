package com.xtremelabs.robolectric.res;

import android.content.Context;
import android.text.TextUtils;
import android.view.Menu;
import android.view.View;
import com.xtremelabs.robolectric.tester.android.util.TestAttributeSet;
import com.xtremelabs.robolectric.util.I18nException;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class MenuLoader extends XmlLoader {
    /* access modifiers changed from: private */
    public AttrResourceLoader attrResourceLoader;
    private Map<String, MenuNode> menuNodesByMenuName = new HashMap();

    public MenuLoader(ResourceExtractor resourceExtractor, AttrResourceLoader attrResourceLoader2) {
        super(resourceExtractor);
        this.attrResourceLoader = attrResourceLoader2;
    }

    /* access modifiers changed from: protected */
    public void processResourceXml(File xmlFile, Document document, boolean ignored) throws Exception {
        MenuNode topLevelNode = new MenuNode("top-level", new HashMap());
        NodeList items = document.getChildNodes();
        if (items.getLength() != 1) {
            throw new RuntimeException("Expected only one top-level item in menu file " + xmlFile.getName());
        } else if (items.item(0).getNodeName().compareTo("menu") != 0) {
            throw new RuntimeException("Expected a top-level item called 'menu' in menu file " + xmlFile.getName());
        } else {
            processChildren(items.item(0).getChildNodes(), topLevelNode);
            this.menuNodesByMenuName.put("menu/" + xmlFile.getName().replace(".xml", ""), topLevelNode);
        }
    }

    private void processChildren(NodeList childNodes, MenuNode parent) {
        for (int i = 0; i < childNodes.getLength(); i++) {
            processNode(childNodes.item(i), parent);
        }
    }

    private void processNode(Node node, MenuNode parent) {
        String name = node.getNodeName();
        NamedNodeMap attributes = node.getAttributes();
        Map<String, String> attrMap = new HashMap<>();
        if (attributes != null) {
            int length = attributes.getLength();
            for (int i = 0; i < length; i++) {
                Node attr = attributes.item(i);
                attrMap.put(attr.getNodeName(), attr.getNodeValue());
            }
        }
        if (!name.startsWith("#")) {
            MenuNode menuNode = new MenuNode(name, attrMap);
            parent.addChild(menuNode);
            NodeList children = node.getChildNodes();
            if (children != null && children.getLength() != 0) {
                for (int i2 = 0; i2 < children.getLength(); i2++) {
                    Node nodei = children.item(i2);
                    if (!childToIgnore(nodei)) {
                        if (validChildren(nodei)) {
                            processNode(nodei, menuNode);
                        } else {
                            throw new RuntimeException("Unknown menu node" + nodei.getNodeName());
                        }
                    }
                }
            }
        }
    }

    private static boolean childToIgnore(Node nodei) {
        return TextUtils.isEmpty(nodei.getNodeName()) || nodei.getNodeName().startsWith("#");
    }

    private static boolean validChildren(Node nodei) {
        return nodei.getNodeName().equals("item") || nodei.getNodeName().equals("menu") || nodei.getNodeName().equals("group");
    }

    public void inflateMenu(Context context, String key, Menu root) {
        inflateMenu(context, key, (Map<String, String>) null, root);
    }

    public void inflateMenu(Context context, int resourceId, Menu root) {
        inflateMenu(context, this.resourceExtractor.getResourceName(resourceId), root);
    }

    private void inflateMenu(Context context, String key, Map<String, String> attributes, Menu root) {
        MenuNode menuNode = this.menuNodesByMenuName.get(key);
        if (menuNode == null) {
            throw new RuntimeException("Could not find menu " + key);
        }
        if (attributes != null) {
            try {
                for (Map.Entry<String, String> entry : attributes.entrySet()) {
                    if (!entry.getKey().equals("menu")) {
                        menuNode.attributes.put(entry.getKey(), entry.getValue());
                    }
                }
            } catch (I18nException e) {
                throw e;
            } catch (Exception e2) {
                throw new RuntimeException("error inflating " + key, e2);
            }
        }
        menuNode.inflate(context, root);
    }

    public class MenuNode {
        /* access modifiers changed from: private */
        public final TestAttributeSet attributes;
        private List<MenuNode> children = new ArrayList();
        private String name;

        public MenuNode(String name2, Map<String, String> attributes2) {
            this.name = name2;
            this.attributes = new TestAttributeSet(attributes2, MenuLoader.this.resourceExtractor, MenuLoader.this.attrResourceLoader, (Class<? extends View>) null, false);
        }

        public List<MenuNode> getChildren() {
            return this.children;
        }

        public void addChild(MenuNode MenuNode) {
            this.children.add(MenuNode);
        }

        private boolean isSubMenuItem(MenuNode child) {
            List<MenuNode> ch = child.children;
            return ch != null && ch.size() == 1 && "menu".equals(ch.get(0).name);
        }

        private void addChildrenInGroup(MenuNode source, int groupId, Menu root) {
            for (MenuNode child : source.children) {
                String name2 = child.name;
                TestAttributeSet attributes2 = child.attributes;
                if (MenuLoader.this.strictI18n) {
                    attributes2.validateStrictI18n();
                }
                if (name2.equals("item")) {
                    if (isSubMenuItem(child)) {
                        addChildrenInGroup(child.children.get(0), groupId, root.addSubMenu(groupId, attributes2.getAttributeResourceValue("android", "id", 0), 0, attributes2.getAttributeValue("android", "title")));
                    } else {
                        root.add(groupId, attributes2.getAttributeResourceValue("android", "id", 0), 0, attributes2.getAttributeValue("android", "title"));
                    }
                } else if (name2.equals("group")) {
                    addChildrenInGroup(child, attributes2.getAttributeResourceValue("android", "id", 0), root);
                }
            }
        }

        public void inflate(Context context, Menu root) throws Exception {
            addChildrenInGroup(this, 0, root);
        }
    }
}
