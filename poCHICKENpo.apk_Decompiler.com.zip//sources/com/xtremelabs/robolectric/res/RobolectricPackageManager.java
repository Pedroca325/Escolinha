package com.xtremelabs.robolectric.res;

import android.content.ComponentName;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;
import com.xtremelabs.robolectric.RobolectricConfig;
import com.xtremelabs.robolectric.tester.android.content.pm.StubPackageManager;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class RobolectricPackageManager extends StubPackageManager {
    private ApplicationInfo applicationInfo;
    private Map<ComponentName, ComponentState> componentList = new HashMap();
    private RobolectricConfig config;
    private ContextWrapper contextWrapper;
    private Map<ComponentName, Drawable> drawableList = new HashMap();
    private Map<String, PackageInfo> packageList;
    private Map<IntentFilter, ComponentName> preferredActivities = new HashMap();
    private Map<Intent, List<ResolveInfo>> resolveList = new HashMap();
    private Map<String, Boolean> systemFeatureList = new HashMap();

    public RobolectricPackageManager(ContextWrapper contextWrapper2, RobolectricConfig config2) {
        this.contextWrapper = contextWrapper2;
        this.config = config2;
        initializePackageInfo();
    }

    public PackageInfo getPackageInfo(String packageName, int flags) throws PackageManager.NameNotFoundException {
        if (this.packageList.containsKey(packageName)) {
            return this.packageList.get(packageName);
        }
        throw new PackageManager.NameNotFoundException();
    }

    public ApplicationInfo getApplicationInfo(String packageName, int flags) throws PackageManager.NameNotFoundException {
        if (this.config.getPackageName().equals(packageName)) {
            if (this.applicationInfo == null) {
                this.applicationInfo = new ApplicationInfo();
                this.applicationInfo.flags = this.config.getApplicationFlags();
                this.applicationInfo.targetSdkVersion = this.config.getSdkVersion();
                this.applicationInfo.packageName = this.config.getPackageName();
                this.applicationInfo.processName = this.config.getProcessName();
                this.applicationInfo.name = this.config.getApplicationName();
            }
            return this.applicationInfo;
        }
        PackageInfo info = this.packageList.get(packageName);
        if (info != null) {
            return info.applicationInfo;
        }
        throw new PackageManager.NameNotFoundException();
    }

    public List<PackageInfo> getInstalledPackages(int flags) {
        return new ArrayList(this.packageList.values());
    }

    public List<ResolveInfo> queryIntentActivities(Intent intent, int flags) {
        List<ResolveInfo> result = this.resolveList.get(intent);
        return result == null ? new ArrayList<>() : result;
    }

    public ResolveInfo resolveActivity(Intent intent, int flags) {
        List<ResolveInfo> candidates = queryIntentActivities(intent, flags);
        if (candidates.isEmpty()) {
            return null;
        }
        return candidates.get(0);
    }

    public ResolveInfo resolveService(Intent intent, int flags) {
        return resolveActivity(intent, flags);
    }

    public void addResolveInfoForIntent(Intent intent, List<ResolveInfo> info) {
        this.resolveList.put(intent, info);
    }

    public void addResolveInfoForIntent(Intent intent, ResolveInfo info) {
        List<ResolveInfo> l = this.resolveList.get(intent);
        if (l == null) {
            l = new ArrayList<>();
            this.resolveList.put(intent, l);
        }
        l.add(info);
    }

    public Drawable getActivityIcon(Intent intent) {
        return this.drawableList.get(intent.getComponent());
    }

    public Drawable getActivityIcon(ComponentName componentName) {
        return this.drawableList.get(componentName);
    }

    public void addActivityIcon(ComponentName component, Drawable d) {
        this.drawableList.put(component, d);
    }

    public void addActivityIcon(Intent intent, Drawable d) {
        this.drawableList.put(intent.getComponent(), d);
    }

    public Intent getLaunchIntentForPackage(String packageName) {
        Intent i = new Intent();
        i.setComponent(new ComponentName(packageName, ""));
        return i;
    }

    public CharSequence getApplicationLabel(ApplicationInfo info) {
        return info.name;
    }

    public void setComponentEnabledSetting(ComponentName componentName, int newState, int flags) {
        this.componentList.put(componentName, new ComponentState(newState, flags));
    }

    public void addPreferredActivity(IntentFilter filter, int match, ComponentName[] set, ComponentName activity) {
        this.preferredActivities.put(filter, activity);
    }

    public int getPreferredActivities(List<IntentFilter> outFilters, List<ComponentName> outActivities, String packageName) {
        if (outFilters != null) {
            Set<IntentFilter> filters = this.preferredActivities.keySet();
            for (IntentFilter filter : outFilters) {
                for (IntentFilter testFilter : filters) {
                    ComponentName name = this.preferredActivities.get(testFilter);
                    if (packageName == null || name.getPackageName().equals(packageName)) {
                        Iterator<String> iterator = filter.actionsIterator();
                        while (true) {
                            if (iterator.hasNext()) {
                                if (!testFilter.matchAction(iterator.next())) {
                                    break;
                                }
                            } else {
                                Iterator<String> iterator2 = filter.categoriesIterator();
                                while (true) {
                                    if (iterator2.hasNext()) {
                                        if (!filter.hasCategory(iterator2.next())) {
                                            break;
                                        }
                                    } else {
                                        if (outActivities == null) {
                                            outActivities = new ArrayList<>();
                                        }
                                        outActivities.add(name);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return 0;
    }

    public ComponentState getComponentState(ComponentName componentName) {
        return this.componentList.get(componentName);
    }

    public void addPackage(PackageInfo packageInfo) {
        this.packageList.put(packageInfo.packageName, packageInfo);
    }

    public void addPackage(String packageName) {
        PackageInfo info = new PackageInfo();
        info.packageName = packageName;
        addPackage(info);
    }

    public boolean hasSystemFeature(String name) {
        if (this.systemFeatureList.containsKey(name)) {
            return this.systemFeatureList.get(name).booleanValue();
        }
        return false;
    }

    public void setSystemFeature(String name, boolean supported) {
        this.systemFeatureList.put(name, Boolean.valueOf(supported));
    }

    private void initializePackageInfo() {
        if (this.packageList == null) {
            PackageInfo packageInfo = new PackageInfo();
            packageInfo.packageName = this.contextWrapper.getPackageName();
            packageInfo.versionName = "1.0";
            this.packageList = new HashMap();
            addPackage(packageInfo);
        }
    }

    public class ComponentState {
        public int flags;
        public int newState;

        public ComponentState(int newState2, int flags2) {
            this.newState = newState2;
            this.flags = flags2;
        }
    }
}
