package com.xtremelabs.robolectric.res;

import org.w3c.dom.Node;

public class IntegerResourceLoader extends XTagXmlResourceLoader implements ResourceValueConverter {
    private final ResourceReferenceResolver<Integer> integerResolver = new ResourceReferenceResolver<>("integer");

    public IntegerResourceLoader(ResourceExtractor resourceExtractor) {
        super(resourceExtractor, "integer");
    }

    public int getValue(int resourceId) {
        String resourceIdDebugString = String.valueOf(String.valueOf(resourceId)) + " (" + "0x" + Integer.toHexString(resourceId) + ")";
        String resourceName = this.resourceExtractor.getResourceName(resourceId);
        if (resourceName == null) {
            throw new IllegalArgumentException("No such resource: " + resourceId);
        }
        Integer value = this.integerResolver.getValue(resourceName);
        if (value != null) {
            return value.intValue();
        }
        throw new IllegalArgumentException("Got resource name " + resourceName + " from id " + resourceIdDebugString + ", but found no resource by that name");
    }

    public int getValue(String resourceName, boolean isSystem) {
        Integer resourceId = this.resourceExtractor.getResourceId(resourceName, isSystem);
        if (resourceName != null) {
            return getValue(resourceId.intValue());
        }
        throw new IllegalArgumentException("No such resource (" + isSystem + "): " + resourceName);
    }

    public Object convertRawValue(String rawValue) {
        try {
            return Integer.valueOf((int) Long.decode(rawValue).longValue());
        } catch (NumberFormatException nfe) {
            throw new RuntimeException(String.valueOf(rawValue) + " is not an integer.", nfe);
        }
    }

    /* access modifiers changed from: protected */
    public void processNode(Node node, String name, boolean isSystem) {
        this.integerResolver.processResource(name, node.getTextContent(), this, isSystem);
    }
}
