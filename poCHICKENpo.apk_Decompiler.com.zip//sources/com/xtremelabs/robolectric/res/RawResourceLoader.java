package com.xtremelabs.robolectric.res;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

public class RawResourceLoader {
    private File resourceDir;
    private ResourceExtractor resourceExtractor;

    public RawResourceLoader(ResourceExtractor resourceExtractor2, File resourceDir2) {
        this.resourceExtractor = resourceExtractor2;
        this.resourceDir = resourceDir2;
    }

    public InputStream getValue(int resourceId) {
        String fileBaseName;
        String resourceName = this.resourceExtractor.getResourceName(resourceId).substring("/raw".length());
        try {
            File[] files = new File(this.resourceDir, "raw").listFiles();
            for (File file : files) {
                String name = file.getName();
                int dotIndex = name.indexOf(".");
                if (dotIndex >= 0) {
                    fileBaseName = name.substring(0, dotIndex);
                } else {
                    fileBaseName = name;
                }
                if (fileBaseName.equals(resourceName)) {
                    return new FileInputStream(file);
                }
            }
            return null;
        } catch (FileNotFoundException e) {
            return null;
        }
    }
}
