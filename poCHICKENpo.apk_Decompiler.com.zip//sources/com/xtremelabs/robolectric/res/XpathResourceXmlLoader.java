package com.xtremelabs.robolectric.res;

import java.io.File;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public abstract class XpathResourceXmlLoader extends XmlLoader {
    private String expression;

    /* access modifiers changed from: protected */
    public abstract void processNode(Node node, String str, boolean z) throws XPathExpressionException;

    public XpathResourceXmlLoader(ResourceExtractor resourceExtractor, String expression2) {
        super(resourceExtractor);
        this.expression = expression2;
    }

    /* access modifiers changed from: protected */
    public void processResourceXml(File xmlFile, Document document, boolean isSystem) throws Exception {
        NodeList nodes = (NodeList) XPathFactory.newInstance().newXPath().compile(this.expression).evaluate(document, XPathConstants.NODESET);
        for (int i = 0; i < nodes.getLength(); i++) {
            Node node = nodes.item(i);
            processNode(node, node.getAttributes().getNamedItem("name").getNodeValue(), isSystem);
        }
    }
}
