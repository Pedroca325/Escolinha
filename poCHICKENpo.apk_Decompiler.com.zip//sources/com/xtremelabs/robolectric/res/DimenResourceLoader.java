package com.xtremelabs.robolectric.res;

import org.w3c.dom.Node;

public class DimenResourceLoader extends XpathResourceXmlLoader implements ResourceValueConverter {
    private static final String[] UNITS = {"dp", "dip", "pt", "px", "sp"};
    private ResourceReferenceResolver<Float> dimenResolver = new ResourceReferenceResolver<>("dimen");

    public DimenResourceLoader(ResourceExtractor resourceExtractor) {
        super(resourceExtractor, "/resources/dimen");
    }

    public float getValue(int resourceId) {
        return this.dimenResolver.getValue(this.resourceExtractor.getResourceName(resourceId)).floatValue();
    }

    public float getValue(String resourceName, boolean isSystem) {
        return getValue(this.resourceExtractor.getResourceId(resourceName, isSystem).intValue());
    }

    /* access modifiers changed from: protected */
    public void processNode(Node node, String name, boolean isSystem) {
        this.dimenResolver.processResource(name, node.getTextContent(), this, isSystem);
    }

    public Object convertRawValue(String rawValue) {
        int end = rawValue.length();
        for (String indexOf : UNITS) {
            int index = rawValue.indexOf(indexOf);
            if (index >= 0 && end > index) {
                end = index;
            }
        }
        return Float.valueOf(Float.parseFloat(rawValue.substring(0, end)));
    }
}
