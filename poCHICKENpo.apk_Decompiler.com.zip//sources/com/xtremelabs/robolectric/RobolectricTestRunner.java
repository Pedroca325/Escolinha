package com.xtremelabs.robolectric;

import android.app.Application;
import com.xtremelabs.robolectric.bytecode.ClassHandler;
import com.xtremelabs.robolectric.bytecode.RobolectricClassLoader;
import com.xtremelabs.robolectric.bytecode.ShadowWrangler;
import com.xtremelabs.robolectric.internal.RobolectricTestRunnerInterface;
import com.xtremelabs.robolectric.res.ResourceLoader;
import com.xtremelabs.robolectric.shadows.ShadowApplication;
import com.xtremelabs.robolectric.shadows.ShadowLog;
import com.xtremelabs.robolectric.util.DatabaseConfig;
import com.xtremelabs.robolectric.util.SQLiteMap;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javassist.Loader;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.junit.runners.BlockJUnit4ClassRunner;
import org.junit.runners.model.FrameworkMethod;
import org.junit.runners.model.InitializationError;
import org.junit.runners.model.Statement;
import org.xml.sax.SAXException;

public class RobolectricTestRunner extends BlockJUnit4ClassRunner implements RobolectricTestRunnerInterface {
    private static RobolectricClassLoader defaultLoader;
    private static InstrumentDetector instrumentDetector = InstrumentDetector.DEFAULT;
    private static Map<RobolectricConfig, ResourceLoader> resourceLoaderForRootAndDirectory = new HashMap();
    /* access modifiers changed from: private */
    public ClassHandler classHandler;
    private RobolectricClassLoader classLoader;
    private DatabaseConfig.DatabaseMap databaseMap;
    /* access modifiers changed from: private */
    public RobolectricTestRunnerInterface delegate;
    protected RobolectricConfig robolectricConfig;

    public interface InstrumentDetector {
        public static final InstrumentDetector DEFAULT = new InstrumentDetector() {
            public boolean isInstrumented() {
                return RobolectricTestRunner.class.getClassLoader().getClass().getName().contains(RobolectricClassLoader.class.getName());
            }
        };

        boolean isInstrumented();
    }

    private static RobolectricClassLoader getDefaultLoader() {
        if (defaultLoader == null) {
            defaultLoader = new RobolectricClassLoader(ShadowWrangler.getInstance());
        }
        return defaultLoader;
    }

    public static void setInstrumentDetector(InstrumentDetector detector) {
        instrumentDetector = detector;
    }

    public static void setDefaultLoader(Loader robolectricClassLoader) {
        if (defaultLoader == null) {
            defaultLoader = (RobolectricClassLoader) robolectricClassLoader;
            return;
        }
        throw new RuntimeException("You may not set the default robolectricClassLoader unless it is null!");
    }

    protected static void addClassOrPackageToInstrument(String classOrPackageToBeInstrumented) {
        if (!isInstrumented()) {
            defaultLoader.addCustomShadowClass(classOrPackageToBeInstrumented);
        }
    }

    public RobolectricTestRunner(Class<?> testClass) throws InitializationError {
        this(testClass, new RobolectricConfig(new File(".")));
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    protected RobolectricTestRunner(Class<?> testClass, RobolectricConfig robolectricConfig2) throws InitializationError {
        this(testClass, isInstrumented() ? null : ShadowWrangler.getInstance(), isInstrumented() ? null : getDefaultLoader(), robolectricConfig2, new SQLiteMap());
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    protected RobolectricTestRunner(Class<?> testClass, RobolectricConfig robolectricConfig2, DatabaseConfig.DatabaseMap databaseMap2) throws InitializationError {
        this(testClass, isInstrumented() ? null : ShadowWrangler.getInstance(), isInstrumented() ? null : getDefaultLoader(), robolectricConfig2, databaseMap2);
    }

    public RobolectricTestRunner(Class<?> testClass, File androidProjectRoot) throws InitializationError {
        this(testClass, new RobolectricConfig(androidProjectRoot));
    }

    @Deprecated
    public RobolectricTestRunner(Class<?> testClass, String androidProjectRoot) throws InitializationError {
        this(testClass, new RobolectricConfig(new File(androidProjectRoot)));
    }

    protected RobolectricTestRunner(Class<?> testClass, File androidManifestPath, File resourceDirectory) throws InitializationError {
        this(testClass, new RobolectricConfig(androidManifestPath, resourceDirectory));
    }

    @Deprecated
    protected RobolectricTestRunner(Class<?> testClass, String androidManifestPath, String resourceDirectory) throws InitializationError {
        this(testClass, new RobolectricConfig(new File(androidManifestPath), new File(resourceDirectory)));
    }

    protected RobolectricTestRunner(Class<?> testClass, ClassHandler classHandler2, RobolectricClassLoader classLoader2, RobolectricConfig robolectricConfig2) throws InitializationError {
        this(testClass, classHandler2, classLoader2, robolectricConfig2, new SQLiteMap());
    }

    /* JADX WARNING: type inference failed for: r9v0, types: [com.xtremelabs.robolectric.bytecode.RobolectricClassLoader, java.lang.ClassLoader] */
    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    protected RobolectricTestRunner(java.lang.Class<?> r7, com.xtremelabs.robolectric.bytecode.ClassHandler r8, com.xtremelabs.robolectric.bytecode.RobolectricClassLoader r9, com.xtremelabs.robolectric.RobolectricConfig r10, com.xtremelabs.robolectric.util.DatabaseConfig.DatabaseMap r11) throws org.junit.runners.model.InitializationError {
        /*
            r6 = this;
            boolean r3 = isInstrumented()
            if (r3 == 0) goto L_0x0095
            r3 = r7
        L_0x0007:
            r6.<init>(r3)
            boolean r3 = isInstrumented()
            if (r3 != 0) goto L_0x0094
            r6.classHandler = r8
            r6.classLoader = r9
            r6.robolectricConfig = r10
            com.xtremelabs.robolectric.util.DatabaseConfig$DatabaseMap r3 = r6.setupDatabaseMap(r7, r11)
            r6.databaseMap = r3
            java.lang.Thread r3 = java.lang.Thread.currentThread()
            r3.setContextClassLoader(r9)
            java.lang.Class<android.net.Uri__FromAndroid> r3 = android.net.Uri__FromAndroid.class
            java.lang.String r3 = r3.getName()
            r6.delegateLoadingOf(r3)
            java.lang.Class<com.xtremelabs.robolectric.internal.RobolectricTestRunnerInterface> r3 = com.xtremelabs.robolectric.internal.RobolectricTestRunnerInterface.class
            java.lang.String r3 = r3.getName()
            r6.delegateLoadingOf(r3)
            java.lang.Class<com.xtremelabs.robolectric.internal.RealObject> r3 = com.xtremelabs.robolectric.internal.RealObject.class
            java.lang.String r3 = r3.getName()
            r6.delegateLoadingOf(r3)
            java.lang.Class<com.xtremelabs.robolectric.bytecode.ShadowWrangler> r3 = com.xtremelabs.robolectric.bytecode.ShadowWrangler.class
            java.lang.String r3 = r3.getName()
            r6.delegateLoadingOf(r3)
            java.lang.Class<com.xtremelabs.robolectric.RobolectricConfig> r3 = com.xtremelabs.robolectric.RobolectricConfig.class
            java.lang.String r3 = r3.getName()
            r6.delegateLoadingOf(r3)
            java.lang.Class<com.xtremelabs.robolectric.util.DatabaseConfig$DatabaseMap> r3 = com.xtremelabs.robolectric.util.DatabaseConfig.DatabaseMap.class
            java.lang.String r3 = r3.getName()
            r6.delegateLoadingOf(r3)
            java.lang.Class<android.R> r3 = android.R.class
            java.lang.String r3 = r3.getName()
            r6.delegateLoadingOf(r3)
            java.lang.Class r3 = r6.getClass()
            java.lang.Class r1 = r9.bootstrap(r3)
            r3 = 1
            java.lang.Class[] r3 = new java.lang.Class[r3]     // Catch:{ Exception -> 0x009b }
            r4 = 0
            java.lang.Class<java.lang.Class> r5 = java.lang.Class.class
            r3[r4] = r5     // Catch:{ Exception -> 0x009b }
            java.lang.reflect.Constructor r0 = r1.getConstructor(r3)     // Catch:{ Exception -> 0x009b }
            r3 = 1
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch:{ Exception -> 0x009b }
            r4 = 0
            java.lang.Class r5 = r9.bootstrap(r7)     // Catch:{ Exception -> 0x009b }
            r3[r4] = r5     // Catch:{ Exception -> 0x009b }
            java.lang.Object r3 = r0.newInstance(r3)     // Catch:{ Exception -> 0x009b }
            com.xtremelabs.robolectric.internal.RobolectricTestRunnerInterface r3 = (com.xtremelabs.robolectric.internal.RobolectricTestRunnerInterface) r3     // Catch:{ Exception -> 0x009b }
            r6.delegate = r3     // Catch:{ Exception -> 0x009b }
            com.xtremelabs.robolectric.internal.RobolectricTestRunnerInterface r3 = r6.delegate     // Catch:{ Exception -> 0x009b }
            r3.setRobolectricConfig(r10)     // Catch:{ Exception -> 0x009b }
            com.xtremelabs.robolectric.internal.RobolectricTestRunnerInterface r3 = r6.delegate     // Catch:{ Exception -> 0x009b }
            com.xtremelabs.robolectric.util.DatabaseConfig$DatabaseMap r4 = r6.databaseMap     // Catch:{ Exception -> 0x009b }
            r3.setDatabaseMap(r4)     // Catch:{ Exception -> 0x009b }
        L_0x0094:
            return
        L_0x0095:
            java.lang.Class r3 = r9.bootstrap(r7)
            goto L_0x0007
        L_0x009b:
            r2 = move-exception
            java.lang.RuntimeException r3 = new java.lang.RuntimeException
            r3.<init>(r2)
            throw r3
        */
        throw new UnsupportedOperationException("Method not decompiled: com.xtremelabs.robolectric.RobolectricTestRunner.<init>(java.lang.Class, com.xtremelabs.robolectric.bytecode.ClassHandler, com.xtremelabs.robolectric.bytecode.RobolectricClassLoader, com.xtremelabs.robolectric.RobolectricConfig, com.xtremelabs.robolectric.util.DatabaseConfig$DatabaseMap):void");
    }

    protected static boolean isInstrumented() {
        return instrumentDetector.isInstrumented();
    }

    protected RobolectricTestRunner(Class<?> testClass, ClassHandler classHandler2, RobolectricConfig robolectricConfig2) throws InitializationError {
        super(testClass);
        this.classHandler = classHandler2;
        this.robolectricConfig = robolectricConfig2;
    }

    public static void setStaticValue(Class<?> clazz, String fieldName, Object value) {
        try {
            Field field = clazz.getField(fieldName);
            field.setAccessible(true);
            Field modifiersField = Field.class.getDeclaredField("modifiers");
            modifiersField.setAccessible(true);
            modifiersField.setInt(field, field.getModifiers() & -17);
            field.set((Object) null, value);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /* access modifiers changed from: protected */
    public void delegateLoadingOf(String className) {
        this.classLoader.delegateLoadingOf(className);
    }

    /* access modifiers changed from: protected */
    public Statement methodBlock(final FrameworkMethod method) {
        setupI18nStrictState(method.getMethod(), this.robolectricConfig);
        if (this.classHandler != null) {
            this.classHandler.configure(this.robolectricConfig);
            this.classHandler.beforeTest();
        }
        this.delegate.internalBeforeTest(method.getMethod());
        final Statement statement = RobolectricTestRunner.super.methodBlock(method);
        return new Statement() {
            public void evaluate() throws Throwable {
                try {
                    statement.evaluate();
                } finally {
                    RobolectricTestRunner.this.delegate.internalAfterTest(method.getMethod());
                    if (RobolectricTestRunner.this.classHandler != null) {
                        RobolectricTestRunner.this.classHandler.afterTest();
                    }
                }
            }
        };
    }

    public void internalBeforeTest(Method method) {
        setupApplicationState(this.robolectricConfig);
        beforeTest(method);
    }

    public void internalAfterTest(Method method) {
        afterTest(method);
    }

    public void setRobolectricConfig(RobolectricConfig robolectricConfig2) {
        this.robolectricConfig = robolectricConfig2;
    }

    public void beforeTest(Method method) {
    }

    public void afterTest(Method method) {
    }

    public Object createTest() throws Exception {
        if (this.delegate != null) {
            return this.delegate.createTest();
        }
        Object test = RobolectricTestRunner.super.createTest();
        prepareTest(test);
        return test;
    }

    public void prepareTest(Object test) {
    }

    public void setupApplicationState(RobolectricConfig robolectricConfig2) {
        setupLogging();
        ResourceLoader resourceLoader = createResourceLoader(robolectricConfig2);
        Robolectric.bindDefaultShadowClasses();
        bindShadowClasses();
        resourceLoader.setLayoutQualifierSearchPath(new String[0]);
        Robolectric.resetStaticState();
        resetStaticState();
        DatabaseConfig.setDatabaseMap(this.databaseMap);
        Robolectric.application = ShadowApplication.bind(createApplication(), resourceLoader);
    }

    /* access modifiers changed from: protected */
    public void bindShadowClasses() {
    }

    /* access modifiers changed from: protected */
    public void resetStaticState() {
    }

    private void setupI18nStrictState(Method method, RobolectricConfig robolectricConfig2) {
        robolectricConfig2.setStrictI18n(lookForI18nAnnotations(lookForI18nAnnotations(globalI18nStrictEnabled(), method.getDeclaringClass().getAnnotations()), method.getAnnotations()));
    }

    /* access modifiers changed from: protected */
    public boolean globalI18nStrictEnabled() {
        return Boolean.valueOf(System.getProperty("robolectric.strictI18n")).booleanValue();
    }

    private boolean lookForI18nAnnotations(boolean strictI18n, Annotation[] annos) {
        for (Annotation annotationType : annos) {
            String name = annotationType.annotationType().getName();
            if (name.equals("com.xtremelabs.robolectric.annotation.EnableStrictI18n")) {
                return true;
            }
            if (name.equals("com.xtremelabs.robolectric.annotation.DisableStrictI18n")) {
                return false;
            }
        }
        return strictI18n;
    }

    private void setupLogging() {
        String logging = System.getProperty("robolectric.logging");
        if (logging != null && ShadowLog.stream == null) {
            PrintStream stream = null;
            if ("stdout".equalsIgnoreCase(logging)) {
                stream = System.out;
            } else if ("stderr".equalsIgnoreCase(logging)) {
                stream = System.err;
            } else {
                try {
                    final PrintStream file = new PrintStream(new FileOutputStream(logging));
                    stream = file;
                    Runtime.getRuntime().addShutdownHook(new Thread() {
                        public void run() {
                            try {
                                file.close();
                            } catch (Exception e) {
                            }
                        }
                    });
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            ShadowLog.stream = stream;
        }
    }

    /* access modifiers changed from: protected */
    public Application createApplication() {
        return new ApplicationResolver(this.robolectricConfig).resolveApplication();
    }

    private ResourceLoader createResourceLoader(RobolectricConfig robolectricConfig2) {
        ResourceLoader resourceLoader = resourceLoaderForRootAndDirectory.get(robolectricConfig2);
        if (resourceLoader == null) {
            try {
                robolectricConfig2.validate();
                ResourceLoader resourceLoader2 = new ResourceLoader(robolectricConfig2.getRealSdkVersion(), Class.forName(robolectricConfig2.getRClassName()), robolectricConfig2.getResourceDirectory(), robolectricConfig2.getAssetsDirectory());
                try {
                    resourceLoaderForRootAndDirectory.put(robolectricConfig2, resourceLoader2);
                    resourceLoader = resourceLoader2;
                } catch (Exception e) {
                    e = e;
                    ResourceLoader resourceLoader3 = resourceLoader2;
                    throw new RuntimeException(e);
                }
            } catch (Exception e2) {
                e = e2;
                throw new RuntimeException(e);
            }
        }
        resourceLoader.setStrictI18n(robolectricConfig2.getStrictI18n());
        return resourceLoader;
    }

    private String findResourcePackageName(File projectManifestFile) throws ParserConfigurationException, IOException, SAXException {
        return DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(projectManifestFile).getElementsByTagName("manifest").item(0).getAttributes().getNamedItem("package").getTextContent() + ".R";
    }

    /* access modifiers changed from: protected */
    public DatabaseConfig.DatabaseMap setupDatabaseMap(Class<?> testClass, DatabaseConfig.DatabaseMap map) {
        DatabaseConfig.DatabaseMap dbMap = map;
        if (!testClass.isAnnotationPresent(DatabaseConfig.UsingDatabaseMap.class)) {
            return dbMap;
        }
        DatabaseConfig.UsingDatabaseMap usingMap = (DatabaseConfig.UsingDatabaseMap) testClass.getAnnotation(DatabaseConfig.UsingDatabaseMap.class);
        if (usingMap.value() != null) {
            return (DatabaseConfig.DatabaseMap) Robolectric.newInstanceOf(usingMap.value());
        }
        if (dbMap != null) {
            return dbMap;
        }
        throw new RuntimeException("UsingDatabaseMap annotation value must provide a class implementing DatabaseMap");
    }

    public DatabaseConfig.DatabaseMap getDatabaseMap() {
        return this.databaseMap;
    }

    public void setDatabaseMap(DatabaseConfig.DatabaseMap databaseMap2) {
        this.databaseMap = databaseMap2;
    }
}
