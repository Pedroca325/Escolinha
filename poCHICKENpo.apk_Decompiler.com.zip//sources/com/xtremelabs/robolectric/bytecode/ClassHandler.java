package com.xtremelabs.robolectric.bytecode;

import com.xtremelabs.robolectric.RobolectricConfig;
import javassist.CtClass;

public interface ClassHandler {
    void afterTest();

    void beforeTest();

    void configure(RobolectricConfig robolectricConfig);

    void instrument(CtClass ctClass);

    Object methodInvoked(Class cls, String str, Object obj, String[] strArr, Object[] objArr) throws Throwable;
}
