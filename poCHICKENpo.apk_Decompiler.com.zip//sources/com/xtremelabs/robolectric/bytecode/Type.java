package com.xtremelabs.robolectric.bytecode;

import javassist.CtClass;

enum Type {
    VOID((String) null, (int) null, "", "", Void.TYPE),
    BOOLEAN(false, "false", ".booleanValue()", "java.lang.Boolean", Boolean.TYPE),
    BYTE(0, "0", ".byteValue()", "java.lang.Byte", Byte.TYPE),
    CHAR(0, "0", ".charValue()", "java.lang.Character", Character.TYPE),
    SHORT(0, "0", ".shortValue()", "java.lang.Short", Short.TYPE),
    INT(0, "0", ".intValue()", "java.lang.Integer", Integer.TYPE),
    LONG(0, "0l", ".longValue()", "java.lang.Long", Long.TYPE),
    FLOAT(0, "0f", ".floatValue()", "java.lang.Float", Float.TYPE),
    DOUBLE(0, "0d", ".doubleValue()", "java.lang.Double", Double.TYPE),
    OBJECT((String) null, "null", "", (String) null, (String) null);
    
    private String defaultReturnString;
    private Object defaultReturnValue;
    private String nonPrimitiveClassName;
    private Class type;
    private String unboxString;

    private Type(Object defaultReturnValue2, String defaultReturnString2, String unboxString2, String nonPrimitiveClassName2, Class type2) {
        this.defaultReturnValue = defaultReturnValue2;
        this.defaultReturnString = defaultReturnString2;
        this.unboxString = unboxString2;
        this.nonPrimitiveClassName = nonPrimitiveClassName2;
        this.type = type2;
    }

    /* access modifiers changed from: package-private */
    public Object defaultReturnValue() {
        return this.defaultReturnValue;
    }

    /* access modifiers changed from: package-private */
    public String defaultReturnString() {
        return this.defaultReturnString;
    }

    /* access modifiers changed from: package-private */
    public String unboxString() {
        return this.unboxString;
    }

    /* access modifiers changed from: package-private */
    public String nonPrimitiveClassName(CtClass returnCtClass) {
        return this.nonPrimitiveClassName == null ? returnCtClass.getName() : this.nonPrimitiveClassName;
    }

    /* access modifiers changed from: package-private */
    public boolean isVoid() {
        return this == VOID;
    }

    public static Type find(CtClass ctClass) {
        if (ctClass.equals(CtClass.voidType)) {
            return VOID;
        }
        if (ctClass.equals(CtClass.booleanType)) {
            return BOOLEAN;
        }
        if (ctClass.equals(CtClass.byteType)) {
            return BYTE;
        }
        if (ctClass.equals(CtClass.charType)) {
            return CHAR;
        }
        if (ctClass.equals(CtClass.shortType)) {
            return SHORT;
        }
        if (ctClass.equals(CtClass.intType)) {
            return INT;
        }
        if (ctClass.equals(CtClass.longType)) {
            return LONG;
        }
        if (ctClass.equals(CtClass.floatType)) {
            return FLOAT;
        }
        if (ctClass.equals(CtClass.doubleType)) {
            return DOUBLE;
        }
        if (!ctClass.isPrimitive()) {
            return OBJECT;
        }
        throw new RuntimeException("unknown return type " + ctClass);
    }

    public static Class findPrimitiveClass(String name) {
        for (Type type2 : values()) {
            if (type2.type != null && type2.type.getName().equals(name)) {
                return type2.type;
            }
        }
        return null;
    }
}
