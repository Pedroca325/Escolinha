package com.xtremelabs.robolectric.bytecode;

import java.io.File;
import java.util.List;
import javassist.CannotCompileException;
import javassist.ClassPool;
import javassist.Loader;
import javassist.LoaderClassPath;
import javassist.NotFoundException;

public class RobolectricClassLoader extends Loader {
    private AndroidTranslator androidTranslator;
    private ClassCache classCache;

    public RobolectricClassLoader(ClassHandler classHandler) {
        this(classHandler, (List<String>) null);
    }

    public RobolectricClassLoader(ClassHandler classHandler, List<String> customClassNames) {
        super(RobolectricClassLoader.class.getClassLoader(), (ClassPool) null);
        File classCacheDirectory;
        delegateLoadingOf(AndroidTranslator.class.getName());
        delegateLoadingOf(ClassHandler.class.getName());
        String classCachePath = System.getProperty("cached.roboelectric.classes.path");
        if (classCachePath == null || "".equals(classCachePath.trim())) {
            classCacheDirectory = new File("./tmp");
        } else {
            classCacheDirectory = new File(classCachePath);
        }
        this.classCache = new ClassCache(new File(classCacheDirectory, "cached-robolectric-classes.jar").getAbsolutePath(), 20);
        try {
            ClassPool classPool = new ClassPool();
            classPool.appendClassPath(new LoaderClassPath(RobolectricClassLoader.class.getClassLoader()));
            this.androidTranslator = new AndroidTranslator(classHandler, this.classCache, customClassNames);
            addTranslator(classPool, this.androidTranslator);
        } catch (NotFoundException e) {
            throw new RuntimeException(e);
        } catch (CannotCompileException e2) {
            throw new RuntimeException(e2);
        }
    }

    public void addCustomShadowClass(String classOrPackageToBeInstrumented) {
        this.androidTranslator.addCustomShadowClass(classOrPackageToBeInstrumented);
    }

    public Class loadClass(String name) throws ClassNotFoundException {
        if (!name.startsWith("org.junit") && !name.startsWith("org.hamcrest") && !name.startsWith("org.specs2") && !name.startsWith("scala.")) {
            return RobolectricClassLoader.super.loadClass(name);
        }
        return getParent().loadClass(name);
    }

    public Class<?> bootstrap(Class testClass) {
        try {
            return loadClass(testClass.getName());
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    /* access modifiers changed from: protected */
    public Class findClass(String name) throws ClassNotFoundException {
        byte[] classBytes = this.classCache.getClassBytesFor(name);
        if (classBytes != null) {
            return defineClass(name, classBytes, 0, classBytes.length);
        }
        return RobolectricClassLoader.super.findClass(name);
    }
}
