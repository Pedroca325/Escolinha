package com.xtremelabs.robolectric.bytecode;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.jar.Attributes;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.jar.Manifest;

public class ClassCache {
    /* access modifiers changed from: private */
    public static final Attributes.Name VERSION_ATTRIBUTE = new Attributes.Name("version");
    private Map<String, byte[]> cachedClasses = new HashMap();
    private boolean startedWriting = false;

    public ClassCache(String classCachePath, final int expectedCacheVersion) {
        Attributes attributes;
        String cacheVersionStr;
        final File cacheJarFile = new File(classCachePath);
        try {
            JarFile cacheFile = new JarFile(cacheJarFile);
            int cacheVersion = 0;
            Manifest manifest = cacheFile.getManifest();
            if (!(manifest == null || (attributes = manifest.getEntries().get("robolectric")) == null || (cacheVersionStr = (String) attributes.get(VERSION_ATTRIBUTE)) == null)) {
                cacheVersion = Integer.parseInt(cacheVersionStr);
            }
            if (cacheVersion != expectedCacheVersion) {
                cacheJarFile.delete();
            } else {
                readEntries(cacheFile);
            }
        } catch (IOException e) {
        }
        Runtime.getRuntime().addShutdownHook(new Thread() {
            public void run() {
                Manifest manifest = new Manifest();
                Attributes attributes = new Attributes();
                attributes.put(ClassCache.VERSION_ATTRIBUTE, String.valueOf(expectedCacheVersion));
                manifest.getEntries().put("robolectric", attributes);
                ClassCache.this.saveAllClassesToCache(cacheJarFile, manifest);
            }
        });
    }

    public byte[] getClassBytesFor(String name) {
        return this.cachedClasses.get(name);
    }

    public boolean isWriting() {
        boolean z;
        synchronized (this) {
            z = this.startedWriting;
        }
        return z;
    }

    public void addClass(String className, byte[] classBytes) {
        this.cachedClasses.put(className, classBytes);
    }

    private void readEntries(JarFile cacheFile) {
        Enumeration<JarEntry> entries = cacheFile.entries();
        while (entries.hasMoreElements()) {
            try {
                JarEntry entry = entries.nextElement();
                String className = entry.getName();
                if (className.endsWith(".class")) {
                    InputStream inputStream = cacheFile.getInputStream(entry);
                    ByteArrayOutputStream baos = new ByteArrayOutputStream((int) entry.getSize());
                    while (true) {
                        int c = inputStream.read();
                        if (c == -1) {
                            break;
                        }
                        baos.write(c);
                    }
                    addClass(className.substring(0, className.indexOf(".class")).replace('/', '.'), baos.toByteArray());
                }
            } catch (IOException e) {
                return;
            }
        }
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Removed duplicated region for block: B:23:0x007b A[SYNTHETIC, Splitter:B:23:0x007b] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void saveAllClassesToCache(java.io.File r12, java.util.jar.Manifest r13) {
        /*
            r11 = this;
            monitor-enter(r11)
            r7 = 1
            r11.startedWriting = r7     // Catch:{ all -> 0x007f }
            java.util.Map<java.lang.String, byte[]> r7 = r11.cachedClasses     // Catch:{ all -> 0x007f }
            int r7 = r7.size()     // Catch:{ all -> 0x007f }
            if (r7 <= 0) goto L_0x0087
            r4 = 0
            java.io.File r0 = r12.getParentFile()     // Catch:{ IOException -> 0x0093 }
            boolean r7 = r0.exists()     // Catch:{ IOException -> 0x0093 }
            if (r7 != 0) goto L_0x001a
            r0.mkdirs()     // Catch:{ IOException -> 0x0093 }
        L_0x001a:
            java.util.jar.JarOutputStream r5 = new java.util.jar.JarOutputStream     // Catch:{ IOException -> 0x0093 }
            java.io.FileOutputStream r7 = new java.io.FileOutputStream     // Catch:{ IOException -> 0x0093 }
            r7.<init>(r12)     // Catch:{ IOException -> 0x0093 }
            r5.<init>(r7, r13)     // Catch:{ IOException -> 0x0093 }
            java.util.Map<java.lang.String, byte[]> r7 = r11.cachedClasses     // Catch:{ IOException -> 0x0070, all -> 0x0090 }
            java.util.Set r7 = r7.entrySet()     // Catch:{ IOException -> 0x0070, all -> 0x0090 }
            java.util.Iterator r3 = r7.iterator()     // Catch:{ IOException -> 0x0070, all -> 0x0090 }
        L_0x002e:
            boolean r7 = r3.hasNext()     // Catch:{ IOException -> 0x0070, all -> 0x0090 }
            if (r7 == 0) goto L_0x0082
            java.lang.Object r2 = r3.next()     // Catch:{ IOException -> 0x0070, all -> 0x0090 }
            java.util.Map$Entry r2 = (java.util.Map.Entry) r2     // Catch:{ IOException -> 0x0070, all -> 0x0090 }
            java.lang.Object r6 = r2.getKey()     // Catch:{ IOException -> 0x0070, all -> 0x0090 }
            java.lang.String r6 = (java.lang.String) r6     // Catch:{ IOException -> 0x0070, all -> 0x0090 }
            java.util.jar.JarEntry r7 = new java.util.jar.JarEntry     // Catch:{ IOException -> 0x0070, all -> 0x0090 }
            java.lang.StringBuilder r8 = new java.lang.StringBuilder     // Catch:{ IOException -> 0x0070, all -> 0x0090 }
            r8.<init>()     // Catch:{ IOException -> 0x0070, all -> 0x0090 }
            r9 = 46
            r10 = 47
            java.lang.String r9 = r6.replace(r9, r10)     // Catch:{ IOException -> 0x0070, all -> 0x0090 }
            java.lang.StringBuilder r8 = r8.append(r9)     // Catch:{ IOException -> 0x0070, all -> 0x0090 }
            java.lang.String r9 = ".class"
            java.lang.StringBuilder r8 = r8.append(r9)     // Catch:{ IOException -> 0x0070, all -> 0x0090 }
            java.lang.String r8 = r8.toString()     // Catch:{ IOException -> 0x0070, all -> 0x0090 }
            r7.<init>(r8)     // Catch:{ IOException -> 0x0070, all -> 0x0090 }
            r5.putNextEntry(r7)     // Catch:{ IOException -> 0x0070, all -> 0x0090 }
            java.lang.Object r7 = r2.getValue()     // Catch:{ IOException -> 0x0070, all -> 0x0090 }
            byte[] r7 = (byte[]) r7     // Catch:{ IOException -> 0x0070, all -> 0x0090 }
            r5.write(r7)     // Catch:{ IOException -> 0x0070, all -> 0x0090 }
            r5.closeEntry()     // Catch:{ IOException -> 0x0070, all -> 0x0090 }
            goto L_0x002e
        L_0x0070:
            r1 = move-exception
            r4 = r5
        L_0x0072:
            java.lang.RuntimeException r7 = new java.lang.RuntimeException     // Catch:{ all -> 0x0078 }
            r7.<init>(r1)     // Catch:{ all -> 0x0078 }
            throw r7     // Catch:{ all -> 0x0078 }
        L_0x0078:
            r7 = move-exception
        L_0x0079:
            if (r4 == 0) goto L_0x007e
            r4.close()     // Catch:{ IOException -> 0x008e }
        L_0x007e:
            throw r7     // Catch:{ all -> 0x007f }
        L_0x007f:
            r7 = move-exception
            monitor-exit(r11)     // Catch:{ all -> 0x007f }
            throw r7
        L_0x0082:
            if (r5 == 0) goto L_0x0087
            r5.close()     // Catch:{ IOException -> 0x008c }
        L_0x0087:
            r7 = 0
            r11.startedWriting = r7     // Catch:{ all -> 0x007f }
            monitor-exit(r11)     // Catch:{ all -> 0x007f }
            return
        L_0x008c:
            r7 = move-exception
            goto L_0x0087
        L_0x008e:
            r8 = move-exception
            goto L_0x007e
        L_0x0090:
            r7 = move-exception
            r4 = r5
            goto L_0x0079
        L_0x0093:
            r1 = move-exception
            goto L_0x0072
        */
        throw new UnsupportedOperationException("Method not decompiled: com.xtremelabs.robolectric.bytecode.ClassCache.saveAllClassesToCache(java.io.File, java.util.jar.Manifest):void");
    }
}
