package com.xtremelabs.robolectric.bytecode;

import com.xtremelabs.robolectric.RobolectricConfig;
import com.xtremelabs.robolectric.internal.RealObject;
import com.xtremelabs.robolectric.util.I18nException;
import com.xtremelabs.robolectric.util.Join;
import java.lang.annotation.Annotation;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ShadowWrangler implements ClassHandler {
    public static final String SHADOW_FIELD_NAME = "__shadow__";
    private static ShadowWrangler singleton;
    public boolean debug = false;
    private boolean logMissingShadowMethods = false;
    private final Map<Class, MetaShadow> metaShadowMap = new HashMap();
    private Map<String, String> shadowClassMap = new HashMap();
    private Map<Class, Field> shadowFieldMap = new HashMap();
    private boolean strictI18n = false;

    public static ShadowWrangler getInstance() {
        if (singleton == null) {
            singleton = new ShadowWrangler();
        }
        return singleton;
    }

    private ShadowWrangler() {
    }

    public void configure(RobolectricConfig robolectricConfig) {
        this.strictI18n = robolectricConfig.getStrictI18n();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:10:0x002a, code lost:
        throw new java.lang.RuntimeException(r0);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:15:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:7:?, code lost:
        r1 = new javassist.CtField(r2, SHADOW_FIELD_NAME, r6);
        r1.setModifiers(1);
        r6.addField(r1);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:8:0x0024, code lost:
        r0 = move-exception;
     */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0024 A[ExcHandler: CannotCompileException (r0v1 'e' javassist.CannotCompileException A[CUSTOM_DECLARE]), Splitter:B:0:0x0000] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void instrument(javassist.CtClass r6) {
        /*
            r5 = this;
            javassist.ClassPool r3 = r6.getClassPool()     // Catch:{ CannotCompileException -> 0x0024, NotFoundException -> 0x002b }
            java.lang.Class<java.lang.Object> r4 = java.lang.Object.class
            java.lang.String r4 = r4.getName()     // Catch:{ CannotCompileException -> 0x0024, NotFoundException -> 0x002b }
            javassist.CtClass r2 = r3.get(r4)     // Catch:{ CannotCompileException -> 0x0024, NotFoundException -> 0x002b }
            java.lang.String r3 = "__shadow__"
            r6.getField(r3)     // Catch:{ NotFoundException -> 0x0014, CannotCompileException -> 0x0024 }
        L_0x0013:
            return
        L_0x0014:
            r0 = move-exception
            javassist.CtField r1 = new javassist.CtField     // Catch:{ CannotCompileException -> 0x0024, NotFoundException -> 0x002b }
            java.lang.String r3 = "__shadow__"
            r1.<init>(r2, r3, r6)     // Catch:{ CannotCompileException -> 0x0024, NotFoundException -> 0x002b }
            r3 = 1
            r1.setModifiers(r3)     // Catch:{ CannotCompileException -> 0x0024, NotFoundException -> 0x002b }
            r6.addField(r1)     // Catch:{ CannotCompileException -> 0x0024, NotFoundException -> 0x002b }
            goto L_0x0013
        L_0x0024:
            r0 = move-exception
            java.lang.RuntimeException r3 = new java.lang.RuntimeException
            r3.<init>(r0)
            throw r3
        L_0x002b:
            r0 = move-exception
            java.lang.RuntimeException r3 = new java.lang.RuntimeException
            r3.<init>(r0)
            throw r3
        */
        throw new UnsupportedOperationException("Method not decompiled: com.xtremelabs.robolectric.bytecode.ShadowWrangler.instrument(javassist.CtClass):void");
    }

    public void beforeTest() {
        this.shadowClassMap.clear();
    }

    public void afterTest() {
    }

    public void bindShadowClass(Class<?> realClass, Class<?> shadowClass) {
        this.shadowClassMap.put(realClass.getName(), shadowClass.getName());
        if (this.debug) {
            System.out.println("shadow " + realClass + " with " + shadowClass);
        }
    }

    public Object methodInvoked(Class clazz, String methodName, Object instance, String[] paramTypes, Object[] params) throws Throwable {
        InvocationPlan invocationPlan = new InvocationPlan(clazz, methodName, instance, paramTypes);
        if (!invocationPlan.prepare()) {
            reportNoShadowMethodFound(clazz, methodName, paramTypes);
            return null;
        } else if (!this.strictI18n || invocationPlan.isI18nSafe()) {
            try {
                return invocationPlan.getMethod().invoke(invocationPlan.getShadow(), params);
            } catch (IllegalArgumentException e) {
                throw new RuntimeException(invocationPlan.getShadow().getClass().getName() + " is not assignable from " + invocationPlan.getDeclaredShadowClass().getName(), e);
            } catch (InvocationTargetException e2) {
                throw stripStackTrace(e2.getCause());
            }
        } else {
            throw new I18nException("Method " + methodName + " on class " + clazz.getName() + " is not i18n-safe.");
        }
    }

    private <T extends Throwable> T stripStackTrace(T throwable) {
        List<StackTraceElement> stackTrace = new ArrayList<>();
        for (StackTraceElement stackTraceElement : throwable.getStackTrace()) {
            String className = stackTraceElement.getClassName();
            if (!(className.startsWith("sun.reflect.") || className.startsWith("java.lang.reflect.") || className.equals(ShadowWrangler.class.getName()) || className.equals(RobolectricInternals.class.getName()))) {
                stackTrace.add(stackTraceElement);
            }
        }
        throwable.setStackTrace((StackTraceElement[]) stackTrace.toArray(new StackTraceElement[stackTrace.size()]));
        return throwable;
    }

    private void reportNoShadowMethodFound(Class clazz, String methodName, String[] paramTypes) {
        if (this.logMissingShadowMethods) {
            System.out.println("No Shadow method found for " + clazz.getSimpleName() + "." + methodName + "(" + Join.join(", ", (Object[]) paramTypes) + ")");
        }
    }

    public static Class<?> loadClass(String paramType, ClassLoader classLoader) {
        Class primitiveClass = Type.findPrimitiveClass(paramType);
        if (primitiveClass != null) {
            return primitiveClass;
        }
        int arrayLevel = 0;
        while (paramType.endsWith("[]")) {
            arrayLevel++;
            paramType = paramType.substring(0, paramType.length() - 2);
        }
        Class<?> clazz = Type.findPrimitiveClass(paramType);
        if (clazz == null) {
            try {
                clazz = classLoader.loadClass(paramType);
            } catch (ClassNotFoundException e) {
                throw new RuntimeException(e);
            }
        }
        while (true) {
            int arrayLevel2 = arrayLevel;
            arrayLevel = arrayLevel2 - 1;
            if (arrayLevel2 <= 0) {
                return clazz;
            }
            clazz = Array.newInstance(clazz, 0).getClass();
        }
    }

    public Object shadowFor(Object instance) {
        Object shadow;
        Field field = getShadowField(instance);
        Object shadow2 = readField(instance, field);
        if (shadow2 != null) {
            return shadow2;
        }
        String shadowClassName = getShadowClassName(instance.getClass());
        if (this.debug) {
            System.out.println("creating new " + shadowClassName + " as shadow for " + instance.getClass().getName());
        }
        try {
            Class<?> shadowClass = loadClass(shadowClassName, instance.getClass().getClassLoader());
            Constructor<?> constructor = findConstructor(instance, shadowClass);
            if (constructor != null) {
                shadow = constructor.newInstance(new Object[]{instance});
            } else {
                shadow = shadowClass.newInstance();
            }
            field.set(instance, shadow);
            injectRealObjectOn(shadow, shadowClass, instance);
            return shadow;
        } catch (InstantiationException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException e2) {
            throw new RuntimeException(e2);
        } catch (InvocationTargetException e3) {
            throw new RuntimeException(e3);
        }
    }

    private void injectRealObjectOn(Object shadow, Class<?> shadowClass, Object instance) {
        for (Field realObjectField : getMetaShadow(shadowClass).realObjectFields) {
            writeField(shadow, instance, realObjectField);
        }
    }

    private MetaShadow getMetaShadow(Class<?> shadowClass) {
        MetaShadow metaShadow;
        synchronized (this.metaShadowMap) {
            metaShadow = this.metaShadowMap.get(shadowClass);
            if (metaShadow == null) {
                metaShadow = new MetaShadow(shadowClass);
                this.metaShadowMap.put(shadowClass, metaShadow);
            }
        }
        return metaShadow;
    }

    /* access modifiers changed from: private */
    public String getShadowClassName(Class clazz) {
        String shadowClassName = null;
        while (shadowClassName == null && clazz != null) {
            shadowClassName = this.shadowClassMap.get(clazz.getName());
            clazz = clazz.getSuperclass();
        }
        return shadowClassName;
    }

    private Constructor<?> findConstructor(Object instance, Class<?> shadowClass) {
        Class clazz = instance.getClass();
        Constructor constructor = null;
        while (constructor == null && clazz != null) {
            try {
                constructor = shadowClass.getConstructor(new Class[]{clazz});
            } catch (NoSuchMethodException e) {
            }
            clazz = clazz.getSuperclass();
        }
        return constructor;
    }

    private Field getShadowField(Object instance) {
        Class clazz = instance.getClass();
        Field field = this.shadowFieldMap.get(clazz);
        if (field == null) {
            try {
                field = clazz.getField(SHADOW_FIELD_NAME);
                this.shadowFieldMap.put(clazz, field);
            } catch (NoSuchFieldException e) {
                throw new RuntimeException(instance.getClass().getName() + " has no shadow field", e);
            }
        }
        return field;
    }

    public Object shadowOf(Object instance) {
        if (instance != null) {
            return readField(instance, getShadowField(instance));
        }
        throw new NullPointerException("can't get a shadow for null");
    }

    private Object readField(Object target, Field field) {
        try {
            return field.get(target);
        } catch (IllegalAccessException e1) {
            throw new RuntimeException(e1);
        }
    }

    private void writeField(Object target, Object value, Field realObjectField) {
        try {
            realObjectField.set(target, value);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }

    public void logMissingInvokedShadowMethods() {
        this.logMissingShadowMethods = true;
    }

    public void silence() {
        this.logMissingShadowMethods = false;
    }

    private class InvocationPlan {
        private ClassLoader classLoader;
        private Class clazz;
        private Class<?> declaredShadowClass;
        private Object instance;
        private Method method;
        private String methodName;
        private String[] paramTypes;
        private Object shadow;

        public InvocationPlan(Class clazz2, String methodName2, Object instance2, String... paramTypes2) {
            this.clazz = clazz2;
            this.classLoader = clazz2.getClassLoader();
            this.methodName = methodName2;
            this.instance = instance2;
            this.paramTypes = paramTypes2;
        }

        public Class<?> getDeclaredShadowClass() {
            return this.declaredShadowClass;
        }

        public Method getMethod() {
            return this.method;
        }

        public Object getShadow() {
            return this.shadow;
        }

        public boolean isI18nSafe() {
            Annotation[] annos = this.method.getAnnotations();
            int i = 0;
            while (i < annos.length) {
                if (annos[i].annotationType().getName().equals("com.xtremelabs.robolectric.internal.Implementation")) {
                    try {
                        return ((Boolean) annos[i].getClass().getMethod("i18nSafe", new Class[0]).invoke(annos[i], new Object[0])).booleanValue();
                    } catch (Exception e) {
                        return true;
                    }
                } else {
                    i++;
                }
            }
            return true;
        }

        public boolean prepare() {
            boolean z = false;
            Class<?>[] paramClasses = getParamClasses();
            this.declaredShadowClass = findDeclaredShadowClassForMethod(ShadowWrangler.loadClass(this.clazz.getName(), this.classLoader), this.methodName, paramClasses);
            if (this.declaredShadowClass == null) {
                return false;
            }
            if (this.methodName.equals("<init>")) {
                this.methodName = "__constructor__";
            }
            if (this.instance != null) {
                this.shadow = ShadowWrangler.this.shadowFor(this.instance);
                this.method = getMethod(this.shadow.getClass(), this.methodName, paramClasses);
            } else {
                this.shadow = null;
                this.method = getMethod(findShadowClass(this.clazz), this.methodName, paramClasses);
            }
            if (this.method != null) {
                if (this.instance == null) {
                    z = true;
                }
                if (z != Modifier.isStatic(this.method.getModifiers())) {
                    throw new RuntimeException("method staticness of " + this.clazz.getName() + "." + this.methodName + " and " + this.declaredShadowClass.getName() + "." + this.method.getName() + " don't match");
                }
                this.method.setAccessible(true);
                return true;
            } else if (!ShadowWrangler.this.debug) {
                return false;
            } else {
                System.out.println("No method found for " + this.clazz + "." + this.methodName + "(" + Arrays.asList(paramClasses) + ") on " + this.declaredShadowClass.getName());
                return false;
            }
        }

        private Class<?> findDeclaredShadowClassForMethod(Class<?> originalClass, String methodName2, Class<?>[] paramClasses) {
            return findShadowClass(findDeclaringClassForMethod(methodName2, paramClasses, originalClass));
        }

        private Class<?> findShadowClass(Class<?> originalClass) {
            String declaredShadowClassName = ShadowWrangler.this.getShadowClassName(originalClass);
            if (declaredShadowClassName == null) {
                return null;
            }
            return ShadowWrangler.loadClass(declaredShadowClassName, this.classLoader);
        }

        private Class<?> findDeclaringClassForMethod(String methodName2, Class<?>[] paramClasses, Class<?> originalClass) {
            if (this.methodName.equals("<init>")) {
                return originalClass;
            }
            try {
                return originalClass.getDeclaredMethod(methodName2, paramClasses).getDeclaringClass();
            } catch (NoSuchMethodException e) {
                throw new RuntimeException(e);
            }
        }

        private Class<?>[] getParamClasses() {
            Class<?>[] paramClasses = new Class[this.paramTypes.length];
            for (int i = 0; i < this.paramTypes.length; i++) {
                paramClasses[i] = ShadowWrangler.loadClass(this.paramTypes[i], this.classLoader);
            }
            return paramClasses;
        }

        private Method getMethod(Class<?> clazz2, String methodName2, Class<?>[] paramClasses) {
            Method method2;
            try {
                method2 = clazz2.getMethod(methodName2, paramClasses);
            } catch (NoSuchMethodException e) {
                try {
                    method2 = clazz2.getDeclaredMethod(methodName2, paramClasses);
                } catch (NoSuchMethodException e2) {
                    method2 = null;
                }
            }
            if (method2 == null || isOnShadowClass(method2)) {
                return method2;
            }
            return null;
        }

        private boolean isOnShadowClass(Method method2) {
            for (Annotation annotation : method2.getDeclaringClass().getAnnotations()) {
                if (annotation.annotationType().toString().equals("interface com.xtremelabs.robolectric.internal.Implements")) {
                    return true;
                }
            }
            return false;
        }

        public String toString() {
            return "delegating to " + this.declaredShadowClass.getName() + "." + this.method.getName() + "(" + Arrays.toString(this.method.getParameterTypes()) + ")";
        }
    }

    private class MetaShadow {
        List<Field> realObjectFields = new ArrayList();

        public MetaShadow(Class<?> cls) {
            for (Class<? super Object> shadowClass = cls; shadowClass != null; shadowClass = shadowClass.getSuperclass()) {
                for (Field field : shadowClass.getDeclaredFields()) {
                    if (field.isAnnotationPresent(RealObject.class)) {
                        field.setAccessible(true);
                        this.realObjectFields.add(field);
                    }
                }
            }
        }
    }
}
