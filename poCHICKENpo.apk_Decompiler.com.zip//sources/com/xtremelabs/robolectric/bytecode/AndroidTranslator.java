package com.xtremelabs.robolectric.bytecode;

import android.net.Uri;
import java.util.ArrayList;
import java.util.List;
import javassist.CannotCompileException;
import javassist.ClassMap;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtConstructor;
import javassist.CtField;
import javassist.CtMethod;
import javassist.CtNewConstructor;
import javassist.CtNewMethod;
import javassist.Modifier;
import javassist.NotFoundException;
import javassist.Translator;

public class AndroidTranslator implements Translator {
    public static final int CACHE_VERSION = 20;
    private static final List<ClassHandler> CLASS_HANDLERS = new ArrayList();
    private static final ArrayList<String> instrumentingList = new ArrayList<>();
    private ClassCache classCache;
    private ClassHandler classHandler;

    public AndroidTranslator(ClassHandler classHandler2, ClassCache classCache2) {
        this.classHandler = classHandler2;
        this.classCache = classCache2;
        instrumentingList.add("android.");
        instrumentingList.add("com.google.android.maps");
        instrumentingList.add("org.apache.http.impl.client.DefaultRequestDirector");
    }

    public AndroidTranslator(ClassHandler classHandler2, ClassCache classCache2, List<String> customShadowClassNames) {
        this(classHandler2, classCache2);
        if (customShadowClassNames != null && !customShadowClassNames.isEmpty()) {
            instrumentingList.addAll(customShadowClassNames);
        }
    }

    public void addCustomShadowClass(String customShadowClassName) {
        if (!instrumentingList.contains(customShadowClassName)) {
            instrumentingList.add(customShadowClassName);
        }
    }

    public static ClassHandler getClassHandler(int index) {
        return CLASS_HANDLERS.get(index);
    }

    public void start(ClassPool classPool) throws NotFoundException, CannotCompileException {
        injectClassHandlerToInstrumentedClasses(classPool);
    }

    private void injectClassHandlerToInstrumentedClasses(ClassPool classPool) throws NotFoundException, CannotCompileException {
        int index;
        synchronized (CLASS_HANDLERS) {
            CLASS_HANDLERS.add(this.classHandler);
            index = CLASS_HANDLERS.size() - 1;
        }
        CtClass robolectricInternalsCtClass = classPool.get(RobolectricInternals.class.getName());
        robolectricInternalsCtClass.setModifiers(1);
        robolectricInternalsCtClass.getClassInitializer().insertBefore("{\nclassHandler = " + AndroidTranslator.class.getName() + ".getClassHandler(" + index + ");\n" + "}");
    }

    /* JADX WARNING: type inference failed for: r6v3, types: [java.lang.Throwable, com.xtremelabs.robolectric.bytecode.IgnorableClassNotFoundException] */
    /* JADX WARNING: Removed duplicated region for block: B:12:0x003d A[LOOP:0: B:12:0x003d->B:15:0x004d, LOOP_START, PHI: r5 
      PHI: (r5v2 'wantsToBeInstrumented' boolean) = (r5v0 'wantsToBeInstrumented' boolean), (r5v3 'wantsToBeInstrumented' boolean) binds: [B:11:0x0037, B:15:0x004d] A[DONT_GENERATE, DONT_INLINE]] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onLoad(javassist.ClassPool r10, java.lang.String r11) throws javassist.NotFoundException, javassist.CannotCompileException {
        /*
            r9 = this;
            com.xtremelabs.robolectric.bytecode.ClassCache r6 = r9.classCache
            boolean r6 = r6.isWriting()
            if (r6 == 0) goto L_0x0021
            java.lang.IllegalStateException r6 = new java.lang.IllegalStateException
            java.lang.StringBuilder r7 = new java.lang.StringBuilder
            r7.<init>()
            java.lang.String r8 = "shouldn't be modifying bytecode after we've started writing cache! class="
            java.lang.StringBuilder r7 = r7.append(r8)
            java.lang.StringBuilder r7 = r7.append(r11)
            java.lang.String r7 = r7.toString()
            r6.<init>(r7)
            throw r6
        L_0x0021:
            boolean r6 = r9.classHasFromAndroidEquivalent(r11)
            if (r6 == 0) goto L_0x002b
            r9.replaceClassWithFromAndroidEquivalent(r10, r11)
        L_0x002a:
            return
        L_0x002b:
            javassist.CtClass r0 = r10.get(r11)     // Catch:{ NotFoundException -> 0x008a }
            java.lang.Class<com.xtremelabs.robolectric.internal.Instrument> r6 = com.xtremelabs.robolectric.internal.Instrument.class
            boolean r5 = r0.hasAnnotation(r6)
            if (r5 != 0) goto L_0x004f
            java.util.ArrayList<java.lang.String> r6 = instrumentingList
            java.util.Iterator r2 = r6.iterator()
        L_0x003d:
            boolean r6 = r2.hasNext()
            if (r6 == 0) goto L_0x004f
            java.lang.Object r3 = r2.next()
            java.lang.String r3 = (java.lang.String) r3
            boolean r5 = r11.startsWith(r3)
            if (r5 == 0) goto L_0x003d
        L_0x004f:
            if (r5 == 0) goto L_0x002a
            java.lang.Class<com.xtremelabs.robolectric.internal.DoNotInstrument> r6 = com.xtremelabs.robolectric.internal.DoNotInstrument.class
            boolean r6 = r0.hasAnnotation(r6)
            if (r6 != 0) goto L_0x002a
            int r4 = r0.getModifiers()
            boolean r6 = javassist.Modifier.isFinal(r4)
            if (r6 == 0) goto L_0x0068
            r6 = r4 & -17
            r0.setModifiers(r6)
        L_0x0068:
            boolean r6 = r0.isInterface()
            if (r6 != 0) goto L_0x002a
            com.xtremelabs.robolectric.bytecode.ClassHandler r6 = r9.classHandler
            r6.instrument(r0)
            r9.fixConstructors(r0)
            r9.fixMethods(r0)
            com.xtremelabs.robolectric.bytecode.ClassCache r6 = r9.classCache     // Catch:{ IOException -> 0x0083 }
            byte[] r7 = r0.toBytecode()     // Catch:{ IOException -> 0x0083 }
            r6.addClass(r11, r7)     // Catch:{ IOException -> 0x0083 }
            goto L_0x002a
        L_0x0083:
            r1 = move-exception
            java.lang.RuntimeException r6 = new java.lang.RuntimeException
            r6.<init>(r1)
            throw r6
        L_0x008a:
            r1 = move-exception
            com.xtremelabs.robolectric.bytecode.IgnorableClassNotFoundException r6 = new com.xtremelabs.robolectric.bytecode.IgnorableClassNotFoundException
            r6.<init>(r1)
            throw r6
        */
        throw new UnsupportedOperationException("Method not decompiled: com.xtremelabs.robolectric.bytecode.AndroidTranslator.onLoad(javassist.ClassPool, java.lang.String):void");
    }

    private boolean classHasFromAndroidEquivalent(String className) {
        return className.startsWith(Uri.class.getName());
    }

    private void replaceClassWithFromAndroidEquivalent(ClassPool classPool, String className) throws NotFoundException {
        FromAndroidClassNameParts classNameParts = new FromAndroidClassNameParts(className);
        if (!classNameParts.isFromAndroid()) {
            classPool.getAndRename(classNameParts.getNameWithFromAndroid(), className).replaceClassName(new ClassMap() {
                public Object get(Object jvmClassName) {
                    FromAndroidClassNameParts classNameParts = new FromAndroidClassNameParts(jvmClassName.toString());
                    if (classNameParts.isFromAndroid()) {
                        return classNameParts.getNameWithoutFromAndroid();
                    }
                    return jvmClassName;
                }
            });
        }
    }

    class FromAndroidClassNameParts {
        private static final String TOKEN = "__FromAndroid";
        private String prefix;
        private String suffix = "";

        FromAndroidClassNameParts(String name) {
            int dollarIndex = name.indexOf("$");
            this.prefix = name;
            if (dollarIndex > -1) {
                this.prefix = name.substring(0, dollarIndex);
                this.suffix = name.substring(dollarIndex);
            }
        }

        public boolean isFromAndroid() {
            return this.prefix.endsWith(TOKEN);
        }

        public String getNameWithFromAndroid() {
            return this.prefix + TOKEN + this.suffix;
        }

        public String getNameWithoutFromAndroid() {
            return this.prefix.replace(TOKEN, "") + this.suffix;
        }
    }

    private void addBypassShadowField(CtClass ctClass, String fieldName) {
        try {
            ctClass.getField(fieldName);
        } catch (NotFoundException e) {
            try {
                CtField field = new CtField(CtClass.booleanType, fieldName, ctClass);
                field.setModifiers(9);
                ctClass.addField(field);
            } catch (CannotCompileException e2) {
                throw new RuntimeException(e2);
            }
        }
    }

    private void fixConstructors(CtClass ctClass) throws CannotCompileException, NotFoundException {
        if (!ctClass.isEnum()) {
            boolean hasDefault = false;
            CtConstructor[] arr$ = ctClass.getDeclaredConstructors();
            int len$ = arr$.length;
            int i$ = 0;
            while (i$ < len$) {
                CtConstructor ctConstructor = arr$[i$];
                try {
                    fixConstructor(ctClass, hasDefault, ctConstructor);
                    if (ctConstructor.getParameterTypes().length == 0) {
                        hasDefault = true;
                    }
                    i$++;
                } catch (Exception e) {
                    throw new RuntimeException("problem instrumenting " + ctConstructor, e);
                }
            }
            if (!hasDefault) {
                ctClass.addConstructor(CtNewConstructor.make(new CtClass[0], new CtClass[0], "{\n" + generateConstructorBody(ctClass, new CtClass[0]) + "}\n", ctClass));
            }
        }
    }

    private boolean fixConstructor(CtClass ctClass, boolean needsDefault, CtConstructor ctConstructor) throws NotFoundException, CannotCompileException {
        ctConstructor.setBody("{\n" + generateConstructorBody(ctClass, ctConstructor.getParameterTypes()) + "}\n");
        return needsDefault;
    }

    private String generateConstructorBody(CtClass ctClass, CtClass[] parameterTypes) throws NotFoundException {
        return generateMethodBody(ctClass, new CtMethod(CtClass.voidType, "<init>", parameterTypes, ctClass), CtClass.voidType, Type.VOID, false, false);
    }

    private void fixMethods(CtClass ctClass) throws NotFoundException, CannotCompileException {
        for (CtMethod ctMethod : ctClass.getDeclaredMethods()) {
            fixMethod(ctClass, ctMethod, true);
        }
        CtMethod equalsMethod = ctClass.getMethod("equals", "(Ljava/lang/Object;)Z");
        CtMethod hashCodeMethod = ctClass.getMethod("hashCode", "()I");
        CtMethod toStringMethod = ctClass.getMethod("toString", "()Ljava/lang/String;");
        fixMethod(ctClass, equalsMethod, false);
        fixMethod(ctClass, hashCodeMethod, false);
        fixMethod(ctClass, toStringMethod, false);
    }

    private String describe(CtMethod ctMethod) throws NotFoundException {
        return Modifier.toString(ctMethod.getModifiers()) + " " + ctMethod.getReturnType().getSimpleName() + " " + ctMethod.getLongName();
    }

    private void fixMethod(CtClass ctClass, CtMethod ctMethod, boolean wasFoundInClass) throws NotFoundException {
        String describeBefore = describe(ctMethod);
        try {
            CtClass declaringClass = ctMethod.getDeclaringClass();
            int originalModifiers = ctMethod.getModifiers();
            boolean wasNative = Modifier.isNative(originalModifiers);
            boolean wasFinal = Modifier.isFinal(originalModifiers);
            boolean wasAbstract = Modifier.isAbstract(originalModifiers);
            boolean wasDeclaredInClass = ctClass == declaringClass;
            if (!wasFinal || !ctClass.isEnum()) {
                int newModifiers = originalModifiers;
                if (wasNative) {
                    newModifiers = Modifier.clear(newModifiers, 256);
                }
                if (wasFinal) {
                    newModifiers = Modifier.clear(newModifiers, 16);
                }
                if (wasFoundInClass) {
                    ctMethod.setModifiers(newModifiers);
                }
                CtClass returnCtClass = ctMethod.getReturnType();
                Type returnType = Type.find(returnCtClass);
                String methodName = ctMethod.getName();
                CtClass[] paramTypes = ctMethod.getParameterTypes();
                String methodBody = generateMethodBody(ctClass, ctMethod, wasNative, wasAbstract, returnCtClass, returnType, Modifier.isStatic(originalModifiers), !wasFoundInClass);
                if (!wasFoundInClass) {
                    CtMethod newMethod = makeNewMethod(ctClass, ctMethod, returnCtClass, methodName, paramTypes, "{\n" + methodBody + generateCallToSuper(methodName, paramTypes) + "\n}");
                    newMethod.setModifiers(newModifiers);
                    if (wasDeclaredInClass) {
                        ctMethod.insertBefore("{\n" + methodBody + "}\n");
                    } else {
                        ctClass.addMethod(newMethod);
                    }
                } else if (wasAbstract || wasNative) {
                    ctMethod.setBody(makeNewMethod(ctClass, ctMethod, returnCtClass, methodName, paramTypes, "{\n" + methodBody + "\n}"), (ClassMap) null);
                } else {
                    ctMethod.insertBefore("{\n" + methodBody + "}\n");
                }
            }
        } catch (Exception e) {
            throw new RuntimeException("problem instrumenting " + describeBefore, e);
        }
    }

    private CtMethod makeNewMethod(CtClass ctClass, CtMethod ctMethod, CtClass returnCtClass, String methodName, CtClass[] paramTypes, String methodBody) throws CannotCompileException, NotFoundException {
        return CtNewMethod.make(ctMethod.getModifiers(), returnCtClass, methodName, paramTypes, ctMethod.getExceptionTypes(), methodBody, ctClass);
    }

    public String generateCallToSuper(String methodName, CtClass[] paramTypes) {
        return "return super." + methodName + "(" + makeParameterReplacementList(paramTypes.length) + ");";
    }

    public String makeParameterReplacementList(int length) {
        if (length == 0) {
            return "";
        }
        String parameterReplacementList = "$1";
        for (int i = 2; i <= length; i++) {
            parameterReplacementList = parameterReplacementList + ", $" + i;
        }
        return parameterReplacementList;
    }

    private String generateMethodBody(CtClass ctClass, CtMethod ctMethod, boolean wasNative, boolean wasAbstract, CtClass returnCtClass, Type returnType, boolean aStatic, boolean shouldGenerateCallToSuper) throws NotFoundException {
        String methodBody;
        if (wasAbstract) {
            methodBody = returnType.isVoid() ? "" : "return " + returnType.defaultReturnString() + ";";
        } else {
            methodBody = generateMethodBody(ctClass, ctMethod, returnCtClass, returnType, aStatic, shouldGenerateCallToSuper);
        }
        if (!wasNative) {
            return methodBody;
        }
        return methodBody + (returnType.isVoid() ? "" : "return " + returnType.defaultReturnString() + ";");
    }

    public String generateMethodBody(CtClass ctClass, CtMethod ctMethod, CtClass returnCtClass, Type returnType, boolean isStatic, boolean shouldGenerateCallToSuper) throws NotFoundException {
        boolean returnsVoid = returnType.isVoid();
        String className = ctClass.getName();
        StringBuilder buf = new StringBuilder();
        buf.append("if (!");
        buf.append(RobolectricInternals.class.getName());
        buf.append(".shouldCallDirectly(");
        buf.append(isStatic ? className + ".class" : "this");
        buf.append(")) {\n");
        if (!returnsVoid) {
            buf.append("Object x = ");
        }
        buf.append(RobolectricInternals.class.getName());
        buf.append(".methodInvoked(\n  ");
        buf.append(className);
        buf.append(".class, \"");
        buf.append(ctMethod.getName());
        buf.append("\", ");
        if (!isStatic) {
            buf.append("this");
        } else {
            buf.append("null");
        }
        buf.append(", ");
        appendParamTypeArray(buf, ctMethod);
        buf.append(", ");
        appendParamArray(buf, ctMethod);
        buf.append(")");
        buf.append(";\n");
        if (!returnsVoid) {
            buf.append("if (x != null) return ((");
            buf.append(returnType.nonPrimitiveClassName(returnCtClass));
            buf.append(") x)");
            buf.append(returnType.unboxString());
            buf.append(";\n");
            if (shouldGenerateCallToSuper) {
                buf.append(generateCallToSuper(ctMethod.getName(), ctMethod.getParameterTypes()));
            } else {
                buf.append("return ");
                buf.append(returnType.defaultReturnString());
                buf.append(";\n");
            }
        } else {
            buf.append("return;\n");
        }
        buf.append("}\n");
        return buf.toString();
    }

    private void appendParamTypeArray(StringBuilder buf, CtMethod ctMethod) throws NotFoundException {
        CtClass[] parameterTypes = ctMethod.getParameterTypes();
        if (parameterTypes.length == 0) {
            buf.append("new String[0]");
            return;
        }
        buf.append("new String[] {");
        for (int i = 0; i < parameterTypes.length; i++) {
            if (i > 0) {
                buf.append(", ");
            }
            buf.append("\"");
            buf.append(parameterTypes[i].getName());
            buf.append("\"");
        }
        buf.append("}");
    }

    private void appendParamArray(StringBuilder buf, CtMethod ctMethod) throws NotFoundException {
        int parameterCount = ctMethod.getParameterTypes().length;
        if (parameterCount == 0) {
            buf.append("new Object[0]");
            return;
        }
        buf.append("new Object[] {");
        for (int i = 0; i < parameterCount; i++) {
            if (i > 0) {
                buf.append(", ");
            }
            buf.append(RobolectricInternals.class.getName());
            buf.append(".autobox(");
            buf.append("$").append(i + 1);
            buf.append(")");
        }
        buf.append("}");
    }

    private boolean declareField(CtClass ctClass, String fieldName, CtClass fieldType) throws CannotCompileException, NotFoundException {
        CtMethod ctMethod = getMethod(ctClass, "get" + fieldName, "");
        if (ctMethod == null || !ctMethod.getReturnType().equals(fieldType)) {
            return false;
        }
        if (getField(ctClass, fieldName) == null) {
            CtField field = new CtField(fieldType, fieldName, ctClass);
            field.setModifiers(2);
            ctClass.addField(field);
        }
        return true;
    }

    private CtField getField(CtClass ctClass, String fieldName) {
        try {
            return ctClass.getField(fieldName);
        } catch (NotFoundException e) {
            return null;
        }
    }

    private CtMethod getMethod(CtClass ctClass, String methodName, String desc) {
        try {
            return ctClass.getMethod(methodName, desc);
        } catch (NotFoundException e) {
            return null;
        }
    }
}
