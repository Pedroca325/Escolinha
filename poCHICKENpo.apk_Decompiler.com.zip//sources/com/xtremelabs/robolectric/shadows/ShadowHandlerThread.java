package com.xtremelabs.robolectric.shadows;

import android.os.HandlerThread;
import android.os.Looper;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;

@Implements(HandlerThread.class)
public class ShadowHandlerThread {
    private Looper looper;
    private String name;

    public void __constructor__(String name2) {
        __constructor__(name2, -1);
    }

    public void __constructor__(String name2, int priority) {
        this.name = name2;
        this.looper = Looper.getMainLooper();
    }

    @Implementation
    public void run() {
        Looper.prepare();
        synchronized (this) {
            this.looper = Looper.myLooper();
            notifyAll();
        }
        Looper.loop();
    }

    @Implementation
    public Looper getLooper() {
        synchronized (this) {
            while (this.looper == null) {
                try {
                    wait();
                } catch (InterruptedException e) {
                }
            }
        }
        return this.looper;
    }
}
