package com.xtremelabs.robolectric.shadows;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;

@Implements(Notification.class)
public class ShadowNotification {
    private LatestEventInfo latestEventInfo;
    @RealObject
    Notification realNotification;

    public Notification getRealNotification() {
        return this.realNotification;
    }

    public void __constructor__(int icon, CharSequence tickerText, long when) {
        this.realNotification.icon = icon;
        this.realNotification.tickerText = tickerText;
        this.realNotification.when = when;
    }

    @Implementation
    public void setLatestEventInfo(Context context, CharSequence contentTitle, CharSequence contentText, PendingIntent contentIntent) {
        this.latestEventInfo = new LatestEventInfo(contentTitle, contentText, contentIntent);
        this.realNotification.contentIntent = contentIntent;
    }

    public LatestEventInfo getLatestEventInfo() {
        return this.latestEventInfo;
    }

    public static class LatestEventInfo {
        private final PendingIntent contentIntent;
        private final CharSequence contentText;
        private final CharSequence contentTitle;

        private LatestEventInfo(CharSequence contentTitle2, CharSequence contentText2, PendingIntent contentIntent2) {
            this.contentTitle = contentTitle2;
            this.contentText = contentText2;
            this.contentIntent = contentIntent2;
        }

        public CharSequence getContentTitle() {
            return this.contentTitle;
        }

        public CharSequence getContentText() {
            return this.contentText;
        }

        public PendingIntent getContentIntent() {
            return this.contentIntent;
        }
    }
}
