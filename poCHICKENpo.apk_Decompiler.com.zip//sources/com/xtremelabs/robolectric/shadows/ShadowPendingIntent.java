package com.xtremelabs.robolectric.shadows;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.TestIntentSender;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;

@Implements(PendingIntent.class)
public class ShadowPendingIntent {
    private boolean isActivityIntent;
    private boolean isBroadcastIntent;
    private boolean isServiceIntent;
    private int requestCode;
    private Context savedContext;
    private Intent savedIntent;

    @Implementation
    public static PendingIntent getActivity(Context context, int requestCode2, Intent intent, int flags) {
        return create(context, intent, true, false, false, requestCode2);
    }

    @Implementation
    public static PendingIntent getBroadcast(Context context, int requestCode2, Intent intent, int flags) {
        return create(context, intent, false, true, false, requestCode2);
    }

    @Implementation
    public static PendingIntent getService(Context context, int requestCode2, Intent intent, int flags) {
        return create(context, intent, false, false, true, requestCode2);
    }

    @Implementation
    public void send() throws PendingIntent.CanceledException {
        send(this.savedContext, 0, this.savedIntent);
    }

    @Implementation
    public void send(Context context, int code, Intent intent) throws PendingIntent.CanceledException {
        this.savedIntent.fillIn(intent, 0);
        if (this.isActivityIntent) {
            context.startActivity(this.savedIntent);
        } else if (this.isBroadcastIntent) {
            context.sendBroadcast(this.savedIntent);
        } else if (this.isServiceIntent) {
            context.startService(this.savedIntent);
        }
    }

    @Implementation
    public IntentSender getIntentSender() {
        TestIntentSender testIntentSender = new TestIntentSender();
        testIntentSender.intent = this.savedIntent;
        return testIntentSender;
    }

    public boolean isActivityIntent() {
        return this.isActivityIntent;
    }

    public boolean isBroadcastIntent() {
        return this.isBroadcastIntent;
    }

    public boolean isServiceIntent() {
        return this.isServiceIntent;
    }

    public Context getSavedContext() {
        return this.savedContext;
    }

    public Intent getSavedIntent() {
        return this.savedIntent;
    }

    public int getRequestCode() {
        return this.requestCode;
    }

    private static PendingIntent create(Context context, Intent intent, boolean isActivity, boolean isBroadcast, boolean isService, int requestCode2) {
        PendingIntent pendingIntent = (PendingIntent) Robolectric.newInstanceOf(PendingIntent.class);
        ShadowPendingIntent shadowPendingIntent = Robolectric.shadowOf(pendingIntent);
        shadowPendingIntent.savedIntent = intent;
        shadowPendingIntent.isActivityIntent = isActivity;
        shadowPendingIntent.isBroadcastIntent = isBroadcast;
        shadowPendingIntent.isServiceIntent = isService;
        shadowPendingIntent.savedContext = context;
        shadowPendingIntent.requestCode = requestCode2;
        return pendingIntent;
    }
}
