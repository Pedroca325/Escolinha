package com.xtremelabs.robolectric.shadows;

import android.content.Context;
import android.net.Uri;
import android.support.v4.content.CursorLoader;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;

@Implements(CursorLoader.class)
public class ShadowCursorLoader {
    private Context context;
    private String[] projection;
    private String selection;
    private String[] selectionArgs;
    private String sortOrder;
    private Uri uri;

    public void __constructor__(Context context2) {
        this.context = context2;
    }

    public void __constructor__(Context context2, Uri uri2, String[] projection2, String selection2, String[] selectionArgs2, String sortOrder2) {
        this.context = context2;
        this.uri = uri2;
        this.projection = projection2;
        this.selection = selection2;
        this.selectionArgs = selectionArgs2;
        this.sortOrder = sortOrder2;
    }

    @Implementation
    public Uri getUri() {
        return this.uri;
    }

    @Implementation
    public void setUri(Uri uri2) {
        this.uri = uri2;
    }

    @Implementation
    public String[] getProjection() {
        return this.projection;
    }

    @Implementation
    public void setProjection(String[] projection2) {
        this.projection = projection2;
    }

    @Implementation
    public String getSelection() {
        return this.selection;
    }

    @Implementation
    public void setSelection(String selection2) {
        this.selection = selection2;
    }

    @Implementation
    public String[] getSelectionArgs() {
        return this.selectionArgs;
    }

    @Implementation
    public void setSelectionArgs(String[] selectionArgs2) {
        this.selectionArgs = selectionArgs2;
    }

    @Implementation
    public String getSortOrder() {
        return this.sortOrder;
    }

    @Implementation
    public void setSortOrder(String sortOrder2) {
        this.sortOrder = sortOrder2;
    }
}
