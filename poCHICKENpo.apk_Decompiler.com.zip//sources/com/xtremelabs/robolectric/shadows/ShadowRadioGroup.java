package com.xtremelabs.robolectric.shadows;

import android.widget.RadioGroup;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;

@Implements(RadioGroup.class)
public class ShadowRadioGroup extends ShadowLinearLayout {
    private int checkedRadioButtonId = -1;
    private RadioGroup.OnCheckedChangeListener onCheckedChangeListener;
    @RealObject
    protected RadioGroup realGroup;

    @Implementation
    public int getCheckedRadioButtonId() {
        return this.checkedRadioButtonId;
    }

    @Implementation
    public void check(int id) {
        this.checkedRadioButtonId = id;
        notifyListener();
    }

    @Implementation
    public void clearCheck() {
        notifyListener();
        this.checkedRadioButtonId = -1;
        notifyListener();
    }

    private void notifyListener() {
        if (this.onCheckedChangeListener != null) {
            this.onCheckedChangeListener.onCheckedChanged(this.realGroup, this.checkedRadioButtonId);
        }
    }

    @Implementation
    public void setOnCheckedChangeListener(RadioGroup.OnCheckedChangeListener listener) {
        this.onCheckedChangeListener = listener;
    }
}
