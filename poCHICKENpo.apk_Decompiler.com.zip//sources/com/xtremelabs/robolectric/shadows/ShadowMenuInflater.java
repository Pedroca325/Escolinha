package com.xtremelabs.robolectric.shadows;

import android.content.Context;
import android.view.Menu;
import android.view.MenuInflater;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;

@Implements(MenuInflater.class)
public class ShadowMenuInflater {
    private Context context;

    public void __constructor__(Context context2) {
        this.context = context2;
    }

    @Implementation
    public void inflate(int resource, Menu root) {
        Robolectric.shadowOf(this.context.getApplicationContext()).getResourceLoader().inflateMenu(this.context, resource, root);
    }
}
