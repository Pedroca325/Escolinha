package com.xtremelabs.robolectric.shadows;

import android.graphics.Bitmap;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;
import java.io.IOException;
import java.io.OutputStream;

@Implements(Bitmap.class)
public class ShadowBitmap {
    private Bitmap.Config config;
    private String description = "";
    private int height;
    private int loadedFromResourceId = -1;
    private boolean mutable;
    @RealObject
    private Bitmap realBitmap;
    private boolean recycled = false;
    private int width;

    @Implementation
    public boolean compress(Bitmap.CompressFormat format, int quality, OutputStream stream) {
        try {
            stream.write((this.description + " compressed as " + format + " with quality " + quality).getBytes());
            return true;
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Implementation
    public static Bitmap createBitmap(int width2, int height2, Bitmap.Config config2) {
        Bitmap scaledBitmap = (Bitmap) Robolectric.newInstanceOf(Bitmap.class);
        ShadowBitmap shadowBitmap = Robolectric.shadowOf(scaledBitmap);
        shadowBitmap.appendDescription("Bitmap (" + width2 + " x " + height2 + ")");
        shadowBitmap.setWidth(width2);
        shadowBitmap.setHeight(height2);
        shadowBitmap.setConfig(config2);
        return scaledBitmap;
    }

    @Implementation
    public static Bitmap createBitmap(Bitmap bitmap) {
        Robolectric.shadowOf(bitmap).appendDescription(" created from Bitmap object");
        return bitmap;
    }

    @Implementation
    public static Bitmap createScaledBitmap(Bitmap src, int dstWidth, int dstHeight, boolean filter) {
        Bitmap scaledBitmap = (Bitmap) Robolectric.newInstanceOf(Bitmap.class);
        ShadowBitmap shadowBitmap = Robolectric.shadowOf(scaledBitmap);
        shadowBitmap.appendDescription(Robolectric.shadowOf(src).getDescription());
        shadowBitmap.appendDescription(" scaled to " + dstWidth + " x " + dstHeight);
        if (filter) {
            shadowBitmap.appendDescription(" with filter " + filter);
        }
        shadowBitmap.setWidth(dstWidth);
        shadowBitmap.setHeight(dstHeight);
        return scaledBitmap;
    }

    @Implementation
    public void recycle() {
        this.recycled = true;
    }

    @Implementation
    public final boolean isRecycled() {
        return this.recycled;
    }

    @Implementation
    public Bitmap copy(Bitmap.Config config2, boolean isMutable) {
        ShadowBitmap shadowBitmap = Robolectric.shadowOf(this.realBitmap);
        shadowBitmap.setConfig(config2);
        shadowBitmap.setMutable(isMutable);
        return this.realBitmap;
    }

    @Implementation
    public final Bitmap.Config getConfig() {
        return this.config;
    }

    public void setConfig(Bitmap.Config config2) {
        this.config = config2;
    }

    @Implementation
    public final boolean isMutable() {
        return this.mutable;
    }

    public void setMutable(boolean mutable2) {
        this.mutable = mutable2;
    }

    public void appendDescription(String s) {
        this.description += s;
    }

    public void setDescription(String s) {
        this.description = s;
    }

    public String getDescription() {
        return this.description;
    }

    public static Bitmap create(String name) {
        Bitmap bitmap = (Bitmap) Robolectric.newInstanceOf(Bitmap.class);
        Robolectric.shadowOf(bitmap).appendDescription(name);
        return bitmap;
    }

    public void setLoadedFromResourceId(int loadedFromResourceId2) {
        this.loadedFromResourceId = loadedFromResourceId2;
    }

    public int getLoadedFromResourceId() {
        if (this.loadedFromResourceId != -1) {
            return this.loadedFromResourceId;
        }
        throw new IllegalStateException("not loaded from a resource");
    }

    public void setWidth(int width2) {
        this.width = width2;
    }

    @Implementation
    public int getWidth() {
        return this.width;
    }

    public void setHeight(int height2) {
        this.height = height2;
    }

    @Implementation
    public int getHeight() {
        return this.height;
    }

    @Implementation
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != ShadowBitmap.class) {
            return false;
        }
        ShadowBitmap that = Robolectric.shadowOf((Bitmap) o);
        if (this.height != that.height) {
            return false;
        }
        if (this.width != that.width) {
            return false;
        }
        if (this.description != null) {
            if (this.description.equals(that.description)) {
                return true;
            }
        } else if (that.description == null) {
            return true;
        }
        return false;
    }

    @Implementation
    public int hashCode() {
        return (((this.width * 31) + this.height) * 31) + (this.description != null ? this.description.hashCode() : 0);
    }

    @Implementation
    public String toString() {
        return "ShadowBitmap{description='" + this.description + '\'' + ", width=" + this.width + ", height=" + this.height + '}';
    }

    public Bitmap getRealBitmap() {
        return this.realBitmap;
    }
}
