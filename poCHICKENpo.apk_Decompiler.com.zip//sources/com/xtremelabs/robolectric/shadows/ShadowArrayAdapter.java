package com.xtremelabs.robolectric.shadows;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Filter;
import android.widget.TextView;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.res.ResourceLoader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Implements(ArrayAdapter.class)
public class ShadowArrayAdapter<T> extends ShadowBaseAdapter {
    private static final Filter STUB_FILTER = new Filter() {
        /* access modifiers changed from: protected */
        public Filter.FilterResults performFiltering(CharSequence constraint) {
            return null;
        }

        /* access modifiers changed from: protected */
        public void publishResults(CharSequence constraint, Filter.FilterResults results) {
        }
    };
    private Context context;
    private Filter filter;
    private List<T> list;
    private int resource;
    private int textViewResourceId;

    public int getTextViewResourceId() {
        return this.textViewResourceId;
    }

    public int getResourceId() {
        return this.resource;
    }

    public void __constructor__(Context context2, int textViewResourceId2) {
        init(context2, textViewResourceId2, 0, new ArrayList());
    }

    public void __constructor__(Context context2, int resource2, int textViewResourceId2) {
        init(context2, resource2, textViewResourceId2, new ArrayList());
    }

    public void __constructor__(Context context2, int textViewResourceId2, T[] objects) {
        init(context2, textViewResourceId2, 0, Arrays.asList(objects));
    }

    public void __constructor__(Context context2, int resource2, int textViewResourceId2, T[] objects) {
        init(context2, resource2, textViewResourceId2, Arrays.asList(objects));
    }

    public void __constructor__(Context context2, int textViewResourceId2, List<T> objects) {
        init(context2, textViewResourceId2, 0, objects);
    }

    public void __constructor__(Context context2, int resource2, int textViewResourceId2, List<T> objects) {
        init(context2, resource2, textViewResourceId2, objects);
    }

    private void init(Context context2, int resource2, int textViewResourceId2, List<T> objects) {
        this.context = context2;
        this.list = objects;
        this.resource = resource2;
        this.textViewResourceId = textViewResourceId2;
    }

    @Implementation
    public void add(T object) {
        this.list.add(object);
    }

    @Implementation
    public void clear() {
        this.list.clear();
    }

    @Implementation
    public void remove(T object) {
        this.list.remove(object);
    }

    @Implementation
    public void insert(T object, int index) {
        this.list.add(index, object);
    }

    @Implementation
    public Context getContext() {
        return this.context;
    }

    @Implementation
    public int getCount() {
        return this.list.size();
    }

    @Implementation
    public T getItem(int position) {
        return this.list.get(position);
    }

    @Implementation
    public int getPosition(T item) {
        return this.list.indexOf(item);
    }

    @Implementation
    public View getView(int position, View convertView, ViewGroup parent) {
        View view;
        TextView text;
        T item = this.list.get(position);
        if (convertView == null) {
            view = getResourceLoader().inflateView(this.context, this.resource, (ViewGroup) null);
        } else {
            view = convertView;
        }
        if (this.textViewResourceId == 0) {
            text = (TextView) view;
        } else {
            text = (TextView) view.findViewById(this.textViewResourceId);
        }
        if (item instanceof CharSequence) {
            Robolectric.shadowOf(text).setText((CharSequence) (CharSequence) item);
        } else {
            Robolectric.shadowOf(text).setText((CharSequence) item.toString());
        }
        return view;
    }

    @Implementation
    public Filter getFilter() {
        return STUB_FILTER;
    }

    private ResourceLoader getResourceLoader() {
        return Robolectric.shadowOf(Robolectric.application).getResourceLoader();
    }

    @Implementation
    public static ArrayAdapter<CharSequence> createFromResource(Context context2, int textArrayResId, int textViewResId) {
        return new ArrayAdapter<>(context2, textViewResId, context2.getResources().getTextArray(textArrayResId));
    }
}
