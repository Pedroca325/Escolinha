package com.xtremelabs.robolectric.shadows;

import android.content.ContentValues;
import android.util.Log;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

@Implements(ContentValues.class)
public final class ShadowContentValues {
    private static final String TAG = "ShadowContentValues";
    private HashMap<String, Object> values = new HashMap<>();

    public void __constructor__(ContentValues from) {
        this.values = new HashMap<>(Robolectric.shadowOf(from).values);
    }

    @Implementation
    public void put(String key, String value) {
        this.values.put(key, value);
    }

    @Implementation
    public void putAll(ContentValues other) {
        this.values.putAll(Robolectric.shadowOf(other).values);
    }

    @Implementation
    public void put(String key, Byte value) {
        this.values.put(key, value);
    }

    @Implementation
    public void put(String key, Short value) {
        this.values.put(key, value);
    }

    @Implementation
    public void put(String key, Integer value) {
        this.values.put(key, value);
    }

    @Implementation
    public void put(String key, Long value) {
        this.values.put(key, value);
    }

    @Implementation
    public void put(String key, Float value) {
        this.values.put(key, value);
    }

    @Implementation
    public void put(String key, Double value) {
        this.values.put(key, value);
    }

    @Implementation
    public void put(String key, Boolean value) {
        this.values.put(key, value);
    }

    @Implementation
    public void put(String key, byte[] value) {
        this.values.put(key, value);
    }

    @Implementation
    public void putNull(String key) {
        this.values.put(key, (Object) null);
    }

    @Implementation
    public int size() {
        return this.values.size();
    }

    @Implementation
    public void remove(String key) {
        this.values.remove(key);
    }

    @Implementation
    public void clear() {
        this.values.clear();
    }

    @Implementation
    public boolean containsKey(String key) {
        return this.values.containsKey(key);
    }

    @Implementation
    public Object get(String key) {
        return this.values.get(key);
    }

    @Implementation
    public String getAsString(String key) {
        Object value = this.values.get(key);
        if (value != null) {
            return value.toString();
        }
        return null;
    }

    @Implementation
    public Long getAsLong(String key) {
        Long l;
        Object value = this.values.get(key);
        if (value != null) {
            try {
                l = Long.valueOf(((Number) value).longValue());
            } catch (ClassCastException e) {
                if (value instanceof CharSequence) {
                    try {
                        return Long.valueOf(value.toString());
                    } catch (NumberFormatException e2) {
                        Log.e(TAG, "Cannot parse Long value for " + value + " at key " + key);
                        return null;
                    }
                } else {
                    Log.e(TAG, "Cannot cast value for " + key + " to a Long: " + value, e);
                    return null;
                }
            }
        } else {
            l = null;
        }
        return l;
    }

    @Implementation
    public Integer getAsInteger(String key) {
        Integer num;
        Object value = this.values.get(key);
        if (value != null) {
            try {
                num = Integer.valueOf(((Number) value).intValue());
            } catch (ClassCastException e) {
                if (value instanceof CharSequence) {
                    try {
                        return Integer.valueOf(value.toString());
                    } catch (NumberFormatException e2) {
                        Log.e(TAG, "Cannot parse Integer value for " + value + " at key " + key);
                        return null;
                    }
                } else {
                    Log.e(TAG, "Cannot cast value for " + key + " to a Integer: " + value, e);
                    return null;
                }
            }
        } else {
            num = null;
        }
        return num;
    }

    @Implementation
    public Short getAsShort(String key) {
        Short sh;
        Object value = this.values.get(key);
        if (value != null) {
            try {
                sh = Short.valueOf(((Number) value).shortValue());
            } catch (ClassCastException e) {
                if (value instanceof CharSequence) {
                    try {
                        return Short.valueOf(value.toString());
                    } catch (NumberFormatException e2) {
                        Log.e(TAG, "Cannot parse Short value for " + value + " at key " + key);
                        return null;
                    }
                } else {
                    Log.e(TAG, "Cannot cast value for " + key + " to a Short: " + value, e);
                    return null;
                }
            }
        } else {
            sh = null;
        }
        return sh;
    }

    @Implementation
    public Byte getAsByte(String key) {
        Byte b;
        Object value = this.values.get(key);
        if (value != null) {
            try {
                b = Byte.valueOf(((Number) value).byteValue());
            } catch (ClassCastException e) {
                if (value instanceof CharSequence) {
                    try {
                        return Byte.valueOf(value.toString());
                    } catch (NumberFormatException e2) {
                        Log.e(TAG, "Cannot parse Byte value for " + value + " at key " + key);
                        return null;
                    }
                } else {
                    Log.e(TAG, "Cannot cast value for " + key + " to a Byte: " + value, e);
                    return null;
                }
            }
        } else {
            b = null;
        }
        return b;
    }

    @Implementation
    public Double getAsDouble(String key) {
        Double d;
        Object value = this.values.get(key);
        if (value != null) {
            try {
                d = Double.valueOf(((Number) value).doubleValue());
            } catch (ClassCastException e) {
                if (value instanceof CharSequence) {
                    try {
                        return Double.valueOf(value.toString());
                    } catch (NumberFormatException e2) {
                        Log.e(TAG, "Cannot parse Double value for " + value + " at key " + key);
                        return null;
                    }
                } else {
                    Log.e(TAG, "Cannot cast value for " + key + " to a Double: " + value, e);
                    return null;
                }
            }
        } else {
            d = null;
        }
        return d;
    }

    @Implementation
    public Float getAsFloat(String key) {
        Float f;
        Object value = this.values.get(key);
        if (value != null) {
            try {
                f = Float.valueOf(((Number) value).floatValue());
            } catch (ClassCastException e) {
                if (value instanceof CharSequence) {
                    try {
                        return Float.valueOf(value.toString());
                    } catch (NumberFormatException e2) {
                        Log.e(TAG, "Cannot parse Float value for " + value + " at key " + key);
                        return null;
                    }
                } else {
                    Log.e(TAG, "Cannot cast value for " + key + " to a Float: " + value, e);
                    return null;
                }
            }
        } else {
            f = null;
        }
        return f;
    }

    @Implementation
    public Boolean getAsBoolean(String key) {
        Object value = this.values.get(key);
        try {
            return (Boolean) value;
        } catch (ClassCastException e) {
            if (value instanceof CharSequence) {
                return Boolean.valueOf(value.toString());
            }
            Log.e(TAG, "Cannot cast value for " + key + " to a Boolean: " + value, e);
            return null;
        }
    }

    @Implementation
    public byte[] getAsByteArray(String key) {
        Object value = this.values.get(key);
        if (value instanceof byte[]) {
            return (byte[]) value;
        }
        return null;
    }

    @Implementation
    public Set<Map.Entry<String, Object>> valueSet() {
        return this.values.entrySet();
    }

    @Implementation
    public int describeContents() {
        return 0;
    }

    @Implementation
    public boolean equals(Object object) {
        Object o;
        if (object == null || (o = Robolectric.shadowOf_(object)) == null) {
            return false;
        }
        if (this == o) {
            return true;
        }
        if (getClass() != o.getClass() || !(o instanceof ContentValues)) {
            return false;
        }
        return this.values.equals(Robolectric.shadowOf((ContentValues) o).values);
    }

    @Implementation
    public int hashCode() {
        return this.values.hashCode();
    }

    @Implementation
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (String name : this.values.keySet()) {
            String value = getAsString(name);
            if (sb.length() > 0) {
                sb.append(" ");
            }
            sb.append(name + "=" + value);
        }
        return sb.toString();
    }
}
