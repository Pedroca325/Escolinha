package com.xtremelabs.robolectric.shadows;

import android.widget.Spinner;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;

@Implements(Spinner.class)
public class ShadowSpinner extends ShadowAbsSpinner {
    private CharSequence prompt;

    @Implementation
    public void setPrompt(CharSequence prompt2) {
        this.prompt = prompt2;
    }

    @Implementation
    public CharSequence getPrompt() {
        return this.prompt;
    }
}
