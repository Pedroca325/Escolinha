package com.xtremelabs.robolectric.shadows;

import android.webkit.CookieManager;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import java.util.HashMap;
import java.util.Map;

@Implements(CookieManager.class)
public class ShadowCookieManager {
    private static CookieManager sRef;
    private boolean accept;
    private Map<String, String> cookies = new HashMap();

    @Implementation
    public static CookieManager getInstance() {
        if (sRef == null) {
            sRef = (CookieManager) Robolectric.newInstanceOf(CookieManager.class);
        }
        return sRef;
    }

    @Implementation
    public void setCookie(String url, String value) {
        this.cookies.put(url, value);
    }

    @Implementation
    public String getCookie(String url) {
        return this.cookies.get(url);
    }

    @Implementation
    public void setAcceptCookie(boolean accept2) {
        this.accept = accept2;
    }

    @Implementation
    public boolean acceptCookie() {
        return this.accept;
    }

    @Implementation
    public void removeAllCookie() {
        this.cookies.clear();
    }
}
