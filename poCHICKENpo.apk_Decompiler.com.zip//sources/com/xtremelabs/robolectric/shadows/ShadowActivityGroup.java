package com.xtremelabs.robolectric.shadows;

import android.app.Activity;
import android.app.ActivityGroup;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;

@Implements(ActivityGroup.class)
public class ShadowActivityGroup extends ShadowActivity {
    private Activity currentActivity;

    @Implementation
    public Activity getCurrentActivity() {
        return this.currentActivity;
    }

    public void setCurrentActivity(Activity activity) {
        this.currentActivity = activity;
    }
}
