package com.xtremelabs.robolectric.shadows;

import android.location.Location;
import android.os.Bundle;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;

@Implements(Location.class)
public class ShadowLocation {
    private float accuracy;
    private Bundle extras = new Bundle();
    private double latitude;
    private double longitude;
    private float mDistance = 0.0f;
    private float mInitialBearing = 0.0f;
    private double mLat1 = 0.0d;
    private double mLat2 = 0.0d;
    private double mLon1 = 0.0d;
    private double mLon2 = 0.0d;
    private float[] mResults = new float[2];
    private String provider;
    private long time;

    public void __constructor__(String provider2) {
        this.provider = provider2;
        this.time = System.currentTimeMillis();
    }

    @Implementation
    public String getProvider() {
        return this.provider;
    }

    @Implementation
    public void setProvider(String provider2) {
        this.provider = provider2;
    }

    @Implementation
    public long getTime() {
        return this.time;
    }

    @Implementation
    public void setTime(long time2) {
        this.time = time2;
    }

    @Implementation
    public double getLatitude() {
        return this.latitude;
    }

    @Implementation
    public void setLatitude(double latitude2) {
        this.latitude = latitude2;
    }

    @Implementation
    public double getLongitude() {
        return this.longitude;
    }

    @Implementation
    public void setLongitude(double longitude2) {
        this.longitude = longitude2;
    }

    @Implementation
    public float getAccuracy() {
        return this.accuracy;
    }

    @Implementation
    public void setAccuracy(float accuracy2) {
        this.accuracy = accuracy2;
    }

    @Implementation
    public boolean equals(Object o) {
        Object o2;
        if (o == null || (o2 = Robolectric.shadowOf_(o)) == null || getClass() != o2.getClass()) {
            return false;
        }
        if (this == o2) {
            return true;
        }
        ShadowLocation that = (ShadowLocation) o2;
        if (Double.compare(that.latitude, this.latitude) != 0 || Double.compare(that.longitude, this.longitude) != 0 || this.time != that.time) {
            return false;
        }
        if (this.provider != null) {
            if (!this.provider.equals(that.provider)) {
                return false;
            }
        } else if (that.provider != null) {
            return false;
        }
        if (this.accuracy == that.accuracy) {
            return true;
        }
        return false;
    }

    @Implementation
    public int hashCode() {
        long temp;
        long temp2;
        long temp3;
        int result = (((int) (this.time ^ (this.time >>> 32))) * 31) + (this.provider != null ? this.provider.hashCode() : 0);
        if (this.latitude != 0.0d) {
            temp = Double.doubleToLongBits(this.latitude);
        } else {
            temp = 0;
        }
        int result2 = (result * 31) + ((int) ((temp >>> 32) ^ temp));
        if (this.longitude != 0.0d) {
            temp2 = Double.doubleToLongBits(this.longitude);
        } else {
            temp2 = 0;
        }
        int result3 = (result2 * 31) + ((int) ((temp2 >>> 32) ^ temp2));
        if (this.accuracy != 0.0f) {
            temp3 = (long) Float.floatToIntBits(this.accuracy);
        } else {
            temp3 = 0;
        }
        return (result3 * 31) + ((int) ((temp3 >>> 32) ^ temp3));
    }

    @Implementation
    public String toString() {
        return "Location{time=" + this.time + ", provider='" + this.provider + '\'' + ", latitude=" + this.latitude + ", longitude=" + this.longitude + ", accuracy=" + this.accuracy + '}';
    }

    private static void computeDistanceAndBearing(double lat1, double lon1, double lat2, double lon2, float[] results) {
        double cos2SM;
        double f = (6378137.0d - 6356752.3142d) / 6378137.0d;
        double aSqMinusBSqOverBSq = ((6378137.0d * 6378137.0d) - (6356752.3142d * 6356752.3142d)) / (6356752.3142d * 6356752.3142d);
        double L = (lon2 * 0.017453292519943295d) - (lon1 * 0.017453292519943295d);
        double A = 0.0d;
        double U1 = Math.atan((1.0d - f) * Math.tan(lat1 * 0.017453292519943295d));
        double U2 = Math.atan((1.0d - f) * Math.tan(lat2 * 0.017453292519943295d));
        double cosU1 = Math.cos(U1);
        double cosU2 = Math.cos(U2);
        double sinU1 = Math.sin(U1);
        double sinU2 = Math.sin(U2);
        double cosU1cosU2 = cosU1 * cosU2;
        double sinU1sinU2 = sinU1 * sinU2;
        double sigma = 0.0d;
        double deltaSigma = 0.0d;
        double cosLambda = 0.0d;
        double sinLambda = 0.0d;
        double lambda = L;
        for (int iter = 0; iter < 20; iter++) {
            double lambdaOrig = lambda;
            cosLambda = Math.cos(lambda);
            sinLambda = Math.sin(lambda);
            double t1 = cosU2 * sinLambda;
            double t2 = (cosU1 * sinU2) - ((sinU1 * cosU2) * cosLambda);
            double sinSigma = Math.sqrt((t1 * t1) + (t2 * t2));
            double cosSigma = sinU1sinU2 + (cosU1cosU2 * cosLambda);
            sigma = Math.atan2(sinSigma, cosSigma);
            double sinAlpha = sinSigma == 0.0d ? 0.0d : (cosU1cosU2 * sinLambda) / sinSigma;
            double cosSqAlpha = 1.0d - (sinAlpha * sinAlpha);
            if (cosSqAlpha == 0.0d) {
                cos2SM = 0.0d;
            } else {
                cos2SM = cosSigma - ((2.0d * sinU1sinU2) / cosSqAlpha);
            }
            double uSquared = cosSqAlpha * aSqMinusBSqOverBSq;
            A = 1.0d + ((uSquared / 16384.0d) * (4096.0d + ((-768.0d + ((320.0d - (175.0d * uSquared)) * uSquared)) * uSquared)));
            double B = (uSquared / 1024.0d) * (256.0d + ((-128.0d + ((74.0d - (47.0d * uSquared)) * uSquared)) * uSquared));
            double C = (f / 16.0d) * cosSqAlpha * (4.0d + ((4.0d - (3.0d * cosSqAlpha)) * f));
            double cos2SMSq = cos2SM * cos2SM;
            deltaSigma = B * sinSigma * (((B / 4.0d) * (((-1.0d + (2.0d * cos2SMSq)) * cosSigma) - ((((B / 6.0d) * cos2SM) * (-3.0d + ((4.0d * sinSigma) * sinSigma))) * (-3.0d + (4.0d * cos2SMSq))))) + cos2SM);
            lambda = L + ((1.0d - C) * f * sinAlpha * ((C * sinSigma * ((C * cosSigma * (-1.0d + (2.0d * cos2SM * cos2SM))) + cos2SM)) + sigma));
            if (Math.abs((lambda - lambdaOrig) / lambda) < 1.0E-12d) {
                break;
            }
        }
        results[0] = (float) (6356752.3142d * A * (sigma - deltaSigma));
        if (results.length > 1) {
            results[1] = (float) (((double) ((float) Math.atan2(cosU2 * sinLambda, (cosU1 * sinU2) - ((sinU1 * cosU2) * cosLambda)))) * 57.29577951308232d);
            if (results.length > 2) {
                results[2] = (float) (((double) ((float) Math.atan2(cosU1 * sinLambda, ((-sinU1) * cosU2) + (cosU1 * sinU2 * cosLambda)))) * 57.29577951308232d);
            }
        }
    }

    @Implementation
    public static void distanceBetween(double startLatitude, double startLongitude, double endLatitude, double endLongitude, float[] results) {
        if (results == null || results.length < 1) {
            throw new IllegalArgumentException("results is null or has length < 1");
        }
        computeDistanceAndBearing(startLatitude, startLongitude, endLatitude, endLongitude, results);
    }

    @Implementation
    public float distanceTo(Location dest) {
        float f;
        synchronized (this.mResults) {
            if (!(this.latitude == this.mLat1 && this.longitude == this.mLon1 && dest.getLatitude() == this.mLat2 && dest.getLongitude() == this.mLon2)) {
                computeDistanceAndBearing(this.latitude, this.longitude, dest.getLatitude(), dest.getLongitude(), this.mResults);
                this.mLat1 = this.latitude;
                this.mLon1 = this.longitude;
                this.mLat2 = dest.getLatitude();
                this.mLon2 = dest.getLongitude();
                this.mDistance = this.mResults[0];
                this.mInitialBearing = this.mResults[1];
            }
            f = this.mDistance;
        }
        return f;
    }

    @Implementation
    public float bearingTo(Location dest) {
        float f;
        synchronized (this.mResults) {
            if (!(this.latitude == this.mLat1 && this.longitude == this.mLon1 && dest.getLatitude() == this.mLat2 && dest.getLongitude() == this.mLon2)) {
                computeDistanceAndBearing(this.latitude, this.longitude, dest.getLatitude(), dest.getLongitude(), this.mResults);
                this.mLat1 = this.latitude;
                this.mLon1 = this.longitude;
                this.mLat2 = dest.getLatitude();
                this.mLon2 = dest.getLongitude();
                this.mDistance = this.mResults[0];
                this.mInitialBearing = this.mResults[1];
            }
            f = this.mInitialBearing;
        }
        return f;
    }

    @Implementation
    public Bundle getExtras() {
        return this.extras;
    }

    @Implementation
    public void setExtras(Bundle extras2) {
        this.extras = extras2;
    }
}
