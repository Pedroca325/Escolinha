package com.xtremelabs.robolectric.shadows;

import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;
import com.xtremelabs.robolectric.tester.org.apache.http.HttpRequestInfo;
import java.io.IOException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.ConnectionReuseStrategy;
import org.apache.http.HttpException;
import org.apache.http.HttpHost;
import org.apache.http.HttpRequest;
import org.apache.http.HttpResponse;
import org.apache.http.client.AuthenticationHandler;
import org.apache.http.client.HttpRequestRetryHandler;
import org.apache.http.client.RedirectHandler;
import org.apache.http.client.UserTokenHandler;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.ConnectionKeepAliveStrategy;
import org.apache.http.conn.routing.HttpRoutePlanner;
import org.apache.http.impl.client.DefaultRequestDirector;
import org.apache.http.params.HttpParams;
import org.apache.http.protocol.HttpContext;
import org.apache.http.protocol.HttpProcessor;
import org.apache.http.protocol.HttpRequestExecutor;

@Implements(DefaultRequestDirector.class)
public class ShadowDefaultRequestDirector {
    protected ConnectionKeepAliveStrategy connectionKeepAliveStrategy;
    protected ClientConnectionManager connectionManager;
    protected ConnectionReuseStrategy connectionReuseStrategy;
    protected HttpParams httpParams;
    protected HttpProcessor httpProcessor;
    protected HttpRequestExecutor httpRequestExecutor;
    protected HttpRequestRetryHandler httpRequestRetryHandler;
    protected HttpRoutePlanner httpRoutePlanner;
    protected Log log;
    protected AuthenticationHandler proxyAuthenticationHandler;
    @RealObject
    DefaultRequestDirector realObject;
    protected RedirectHandler redirectHandler;
    com.xtremelabs.robolectric.tester.org.apache.http.impl.client.DefaultRequestDirector redirector;
    protected AuthenticationHandler targetAuthenticationHandler;
    protected UserTokenHandler userTokenHandler;

    public void __constructor__(Log log2, HttpRequestExecutor requestExec, ClientConnectionManager conman, ConnectionReuseStrategy reustrat, ConnectionKeepAliveStrategy kastrat, HttpRoutePlanner rouplan, HttpProcessor httpProcessor2, HttpRequestRetryHandler retryHandler, RedirectHandler redirectHandler2, AuthenticationHandler targetAuthHandler, AuthenticationHandler proxyAuthHandler, UserTokenHandler userTokenHandler2, HttpParams params) {
        this.log = log2;
        this.httpRequestExecutor = requestExec;
        this.connectionManager = conman;
        this.connectionReuseStrategy = reustrat;
        this.connectionKeepAliveStrategy = kastrat;
        this.httpRoutePlanner = rouplan;
        this.httpProcessor = httpProcessor2;
        this.httpRequestRetryHandler = retryHandler;
        this.redirectHandler = redirectHandler2;
        this.targetAuthenticationHandler = targetAuthHandler;
        this.proxyAuthenticationHandler = proxyAuthHandler;
        this.userTokenHandler = userTokenHandler2;
        this.httpParams = params;
        try {
            this.redirector = new com.xtremelabs.robolectric.tester.org.apache.http.impl.client.DefaultRequestDirector(log2, requestExec, conman, reustrat, kastrat, rouplan, httpProcessor2, retryHandler, redirectHandler2, targetAuthHandler, proxyAuthHandler, userTokenHandler2, params);
        } catch (IllegalArgumentException e) {
            Robolectric.getFakeHttpLayer().interceptHttpRequests(true);
        }
    }

    public void __constructor__(HttpRequestExecutor requestExec, ClientConnectionManager conman, ConnectionReuseStrategy reustrat, ConnectionKeepAliveStrategy kastrat, HttpRoutePlanner rouplan, HttpProcessor httpProcessor2, HttpRequestRetryHandler retryHandler, RedirectHandler redirectHandler2, AuthenticationHandler targetAuthHandler, AuthenticationHandler proxyAuthHandler, UserTokenHandler userTokenHandler2, HttpParams params) {
        __constructor__(LogFactory.getLog(DefaultRequestDirector.class), requestExec, conman, reustrat, kastrat, rouplan, httpProcessor2, retryHandler, redirectHandler2, targetAuthHandler, proxyAuthHandler, userTokenHandler2, params);
    }

    public static HttpRequest getSentHttpRequest(int index) {
        return getSentHttpRequestInfo(index).getHttpRequest();
    }

    public static HttpRequest getLatestSentHttpRequest() {
        return getLatestSentHttpRequestInfo().getHttpRequest();
    }

    public static HttpRequestInfo getLatestSentHttpRequestInfo() {
        return Robolectric.getFakeHttpLayer().getSentHttpRequestInfo(Robolectric.getFakeHttpLayer().getSentHttpRequestInfos().size() - 1);
    }

    public static HttpRequestInfo getSentHttpRequestInfo(int index) {
        return Robolectric.getFakeHttpLayer().getSentHttpRequestInfo(index);
    }

    @Implementation
    public HttpResponse execute(HttpHost httpHost, HttpRequest httpRequest, HttpContext httpContext) throws HttpException, IOException {
        if (Robolectric.getFakeHttpLayer().isInterceptingHttpRequests()) {
            return Robolectric.getFakeHttpLayer().emulateRequest(httpHost, httpRequest, httpContext, this.realObject);
        }
        return this.redirector.execute(httpHost, httpRequest, httpContext);
    }

    public Log getLog() {
        return this.log;
    }

    public ClientConnectionManager getConnectionManager() {
        return this.connectionManager;
    }

    public HttpRoutePlanner getHttpRoutePlanner() {
        return this.httpRoutePlanner;
    }

    public ConnectionReuseStrategy getConnectionReuseStrategy() {
        return this.connectionReuseStrategy;
    }

    public ConnectionKeepAliveStrategy getConnectionKeepAliveStrategy() {
        return this.connectionKeepAliveStrategy;
    }

    public HttpRequestExecutor getHttpRequestExecutor() {
        return this.httpRequestExecutor;
    }

    public HttpProcessor getHttpProcessor() {
        return this.httpProcessor;
    }

    public HttpRequestRetryHandler getHttpRequestRetryHandler() {
        return this.httpRequestRetryHandler;
    }

    public RedirectHandler getRedirectHandler() {
        return this.redirectHandler;
    }

    public AuthenticationHandler getTargetAuthenticationHandler() {
        return this.targetAuthenticationHandler;
    }

    public AuthenticationHandler getProxyAuthenticationHandler() {
        return this.proxyAuthenticationHandler;
    }

    public UserTokenHandler getUserTokenHandler() {
        return this.userTokenHandler;
    }

    public HttpParams getHttpParams() {
        return this.httpParams;
    }
}
