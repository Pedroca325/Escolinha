package com.xtremelabs.robolectric.shadows;

import android.accounts.Account;
import android.os.Parcel;
import android.text.TextUtils;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;
import java.lang.reflect.Field;

@Implements(Account.class)
public class ShadowAccount {
    @RealObject
    private Account realObject;

    public void __constructor__(String name, String type) throws Exception {
        set(name, type);
    }

    public void __constructor__(Parcel parcel) throws Exception {
        set(parcel.readString(), parcel.readString());
    }

    @Implementation
    public String toString() {
        return "Account {name=" + this.realObject.name + ", type=" + this.realObject.type + "}";
    }

    private void set(String name, String type) throws Exception {
        if (TextUtils.isEmpty(name) || TextUtils.isEmpty(type)) {
            throw new IllegalArgumentException();
        }
        Field nameF = this.realObject.getClass().getField("name");
        nameF.setAccessible(true);
        nameF.set(this.realObject, name);
        Field typeF = this.realObject.getClass().getField("type");
        typeF.setAccessible(true);
        typeF.set(this.realObject, type);
    }

    @Implementation
    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof Account)) {
            return false;
        }
        Account other = (Account) o;
        if (!this.realObject.name.equals(other.name) || !this.realObject.type.equals(other.type)) {
            return false;
        }
        return true;
    }

    @Implementation
    public int hashCode() {
        return ((this.realObject.name.hashCode() + 527) * 31) + this.realObject.type.hashCode();
    }
}
