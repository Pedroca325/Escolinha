package com.xtremelabs.robolectric.shadows;

import android.view.ViewGroup;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;

@Implements(ViewGroup.LayoutParams.class)
public class ShadowLayoutParams {
    @RealObject
    private ViewGroup.LayoutParams realLayoutParams;

    public void __constructor__(int w, int h) {
        this.realLayoutParams.width = w;
        this.realLayoutParams.height = h;
    }
}
