package com.xtremelabs.robolectric.shadows;

import android.app.ListActivity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

@Implements(ListActivity.class)
public class ShadowListActivity extends ShadowActivity {
    private ListAdapter listAdapter;
    private ListView listView;

    @Implementation
    public ListView getListView() {
        if (this.listView == null) {
            ListView findListView = findListView(this.contentView);
            this.listView = findListView;
            if (findListView == null) {
                throw new RuntimeException("No ListView found under content view");
            }
        }
        return this.listView;
    }

    public void setListView(ListView view) {
        this.listView = view;
    }

    @Implementation
    public void setListAdapter(ListAdapter listAdapter2) {
        this.listAdapter = listAdapter2;
        ListView lv = findListView(this.contentView);
        if (lv != null) {
            lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    try {
                        Method handler = ShadowListActivity.this.realActivity.getClass().getDeclaredMethod("onListItemClick", new Class[]{ListView.class, View.class, Integer.TYPE, Long.TYPE});
                        handler.setAccessible(true);
                        handler.invoke(ShadowListActivity.this.realActivity, new Object[]{parent, view, Integer.valueOf(position), Long.valueOf(id)});
                    } catch (IllegalAccessException | NoSuchMethodException | InvocationTargetException e) {
                    }
                }
            });
            lv.setAdapter(listAdapter2);
        }
    }

    @Implementation
    public ListAdapter getListAdapter() {
        return this.listAdapter;
    }

    private ListView findListView(View parent) {
        if (parent instanceof ListView) {
            return (ListView) parent;
        }
        if (parent instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) parent;
            for (int i = 0; i < viewGroup.getChildCount(); i++) {
                ListView listView2 = findListView(viewGroup.getChildAt(i));
                if (listView2 != null) {
                    return listView2;
                }
            }
        }
        return null;
    }
}
