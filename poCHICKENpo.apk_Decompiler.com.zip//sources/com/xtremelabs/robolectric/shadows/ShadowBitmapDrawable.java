package com.xtremelabs.robolectric.shadows;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Shader;
import android.graphics.drawable.BitmapDrawable;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;

@Implements(BitmapDrawable.class)
public class ShadowBitmapDrawable extends ShadowDrawable {
    private Bitmap bitmap;
    private ColorFilter colorFilter;
    private String drawableCreateFromPath;
    private String drawableCreateFromStreamSource;
    @RealObject
    private BitmapDrawable realBitmapDrawable;
    private Shader.TileMode tileModeX;
    private Shader.TileMode tileModeY;

    public void __constructor__(Bitmap bitmap2) {
        this.bitmap = bitmap2;
    }

    @Implementation
    public void draw(Canvas canvas) {
        Paint paint = new Paint();
        paint.setColorFilter(this.colorFilter);
        canvas.drawBitmap(this.realBitmapDrawable.getBitmap(), 0.0f, 0.0f, paint);
    }

    @Implementation
    public void setColorFilter(ColorFilter colorFilter2) {
        this.colorFilter = colorFilter2;
    }

    @Implementation
    public Bitmap getBitmap() {
        return this.bitmap;
    }

    public int getLoadedFromResourceId() {
        return Robolectric.shadowOf(this.bitmap).getLoadedFromResourceId();
    }

    public void setSource(String drawableCreateFromStreamSource2) {
        this.drawableCreateFromStreamSource = drawableCreateFromStreamSource2;
    }

    public String getSource() {
        return this.drawableCreateFromStreamSource;
    }

    public void setPath(String drawableCreateFromPath2) {
        this.drawableCreateFromPath = drawableCreateFromPath2;
    }

    public String getPath() {
        return this.drawableCreateFromPath;
    }

    @Implementation
    public void setTileModeX(Shader.TileMode mode) {
        this.tileModeX = mode;
    }

    @Implementation
    public Shader.TileMode getTileModeX() {
        return this.tileModeX;
    }

    @Implementation
    public void setTileModeY(Shader.TileMode mode) {
        this.tileModeY = mode;
    }

    @Implementation
    public Shader.TileMode getTileModeY() {
        return this.tileModeY;
    }

    @Implementation
    public void setTileModeXY(Shader.TileMode modeX, Shader.TileMode modeY) {
        setTileModeX(modeX);
        setTileModeY(modeY);
    }

    @Implementation
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != ShadowBitmapDrawable.class) {
            return false;
        }
        ShadowBitmapDrawable that = Robolectric.shadowOf((BitmapDrawable) o);
        if (this.bitmap == null ? that.bitmap != null : !this.bitmap.equals(that.bitmap)) {
            return false;
        }
        return super.equals(o);
    }

    @Implementation
    public int hashCode() {
        if (this.bitmap != null) {
            return this.bitmap.hashCode();
        }
        return 0;
    }

    @Implementation
    public String toString() {
        return "ShadowBitmapDrawable{bitmap=" + this.bitmap + '}';
    }
}
