package com.xtremelabs.robolectric.shadows;

import android.location.Address;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;

@Implements(Address.class)
public class ShadowAddress {
    private String addressLine1;
    private String adminArea;
    private String countryCode;
    private boolean hasLatitude;
    private boolean hasLongitude;
    private double latitude;
    private String locality;
    private double longitude;
    private String postalCode;

    @Implementation
    public double getLatitude() {
        return this.latitude;
    }

    @Implementation
    public void setLatitude(double latitude2) {
        this.latitude = latitude2;
    }

    @Implementation
    public double getLongitude() {
        return this.longitude;
    }

    @Implementation
    public void setLongitude(double longitude2) {
        this.longitude = longitude2;
    }

    @Implementation
    public void setAddressLine(int index, String line) {
        this.addressLine1 = line;
    }

    @Implementation
    public String getAddressLine(int index) {
        return this.addressLine1;
    }

    @Implementation
    public void setLocality(String locality2) {
        this.locality = locality2;
    }

    @Implementation
    public String getLocality() {
        return this.locality;
    }

    @Implementation
    public String getAdminArea() {
        return this.adminArea;
    }

    @Implementation
    public void setAdminArea(String adminArea2) {
        this.adminArea = adminArea2;
    }

    @Implementation
    public String getPostalCode() {
        return this.postalCode;
    }

    @Implementation
    public void setPostalCode(String postalCode2) {
        this.postalCode = postalCode2;
    }

    @Implementation
    public String getCountryCode() {
        return this.countryCode;
    }

    @Implementation
    public void setCountryCode(String countryCode2) {
        this.countryCode = countryCode2;
    }

    @Implementation
    public boolean hasLatitude() {
        return this.hasLatitude;
    }

    @Implementation
    public boolean hasLongitude() {
        return this.hasLongitude;
    }

    public void setSimulatedHasLatLong(boolean hasLatitude2, boolean hasLongitude2) {
        this.hasLatitude = hasLatitude2;
        this.hasLongitude = hasLongitude2;
    }
}
