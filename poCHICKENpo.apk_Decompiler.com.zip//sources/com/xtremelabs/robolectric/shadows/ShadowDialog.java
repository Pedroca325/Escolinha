package com.xtremelabs.robolectric.shadows;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;
import com.xtremelabs.robolectric.tester.android.view.TestWindow;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

@Implements(Dialog.class)
public class ShadowDialog {
    private static final ArrayList<Dialog> shownDialogs = new ArrayList<>();
    Context context;
    private boolean hasBeenDismissed;
    private boolean hasShownBefore;
    private View inflatedView;
    private boolean isCancelable = true;
    private boolean isShowing;
    private int layoutId;
    private DialogInterface.OnCancelListener onCancelListener;
    private DialogInterface.OnDismissListener onDismissListener;
    private Activity ownerActivity;
    @RealObject
    private Dialog realDialog;
    private int themeId;
    protected CharSequence title;
    private Window window;

    public static void reset() {
        setLatestDialog((ShadowDialog) null);
        shownDialogs.clear();
    }

    public static Dialog getLatestDialog() {
        ShadowDialog dialog = Robolectric.getShadowApplication().getLatestDialog();
        if (dialog == null) {
            return null;
        }
        return dialog.realDialog;
    }

    public static void setLatestDialog(ShadowDialog latestDialog) {
        Robolectric.getShadowApplication().setLatestDialog(latestDialog);
    }

    public void __constructor__(Context context2) {
        __constructor__(context2, -1);
    }

    public void __constructor__(Context context2, int themeId2) {
        this.context = context2;
        this.themeId = themeId2;
    }

    @Implementation
    public void setContentView(int layoutResID) {
        this.layoutId = layoutResID;
    }

    @Implementation
    public void setContentView(View view) {
        this.inflatedView = view;
    }

    @Implementation
    public void setTitle(int stringResourceId) {
        this.title = this.context.getResources().getText(stringResourceId);
    }

    @Implementation(i18nSafe = false)
    public void setTitle(CharSequence title2) {
        this.title = title2;
    }

    @Implementation
    public void setOwnerActivity(Activity activity) {
        this.ownerActivity = activity;
    }

    @Implementation
    public Activity getOwnerActivity() {
        return this.ownerActivity;
    }

    @Implementation
    public Context getContext() {
        return this.context;
    }

    @Implementation
    public void onBackPressed() {
        cancel();
    }

    @Implementation
    public void show() {
        setLatestDialog(this);
        shownDialogs.add(this.realDialog);
        this.isShowing = true;
        try {
            if (!this.hasShownBefore) {
                Method onCreateMethod = Dialog.class.getDeclaredMethod("onCreate", new Class[]{Bundle.class});
                onCreateMethod.setAccessible(true);
                onCreateMethod.invoke(this.realDialog, new Object[]{null});
            }
            Method onStartMethod = Dialog.class.getDeclaredMethod("onStart", new Class[0]);
            onStartMethod.setAccessible(true);
            onStartMethod.invoke(this.realDialog, new Object[0]);
            this.hasShownBefore = true;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Implementation
    public void hide() {
        this.isShowing = false;
    }

    @Implementation
    public boolean isShowing() {
        return this.isShowing;
    }

    @Implementation
    public void dismiss() {
        this.isShowing = false;
        this.hasBeenDismissed = true;
        if (this.onDismissListener != null) {
            this.onDismissListener.onDismiss(this.realDialog);
        }
    }

    @Implementation
    public View findViewById(int viewId) {
        if (this.inflatedView != null) {
            return this.inflatedView.findViewById(viewId);
        }
        if (this.layoutId <= 0 || this.context == null) {
            return null;
        }
        this.inflatedView = ShadowLayoutInflater.from(this.context).inflate(this.layoutId, (ViewGroup) null);
        return this.inflatedView.findViewById(viewId);
    }

    public void clickOn(int viewId) {
        findViewById(viewId).performClick();
    }

    @Implementation
    public void setOnDismissListener(DialogInterface.OnDismissListener onDismissListener2) {
        this.onDismissListener = onDismissListener2;
    }

    @Implementation
    public void setCancelable(boolean flag) {
        this.isCancelable = flag;
    }

    public boolean isCancelable() {
        return this.isCancelable;
    }

    @Implementation
    public void cancel() {
        if (this.onCancelListener != null) {
            this.onCancelListener.onCancel(this.realDialog);
        }
        this.realDialog.dismiss();
    }

    @Implementation
    public void setOnCancelListener(DialogInterface.OnCancelListener listener) {
        this.onCancelListener = listener;
    }

    public DialogInterface.OnCancelListener getOnCancelListener() {
        return this.onCancelListener;
    }

    @Implementation
    public Window getWindow() {
        if (this.window == null) {
            this.window = new TestWindow(this.realDialog.getContext());
        }
        return this.window;
    }

    @Implementation
    public LayoutInflater getLayoutInflater() {
        return LayoutInflater.from(this.realDialog.getContext());
    }

    public int getLayoutId() {
        return this.layoutId;
    }

    public int getThemeId() {
        return this.themeId;
    }

    public boolean hasBeenDismissed() {
        return this.hasBeenDismissed;
    }

    public CharSequence getTitle() {
        return this.title;
    }

    public void clickOnText(int textId) {
        if (this.inflatedView == null) {
            this.inflatedView = ShadowLayoutInflater.from(this.context).inflate(this.layoutId, (ViewGroup) null);
        }
        String text = getContext().getResources().getString(textId);
        if (!clickOnText(this.inflatedView, text)) {
            throw new IllegalArgumentException("Text not found: " + text);
        }
    }

    private boolean clickOnText(View view, String text) {
        if (text.equals(Robolectric.shadowOf(view).innerText())) {
            view.performClick();
            return true;
        }
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i = 0; i < viewGroup.getChildCount(); i++) {
                if (clickOnText(viewGroup.getChildAt(i), text)) {
                    return true;
                }
            }
        }
        return false;
    }

    public static List<Dialog> getShownDialogs() {
        return shownDialogs;
    }
}
