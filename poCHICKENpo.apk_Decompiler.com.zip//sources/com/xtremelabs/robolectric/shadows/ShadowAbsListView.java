package com.xtremelabs.robolectric.shadows;

import android.widget.AbsListView;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;

@Implements(AbsListView.class)
public class ShadowAbsListView extends ShadowAdapterView {
    private int lastSmoothScrollByDistance;
    private int lastSmoothScrollByDuration;
    private AbsListView.OnScrollListener onScrollListener;
    private int smoothScrolledPosition;

    @Implementation
    public void setOnScrollListener(AbsListView.OnScrollListener l) {
        this.onScrollListener = l;
    }

    @Implementation
    public void smoothScrollToPosition(int position) {
        this.smoothScrolledPosition = position;
    }

    @Implementation
    public void smoothScrollBy(int distance, int duration) {
        this.lastSmoothScrollByDistance = distance;
        this.lastSmoothScrollByDuration = duration;
    }

    public AbsListView.OnScrollListener getOnScrollListener() {
        return this.onScrollListener;
    }

    public int getSmoothScrolledPosition() {
        return this.smoothScrolledPosition;
    }

    public int getLastSmoothScrollByDistance() {
        return this.lastSmoothScrollByDistance;
    }

    public int getLastSmoothScrollByDuration() {
        return this.lastSmoothScrollByDuration;
    }
}
