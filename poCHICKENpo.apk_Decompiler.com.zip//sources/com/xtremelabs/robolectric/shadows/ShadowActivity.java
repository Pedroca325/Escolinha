package com.xtremelabs.robolectric.shadows;

import android.app.Activity;
import android.app.Application;
import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;
import com.xtremelabs.robolectric.tester.android.view.TestWindow;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Implements(Activity.class)
public class ShadowActivity extends ShadowContextWrapper {
    View contentView;
    private View currentFocus;
    private Map<Integer, Dialog> dialogForId = new HashMap();
    private boolean finishWasCalled;
    private Intent intent;
    private Map<Intent, Integer> intentRequestCodeMap = new HashMap();
    private Object lastNonConfigurationInstance;
    private Integer lastShownDialogId = null;
    private boolean onKeyUpWasCalled;
    private int orientation;
    private Activity parent;
    private int pendingTransitionEnterAnimResId = -1;
    private int pendingTransitionExitAnimResId = -1;
    @RealObject
    protected Activity realActivity;
    private int requestedOrientation = -1;
    private int resultCode;
    private Intent resultIntent;
    private List<IntentForResult> startedActivitiesForResults = new ArrayList();
    private CharSequence title;
    private TestWindow window;

    @Implementation
    public final Application getApplication() {
        return Robolectric.application;
    }

    @Implementation
    public final Application getApplicationContext() {
        return getApplication();
    }

    @Implementation
    public void setIntent(Intent intent2) {
        this.intent = intent2;
    }

    @Implementation
    public Intent getIntent() {
        return this.intent;
    }

    @Implementation(i18nSafe = false)
    public void setTitle(CharSequence title2) {
        this.title = title2;
    }

    @Implementation
    public void setTitle(int titleId) {
        this.title = getResources().getString(titleId);
    }

    @Implementation
    public CharSequence getTitle() {
        return this.title;
    }

    @Implementation
    public void setContentView(int layoutResID) {
        this.contentView = getLayoutInflater().inflate(layoutResID, new FrameLayout(this.realActivity));
        this.realActivity.onContentChanged();
    }

    @Implementation
    public void setContentView(View view) {
        this.contentView = view;
        this.realActivity.onContentChanged();
    }

    @Implementation
    public final void setResult(int resultCode2) {
        this.resultCode = resultCode2;
    }

    @Implementation
    public final void setResult(int resultCode2, Intent data) {
        this.resultCode = resultCode2;
        this.resultIntent = data;
    }

    @Implementation
    public LayoutInflater getLayoutInflater() {
        return LayoutInflater.from(this.realActivity);
    }

    @Implementation
    public MenuInflater getMenuInflater() {
        return new MenuInflater(this.realActivity);
    }

    @Implementation
    public View findViewById(int id) {
        if (this.contentView != null) {
            return this.contentView.findViewById(id);
        }
        System.out.println("WARNING: you probably should have called setContentView() first");
        Thread.dumpStack();
        return null;
    }

    @Implementation
    public final Activity getParent() {
        return this.parent;
    }

    @Implementation
    public void onBackPressed() {
        finish();
    }

    @Implementation
    public void finish() {
        this.finishWasCalled = true;
    }

    public void resetIsFinishing() {
        this.finishWasCalled = false;
    }

    @Implementation
    public boolean isFinishing() {
        return this.finishWasCalled;
    }

    @Implementation
    public Window getWindow() {
        if (this.window == null) {
            this.window = new TestWindow(this.realActivity);
        }
        return this.window;
    }

    @Implementation
    public void runOnUiThread(Runnable action) {
        Robolectric.getUiThreadScheduler().post(action);
    }

    @Implementation
    public void onCreate(Bundle bundle) {
    }

    @Implementation
    public void onDestroy() {
        assertNoBroadcastListenersRegistered();
    }

    @Implementation
    public WindowManager getWindowManager() {
        return (WindowManager) Robolectric.application.getSystemService("window");
    }

    @Implementation
    public void setRequestedOrientation(int requestedOrientation2) {
        this.requestedOrientation = requestedOrientation2;
    }

    @Implementation
    public int getRequestedOrientation() {
        return this.requestedOrientation;
    }

    @Implementation
    public SharedPreferences getPreferences(int mode) {
        return ShadowPreferenceManager.getDefaultSharedPreferences(getApplicationContext());
    }

    public void assertNoBroadcastListenersRegistered() {
        Robolectric.shadowOf(getApplicationContext()).assertNoBroadcastListenersRegistered(this.realActivity, "Activity");
    }

    public View getContentView() {
        return this.contentView;
    }

    public int getResultCode() {
        return this.resultCode;
    }

    public Intent getResultIntent() {
        return this.resultIntent;
    }

    public IntentForResult getNextStartedActivityForResult() {
        if (this.startedActivitiesForResults.isEmpty()) {
            return null;
        }
        return this.startedActivitiesForResults.remove(0);
    }

    public IntentForResult peekNextStartedActivityForResult() {
        if (this.startedActivitiesForResults.isEmpty()) {
            return null;
        }
        return this.startedActivitiesForResults.get(0);
    }

    @Implementation
    public Object getLastNonConfigurationInstance() {
        return this.lastNonConfigurationInstance;
    }

    public void setLastNonConfigurationInstance(Object lastNonConfigurationInstance2) {
        this.lastNonConfigurationInstance = lastNonConfigurationInstance2;
    }

    public void setCurrentFocus(View view) {
        this.currentFocus = view;
    }

    @Implementation
    public View getCurrentFocus() {
        return this.currentFocus;
    }

    @Implementation
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        this.onKeyUpWasCalled = true;
        if (keyCode != 4) {
            return false;
        }
        onBackPressed();
        return true;
    }

    public boolean onKeyUpWasCalled() {
        return this.onKeyUpWasCalled;
    }

    public void resetKeyUpWasCalled() {
        this.onKeyUpWasCalled = false;
    }

    public class IntentForResult {
        public Intent intent;
        public int requestCode;

        public IntentForResult(Intent intent2, int requestCode2) {
            this.intent = intent2;
            this.requestCode = requestCode2;
        }
    }

    @Implementation
    public void startActivityForResult(Intent intent2, int requestCode) {
        this.intentRequestCodeMap.put(intent2, Integer.valueOf(requestCode));
        this.startedActivitiesForResults.add(new IntentForResult(intent2, requestCode));
        getApplicationContext().startActivity(intent2);
    }

    public void receiveResult(Intent requestIntent, int resultCode2, Intent resultIntent2) {
        Integer requestCode = this.intentRequestCodeMap.get(requestIntent);
        if (requestCode == null) {
            throw new RuntimeException("No intent matches " + requestIntent + " among " + this.intentRequestCodeMap.keySet());
        }
        Class<Activity> cls = Activity.class;
        try {
            Method method = cls.getDeclaredMethod("onActivityResult", new Class[]{Integer.TYPE, Integer.TYPE, Intent.class});
            method.setAccessible(true);
            method.invoke(this.realActivity, new Object[]{requestCode, Integer.valueOf(resultCode2), resultIntent2});
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        } catch (InvocationTargetException e2) {
            throw new RuntimeException(e2);
        } catch (NoSuchMethodException e3) {
            throw new RuntimeException(e3);
        }
    }

    @Implementation
    public final void showDialog(int id) {
        showDialog(id, (Bundle) null);
    }

    @Implementation
    public final void dismissDialog(int id) {
        Dialog dialog = this.dialogForId.get(Integer.valueOf(id));
        if (dialog == null) {
            throw new IllegalArgumentException();
        }
        dialog.dismiss();
    }

    @Implementation
    public final void removeDialog(int id) {
        this.dialogForId.remove(Integer.valueOf(id));
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v8, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v0, resolved type: android.app.Dialog} */
    /* JADX WARNING: Multi-variable type inference failed */
    @com.xtremelabs.robolectric.internal.Implementation
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean showDialog(int r11, android.os.Bundle r12) {
        /*
            r10 = this;
            r9 = 1
            r1 = 0
            java.lang.Integer r4 = java.lang.Integer.valueOf(r11)
            r10.lastShownDialogId = r4
            java.util.Map<java.lang.Integer, android.app.Dialog> r4 = r10.dialogForId
            java.lang.Integer r5 = java.lang.Integer.valueOf(r11)
            java.lang.Object r1 = r4.get(r5)
            android.app.Dialog r1 = (android.app.Dialog) r1
            if (r1 != 0) goto L_0x0074
            java.lang.Class<android.app.Activity> r4 = android.app.Activity.class
            java.lang.String r5 = "onCreateDialog"
            r6 = 1
            java.lang.Class[] r6 = new java.lang.Class[r6]     // Catch:{ IllegalAccessException -> 0x00ac, InvocationTargetException -> 0x00b3, NoSuchMethodException -> 0x00ba }
            r7 = 0
            java.lang.Class r8 = java.lang.Integer.TYPE     // Catch:{ IllegalAccessException -> 0x00ac, InvocationTargetException -> 0x00b3, NoSuchMethodException -> 0x00ba }
            r6[r7] = r8     // Catch:{ IllegalAccessException -> 0x00ac, InvocationTargetException -> 0x00b3, NoSuchMethodException -> 0x00ba }
            java.lang.reflect.Method r3 = r4.getDeclaredMethod(r5, r6)     // Catch:{ IllegalAccessException -> 0x00ac, InvocationTargetException -> 0x00b3, NoSuchMethodException -> 0x00ba }
            r4 = 1
            r3.setAccessible(r4)     // Catch:{ IllegalAccessException -> 0x00ac, InvocationTargetException -> 0x00b3, NoSuchMethodException -> 0x00ba }
            android.app.Activity r4 = r10.realActivity     // Catch:{ IllegalAccessException -> 0x00ac, InvocationTargetException -> 0x00b3, NoSuchMethodException -> 0x00ba }
            r5 = 1
            java.lang.Object[] r5 = new java.lang.Object[r5]     // Catch:{ IllegalAccessException -> 0x00ac, InvocationTargetException -> 0x00b3, NoSuchMethodException -> 0x00ba }
            r6 = 0
            java.lang.Integer r7 = java.lang.Integer.valueOf(r11)     // Catch:{ IllegalAccessException -> 0x00ac, InvocationTargetException -> 0x00b3, NoSuchMethodException -> 0x00ba }
            r5[r6] = r7     // Catch:{ IllegalAccessException -> 0x00ac, InvocationTargetException -> 0x00b3, NoSuchMethodException -> 0x00ba }
            java.lang.Object r4 = r3.invoke(r4, r5)     // Catch:{ IllegalAccessException -> 0x00ac, InvocationTargetException -> 0x00b3, NoSuchMethodException -> 0x00ba }
            r0 = r4
            android.app.Dialog r0 = (android.app.Dialog) r0     // Catch:{ IllegalAccessException -> 0x00ac, InvocationTargetException -> 0x00b3, NoSuchMethodException -> 0x00ba }
            r1 = r0
            if (r12 != 0) goto L_0x0078
            java.lang.Class<android.app.Activity> r4 = android.app.Activity.class
            java.lang.String r5 = "onPrepareDialog"
            r6 = 2
            java.lang.Class[] r6 = new java.lang.Class[r6]     // Catch:{ IllegalAccessException -> 0x00ac, InvocationTargetException -> 0x00b3, NoSuchMethodException -> 0x00ba }
            r7 = 0
            java.lang.Class r8 = java.lang.Integer.TYPE     // Catch:{ IllegalAccessException -> 0x00ac, InvocationTargetException -> 0x00b3, NoSuchMethodException -> 0x00ba }
            r6[r7] = r8     // Catch:{ IllegalAccessException -> 0x00ac, InvocationTargetException -> 0x00b3, NoSuchMethodException -> 0x00ba }
            r7 = 1
            java.lang.Class<android.app.Dialog> r8 = android.app.Dialog.class
            r6[r7] = r8     // Catch:{ IllegalAccessException -> 0x00ac, InvocationTargetException -> 0x00b3, NoSuchMethodException -> 0x00ba }
            java.lang.reflect.Method r3 = r4.getDeclaredMethod(r5, r6)     // Catch:{ IllegalAccessException -> 0x00ac, InvocationTargetException -> 0x00b3, NoSuchMethodException -> 0x00ba }
            r4 = 1
            r3.setAccessible(r4)     // Catch:{ IllegalAccessException -> 0x00ac, InvocationTargetException -> 0x00b3, NoSuchMethodException -> 0x00ba }
            android.app.Activity r4 = r10.realActivity     // Catch:{ IllegalAccessException -> 0x00ac, InvocationTargetException -> 0x00b3, NoSuchMethodException -> 0x00ba }
            r5 = 2
            java.lang.Object[] r5 = new java.lang.Object[r5]     // Catch:{ IllegalAccessException -> 0x00ac, InvocationTargetException -> 0x00b3, NoSuchMethodException -> 0x00ba }
            r6 = 0
            java.lang.Integer r7 = java.lang.Integer.valueOf(r11)     // Catch:{ IllegalAccessException -> 0x00ac, InvocationTargetException -> 0x00b3, NoSuchMethodException -> 0x00ba }
            r5[r6] = r7     // Catch:{ IllegalAccessException -> 0x00ac, InvocationTargetException -> 0x00b3, NoSuchMethodException -> 0x00ba }
            r6 = 1
            r5[r6] = r1     // Catch:{ IllegalAccessException -> 0x00ac, InvocationTargetException -> 0x00b3, NoSuchMethodException -> 0x00ba }
            r3.invoke(r4, r5)     // Catch:{ IllegalAccessException -> 0x00ac, InvocationTargetException -> 0x00b3, NoSuchMethodException -> 0x00ba }
        L_0x006b:
            java.util.Map<java.lang.Integer, android.app.Dialog> r4 = r10.dialogForId
            java.lang.Integer r5 = java.lang.Integer.valueOf(r11)
            r4.put(r5, r1)
        L_0x0074:
            r1.show()
            return r9
        L_0x0078:
            java.lang.Class<android.app.Activity> r4 = android.app.Activity.class
            java.lang.String r5 = "onPrepareDialog"
            r6 = 3
            java.lang.Class[] r6 = new java.lang.Class[r6]     // Catch:{ IllegalAccessException -> 0x00ac, InvocationTargetException -> 0x00b3, NoSuchMethodException -> 0x00ba }
            r7 = 0
            java.lang.Class r8 = java.lang.Integer.TYPE     // Catch:{ IllegalAccessException -> 0x00ac, InvocationTargetException -> 0x00b3, NoSuchMethodException -> 0x00ba }
            r6[r7] = r8     // Catch:{ IllegalAccessException -> 0x00ac, InvocationTargetException -> 0x00b3, NoSuchMethodException -> 0x00ba }
            r7 = 1
            java.lang.Class<android.app.Dialog> r8 = android.app.Dialog.class
            r6[r7] = r8     // Catch:{ IllegalAccessException -> 0x00ac, InvocationTargetException -> 0x00b3, NoSuchMethodException -> 0x00ba }
            r7 = 2
            java.lang.Class<android.os.Bundle> r8 = android.os.Bundle.class
            r6[r7] = r8     // Catch:{ IllegalAccessException -> 0x00ac, InvocationTargetException -> 0x00b3, NoSuchMethodException -> 0x00ba }
            java.lang.reflect.Method r3 = r4.getDeclaredMethod(r5, r6)     // Catch:{ IllegalAccessException -> 0x00ac, InvocationTargetException -> 0x00b3, NoSuchMethodException -> 0x00ba }
            r4 = 1
            r3.setAccessible(r4)     // Catch:{ IllegalAccessException -> 0x00ac, InvocationTargetException -> 0x00b3, NoSuchMethodException -> 0x00ba }
            android.app.Activity r4 = r10.realActivity     // Catch:{ IllegalAccessException -> 0x00ac, InvocationTargetException -> 0x00b3, NoSuchMethodException -> 0x00ba }
            r5 = 3
            java.lang.Object[] r5 = new java.lang.Object[r5]     // Catch:{ IllegalAccessException -> 0x00ac, InvocationTargetException -> 0x00b3, NoSuchMethodException -> 0x00ba }
            r6 = 0
            java.lang.Integer r7 = java.lang.Integer.valueOf(r11)     // Catch:{ IllegalAccessException -> 0x00ac, InvocationTargetException -> 0x00b3, NoSuchMethodException -> 0x00ba }
            r5[r6] = r7     // Catch:{ IllegalAccessException -> 0x00ac, InvocationTargetException -> 0x00b3, NoSuchMethodException -> 0x00ba }
            r6 = 1
            r5[r6] = r1     // Catch:{ IllegalAccessException -> 0x00ac, InvocationTargetException -> 0x00b3, NoSuchMethodException -> 0x00ba }
            r6 = 2
            r5[r6] = r12     // Catch:{ IllegalAccessException -> 0x00ac, InvocationTargetException -> 0x00b3, NoSuchMethodException -> 0x00ba }
            r3.invoke(r4, r5)     // Catch:{ IllegalAccessException -> 0x00ac, InvocationTargetException -> 0x00b3, NoSuchMethodException -> 0x00ba }
            goto L_0x006b
        L_0x00ac:
            r2 = move-exception
            java.lang.RuntimeException r4 = new java.lang.RuntimeException
            r4.<init>(r2)
            throw r4
        L_0x00b3:
            r2 = move-exception
            java.lang.RuntimeException r4 = new java.lang.RuntimeException
            r4.<init>(r2)
            throw r4
        L_0x00ba:
            r2 = move-exception
            java.lang.RuntimeException r4 = new java.lang.RuntimeException
            r4.<init>(r2)
            throw r4
        */
        throw new UnsupportedOperationException("Method not decompiled: com.xtremelabs.robolectric.shadows.ShadowActivity.showDialog(int, android.os.Bundle):boolean");
    }

    public Integer getLastShownDialogId() {
        return this.lastShownDialogId;
    }

    public boolean hasCancelledPendingTransitions() {
        return this.pendingTransitionEnterAnimResId == 0 && this.pendingTransitionExitAnimResId == 0;
    }

    @Implementation
    public void overridePendingTransition(int enterAnim, int exitAnim) {
        this.pendingTransitionEnterAnimResId = enterAnim;
        this.pendingTransitionExitAnimResId = exitAnim;
    }

    public Dialog getDialogById(int dialogId) {
        return this.dialogForId.get(Integer.valueOf(dialogId));
    }
}
