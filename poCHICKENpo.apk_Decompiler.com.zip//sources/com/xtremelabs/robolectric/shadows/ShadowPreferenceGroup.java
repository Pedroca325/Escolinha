package com.xtremelabs.robolectric.shadows;

import android.preference.Preference;
import android.preference.PreferenceGroup;
import android.text.TextUtils;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;
import java.util.ArrayList;

@Implements(PreferenceGroup.class)
public class ShadowPreferenceGroup extends ShadowPreference {
    private ArrayList<Preference> preferenceList = new ArrayList<>();
    @RealObject
    private PreferenceGroup realPreferenceGroup;

    @Implementation
    public void addItemFromInflater(Preference preference) {
        addPreference(preference);
    }

    @Implementation
    public boolean addPreference(Preference preference) {
        if (!this.preferenceList.contains(preference)) {
            this.preferenceList.add(preference);
        }
        return true;
    }

    @Implementation
    public Preference getPreference(int index) {
        return this.preferenceList.get(index);
    }

    @Implementation
    public int getPreferenceCount() {
        return this.preferenceList.size();
    }

    @Implementation
    public boolean removePreference(Preference preference) {
        return this.preferenceList.remove(preference);
    }

    @Implementation
    public void removeAll() {
        this.preferenceList.clear();
    }

    @Implementation
    public Preference findPreference(CharSequence key) {
        Preference returnedPreference;
        if (TextUtils.equals(getKey(), key)) {
            return this.realPreferenceGroup;
        }
        int preferenceCount = getPreferenceCount();
        for (int i = 0; i < preferenceCount; i++) {
            Preference preference = getPreference(i);
            String curKey = preference.getKey();
            if (curKey != null && curKey.equals(key)) {
                return preference;
            }
            if ((preference instanceof PreferenceGroup) && (returnedPreference = ((PreferenceGroup) preference).findPreference(key)) != null) {
                return returnedPreference;
            }
        }
        return null;
    }

    @Implementation
    public void setEnabled(boolean enabled) {
        super.setEnabled(enabled);
        int preferenceCount = getPreferenceCount();
        for (int i = 0; i < preferenceCount; i++) {
            getPreference(i).setEnabled(enabled);
        }
    }
}
