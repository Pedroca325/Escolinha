package com.xtremelabs.robolectric.shadows;

import android.view.KeyEvent;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;

@Implements(KeyEvent.class)
public class ShadowKeyEvent {
    private int action;
    private int code;

    public void __constructor__(int action2, int code2) {
        this.action = action2;
        this.code = code2;
    }

    @Implementation
    public final int getAction() {
        return this.action;
    }

    @Implementation
    public final int getKeyCode() {
        return this.code;
    }
}
