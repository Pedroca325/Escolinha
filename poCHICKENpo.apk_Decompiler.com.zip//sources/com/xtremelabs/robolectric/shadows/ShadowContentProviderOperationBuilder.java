package com.xtremelabs.robolectric.shadows;

import android.content.ContentProviderOperation;
import android.net.Uri;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;
import java.util.Map;

@Implements(ContentProviderOperation.Builder.class)
public class ShadowContentProviderOperationBuilder {
    private ContentProviderOperation contentProviderOperation;
    @RealObject
    private ContentProviderOperation.Builder realBuilder;
    private ShadowContentProviderOperation shadowContentProviderOperation;

    public void __constructor__() {
        this.contentProviderOperation = (ContentProviderOperation) Robolectric.newInstanceOf(ContentProviderOperation.class);
        this.shadowContentProviderOperation = Robolectric.shadowOf(this.contentProviderOperation);
    }

    @Implementation
    public ContentProviderOperation.Builder withValue(String key, Object value) {
        this.shadowContentProviderOperation.getValues().put(key, value);
        return this.realBuilder;
    }

    @Implementation
    public ContentProviderOperation.Builder withSelection(String selection, String[] selectionArgs) {
        this.shadowContentProviderOperation.getSelections().put(selection, selectionArgs);
        return this.realBuilder;
    }

    @Implementation
    public ContentProviderOperation.Builder withValueBackReference(String key, int previousResult) {
        this.shadowContentProviderOperation.setWithValueBackReference(key, previousResult);
        return this.realBuilder;
    }

    @Implementation
    public ContentProviderOperation build() {
        return this.contentProviderOperation;
    }

    public Uri getUri() {
        return this.shadowContentProviderOperation.getUri();
    }

    public void setUri(Uri uri) {
        this.shadowContentProviderOperation.setUri(uri);
    }

    public Map<String, Object> getValues() {
        return this.shadowContentProviderOperation.getValues();
    }

    public Map<String, String[]> getSelections() {
        return this.shadowContentProviderOperation.getSelections();
    }

    public boolean isInsert() {
        return this.shadowContentProviderOperation.isInsert();
    }

    public void setInsert(boolean value) {
        this.shadowContentProviderOperation.setInsert(value);
    }

    public boolean isUpdate() {
        return this.shadowContentProviderOperation.isUpdate();
    }

    public void setUpdate(boolean value) {
        this.shadowContentProviderOperation.setUpdate(value);
    }

    public boolean isDelete() {
        return this.shadowContentProviderOperation.isDelete();
    }

    public void setDelete(boolean value) {
        this.shadowContentProviderOperation.setDelete(value);
    }

    public int getWithValueBackReference(String key) {
        return this.shadowContentProviderOperation.getWithValueBackReference(key);
    }
}
