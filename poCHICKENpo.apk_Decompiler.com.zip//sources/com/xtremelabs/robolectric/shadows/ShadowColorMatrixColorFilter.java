package com.xtremelabs.robolectric.shadows;

import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;

@Implements(ColorMatrixColorFilter.class)
public class ShadowColorMatrixColorFilter {
    private ColorMatrix matrix;

    @Implementation
    public void __constructor__(ColorMatrix matrix2) {
        this.matrix = matrix2;
    }

    @Implementation
    public void __constructor__(float[] array) {
        this.matrix = new ColorMatrix(array);
    }

    @Implementation
    public String toString() {
        return "ColorMatrixColorFilter<" + this.matrix + ">";
    }
}
