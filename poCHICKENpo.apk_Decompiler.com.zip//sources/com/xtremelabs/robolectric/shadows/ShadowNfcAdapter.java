package com.xtremelabs.robolectric.shadows;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Context;
import android.content.IntentFilter;
import android.nfc.NfcAdapter;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

@Implements(NfcAdapter.class)
public class ShadowNfcAdapter {
    private Activity disabledActivity;
    private Activity enabledActivity;
    private IntentFilter[] filters;
    private PendingIntent intent;
    @RealObject
    NfcAdapter nfcAdapter;
    private String[][] techLists;

    @Implementation
    public static NfcAdapter getDefaultAdapter(Context context) {
        try {
            Constructor<NfcAdapter> constructor = NfcAdapter.class.getDeclaredConstructor(new Class[0]);
            constructor.setAccessible(true);
            return constructor.newInstance(new Object[0]);
        } catch (InstantiationException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException e2) {
            throw new RuntimeException(e2);
        } catch (InvocationTargetException e3) {
            throw new RuntimeException(e3);
        } catch (NoSuchMethodException e4) {
            throw new RuntimeException(e4);
        }
    }

    @Implementation
    public void enableForegroundDispatch(Activity activity, PendingIntent intent2, IntentFilter[] filters2, String[][] techLists2) {
        this.enabledActivity = activity;
        this.intent = intent2;
        this.filters = filters2;
        this.techLists = techLists2;
    }

    @Implementation
    public void disableForegroundDispatch(Activity activity) {
        this.disabledActivity = activity;
    }

    public Activity getEnabledActivity() {
        return this.enabledActivity;
    }

    public PendingIntent getIntent() {
        return this.intent;
    }

    public IntentFilter[] getFilters() {
        return this.filters;
    }

    public String[][] getTechLists() {
        return this.techLists;
    }

    public Activity getDisabledActivity() {
        return this.disabledActivity;
    }
}
