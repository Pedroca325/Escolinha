package com.xtremelabs.robolectric.shadows;

import android.graphics.drawable.Drawable;
import com.google.android.maps.ItemizedOverlay;
import com.google.android.maps.OverlayItem;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;

@Implements(ItemizedOverlay.class)
public class ShadowItemizedOverlay {
    private boolean isPopulated;
    private boolean lastFocusedIndexWasReset;
    private boolean shouldHit;

    @Implementation
    public final void populate() {
        this.isPopulated = true;
    }

    @Implementation
    public boolean hitTest(OverlayItem item, Drawable drawable, int i, int i1) {
        return this.shouldHit;
    }

    @Implementation
    public void setLastFocusedIndex(int i) {
        this.lastFocusedIndexWasReset = i == -1;
    }

    @Implementation
    public static Drawable boundCenterBottom(Drawable drawable) {
        return drawable;
    }

    public boolean lastFocusedIndexWasReset() {
        return this.lastFocusedIndexWasReset;
    }

    public void setIsPopulated(boolean isPopulated2) {
        this.isPopulated = isPopulated2;
    }

    public boolean isPopulated() {
        return this.isPopulated;
    }

    public void setShouldHit(boolean shouldHit2) {
        this.shouldHit = shouldHit2;
    }
}
