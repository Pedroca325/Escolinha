package com.xtremelabs.robolectric.shadows;

import android.util.DisplayMetrics;
import android.util.TypedValue;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;

@Implements(TypedValue.class)
public class ShadowTypedValue {
    @Implementation
    public static float applyDimension(int unit, float value, DisplayMetrics metrics) {
        switch (unit) {
            case ShadowVideoView.STOP /*0*/:
                return value;
            case 1:
                return value * metrics.density;
            case 2:
                return value * metrics.scaledDensity;
            case 3:
                return metrics.xdpi * value * 0.013888889f;
            case 4:
                return value * metrics.xdpi;
            case ShadowMediaRecorder.STATE_RECORDING:
                return metrics.xdpi * value * 0.03937008f;
            default:
                return 0.0f;
        }
    }
}
