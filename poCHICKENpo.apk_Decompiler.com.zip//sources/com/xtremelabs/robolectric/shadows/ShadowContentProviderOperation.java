package com.xtremelabs.robolectric.shadows;

import android.content.ContentProviderOperation;
import android.net.Uri;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import java.util.HashMap;
import java.util.Map;

@Implements(ContentProviderOperation.class)
public class ShadowContentProviderOperation {
    private boolean isDelete;
    private boolean isInsert;
    private boolean isUpdate;
    private final Map<String, String[]> selections = new HashMap();
    private Uri uri;
    private final Map<String, Object> values = new HashMap();
    private final Map<String, Integer> withValueBackReferences = new HashMap();

    @Implementation
    public static ContentProviderOperation.Builder newInsert(Uri uri2) {
        ContentProviderOperation.Builder builder = (ContentProviderOperation.Builder) Robolectric.newInstanceOf(ContentProviderOperation.Builder.class);
        ShadowContentProviderOperationBuilder shadowBuilder = Robolectric.shadowOf(builder);
        shadowBuilder.setUri(uri2);
        shadowBuilder.setInsert(true);
        return builder;
    }

    @Implementation
    public static ContentProviderOperation.Builder newUpdate(Uri uri2) {
        ContentProviderOperation.Builder builder = (ContentProviderOperation.Builder) Robolectric.newInstanceOf(ContentProviderOperation.Builder.class);
        ShadowContentProviderOperationBuilder shadowBuilder = Robolectric.shadowOf(builder);
        shadowBuilder.setUri(uri2);
        shadowBuilder.setUpdate(true);
        return builder;
    }

    @Implementation
    public static ContentProviderOperation.Builder newDelete(Uri uri2) {
        ContentProviderOperation.Builder builder = (ContentProviderOperation.Builder) Robolectric.newInstanceOf(ContentProviderOperation.Builder.class);
        ShadowContentProviderOperationBuilder shadowBuilder = Robolectric.shadowOf(builder);
        shadowBuilder.setUri(uri2);
        shadowBuilder.setDelete(true);
        return builder;
    }

    @Implementation
    public Uri getUri() {
        return this.uri;
    }

    public void setUri(Uri uri2) {
        this.uri = uri2;
    }

    public Map<String, Object> getValues() {
        return this.values;
    }

    public Map<String, String[]> getSelections() {
        return this.selections;
    }

    public boolean isInsert() {
        return this.isInsert;
    }

    public void setInsert(boolean value) {
        this.isInsert = value;
    }

    public boolean isUpdate() {
        return this.isUpdate;
    }

    public void setUpdate(boolean value) {
        this.isUpdate = value;
    }

    public boolean isDelete() {
        return this.isDelete;
    }

    public void setDelete(boolean value) {
        this.isDelete = value;
    }

    public void setWithValueBackReference(String key, int previousResult) {
        this.withValueBackReferences.put(key, Integer.valueOf(previousResult));
    }

    public int getWithValueBackReference(String key) {
        return this.withValueBackReferences.get(key).intValue();
    }
}
