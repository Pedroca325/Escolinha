package com.xtremelabs.robolectric.shadows;

import android.graphics.Bitmap;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;
import java.io.InputStream;
import java.util.ArrayList;

@Implements(Drawable.class)
public class ShadowDrawable {
    static ArrayList<String> corruptStreamSources = new ArrayList<>();
    private static int defaultIntrinsicHeight = -1;
    private static int defaultIntrinsicWidth = -1;
    private int alpha;
    private Rect bounds = new Rect(0, 0, 0, 0);
    private InputStream inputStream;
    private int intrinsicHeight = defaultIntrinsicHeight;
    private int intrinsicWidth = defaultIntrinsicWidth;
    private int level;
    private int loadedFromResourceId = -1;
    @RealObject
    Drawable realObject;

    @Implementation
    public static Drawable createFromStream(InputStream is, String srcName) {
        if (corruptStreamSources.contains(srcName)) {
            return null;
        }
        BitmapDrawable drawable = new BitmapDrawable((Bitmap) Robolectric.newInstanceOf(Bitmap.class));
        Robolectric.shadowOf(drawable).setSource(srcName);
        Robolectric.shadowOf(drawable).setInputStream(is);
        return drawable;
    }

    @Implementation
    public static Drawable createFromPath(String pathName) {
        BitmapDrawable drawable = new BitmapDrawable((Bitmap) Robolectric.newInstanceOf(Bitmap.class));
        Robolectric.shadowOf(drawable).setPath(pathName);
        return drawable;
    }

    public static Drawable createFromResourceId(int resourceId) {
        Bitmap bitmap = (Bitmap) Robolectric.newInstanceOf(Bitmap.class);
        Robolectric.shadowOf(bitmap).setLoadedFromResourceId(resourceId);
        return new BitmapDrawable(bitmap);
    }

    @Implementation
    public final Rect getBounds() {
        return this.bounds;
    }

    @Implementation
    public void setBounds(Rect rect) {
        this.bounds = rect;
    }

    @Implementation
    public void setBounds(int left, int top, int right, int bottom) {
        this.bounds = new Rect(left, top, right, bottom);
    }

    @Implementation
    public Rect copyBounds() {
        Rect bounds2 = new Rect();
        copyBounds(bounds2);
        return bounds2;
    }

    @Implementation
    public void copyBounds(Rect bounds2) {
        bounds2.set(getBounds());
    }

    @Implementation
    public int getIntrinsicWidth() {
        return this.intrinsicWidth;
    }

    @Implementation
    public int getIntrinsicHeight() {
        return this.intrinsicHeight;
    }

    public static void addCorruptStreamSource(String src) {
        corruptStreamSources.add(src);
    }

    public static void setDefaultIntrinsicWidth(int defaultIntrinsicWidth2) {
        defaultIntrinsicWidth = defaultIntrinsicWidth2;
    }

    public static void setDefaultIntrinsicHeight(int defaultIntrinsicHeight2) {
        defaultIntrinsicHeight = defaultIntrinsicHeight2;
    }

    public void setIntrinsicWidth(int intrinsicWidth2) {
        this.intrinsicWidth = intrinsicWidth2;
    }

    public void setIntrinsicHeight(int intrinsicHeight2) {
        this.intrinsicHeight = intrinsicHeight2;
    }

    public InputStream getInputStream() {
        return this.inputStream;
    }

    public void setInputStream(InputStream inputStream2) {
        this.inputStream = inputStream2;
    }

    @Implementation
    public int getLevel() {
        return this.level;
    }

    @Implementation
    public boolean setLevel(int level2) {
        this.level = level2;
        return false;
    }

    @Implementation
    public boolean equals(Object o) {
        if (this.realObject == o) {
            return true;
        }
        if (o == null || this.realObject.getClass() != o.getClass()) {
            return false;
        }
        ShadowDrawable that = Robolectric.shadowOf((Drawable) o);
        if (this.intrinsicHeight != that.intrinsicHeight) {
            return false;
        }
        if (this.intrinsicWidth != that.intrinsicWidth) {
            return false;
        }
        if (this.bounds != null) {
            if (this.bounds.equals(that.bounds)) {
                return true;
            }
        } else if (that.bounds == null) {
            return true;
        }
        return false;
    }

    @Implementation
    public int hashCode() {
        return ((((this.bounds != null ? this.bounds.hashCode() : 0) * 31) + this.intrinsicWidth) * 31) + this.intrinsicHeight;
    }

    @Implementation
    public void setAlpha(int alpha2) {
        this.alpha = alpha2;
    }

    public int getAlpha() {
        return this.alpha;
    }

    public static void reset() {
        corruptStreamSources.clear();
    }

    public int getLoadedFromResourceId() {
        return this.loadedFromResourceId;
    }

    public void setLoadedFromResourceId(int resourceId) {
        this.loadedFromResourceId = resourceId;
    }
}
