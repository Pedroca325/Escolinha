package com.xtremelabs.robolectric.shadows;

import android.media.MediaPlayer;
import android.net.Uri;
import android.widget.VideoView;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;

@Implements(VideoView.class)
public class ShadowVideoView extends ShadowSurfaceView {
    public static final int PAUSE = 3;
    public static final int RESUME = 4;
    public static final int START = 1;
    public static final int STOP = 0;
    public static final int SUSPEND = 2;
    private MediaPlayer.OnCompletionListener completionListner;
    private int currentState = -1;
    private MediaPlayer.OnErrorListener errorListener;
    private String path;
    private MediaPlayer.OnPreparedListener preparedListener;
    private int prevState;
    private Uri uri;

    @Implementation
    public void setOnPreparedListener(MediaPlayer.OnPreparedListener l) {
        this.preparedListener = l;
    }

    @Implementation
    public void setOnErrorListener(MediaPlayer.OnErrorListener l) {
        this.errorListener = l;
    }

    @Implementation
    public void setOnCompletionListener(MediaPlayer.OnCompletionListener l) {
        this.completionListner = l;
    }

    @Implementation
    public void setVideoPath(String path2) {
        this.path = path2;
    }

    @Implementation
    public void setVideoURI(Uri uri2) {
        this.uri = uri2;
    }

    @Implementation
    public void start() {
        savePrevState();
        this.currentState = 1;
    }

    @Implementation
    public void stopPlayback() {
        savePrevState();
        this.currentState = 0;
    }

    @Implementation
    public void suspend() {
        savePrevState();
        this.currentState = 2;
    }

    @Implementation
    public void pause() {
        savePrevState();
        this.currentState = 3;
    }

    @Implementation
    public void resume() {
        savePrevState();
        this.currentState = 4;
    }

    @Implementation
    public boolean isPlaying() {
        return this.currentState == 1;
    }

    @Implementation
    public boolean canPause() {
        return (this.currentState == 3 || this.currentState == 0 || this.currentState == 2) ? false : true;
    }

    public MediaPlayer.OnPreparedListener getOnPreparedListener() {
        return this.preparedListener;
    }

    public MediaPlayer.OnErrorListener getOnErrorListener() {
        return this.errorListener;
    }

    public MediaPlayer.OnCompletionListener getOnCompletionListener() {
        return this.completionListner;
    }

    public String getVideoPath() {
        return this.path;
    }

    public String getVideoURIString() {
        if (this.uri == null) {
            return null;
        }
        return this.uri.toString();
    }

    public int getCurrentVideoState() {
        return this.currentState;
    }

    public int getPrevVideoState() {
        return this.prevState;
    }

    private void savePrevState() {
        this.prevState = this.currentState;
    }
}
