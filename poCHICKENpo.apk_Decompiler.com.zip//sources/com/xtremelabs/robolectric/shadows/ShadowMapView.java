package com.xtremelabs.robolectric.shadows;

import android.content.Context;
import android.graphics.Point;
import android.view.MotionEvent;
import android.widget.ZoomButtonsController;
import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;
import com.google.android.maps.Overlay;
import com.google.android.maps.Projection;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.RobolectricForMaps;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import java.util.ArrayList;
import java.util.List;

@Implements(MapView.class)
public class ShadowMapView extends ShadowViewGroup {
    private boolean canCoverCenter = true;
    private Point lastTouchEventPoint;
    int latitudeSpan = 30;
    int longitudeSpan = 20;
    GeoPoint mapCenter = new GeoPoint(10, 10);
    private MapController mapController;
    private GeoPoint mouseDownCenter;
    private boolean mouseDownOnMe = false;
    private List<Overlay> overlays = new ArrayList();
    private boolean preLoadWasCalled;
    private Projection projection;
    /* access modifiers changed from: private */
    public MapView realMapView;
    private boolean satelliteOn;
    private ShadowMapController shadowMapController;
    private boolean useBuiltInZoomMapControls;
    private ZoomButtonsController zoomButtonsController;
    int zoomLevel = 1;

    public ShadowMapView(MapView mapView) {
        this.realMapView = mapView;
        this.zoomButtonsController = new ZoomButtonsController(mapView);
    }

    public void __constructor__(Context context, String title) {
        super.__constructor__(context);
    }

    public static int toE6(double d) {
        return (int) (1000000.0d * d);
    }

    public static double fromE6(int i) {
        return ((double) i) / 1000000.0d;
    }

    @Implementation
    public void setSatellite(boolean satelliteOn2) {
        this.satelliteOn = satelliteOn2;
    }

    @Implementation
    public boolean isSatellite() {
        return this.satelliteOn;
    }

    @Implementation
    public boolean canCoverCenter() {
        return this.canCoverCenter;
    }

    @Implementation
    public MapController getController() {
        if (this.mapController == null) {
            try {
                this.mapController = (MapController) Robolectric.newInstanceOf(MapController.class);
                this.shadowMapController = RobolectricForMaps.shadowOf(this.mapController);
                this.shadowMapController.setShadowMapView(this);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
        return this.mapController;
    }

    @Implementation
    public ZoomButtonsController getZoomButtonsController() {
        return this.zoomButtonsController;
    }

    @Implementation
    public void setBuiltInZoomControls(boolean useBuiltInZoomMapControls2) {
        this.useBuiltInZoomMapControls = useBuiltInZoomMapControls2;
    }

    @Implementation
    public Projection getProjection() {
        if (this.projection == null) {
            this.projection = new Projection() {
                public Point toPixels(GeoPoint geoPoint, Point point) {
                    if (point == null) {
                        point = new Point();
                    }
                    point.y = ShadowMapView.this.scaleDegree(geoPoint.getLatitudeE6(), ShadowMapView.this.bottom, ShadowMapView.this.top, ShadowMapView.this.mapCenter.getLatitudeE6(), ShadowMapView.this.latitudeSpan);
                    point.x = ShadowMapView.this.scaleDegree(geoPoint.getLongitudeE6(), ShadowMapView.this.left, ShadowMapView.this.right, ShadowMapView.this.mapCenter.getLongitudeE6(), ShadowMapView.this.longitudeSpan);
                    return point;
                }

                public GeoPoint fromPixels(int x, int y) {
                    return new GeoPoint(ShadowMapView.this.scalePixel(y, ShadowMapView.this.bottom, -ShadowMapView.this.realMapView.getHeight(), ShadowMapView.this.mapCenter.getLatitudeE6(), ShadowMapView.this.latitudeSpan), ShadowMapView.this.scalePixel(x, ShadowMapView.this.left, ShadowMapView.this.realMapView.getWidth(), ShadowMapView.this.mapCenter.getLongitudeE6(), ShadowMapView.this.longitudeSpan));
                }

                public float metersToEquatorPixels(float v) {
                    return 0.0f;
                }
            };
        }
        return this.projection;
    }

    /* access modifiers changed from: private */
    public int scalePixel(int pixel, int minPixel, int maxPixel, int centerDegree, int spanDegrees) {
        return (int) (((double) (centerDegree - (spanDegrees / 2))) + (((double) spanDegrees) * (((double) (pixel - minPixel)) / ((double) maxPixel))));
    }

    /* access modifiers changed from: private */
    public int scaleDegree(int degree, int minPixel, int maxPixel, int centerDegree, int spanDegrees) {
        return (int) (((double) minPixel) + (((double) (maxPixel - minPixel)) * (((double) (degree - (centerDegree - (spanDegrees / 2)))) / ((double) spanDegrees))));
    }

    @Implementation
    public List<Overlay> getOverlays() {
        return this.overlays;
    }

    @Implementation
    public GeoPoint getMapCenter() {
        return this.mapCenter;
    }

    @Implementation
    public int getLatitudeSpan() {
        return this.latitudeSpan;
    }

    @Implementation
    public int getLongitudeSpan() {
        return this.longitudeSpan;
    }

    @Implementation
    public int getZoomLevel() {
        return this.zoomLevel;
    }

    @Implementation
    public boolean dispatchTouchEvent(MotionEvent event) {
        for (Overlay overlay : this.overlays) {
            if (overlay.onTouchEvent(event, this.realMapView)) {
                return true;
            }
        }
        GeoPoint fromPixels = getProjection().fromPixels((int) event.getX(), (int) event.getY());
        int diffX = 0;
        int diffY = 0;
        if (this.mouseDownOnMe) {
            diffX = ((int) event.getX()) - this.lastTouchEventPoint.x;
            diffY = ((int) event.getY()) - this.lastTouchEventPoint.y;
        }
        switch (event.getAction()) {
            case ShadowVideoView.STOP /*0*/:
                this.mouseDownOnMe = true;
                this.mouseDownCenter = getMapCenter();
                break;
            case 1:
                if (this.mouseDownOnMe) {
                    moveByPixels(-diffX, -diffY);
                    this.mouseDownOnMe = false;
                    break;
                }
                break;
            case 2:
                if (this.mouseDownOnMe) {
                    moveByPixels(-diffX, -diffY);
                    break;
                }
                break;
            case 3:
                getController().setCenter(this.mouseDownCenter);
                this.mouseDownOnMe = false;
                break;
        }
        this.lastTouchEventPoint = new Point((int) event.getX(), (int) event.getY());
        return super.dispatchTouchEvent(event);
    }

    @Implementation
    public void preLoad() {
        this.preLoadWasCalled = true;
    }

    private void moveByPixels(int x, int y) {
        Point center = getProjection().toPixels(this.mapCenter, (Point) null);
        center.offset(x, y);
        this.mapCenter = getProjection().fromPixels(center.x, center.y);
    }

    public boolean getUseBuiltInZoomMapControls() {
        return this.useBuiltInZoomMapControls;
    }

    public boolean preLoadWasCalled() {
        return this.preLoadWasCalled;
    }

    public void setLatitudeSpan(int latitudeSpan2) {
        this.latitudeSpan = latitudeSpan2;
    }

    public void setLongitudeSpan(int longitudeSpan2) {
        this.longitudeSpan = longitudeSpan2;
    }

    public void setCanCoverCenter(boolean canCoverCenter2) {
        this.canCoverCenter = canCoverCenter2;
    }
}
