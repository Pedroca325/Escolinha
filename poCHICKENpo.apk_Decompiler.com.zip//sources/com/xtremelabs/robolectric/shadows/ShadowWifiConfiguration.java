package com.xtremelabs.robolectric.shadows;

import android.net.wifi.WifiConfiguration;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;
import java.util.BitSet;

@Implements(WifiConfiguration.class)
public class ShadowWifiConfiguration {
    @RealObject
    WifiConfiguration realObject;

    public void __constructor__() {
        this.realObject.networkId = -1;
        this.realObject.SSID = null;
        this.realObject.BSSID = null;
        this.realObject.priority = 0;
        this.realObject.hiddenSSID = false;
        this.realObject.allowedKeyManagement = new BitSet();
        this.realObject.allowedProtocols = new BitSet();
        this.realObject.allowedAuthAlgorithms = new BitSet();
        this.realObject.allowedPairwiseCiphers = new BitSet();
        this.realObject.allowedGroupCiphers = new BitSet();
        this.realObject.wepKeys = new String[4];
        for (int i = 0; i < this.realObject.wepKeys.length; i++) {
            this.realObject.wepKeys[i] = null;
        }
    }

    public WifiConfiguration copy() {
        WifiConfiguration config = new WifiConfiguration();
        config.networkId = this.realObject.networkId;
        config.SSID = this.realObject.SSID;
        config.BSSID = this.realObject.BSSID;
        config.preSharedKey = this.realObject.preSharedKey;
        config.wepTxKeyIndex = this.realObject.wepTxKeyIndex;
        config.status = this.realObject.status;
        config.priority = this.realObject.priority;
        config.hiddenSSID = this.realObject.hiddenSSID;
        config.allowedKeyManagement = (BitSet) this.realObject.allowedKeyManagement.clone();
        config.allowedProtocols = (BitSet) this.realObject.allowedProtocols.clone();
        config.allowedAuthAlgorithms = (BitSet) this.realObject.allowedAuthAlgorithms.clone();
        config.allowedPairwiseCiphers = (BitSet) this.realObject.allowedPairwiseCiphers.clone();
        config.allowedGroupCiphers = (BitSet) this.realObject.allowedGroupCiphers.clone();
        config.wepKeys = new String[4];
        System.arraycopy(this.realObject.wepKeys, 0, config.wepKeys, 0, config.wepKeys.length);
        return config;
    }
}
