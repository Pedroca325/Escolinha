package com.xtremelabs.robolectric.shadows;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Implements(Handler.class)
public class ShadowHandler {
    private Handler.Callback callback;
    private Looper looper = Looper.myLooper();
    /* access modifiers changed from: private */
    public List<Message> messages = new ArrayList();
    @RealObject
    private Handler realHandler;

    public void __constructor__() {
        this.looper = Looper.myLooper();
    }

    public void __constructor__(Looper looper2) {
        this.looper = looper2;
    }

    public void __constructor__(Handler.Callback callback2) {
        this.callback = callback2;
    }

    @Implementation
    public boolean post(Runnable r) {
        return postDelayed(r, 0);
    }

    @Implementation
    public boolean postDelayed(Runnable r, long delayMillis) {
        Robolectric.shadowOf(this.looper).post(r, delayMillis);
        return true;
    }

    @Implementation
    public final boolean postAtFrontOfQueue(Runnable runnable) {
        Robolectric.shadowOf(this.looper).postAtFrontOfQueue(runnable);
        return true;
    }

    @Implementation
    public Message obtainMessage() {
        return obtainMessage(0);
    }

    @Implementation
    public Message obtainMessage(int what) {
        return obtainMessage(what, (Object) null);
    }

    @Implementation
    public Message obtainMessage(int what, Object obj) {
        return obtainMessage(what, 0, 0, obj);
    }

    @Implementation
    public Message obtainMessage(int what, int arg1, int arg2) {
        return obtainMessage(what, arg1, arg2, (Object) null);
    }

    @Implementation
    public Message obtainMessage(int what, int arg1, int arg2, Object obj) {
        Message message = new Message();
        message.what = what;
        message.arg1 = arg1;
        message.arg2 = arg2;
        message.obj = obj;
        return message;
    }

    @Implementation
    public final boolean sendMessage(Message msg) {
        return sendMessageDelayed(msg, 0);
    }

    @Implementation
    public final boolean sendMessageDelayed(final Message msg, long delayMillis) {
        this.messages.add(msg);
        postDelayed(new Runnable() {
            public void run() {
                if (ShadowHandler.this.messages.contains(msg)) {
                    ShadowHandler.this.routeMessage(msg);
                    ShadowHandler.this.messages.remove(msg);
                }
            }
        }, delayMillis);
        return true;
    }

    /* access modifiers changed from: private */
    public void routeMessage(Message msg) {
        if (this.callback != null) {
            this.callback.handleMessage(msg);
        } else {
            this.realHandler.handleMessage(msg);
        }
    }

    @Implementation
    public final boolean sendEmptyMessage(int what) {
        return sendEmptyMessageDelayed(what, 0);
    }

    @Implementation
    public final boolean sendEmptyMessageDelayed(int what, long delayMillis) {
        Message msg = new Message();
        msg.what = what;
        return sendMessageDelayed(msg, delayMillis);
    }

    @Implementation
    public final Looper getLooper() {
        return this.looper;
    }

    @Implementation
    public final void removeCallbacks(Runnable r) {
        Robolectric.shadowOf(this.looper).getScheduler().remove(r);
    }

    @Implementation
    public final boolean hasMessages(int what) {
        for (Message message : this.messages) {
            if (message.what == what) {
                return true;
            }
        }
        return false;
    }

    @Implementation
    public final boolean hasMessages(int what, Object object) {
        for (Message message : this.messages) {
            if (message.what == what && message.obj == object) {
                return true;
            }
        }
        return false;
    }

    @Implementation
    public final void removeMessages(int what) {
        Iterator<Message> iterator = this.messages.iterator();
        while (iterator.hasNext()) {
            if (iterator.next().what == what) {
                iterator.remove();
            }
        }
    }

    public static void flush() {
        idleMainLooper();
    }

    public static void idleMainLooper() {
        Robolectric.shadowOf(Looper.myLooper()).idle();
    }

    public static void runMainLooperToEndOfTasks() {
        Robolectric.shadowOf(Looper.myLooper()).runToEndOfTasks();
    }

    public static void runMainLooperOneTask() {
        Robolectric.shadowOf(Looper.myLooper()).runOneTask();
    }

    public static void runMainLooperToNextTask() {
        Robolectric.shadowOf(Looper.myLooper()).runToNextTask();
    }
}
