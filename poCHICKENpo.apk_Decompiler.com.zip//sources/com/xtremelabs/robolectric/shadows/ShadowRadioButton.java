package com.xtremelabs.robolectric.shadows;

import android.view.ViewParent;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;

@Implements(RadioButton.class)
public class ShadowRadioButton extends ShadowCompoundButton {
    @Implementation
    public void setChecked(boolean checked) {
        super.setChecked(checked);
        ViewParent viewParent = getParent();
        if (viewParent instanceof RadioGroup) {
            ((RadioGroup) viewParent).check(getId());
        }
    }
}
