package com.xtremelabs.robolectric.shadows;

import android.view.View;
import android.widget.ZoomButtonsController;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;

@Implements(ZoomButtonsController.class)
public class ShadowZoomButtonsController {
    private ZoomButtonsController.OnZoomListener listener;

    public void __constructor__(View ownerView) {
    }

    @Implementation
    public void setOnZoomListener(ZoomButtonsController.OnZoomListener listener2) {
        this.listener = listener2;
    }

    public void simulateZoomInButtonClick() {
        this.listener.onZoom(true);
    }

    public void simulateZoomOutButtonClick() {
        this.listener.onZoom(false);
    }
}
