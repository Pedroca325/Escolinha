package com.xtremelabs.robolectric.shadows;

import android.view.View;
import android.widget.ExpandableListView;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;

@Implements(ExpandableListView.class)
public class ShadowExpandableListView extends ShadowListView {
    private ExpandableListView.OnChildClickListener mChildClickListener;
    @RealObject
    private ExpandableListView mExpandable;

    @Implementation
    public boolean performItemClick(View view, int position, long id) {
        if (this.mChildClickListener == null) {
            return false;
        }
        this.mChildClickListener.onChildClick(this.mExpandable, (View) null, 0, position, id);
        return true;
    }

    @Implementation
    public void setOnChildClickListener(ExpandableListView.OnChildClickListener clildListener) {
        this.mChildClickListener = clildListener;
    }
}
