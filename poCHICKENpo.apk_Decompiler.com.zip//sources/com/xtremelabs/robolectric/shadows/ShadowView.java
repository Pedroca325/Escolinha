package com.xtremelabs.robolectric.shadows;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Point;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewTreeObserver;
import android.view.animation.Animation;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;
import java.io.PrintStream;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Map;

@Implements(View.class)
public class ShadowView {
    private Animation animation;
    protected AttributeSet attributeSet;
    private Drawable background;
    private int backgroundColor;
    private int backgroundResourceId = -1;
    int bottom;
    private boolean clickable;
    protected Context context;
    private boolean didRequestLayout;
    private boolean drawingCacheEnabled;
    private boolean enabled = true;
    protected boolean focusable;
    boolean focusableInTouchMode;
    private int id;
    private boolean isFocused;
    private MotionEvent lastTouchEvent;
    private ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(0, 0);
    int left;
    private View.OnClickListener onClickListener;
    private View.OnFocusChangeListener onFocusChangeListener;
    protected View.OnKeyListener onKeyListener;
    private View.OnLongClickListener onLongClickListener;
    private View.OnTouchListener onTouchListener;
    private int paddingBottom;
    private int paddingLeft;
    private int paddingRight;
    private int paddingTop;
    ShadowView parent;
    @RealObject
    protected View realView;
    int right;
    public Point scrollToCoordinates;
    private boolean selected;
    private Object tag;
    private Map<Integer, Object> tags = new HashMap();
    int top;
    private ViewTreeObserver viewTreeObserver;
    private int visibility = 0;
    private boolean wasInvalidated;

    public void __constructor__(Context context2) {
        __constructor__(context2, (AttributeSet) null);
    }

    public void __constructor__(Context context2, AttributeSet attributeSet2) {
        __constructor__(context2, attributeSet2, 0);
    }

    public void __constructor__(Context context2, AttributeSet attributeSet2, int defStyle) {
        this.context = context2;
        this.attributeSet = attributeSet2;
        if (attributeSet2 != null) {
            applyAttributes();
        }
    }

    public void applyAttributes() {
        applyIdAttribute();
        applyVisibilityAttribute();
        applyEnabledAttribute();
        applyBackgroundAttribute();
        applyTagAttribute();
        applyOnClickAttribute();
    }

    @Implementation
    public void setId(int id2) {
        this.id = id2;
    }

    @Implementation
    public void setClickable(boolean clickable2) {
        this.clickable = clickable2;
    }

    @Implementation
    public void setFocusable(boolean focusable2) {
        this.focusable = focusable2;
        if (!focusable2) {
            setFocusableInTouchMode(false);
        }
    }

    @Implementation
    public final boolean isFocusableInTouchMode() {
        return this.focusableInTouchMode;
    }

    @Implementation
    public void setFocusableInTouchMode(boolean focusableInTouchMode2) {
        this.focusableInTouchMode = focusableInTouchMode2;
        if (focusableInTouchMode2) {
            setFocusable(true);
        }
    }

    @Implementation
    public boolean isFocusable() {
        return this.focusable;
    }

    @Implementation
    public int getId() {
        return this.id;
    }

    @Implementation
    public static View inflate(Context context2, int resource, ViewGroup root) {
        return ShadowLayoutInflater.from(context2).inflate(resource, root);
    }

    @Implementation
    public View findViewById(int id2) {
        if (id2 == this.id) {
            return this.realView;
        }
        return null;
    }

    @Implementation
    public View findViewWithTag(Object obj) {
        if (obj.equals(getTag())) {
            return this.realView;
        }
        return null;
    }

    @Implementation
    public View getRootView() {
        ShadowView root = this;
        while (root.parent != null) {
            root = root.parent;
        }
        return root.realView;
    }

    @Implementation
    public ViewGroup.LayoutParams getLayoutParams() {
        return this.layoutParams;
    }

    @Implementation
    public void setLayoutParams(ViewGroup.LayoutParams params) {
        this.layoutParams = params;
    }

    @Implementation
    public final ViewParent getParent() {
        if (this.parent == null) {
            return null;
        }
        return (ViewParent) this.parent.realView;
    }

    @Implementation
    public final Context getContext() {
        return this.context;
    }

    @Implementation
    public Resources getResources() {
        return this.context.getResources();
    }

    @Implementation
    public void setBackgroundResource(int backgroundResourceId2) {
        this.backgroundResourceId = backgroundResourceId2;
        setBackgroundDrawable(getResources().getDrawable(backgroundResourceId2));
    }

    public int getBackgroundResourceId() {
        return this.backgroundResourceId;
    }

    @Implementation
    public void setBackgroundColor(int color) {
        this.backgroundColor = color;
        setBackgroundDrawable(new ColorDrawable(getResources().getColor(color)));
    }

    public int getBackgroundColor() {
        return this.backgroundColor;
    }

    @Implementation
    public void setBackgroundDrawable(Drawable d) {
        this.background = d;
    }

    @Implementation
    public Drawable getBackground() {
        return this.background;
    }

    @Implementation
    public int getVisibility() {
        return this.visibility;
    }

    @Implementation
    public void setVisibility(int visibility2) {
        this.visibility = visibility2;
    }

    @Implementation
    public void setSelected(boolean selected2) {
        this.selected = selected2;
    }

    @Implementation
    public boolean isSelected() {
        return this.selected;
    }

    @Implementation
    public boolean isEnabled() {
        return this.enabled;
    }

    @Implementation
    public void setEnabled(boolean enabled2) {
        this.enabled = enabled2;
    }

    @Implementation
    public void setOnClickListener(View.OnClickListener onClickListener2) {
        this.onClickListener = onClickListener2;
    }

    @Implementation
    public boolean performClick() {
        if (this.onClickListener == null) {
            return false;
        }
        this.onClickListener.onClick(this.realView);
        return true;
    }

    @Implementation
    public void setOnLongClickListener(View.OnLongClickListener onLongClickListener2) {
        this.onLongClickListener = onLongClickListener2;
    }

    @Implementation
    public boolean performLongClick() {
        if (this.onLongClickListener == null) {
            return false;
        }
        this.onLongClickListener.onLongClick(this.realView);
        return true;
    }

    @Implementation
    public void setOnKeyListener(View.OnKeyListener onKeyListener2) {
        this.onKeyListener = onKeyListener2;
    }

    @Implementation
    public Object getTag() {
        return this.tag;
    }

    @Implementation
    public void setTag(Object tag2) {
        this.tag = tag2;
    }

    @Implementation
    public final int getHeight() {
        return this.bottom - this.top;
    }

    @Implementation
    public final int getWidth() {
        return this.right - this.left;
    }

    @Implementation
    public final int getMeasuredWidth() {
        return getWidth();
    }

    @Implementation
    public final int getMeasuredHeight() {
        return getHeight();
    }

    @Implementation
    public final void layout(int l, int t, int r, int b) {
        this.left = l;
        this.top = t;
        this.right = r;
        this.bottom = b;
    }

    @Implementation
    public void setPadding(int left2, int top2, int right2, int bottom2) {
        this.paddingLeft = left2;
        this.paddingTop = top2;
        this.paddingRight = right2;
        this.paddingBottom = bottom2;
    }

    @Implementation
    public int getPaddingTop() {
        return this.paddingTop;
    }

    @Implementation
    public int getPaddingLeft() {
        return this.paddingLeft;
    }

    @Implementation
    public int getPaddingRight() {
        return this.paddingRight;
    }

    @Implementation
    public int getPaddingBottom() {
        return this.paddingBottom;
    }

    @Implementation
    public Object getTag(int key) {
        return this.tags.get(Integer.valueOf(key));
    }

    @Implementation
    public void setTag(int key, Object value) {
        this.tags.put(Integer.valueOf(key), value);
    }

    @Implementation
    public void requestLayout() {
        this.didRequestLayout = true;
    }

    public boolean didRequestLayout() {
        return this.didRequestLayout;
    }

    @Implementation
    public final boolean requestFocus() {
        return requestFocus(130);
    }

    @Implementation
    public final boolean requestFocus(int direction) {
        setViewFocus(true);
        return true;
    }

    public void setViewFocus(boolean hasFocus) {
        this.isFocused = hasFocus;
        if (this.onFocusChangeListener != null) {
            this.onFocusChangeListener.onFocusChange(this.realView, hasFocus);
        }
    }

    @Implementation
    public boolean isFocused() {
        return this.isFocused;
    }

    @Implementation
    public boolean hasFocus() {
        return this.isFocused;
    }

    @Implementation
    public void clearFocus() {
        setViewFocus(false);
    }

    @Implementation
    public void setOnFocusChangeListener(View.OnFocusChangeListener listener) {
        this.onFocusChangeListener = listener;
    }

    @Implementation
    public View.OnFocusChangeListener getOnFocusChangeListener() {
        return this.onFocusChangeListener;
    }

    @Implementation
    public void invalidate() {
        this.wasInvalidated = true;
    }

    @Implementation
    public boolean onTouchEvent(MotionEvent event) {
        this.lastTouchEvent = event;
        return false;
    }

    @Implementation
    public void setOnTouchListener(View.OnTouchListener onTouchListener2) {
        this.onTouchListener = onTouchListener2;
    }

    @Implementation
    public boolean dispatchTouchEvent(MotionEvent event) {
        if (this.onTouchListener == null || !this.onTouchListener.onTouch(this.realView, event)) {
            return this.realView.onTouchEvent(event);
        }
        return true;
    }

    public MotionEvent getLastTouchEvent() {
        return this.lastTouchEvent;
    }

    @Implementation
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (this.onKeyListener != null) {
            return this.onKeyListener.onKey(this.realView, event.getKeyCode(), event);
        }
        return false;
    }

    public String innerText() {
        return "";
    }

    public void dump() {
        dump(System.out, 0);
    }

    public void dump(PrintStream out, int indent) {
        dumpFirstPart(out, indent);
        out.println("/>");
    }

    /* access modifiers changed from: protected */
    public void dumpFirstPart(PrintStream out, int indent) {
        dumpIndent(out, indent);
        out.print("<" + this.realView.getClass().getSimpleName());
        if (this.id > 0) {
            out.print(" id=\"" + Robolectric.shadowOf(this.context).getResourceLoader().getNameForId(this.id) + "\"");
        }
    }

    /* access modifiers changed from: protected */
    public void dumpIndent(PrintStream out, int indent) {
        for (int i = 0; i < indent; i++) {
            out.print(" ");
        }
    }

    @Implementation
    public int getLeft() {
        return this.left;
    }

    @Implementation
    public int getTop() {
        return this.top;
    }

    @Implementation
    public int getRight() {
        return this.right;
    }

    @Implementation
    public int getBottom() {
        return this.bottom;
    }

    @Implementation
    public boolean isClickable() {
        return this.clickable;
    }

    public boolean wasInvalidated() {
        return this.wasInvalidated;
    }

    public void clearWasInvalidated() {
        this.wasInvalidated = false;
    }

    public void setLeft(int left2) {
        this.left = left2;
    }

    public void setTop(int top2) {
        this.top = top2;
    }

    public void setRight(int right2) {
        this.right = right2;
    }

    public void setBottom(int bottom2) {
        this.bottom = bottom2;
    }

    public void setPaddingLeft(int paddingLeft2) {
        this.paddingLeft = paddingLeft2;
    }

    public void setPaddingTop(int paddingTop2) {
        this.paddingTop = paddingTop2;
    }

    public void setPaddingRight(int paddingRight2) {
        this.paddingRight = paddingRight2;
    }

    public void setPaddingBottom(int paddingBottom2) {
        this.paddingBottom = paddingBottom2;
    }

    public void setFocused(boolean focused) {
        this.isFocused = focused;
    }

    public boolean derivedIsVisible() {
        for (View parent2 = this.realView; parent2 != null; parent2 = (View) parent2.getParent()) {
            if (parent2.getVisibility() != 0) {
                return false;
            }
        }
        return true;
    }

    public boolean checkedPerformClick() {
        if (!derivedIsVisible()) {
            throw new RuntimeException("View is not visible and cannot be clicked");
        } else if (this.realView.isEnabled()) {
            return this.realView.performClick();
        } else {
            throw new RuntimeException("View is not enabled and cannot be clicked");
        }
    }

    public void applyFocus() {
        if (!noParentHasFocus(this.realView)) {
            return;
        }
        if (Boolean.valueOf(this.attributeSet.getAttributeBooleanValue("android", "focus", false)).booleanValue() || this.realView.isFocusableInTouchMode()) {
            this.realView.requestFocus();
        }
    }

    private void applyIdAttribute() {
        Integer id2 = Integer.valueOf(this.attributeSet.getAttributeResourceValue("android", "id", 0));
        if (getId() == 0) {
            setId(id2.intValue());
        }
    }

    private void applyTagAttribute() {
        String tag2 = this.attributeSet.getAttributeValue("android", "tag");
        if (tag2 != null) {
            setTag(tag2);
        }
    }

    private void applyVisibilityAttribute() {
        String visibility2 = this.attributeSet.getAttributeValue("android", "visibility");
        if (visibility2 == null) {
            return;
        }
        if (visibility2.equals("gone")) {
            setVisibility(8);
        } else if (visibility2.equals("invisible")) {
            setVisibility(4);
        }
    }

    private void applyEnabledAttribute() {
        setEnabled(this.attributeSet.getAttributeBooleanValue("android", "enabled", true));
    }

    private void applyBackgroundAttribute() {
        String source = this.attributeSet.getAttributeValue("android", "background");
        if (source != null && source.startsWith("@drawable/")) {
            setBackgroundResource(this.attributeSet.getAttributeResourceValue("android", "background", 0));
        }
    }

    private void applyOnClickAttribute() {
        final String handlerName = this.attributeSet.getAttributeValue("android", "onClick");
        if (handlerName != null) {
            setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    String idText;
                    try {
                        try {
                            ShadowView.this.getContext().getClass().getMethod(handlerName, new Class[]{View.class}).invoke(ShadowView.this.getContext(), new Object[]{ShadowView.this.realView});
                        } catch (IllegalAccessException e) {
                            throw new IllegalStateException("Could not execute non public method of the activity", e);
                        } catch (InvocationTargetException e2) {
                            throw new IllegalStateException("Could not execute method of the activity", e2);
                        }
                    } catch (NoSuchMethodException e3) {
                        int id = ShadowView.this.getId();
                        if (id == -1) {
                            idText = "";
                        } else {
                            idText = " with id '" + Robolectric.shadowOf(ShadowView.this.context).getResourceLoader().getNameForId(id) + "'";
                        }
                        throw new IllegalStateException("Could not find a method " + handlerName + "(View) in the activity " + ShadowView.this.getContext().getClass() + " for onClick handler" + " on view " + ShadowView.this.realView.getClass() + idText, e3);
                    }
                }
            });
        }
    }

    private boolean noParentHasFocus(View view) {
        while (view != null) {
            if (view.hasFocus()) {
                return false;
            }
            view = (View) view.getParent();
        }
        return true;
    }

    public View.OnTouchListener getOnTouchListener() {
        return this.onTouchListener;
    }

    public View.OnClickListener getOnClickListener() {
        return this.onClickListener;
    }

    @Implementation
    public void setDrawingCacheEnabled(boolean drawingCacheEnabled2) {
        this.drawingCacheEnabled = drawingCacheEnabled2;
    }

    @Implementation
    public boolean isDrawingCacheEnabled() {
        return this.drawingCacheEnabled;
    }

    @Implementation
    public Bitmap getDrawingCache() {
        return (Bitmap) Robolectric.newInstanceOf(Bitmap.class);
    }

    @Implementation
    public void post(Runnable action) {
        Robolectric.getUiThreadScheduler().post(action);
    }

    @Implementation
    public void postDelayed(Runnable action, long delayMills) {
        Robolectric.getUiThreadScheduler().postDelayed(action, delayMills);
    }

    @Implementation
    public void postInvalidateDelayed(long delayMilliseconds) {
        Robolectric.getUiThreadScheduler().postDelayed(new Runnable() {
            public void run() {
                ShadowView.this.realView.invalidate();
            }
        }, delayMilliseconds);
    }

    @Implementation
    public Animation getAnimation() {
        return this.animation;
    }

    @Implementation
    public void setAnimation(Animation anim) {
        this.animation = anim;
    }

    @Implementation
    public void startAnimation(Animation anim) {
        setAnimation(anim);
        this.animation.start();
    }

    @Implementation
    public void clearAnimation() {
        if (this.animation != null) {
            this.animation.cancel();
        }
    }

    @Implementation
    public void scrollTo(int x, int y) {
        this.scrollToCoordinates = new Point(x, y);
    }

    @Implementation
    public int getScrollX() {
        if (this.scrollToCoordinates != null) {
            return this.scrollToCoordinates.x;
        }
        return 0;
    }

    @Implementation
    public int getScrollY() {
        if (this.scrollToCoordinates != null) {
            return this.scrollToCoordinates.y;
        }
        return 0;
    }

    @Implementation
    public ViewTreeObserver getViewTreeObserver() {
        if (this.viewTreeObserver == null) {
            this.viewTreeObserver = (ViewTreeObserver) Robolectric.Reflection.newInstanceOf(ViewTreeObserver.class);
        }
        return this.viewTreeObserver;
    }
}
