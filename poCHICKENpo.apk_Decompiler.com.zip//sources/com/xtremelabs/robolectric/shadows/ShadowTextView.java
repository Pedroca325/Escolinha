package com.xtremelabs.robolectric.shadows;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.text.SpannableStringBuilder;
import android.text.TextPaint;
import android.text.TextWatcher;
import android.text.method.MovementMethod;
import android.text.method.TransformationMethod;
import android.text.style.URLSpan;
import android.view.KeyEvent;
import android.widget.TextView;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import java.util.ArrayList;
import java.util.List;

@Implements(TextView.class)
public class ShadowTextView extends ShadowView {
    private int autoLinkMask;
    private boolean autoLinkPhoneNumbers;
    private int compoundDrawablePadding;
    private CompoundDrawables compoundDrawablesImpl;
    private int gravity;
    private Integer hintColorHexValue;
    private CharSequence hintText;
    private int imeOptions = 0;
    private int inputType;
    private boolean linksClickable;
    private MovementMethod movementMethod;
    private TextView.OnEditorActionListener onEditorActionListener;
    private List<Integer> previousKeyCodes = new ArrayList();
    private List<KeyEvent> previousKeyEvents = new ArrayList();
    protected int selectionEnd = 0;
    protected int selectionStart = 0;
    private CharSequence text = "";
    private int textAppearanceId;
    private Integer textColorHexValue;
    private float textSize = 14.0f;
    private TransformationMethod transformationMethod;
    private List<TextWatcher> watchers = new ArrayList();

    public void applyAttributes() {
        super.applyAttributes();
        applyTextAttribute();
        applyTextColorAttribute();
        applyHintAttribute();
        applyHintColorAttribute();
        applyCompoundDrawablesWithIntrinsicBoundsAttributes();
    }

    @Implementation(i18nSafe = false)
    public void setText(CharSequence text2) {
        if (text2 == null) {
            text2 = "";
        }
        sendBeforeTextChanged(text2);
        CharSequence oldValue = this.text;
        this.text = text2;
        sendOnTextChanged(oldValue);
        sendAfterTextChanged();
    }

    @Implementation
    public final void append(CharSequence text2) {
        boolean isSelectStartAtEnd;
        boolean isSelectEndAtEnd;
        if (this.selectionStart == this.text.length()) {
            isSelectStartAtEnd = true;
        } else {
            isSelectStartAtEnd = false;
        }
        if (this.selectionEnd == this.text.length()) {
            isSelectEndAtEnd = true;
        } else {
            isSelectEndAtEnd = false;
        }
        CharSequence oldValue = this.text;
        StringBuffer sb = new StringBuffer(this.text);
        sb.append(text2);
        sendBeforeTextChanged(sb.toString());
        this.text = sb.toString();
        if (isSelectStartAtEnd) {
            this.selectionStart = this.text.length();
        }
        if (isSelectEndAtEnd) {
            this.selectionEnd = this.text.length();
        }
        sendOnTextChanged(oldValue);
        sendAfterTextChanged();
    }

    @Implementation
    public void setText(int textResourceId) {
        sendBeforeTextChanged(this.text);
        CharSequence oldValue = this.text;
        this.text = getResources().getText(textResourceId);
        sendOnTextChanged(oldValue);
        sendAfterTextChanged();
    }

    private void sendAfterTextChanged() {
        for (TextWatcher watcher : this.watchers) {
            watcher.afterTextChanged(new SpannableStringBuilder(getText()));
        }
    }

    private void sendOnTextChanged(CharSequence oldValue) {
        for (TextWatcher watcher : this.watchers) {
            watcher.onTextChanged(this.text, 0, oldValue.length(), this.text.length());
        }
    }

    private void sendBeforeTextChanged(CharSequence newValue) {
        for (TextWatcher watcher : this.watchers) {
            watcher.beforeTextChanged(this.text, 0, this.text.length(), newValue.length());
        }
    }

    @Implementation
    public CharSequence getText() {
        return this.text;
    }

    @Implementation
    public int length() {
        return this.text.length();
    }

    @Implementation
    public void setTextColor(int color) {
        this.textColorHexValue = Integer.valueOf(color);
    }

    @Implementation
    public void setTextSize(float size) {
        this.textSize = size;
    }

    @Implementation
    public void setTextAppearance(Context context, int resid) {
        this.textAppearanceId = resid;
    }

    @Implementation
    public void setInputType(int type) {
        this.inputType = type;
    }

    @Implementation
    public int getInputType() {
        return this.inputType;
    }

    @Implementation
    public final void setHint(int resId) {
        this.hintText = getResources().getText(resId);
    }

    @Implementation(i18nSafe = false)
    public final void setHint(CharSequence hintText2) {
        this.hintText = hintText2;
    }

    @Implementation
    public CharSequence getHint() {
        return this.hintText;
    }

    @Implementation
    public final void setHintTextColor(int color) {
        this.hintColorHexValue = Integer.valueOf(color);
    }

    @Implementation
    public final boolean getLinksClickable() {
        return this.linksClickable;
    }

    @Implementation
    public final void setLinksClickable(boolean whether) {
        this.linksClickable = whether;
    }

    @Implementation
    public final MovementMethod getMovementMethod() {
        return this.movementMethod;
    }

    @Implementation
    public final void setMovementMethod(MovementMethod movement) {
        this.movementMethod = movement;
    }

    @Implementation
    public URLSpan[] getUrls() {
        String[] words = this.text.toString().split("\\s+");
        List<URLSpan> urlSpans = new ArrayList<>();
        for (String word : words) {
            if (word.startsWith("http://")) {
                urlSpans.add(new URLSpan(word));
            }
        }
        return (URLSpan[]) urlSpans.toArray(new URLSpan[urlSpans.size()]);
    }

    @Implementation
    public final void setAutoLinkMask(int mask) {
        this.autoLinkMask = mask;
        this.autoLinkPhoneNumbers = (mask & 4) != 0;
    }

    @Implementation
    public void setCompoundDrawablesWithIntrinsicBounds(int left, int top, int right, int bottom) {
        this.compoundDrawablesImpl = new CompoundDrawables(left, top, right, bottom);
    }

    @Implementation
    public void setCompoundDrawablesWithIntrinsicBounds(Drawable left, Drawable top, Drawable right, Drawable bottom) {
        this.compoundDrawablesImpl = new CompoundDrawables(left, top, right, bottom);
    }

    @Implementation
    public void setCompoundDrawables(Drawable left, Drawable top, Drawable right, Drawable bottom) {
        this.compoundDrawablesImpl = new CompoundDrawables(left, top, right, bottom);
    }

    @Implementation
    public Drawable[] getCompoundDrawables() {
        if (this.compoundDrawablesImpl == null) {
            return new Drawable[]{null, null, null, null};
        }
        return new Drawable[]{this.compoundDrawablesImpl.leftDrawable, this.compoundDrawablesImpl.topDrawable, this.compoundDrawablesImpl.rightDrawable, this.compoundDrawablesImpl.bottomDrawable};
    }

    @Implementation
    public void setCompoundDrawablePadding(int compoundDrawablePadding2) {
        this.compoundDrawablePadding = compoundDrawablePadding2;
    }

    @Implementation
    public int getCompoundDrawablePadding() {
        return this.compoundDrawablePadding;
    }

    @Implementation
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        this.previousKeyCodes.add(Integer.valueOf(keyCode));
        this.previousKeyEvents.add(event);
        if (this.onKeyListener != null) {
            return this.onKeyListener.onKey(this.realView, keyCode, event);
        }
        return false;
    }

    @Implementation
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        this.previousKeyCodes.add(Integer.valueOf(keyCode));
        this.previousKeyEvents.add(event);
        if (this.onKeyListener != null) {
            return this.onKeyListener.onKey(this.realView, keyCode, event);
        }
        return false;
    }

    public int getPreviousKeyCode(int index) {
        return this.previousKeyCodes.get(index).intValue();
    }

    public KeyEvent getPreviousKeyEvent(int index) {
        return this.previousKeyEvents.get(index);
    }

    @Implementation
    public int getGravity() {
        return this.gravity;
    }

    @Implementation
    public void setGravity(int gravity2) {
        this.gravity = gravity2;
    }

    @Implementation
    public int getImeOptions() {
        return this.imeOptions;
    }

    @Implementation
    public void setImeOptions(int imeOptions2) {
        this.imeOptions = imeOptions2;
    }

    public String innerText() {
        return (this.text == null || getVisibility() != 0) ? "" : this.text.toString();
    }

    @Implementation
    public boolean equals(Object o) {
        return super.equals(Robolectric.shadowOf_(o));
    }

    @Implementation
    public int hashCode() {
        return super.hashCode();
    }

    public CompoundDrawables getCompoundDrawablesImpl() {
        return this.compoundDrawablesImpl;
    }

    /* access modifiers changed from: package-private */
    public void setCompoundDrawablesImpl(CompoundDrawables compoundDrawablesImpl2) {
        this.compoundDrawablesImpl = compoundDrawablesImpl2;
    }

    public Integer getTextColorHexValue() {
        return this.textColorHexValue;
    }

    public int getTextAppearanceId() {
        return this.textAppearanceId;
    }

    public Integer getHintColorHexValue() {
        return this.hintColorHexValue;
    }

    @Implementation
    public float getTextSize() {
        return this.textSize;
    }

    public boolean isAutoLinkPhoneNumbers() {
        return this.autoLinkPhoneNumbers;
    }

    private void applyTextAttribute() {
        String text2 = this.attributeSet.getAttributeValue("android", "text");
        if (text2 != null) {
            if (text2.startsWith("@string/")) {
                text2 = this.context.getResources().getString(this.attributeSet.getAttributeResourceValue("android", "text", 0));
            }
            setText((CharSequence) text2);
        }
    }

    private void applyTextColorAttribute() {
        String colorValue = this.attributeSet.getAttributeValue("android", "textColor");
        if (colorValue == null) {
            return;
        }
        if (colorValue.startsWith("@color/") || colorValue.startsWith("@android:color/")) {
            setTextColor(this.context.getResources().getColor(this.attributeSet.getAttributeResourceValue("android", "textColor", 0)));
        } else if (colorValue.startsWith("#")) {
            setTextColor((int) Long.valueOf(colorValue.replaceAll("#", ""), 16).longValue());
        }
    }

    private void applyHintAttribute() {
        String hint = this.attributeSet.getAttributeValue("android", "hint");
        if (hint != null) {
            if (hint.startsWith("@string/")) {
                hint = this.context.getResources().getString(this.attributeSet.getAttributeResourceValue("android", "hint", 0));
            }
            setHint((CharSequence) hint);
        }
    }

    private void applyHintColorAttribute() {
        String colorValue = this.attributeSet.getAttributeValue("android", "hintColor");
        if (colorValue == null) {
            return;
        }
        if (colorValue.startsWith("@color/") || colorValue.startsWith("@android:color/")) {
            setHintTextColor(this.context.getResources().getColor(this.attributeSet.getAttributeResourceValue("android", "hintColor", 0)));
        } else if (colorValue.startsWith("#")) {
            setHintTextColor((int) Long.valueOf(colorValue.replaceAll("#", ""), 16).longValue());
        }
    }

    private void applyCompoundDrawablesWithIntrinsicBoundsAttributes() {
        setCompoundDrawablesWithIntrinsicBounds(this.attributeSet.getAttributeResourceValue("android", "drawableLeft", 0), this.attributeSet.getAttributeResourceValue("android", "drawableTop", 0), this.attributeSet.getAttributeResourceValue("android", "drawableRight", 0), this.attributeSet.getAttributeResourceValue("android", "drawableBottom", 0));
    }

    @Implementation
    public void setOnEditorActionListener(TextView.OnEditorActionListener onEditorActionListener2) {
        this.onEditorActionListener = onEditorActionListener2;
    }

    public void triggerEditorAction(int imeAction) {
        if (this.onEditorActionListener != null) {
            this.onEditorActionListener.onEditorAction((TextView) this.realView, imeAction, (KeyEvent) null);
        }
    }

    @Implementation
    public void setTransformationMethod(TransformationMethod transformationMethod2) {
        this.transformationMethod = transformationMethod2;
    }

    @Implementation
    public TransformationMethod getTransformationMethod() {
        return this.transformationMethod;
    }

    @Implementation
    public void addTextChangedListener(TextWatcher watcher) {
        this.watchers.add(watcher);
    }

    @Implementation
    public void removeTextChangedListener(TextWatcher watcher) {
        this.watchers.remove(watcher);
    }

    @Implementation
    public TextPaint getPaint() {
        return new TextPaint();
    }

    public void setSelection(int index) {
        setSelection(index, index);
    }

    public void setSelection(int start, int end) {
        this.selectionStart = start;
        this.selectionEnd = end;
    }

    @Implementation
    public int getSelectionStart() {
        return this.selectionStart;
    }

    @Implementation
    public int getSelectionEnd() {
        return this.selectionEnd;
    }

    public List<TextWatcher> getWatchers() {
        return this.watchers;
    }

    public static class CompoundDrawables {
        public Drawable bottomDrawable;
        public Drawable leftDrawable;
        public Drawable rightDrawable;
        public Drawable topDrawable;

        public CompoundDrawables(Drawable left, Drawable top, Drawable right, Drawable bottom) {
            this.leftDrawable = left;
            this.topDrawable = top;
            this.rightDrawable = right;
            this.bottomDrawable = bottom;
        }

        public CompoundDrawables(int left, int top, int right, int bottom) {
            Drawable drawable;
            Drawable drawable2;
            Drawable drawable3;
            Drawable drawable4 = null;
            if (left != 0) {
                drawable = ShadowDrawable.createFromResourceId(left);
            } else {
                drawable = null;
            }
            this.leftDrawable = drawable;
            if (top != 0) {
                drawable2 = ShadowDrawable.createFromResourceId(top);
            } else {
                drawable2 = null;
            }
            this.topDrawable = drawable2;
            if (right != 0) {
                drawable3 = ShadowDrawable.createFromResourceId(right);
            } else {
                drawable3 = null;
            }
            this.rightDrawable = drawable3;
            this.bottomDrawable = bottom != 0 ? ShadowDrawable.createFromResourceId(bottom) : drawable4;
        }

        public boolean equals(Object o) {
            if (this == o) {
                return true;
            }
            if (o == null || getClass() != o.getClass()) {
                return false;
            }
            CompoundDrawables that = (CompoundDrawables) o;
            if (getBottom() != that.getBottom()) {
                return false;
            }
            if (getLeft() != that.getLeft()) {
                return false;
            }
            if (getRight() != that.getRight()) {
                return false;
            }
            if (getTop() != that.getTop()) {
                return false;
            }
            return true;
        }

        public int hashCode() {
            return (((((getLeft() * 31) + getTop()) * 31) + getRight()) * 31) + getBottom();
        }

        public String toString() {
            return "CompoundDrawables{left=" + getLeft() + ", top=" + getTop() + ", right=" + getRight() + ", bottom=" + getBottom() + '}';
        }

        public int getLeft() {
            return Robolectric.shadowOf(this.leftDrawable).getLoadedFromResourceId();
        }

        public int getTop() {
            return Robolectric.shadowOf(this.topDrawable).getLoadedFromResourceId();
        }

        public int getRight() {
            return Robolectric.shadowOf(this.rightDrawable).getLoadedFromResourceId();
        }

        public int getBottom() {
            return Robolectric.shadowOf(this.bottomDrawable).getLoadedFromResourceId();
        }
    }
}
