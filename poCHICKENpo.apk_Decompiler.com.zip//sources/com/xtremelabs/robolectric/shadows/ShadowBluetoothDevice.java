package com.xtremelabs.robolectric.shadows;

import android.bluetooth.BluetoothDevice;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;

@Implements(BluetoothDevice.class)
public class ShadowBluetoothDevice {
    private String name;

    public void setName(String name2) {
        this.name = name2;
    }

    @Implementation
    public String getName() {
        return this.name;
    }
}
