package com.xtremelabs.robolectric.shadows;

import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Shader;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;

@Implements(Paint.class)
public class ShadowPaint {
    private int alpha;
    private boolean antiAlias;
    private Paint.Cap cap;
    private int color;
    private boolean dither;
    private ColorFilter filter;
    private int flags;
    private Paint.Join join;
    @RealObject
    Paint paint;
    private Shader shader;
    private int shadowColor;
    private float shadowDx;
    private float shadowDy;
    private float shadowRadius;
    private Paint.Style style;
    private float width;

    public void __constructor__(int flags2) {
        boolean z = true;
        this.flags = flags2;
        if ((flags2 & 1) != 1) {
            z = false;
        }
        this.antiAlias = z;
    }

    @Implementation
    public int getFlags() {
        return this.flags;
    }

    @Implementation
    public Shader setShader(Shader shader2) {
        this.shader = shader2;
        return shader2;
    }

    @Implementation
    public int getAlpha() {
        return this.alpha;
    }

    @Implementation
    public void setAlpha(int alpha2) {
        this.alpha = alpha2;
    }

    @Implementation
    public Shader getShader() {
        return this.shader;
    }

    @Implementation
    public void setColor(int color2) {
        this.color = color2;
    }

    @Implementation
    public int getColor() {
        return this.color;
    }

    @Implementation
    public void setStyle(Paint.Style style2) {
        this.style = style2;
    }

    @Implementation
    public Paint.Style getStyle() {
        return this.style;
    }

    @Implementation
    public void setStrokeCap(Paint.Cap cap2) {
        this.cap = cap2;
    }

    @Implementation
    public Paint.Cap getStrokeCap() {
        return this.cap;
    }

    @Implementation
    public void setStrokeJoin(Paint.Join join2) {
        this.join = join2;
    }

    @Implementation
    public Paint.Join getStrokeJoin() {
        return this.join;
    }

    @Implementation
    public void setStrokeWidth(float width2) {
        this.width = width2;
    }

    @Implementation
    public float getStrokeWidth() {
        return this.width;
    }

    @Implementation
    public void setShadowLayer(float radius, float dx, float dy, int color2) {
        this.shadowRadius = radius;
        this.shadowDx = dx;
        this.shadowDy = dy;
        this.shadowColor = color2;
    }

    public float getShadowRadius() {
        return this.shadowRadius;
    }

    public float getShadowDx() {
        return this.shadowDx;
    }

    public float getShadowDy() {
        return this.shadowDy;
    }

    public int getShadowColor() {
        return this.shadowColor;
    }

    public Paint.Cap getCap() {
        return this.cap;
    }

    public Paint.Join getJoin() {
        return this.join;
    }

    public float getWidth() {
        return this.width;
    }

    @Implementation
    public ColorFilter getColorFilter() {
        return this.filter;
    }

    @Implementation
    public ColorFilter setColorFilter(ColorFilter filter2) {
        this.filter = filter2;
        return filter2;
    }

    @Implementation
    public void setAntiAlias(boolean antiAlias2) {
        this.antiAlias = antiAlias2;
    }

    @Implementation
    public void setDither(boolean dither2) {
        this.dither = dither2;
    }

    @Implementation
    public final boolean isDither() {
        return this.dither;
    }

    @Implementation
    public final boolean isAntiAlias() {
        return this.antiAlias;
    }
}
