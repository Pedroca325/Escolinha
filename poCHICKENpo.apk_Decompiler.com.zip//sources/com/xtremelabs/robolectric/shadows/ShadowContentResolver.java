package com.xtremelabs.robolectric.shadows;

import android.accounts.Account;
import android.content.ContentProvider;
import android.content.ContentProviderOperation;
import android.content.ContentProviderResult;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.PeriodicSync;
import android.database.ContentObserver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.tester.android.database.TestCursor;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Implements(ContentResolver.class)
public class ShadowContentResolver {
    private static boolean masterSyncAutomatically;
    private static final Map<String, ContentProvider> providers = new HashMap();
    private static final Map<String, Map<Account, Status>> syncableAccounts = new HashMap();
    private final Map<String, ArrayList<ContentProviderOperation>> contentProviderOperations = new HashMap();
    private ContentProviderResult[] contentProviderResults;
    private TestCursor cursor;
    private final List<DeleteStatement> deleteStatements = new ArrayList();
    private final List<InsertStatement> insertStatements = new ArrayList();
    private int nextDatabaseIdForInserts;
    private int nextDatabaseIdForUpdates;
    private List<NotifiedUri> notifiedUris = new ArrayList();
    private final List<UpdateStatement> updateStatements = new ArrayList();
    private HashMap<Uri, TestCursor> uriCursorMap = new HashMap<>();

    public static class Status {
        public int state = -1;
        public boolean syncAutomatically;
        public Bundle syncExtras;
        public int syncRequests;
        public List<PeriodicSync> syncs = new ArrayList();
    }

    public static void reset() {
        syncableAccounts.clear();
        providers.clear();
        masterSyncAutomatically = false;
    }

    public static class NotifiedUri {
        public final ContentObserver observer;
        public final boolean syncToNetwork;
        public final Uri uri;

        public NotifiedUri(Uri uri2, ContentObserver observer2, boolean syncToNetwork2) {
            this.uri = uri2;
            this.syncToNetwork = syncToNetwork2;
            this.observer = observer2;
        }
    }

    @Implementation
    public final InputStream openInputStream(final Uri uri) {
        return new InputStream() {
            public int read() throws IOException {
                throw new UnsupportedOperationException();
            }

            public String toString() {
                return "stream for " + uri;
            }
        };
    }

    @Implementation
    public final Uri insert(Uri url, ContentValues values) {
        ContentProvider provider = getProvider(url);
        if (provider != null) {
            return provider.insert(url, values);
        }
        this.insertStatements.add(new InsertStatement(url, new ContentValues(values)));
        StringBuilder append = new StringBuilder().append(url.toString()).append("/");
        int i = this.nextDatabaseIdForInserts;
        this.nextDatabaseIdForInserts = i + 1;
        return Uri.parse(append.append(i).toString());
    }

    @Implementation
    public int update(Uri uri, ContentValues values, String where, String[] selectionArgs) {
        ContentProvider provider = getProvider(uri);
        if (provider != null) {
            return provider.update(uri, values, where, selectionArgs);
        }
        this.updateStatements.add(new UpdateStatement(uri, new ContentValues(values), where, selectionArgs));
        int i = this.nextDatabaseIdForUpdates;
        this.nextDatabaseIdForUpdates = i + 1;
        return i;
    }

    @Implementation
    public final Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        ContentProvider provider = getProvider(uri);
        if (provider != null) {
            return provider.query(uri, projection, selection, selectionArgs, sortOrder);
        }
        TestCursor returnCursor = getCursor(uri);
        if (returnCursor == null) {
            return null;
        }
        returnCursor.setQuery(uri, projection, selection, selectionArgs, sortOrder);
        return returnCursor;
    }

    @Implementation
    public final int delete(Uri url, String where, String[] selectionArgs) {
        ContentProvider provider = getProvider(url);
        if (provider != null) {
            return provider.delete(url, where, selectionArgs);
        }
        this.deleteStatements.add(new DeleteStatement(url, where, selectionArgs));
        return 1;
    }

    @Implementation
    public final int bulkInsert(Uri url, ContentValues[] values) {
        ContentProvider provider = getProvider(url);
        if (provider != null) {
            return provider.bulkInsert(url, values);
        }
        return 0;
    }

    @Implementation
    public void notifyChange(Uri uri, ContentObserver observer, boolean syncToNetwork) {
        this.notifiedUris.add(new NotifiedUri(uri, observer, syncToNetwork));
    }

    @Implementation
    public void notifyChange(Uri uri, ContentObserver observer) {
        notifyChange(uri, observer, false);
    }

    @Implementation
    public ContentProviderResult[] applyBatch(String authority, ArrayList<ContentProviderOperation> operations) {
        this.contentProviderOperations.put(authority, operations);
        return this.contentProviderResults;
    }

    @Implementation
    public static void requestSync(Account account, String authority, Bundle extras) {
        validateSyncExtrasBundle(extras);
        Status status = getStatus(account, authority, true);
        status.syncRequests++;
        status.syncExtras = extras;
    }

    @Implementation
    public static void setIsSyncable(Account account, String authority, int syncable) {
        getStatus(account, authority, true).state = syncable;
    }

    @Implementation
    public static int getIsSyncable(Account account, String authority) {
        return getStatus(account, authority, true).state;
    }

    @Implementation
    public static boolean getSyncAutomatically(Account account, String authority) {
        return getStatus(account, authority, true).syncAutomatically;
    }

    @Implementation
    public static void setSyncAutomatically(Account account, String authority, boolean sync) {
        getStatus(account, authority, true).syncAutomatically = sync;
    }

    @Implementation
    public static void addPeriodicSync(Account account, String authority, Bundle extras, long pollFrequency) {
        validateSyncExtrasBundle(extras);
        getStatus(account, authority, true).syncs.add(new PeriodicSync(account, authority, extras, pollFrequency));
    }

    @Implementation
    public static void removePeriodicSync(Account account, String authority, Bundle extras) {
        validateSyncExtrasBundle(extras);
        Status status = getStatus(account, authority);
        if (status != null) {
            status.syncs.clear();
        }
    }

    @Implementation
    public static List<PeriodicSync> getPeriodicSyncs(Account account, String authority) {
        return getStatus(account, authority, true).syncs;
    }

    @Implementation
    public static void validateSyncExtrasBundle(Bundle extras) {
        for (String key : extras.keySet()) {
            Object value = extras.get(key);
            if (value != null && !(value instanceof Long) && !(value instanceof Integer) && !(value instanceof Boolean) && !(value instanceof Float) && !(value instanceof Double) && !(value instanceof String) && !(value instanceof Account)) {
                throw new IllegalArgumentException("unexpected value type: " + value.getClass().getName());
            }
        }
    }

    @Implementation
    public static void setMasterSyncAutomatically(boolean sync) {
        masterSyncAutomatically = sync;
    }

    @Implementation
    public static boolean getMasterSyncAutomatically() {
        return masterSyncAutomatically;
    }

    public static ContentProvider getProvider(Uri uri) {
        if (uri != null && "content".equals(uri.getScheme())) {
            return providers.get(uri.getAuthority());
        }
        return null;
    }

    public static void registerProvider(String authority, ContentProvider provider) {
        providers.put(authority, provider);
    }

    public static Status getStatus(Account account, String authority) {
        return getStatus(account, authority, false);
    }

    public static Status getStatus(Account account, String authority, boolean create) {
        Map<Account, Status> map = syncableAccounts.get(authority);
        if (map == null) {
            map = new HashMap<>();
            syncableAccounts.put(authority, map);
        }
        Status status = map.get(account);
        if (status != null || !create) {
            return status;
        }
        Status status2 = new Status();
        map.put(account, status2);
        return status2;
    }

    public void setCursor(TestCursor cursor2) {
        this.cursor = cursor2;
    }

    public void setCursor(Uri uri, TestCursor cursorForUri) {
        this.uriCursorMap.put(uri, cursorForUri);
    }

    public void setNextDatabaseIdForInserts(int nextId) {
        this.nextDatabaseIdForInserts = nextId;
    }

    public void setNextDatabaseIdForUpdates(int nextId) {
        this.nextDatabaseIdForUpdates = nextId;
    }

    public List<InsertStatement> getInsertStatements() {
        return this.insertStatements;
    }

    public List<UpdateStatement> getUpdateStatements() {
        return this.updateStatements;
    }

    public List<Uri> getDeletedUris() {
        List<Uri> uris = new ArrayList<>();
        for (DeleteStatement deleteStatement : this.deleteStatements) {
            uris.add(deleteStatement.getUri());
        }
        return uris;
    }

    public List<DeleteStatement> getDeleteStatements() {
        return this.deleteStatements;
    }

    public List<NotifiedUri> getNotifiedUris() {
        return this.notifiedUris;
    }

    public ArrayList<ContentProviderOperation> getContentProviderOperations(String authority) {
        ArrayList<ContentProviderOperation> operations = this.contentProviderOperations.get(authority);
        if (operations == null) {
            return new ArrayList<>();
        }
        return operations;
    }

    public void setContentProviderResult(ContentProviderResult[] contentProviderResults2) {
        this.contentProviderResults = contentProviderResults2;
    }

    private TestCursor getCursor(Uri uri) {
        if (this.uriCursorMap.get(uri) != null) {
            return this.uriCursorMap.get(uri);
        }
        if (this.cursor != null) {
            return this.cursor;
        }
        return null;
    }

    public static class InsertStatement {
        private final ContentValues contentValues;
        private final Uri uri;

        public InsertStatement(Uri uri2, ContentValues contentValues2) {
            this.uri = uri2;
            this.contentValues = contentValues2;
        }

        public Uri getUri() {
            return this.uri;
        }

        public ContentValues getContentValues() {
            return this.contentValues;
        }
    }

    public static class UpdateStatement {
        private final String[] selectionArgs;
        private final Uri uri;
        private final ContentValues values;
        private final String where;

        public UpdateStatement(Uri uri2, ContentValues values2, String where2, String[] selectionArgs2) {
            this.uri = uri2;
            this.values = values2;
            this.where = where2;
            this.selectionArgs = selectionArgs2;
        }

        public Uri getUri() {
            return this.uri;
        }

        public ContentValues getContentValues() {
            return this.values;
        }

        public String getWhere() {
            return this.where;
        }

        public String[] getSelectionArgs() {
            return this.selectionArgs;
        }
    }

    public static class DeleteStatement {
        private final String[] selectionArgs;
        private final Uri uri;
        private final String where;

        public DeleteStatement(Uri uri2, String where2, String[] selectionArgs2) {
            this.uri = uri2;
            this.where = where2;
            this.selectionArgs = selectionArgs2;
        }

        public Uri getUri() {
            return this.uri;
        }

        public String getWhere() {
            return this.where;
        }

        public String[] getSelectionArgs() {
            return this.selectionArgs;
        }
    }
}
