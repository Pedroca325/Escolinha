package com.xtremelabs.robolectric.shadows;

import android.graphics.Rect;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;

@Implements(Rect.class)
public class ShadowRect {
    @RealObject
    Rect realRect;

    public void __constructor__(int left, int top, int right, int bottom) {
        this.realRect.left = left;
        this.realRect.top = top;
        this.realRect.right = right;
        this.realRect.bottom = bottom;
    }

    public void __constructor__(Rect otherRect) {
        this.realRect.left = otherRect.left;
        this.realRect.top = otherRect.top;
        this.realRect.right = otherRect.right;
        this.realRect.bottom = otherRect.bottom;
    }

    @Implementation
    public void set(Rect rect) {
        set(rect.left, rect.top, rect.right, rect.bottom);
    }

    @Implementation
    public void set(int left, int top, int right, int bottom) {
        this.realRect.left = left;
        this.realRect.top = top;
        this.realRect.right = right;
        this.realRect.bottom = bottom;
    }

    @Implementation
    public int width() {
        return this.realRect.right - this.realRect.left;
    }

    @Implementation
    public int height() {
        return this.realRect.bottom - this.realRect.top;
    }

    @Implementation
    public boolean equals(Object obj) {
        Object o;
        boolean z = true;
        if (obj == null || (o = Robolectric.shadowOf_(obj)) == null || getClass() != o.getClass()) {
            return false;
        }
        if (this == o) {
            return true;
        }
        Rect r = (Rect) obj;
        if (!(this.realRect.left == r.left && this.realRect.top == r.top && this.realRect.right == r.right && this.realRect.bottom == r.bottom)) {
            z = false;
        }
        return z;
    }

    @Implementation
    public String toString() {
        StringBuilder sb = new StringBuilder(32);
        sb.append("Rect(");
        sb.append(this.realRect.left);
        sb.append(", ");
        sb.append(this.realRect.top);
        sb.append(" - ");
        sb.append(this.realRect.right);
        sb.append(", ");
        sb.append(this.realRect.bottom);
        sb.append(")");
        return sb.toString();
    }

    @Implementation
    public boolean contains(int x, int y) {
        return x > this.realRect.left && x < this.realRect.right && y >= this.realRect.top && y <= this.realRect.bottom;
    }

    @Implementation
    public boolean contains(Rect r) {
        return equals(r) || (contains(r.left, r.top) && contains(r.right, r.top) && contains(r.left, r.bottom) && contains(r.right, r.bottom));
    }

    @Implementation
    public static boolean intersects(Rect a, Rect b) {
        return a.left < b.right && b.left < a.right && a.top < b.bottom && b.top < a.bottom;
    }

    @Implementation
    public boolean intersect(Rect r) {
        return intersects(this.realRect, r);
    }

    @Implementation
    public boolean intersect(int left, int top, int right, int bottom) {
        return intersect(new Rect(left, top, right, bottom));
    }

    @Implementation
    public void offset(int dx, int dy) {
        this.realRect.left += dx;
        this.realRect.right += dx;
        this.realRect.top += dy;
        this.realRect.bottom += dy;
    }
}
