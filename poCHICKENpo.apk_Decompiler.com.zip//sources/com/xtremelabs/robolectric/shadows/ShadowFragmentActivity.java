package com.xtremelabs.robolectric.shadows;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;
import com.xtremelabs.robolectric.tester.android.util.TestFragmentManager;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Implements(FragmentActivity.class)
public class ShadowFragmentActivity extends ShadowActivity {
    public static final String FRAGMENTS_TAG = "android:fragments";
    private TestFragmentManager fragmentManager;
    @RealObject
    FragmentActivity realObject;

    public void __constructor__() {
        this.fragmentManager = new TestFragmentManager(this.realObject);
    }

    @Implementation
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        if (bundle != null && bundle.containsKey(FRAGMENTS_TAG)) {
            Object[] arr$ = (Object[]) bundle.getSerializable(FRAGMENTS_TAG);
            int len$ = arr$.length;
            int i$ = 0;
            while (i$ < len$) {
                SerializedFragmentState fragmentState = (SerializedFragmentState) arr$[i$];
                try {
                    Fragment fragment = fragmentState.fragmentClass.newInstance();
                    Robolectric.shadowOf(fragment).setSavedInstanceState(bundle);
                    this.fragmentManager.addFragment(fragmentState.containerId, fragmentState.tag, fragment, true);
                    i$++;
                } catch (InstantiationException e) {
                    throw new RuntimeException(e);
                } catch (IllegalAccessException e2) {
                    throw new RuntimeException(e2);
                }
            }
        }
    }

    @Implementation
    public void onStart() {
        for (Fragment fragment : this.fragmentManager.getFragments().values()) {
            this.fragmentManager.startFragment(fragment);
        }
    }

    @Implementation
    public FragmentManager getSupportFragmentManager() {
        return this.fragmentManager;
    }

    /* JADX WARNING: type inference failed for: r4v0, types: [java.lang.Object[], java.io.Serializable] */
    @Implementation
    public void onSaveInstanceState(Bundle outState) {
        List<SerializedFragmentState> fragmentStates = new ArrayList<>();
        for (Map.Entry<Integer, Fragment> entry : this.fragmentManager.getFragments().entrySet()) {
            fragmentStates.add(new SerializedFragmentState(entry.getKey(), entry.getValue()));
        }
        outState.putSerializable(FRAGMENTS_TAG, fragmentStates.toArray());
    }
}
