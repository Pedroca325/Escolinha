package com.xtremelabs.robolectric.shadows;

import android.os.Parcel;
import android.os.Parcelable;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import java.util.ArrayList;
import java.util.List;

@Implements(Parcel.class)
public class ShadowParcel {
    private int index = 0;
    private ArrayList parcelData = new ArrayList();

    @Implementation
    public static Parcel obtain() {
        return (Parcel) Robolectric.newInstanceOf(Parcel.class);
    }

    @Implementation
    public void writeString(String str) {
        if (str != null) {
            this.parcelData.add(str);
        }
    }

    @Implementation
    public void writeInt(int i) {
        this.parcelData.add(Integer.valueOf(i));
    }

    @Implementation
    public void writeLong(long i) {
        this.parcelData.add(Long.valueOf(i));
    }

    @Implementation
    public void writeByte(byte b) {
        this.parcelData.add(Byte.valueOf(b));
    }

    @Implementation
    public String readString() {
        if (this.index >= this.parcelData.size()) {
            return null;
        }
        ArrayList arrayList = this.parcelData;
        int i = this.index;
        this.index = i + 1;
        return (String) arrayList.get(i);
    }

    @Implementation
    public int readInt() {
        if (this.index >= this.parcelData.size()) {
            return 0;
        }
        ArrayList arrayList = this.parcelData;
        int i = this.index;
        this.index = i + 1;
        return ((Integer) arrayList.get(i)).intValue();
    }

    @Implementation
    public byte readByte() {
        if (this.index >= this.parcelData.size()) {
            return 0;
        }
        ArrayList arrayList = this.parcelData;
        int i = this.index;
        this.index = i + 1;
        return ((Byte) arrayList.get(i)).byteValue();
    }

    @Implementation
    public long readLong() {
        if (this.index >= this.parcelData.size()) {
            return 0;
        }
        ArrayList arrayList = this.parcelData;
        int i = this.index;
        this.index = i + 1;
        return ((Long) arrayList.get(i)).longValue();
    }

    @Implementation
    public void writeParcelable(Parcelable p, int flags) {
        this.parcelData.add(p);
    }

    @Implementation
    public Parcelable readParcelable(ClassLoader cl) {
        if (this.index >= this.parcelData.size()) {
            return null;
        }
        ArrayList arrayList = this.parcelData;
        int i = this.index;
        this.index = i + 1;
        return (Parcelable) arrayList.get(i);
    }

    public int getIndex() {
        return this.index;
    }

    public List getParcelData() {
        return this.parcelData;
    }
}
