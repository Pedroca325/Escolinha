package com.xtremelabs.robolectric.shadows;

import android.os.CountDownTimer;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;

@Implements(CountDownTimer.class)
public class ShadowCountDownTimer {
    private long countDownInterval;
    @RealObject
    CountDownTimer countDownTimer;
    private long millisInFuture;
    private boolean started;

    public void __constructor__(long millisInFuture2, long countDownInterval2) {
        this.countDownInterval = countDownInterval2;
        this.millisInFuture = millisInFuture2;
        this.started = false;
    }

    @Implementation
    public final synchronized CountDownTimer start() {
        this.started = true;
        return this.countDownTimer;
    }

    @Implementation
    public final void cancel() {
        this.started = false;
    }

    public void invokeTick(long millisUntilFinished) {
        this.countDownTimer.onTick(millisUntilFinished);
    }

    public void invokeFinish() {
        this.countDownTimer.onFinish();
    }

    public boolean hasStarted() {
        return this.started;
    }

    public long getCountDownInterval() {
        return this.countDownInterval;
    }

    public long getMillisInFuture() {
        return this.millisInFuture;
    }
}
