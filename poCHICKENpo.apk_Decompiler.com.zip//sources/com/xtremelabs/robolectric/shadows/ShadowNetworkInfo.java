package com.xtremelabs.robolectric.shadows;

import android.net.NetworkInfo;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;

@Implements(NetworkInfo.class)
public class ShadowNetworkInfo {
    private int connectionType = 0;
    private NetworkInfo.DetailedState detailedState;
    private boolean isAvailable = true;
    private boolean isConnected = true;

    public static NetworkInfo newInstance() {
        return newInstance((NetworkInfo.DetailedState) null);
    }

    public static NetworkInfo newInstance(NetworkInfo.DetailedState detailedState2) {
        NetworkInfo networkInfo = (NetworkInfo) Robolectric.newInstanceOf(NetworkInfo.class);
        Robolectric.shadowOf(networkInfo).setDetailedState(detailedState2);
        return networkInfo;
    }

    @Implementation
    public boolean isConnected() {
        return this.isConnected;
    }

    @Implementation
    public boolean isConnectedOrConnecting() {
        return this.isConnected;
    }

    @Implementation
    public NetworkInfo.State getState() {
        return this.isConnected ? NetworkInfo.State.CONNECTED : NetworkInfo.State.DISCONNECTED;
    }

    @Implementation
    public NetworkInfo.DetailedState getDetailedState() {
        return this.detailedState;
    }

    @Implementation
    public int getType() {
        return this.connectionType;
    }

    public void setAvailableStatus(boolean isAvailable2) {
        this.isAvailable = isAvailable2;
    }

    @Implementation
    public boolean isAvailable() {
        return this.isAvailable;
    }

    public void setConnectionStatus(boolean isConnected2) {
        this.isConnected = isConnected2;
    }

    public void setConnectionType(int connectionType2) {
        this.connectionType = connectionType2;
    }

    public void setDetailedState(NetworkInfo.DetailedState detailedState2) {
        this.detailedState = detailedState2;
    }
}
