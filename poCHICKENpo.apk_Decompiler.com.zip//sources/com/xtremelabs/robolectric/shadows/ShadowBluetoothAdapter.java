package com.xtremelabs.robolectric.shadows;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

@Implements(BluetoothAdapter.class)
public class ShadowBluetoothAdapter {
    private Set<BluetoothDevice> bondedDevices = new HashSet();
    private boolean isDiscovering;

    @Implementation
    public static BluetoothAdapter getDefaultAdapter() {
        return (BluetoothAdapter) Robolectric.shadowOf(Robolectric.application).getBluetoothAdapter();
    }

    @Implementation
    public Set<BluetoothDevice> getBondedDevices() {
        return Collections.unmodifiableSet(this.bondedDevices);
    }

    public void setBondedDevices(Set<BluetoothDevice> bluetoothDevices) {
        this.bondedDevices = bluetoothDevices;
    }

    @Implementation
    public boolean startDiscovery() {
        this.isDiscovering = true;
        return true;
    }

    @Implementation
    public boolean cancelDiscovery() {
        this.isDiscovering = false;
        return true;
    }

    @Implementation
    public boolean isDiscovering() {
        return this.isDiscovering;
    }
}
