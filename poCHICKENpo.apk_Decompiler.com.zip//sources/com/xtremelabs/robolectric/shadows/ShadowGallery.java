package com.xtremelabs.robolectric.shadows;

import android.view.KeyEvent;
import android.widget.Gallery;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;

@Implements(Gallery.class)
public class ShadowGallery extends ShadowAbsSpinner {
    @RealObject
    Gallery gallery;

    @Implementation
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case 21:
            case 22:
                if (this.onKeyListener != null) {
                    this.onKeyListener.onKey(this.gallery, keyCode, event);
                }
                return true;
            default:
                return false;
        }
    }
}
