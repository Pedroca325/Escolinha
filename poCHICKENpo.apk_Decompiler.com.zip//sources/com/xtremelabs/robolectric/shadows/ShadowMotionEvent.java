package com.xtremelabs.robolectric.shadows;

import android.view.MotionEvent;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;
import java.lang.reflect.Constructor;

@Implements(MotionEvent.class)
public class ShadowMotionEvent {
    private int action;
    private long downTime;
    private long eventTime;
    private int pointerCount = 1;
    private int[] pointerIds = new int[2];
    private int pointerIndex;
    @RealObject
    private MotionEvent realObject;
    private float[] x = new float[2];
    private float[] y = new float[2];

    @Implementation
    public static MotionEvent obtain(long downTime2, long eventTime2, int action2, float x2, float y2, int metaState) {
        try {
            Constructor<MotionEvent> constructor = MotionEvent.class.getDeclaredConstructor(new Class[0]);
            constructor.setAccessible(true);
            MotionEvent motionEvent = constructor.newInstance(new Object[0]);
            ShadowMotionEvent shadowMotionEvent = (ShadowMotionEvent) Robolectric.shadowOf_(motionEvent);
            shadowMotionEvent.x[0] = x2;
            shadowMotionEvent.y[0] = y2;
            shadowMotionEvent.action = action2;
            shadowMotionEvent.downTime = downTime2;
            shadowMotionEvent.eventTime = eventTime2;
            return motionEvent;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Implementation
    public static MotionEvent obtain(MotionEvent motionEvent) {
        return obtain(motionEvent.getDownTime(), motionEvent.getEventTime(), motionEvent.getAction(), motionEvent.getX(), motionEvent.getY(), motionEvent.getMetaState());
    }

    @Implementation
    public int getAction() {
        return this.action | (this.pointerIndex << 8);
    }

    @Implementation
    public float getRawX() {
        return getX();
    }

    @Implementation
    public float getRawY() {
        return getY();
    }

    @Implementation
    public final float getX() {
        return getX(0);
    }

    @Implementation
    public final float getY() {
        return getY(0);
    }

    @Implementation
    public final float getX(int pointerIndex2) {
        return this.x[pointerIndex2];
    }

    @Implementation
    public final float getY(int pointerIndex2) {
        return this.y[pointerIndex2];
    }

    @Implementation
    public final int getPointerCount() {
        return this.pointerCount;
    }

    @Implementation
    public final long getEventTime() {
        return this.eventTime;
    }

    @Implementation
    public final long getDownTime() {
        return this.downTime;
    }

    @Implementation
    public final int getPointerId(int index) {
        return this.pointerIds[index];
    }

    @Implementation
    public final int findPointerIndex(int id) {
        for (int i = 0; i < this.pointerIds.length; i++) {
            if (this.pointerIds[i] == id) {
                return i;
            }
        }
        return -1;
    }

    @Implementation
    public final int getActionMasked() {
        return this.action;
    }

    @Implementation
    public final int getActionIndex() {
        return this.pointerIndex;
    }

    @Implementation
    public final float getPressure(int pointerIndex2) {
        return 1.0f;
    }

    @Implementation
    public final void setLocation(float x2, float y2) {
        this.x[0] = x2;
        this.y[0] = y2;
    }

    public MotionEvent setPointer2(float x2, float y2) {
        this.x[1] = x2;
        this.y[1] = y2;
        this.pointerCount = 2;
        return this.realObject;
    }

    public void setPointerIndex(int pointerIndex2) {
        this.pointerIndex = pointerIndex2;
    }

    public void setPointerIds(int index0PointerId, int index1PointerId) {
        this.pointerIds[0] = index0PointerId;
        this.pointerIds[1] = index1PointerId;
    }
}
