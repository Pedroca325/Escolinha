package com.xtremelabs.robolectric.shadows;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.widget.ImageView;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.res.ResourceLoader;

@Implements(ImageView.class)
public class ShadowImageView extends ShadowView {
    private int alpha;
    private Bitmap imageBitmap;
    private Drawable imageDrawable;
    private int imageLevel;
    private Matrix matrix;
    private int resourceId;
    private ImageView.ScaleType scaleType;

    public void applyAttributes() {
        super.applyAttributes();
        applyImageAttribute();
    }

    @Implementation
    public void setImageBitmap(Bitmap imageBitmap2) {
        setImageDrawable(new BitmapDrawable(imageBitmap2));
        this.imageBitmap = imageBitmap2;
    }

    @Deprecated
    public Bitmap getImageBitmap() {
        return this.imageBitmap;
    }

    @Implementation
    public void setImageDrawable(Drawable drawable) {
        this.imageDrawable = drawable;
    }

    @Implementation
    public void setImageResource(int resId) {
        this.resourceId = resId;
        setImageDrawable(buildDrawable(resId));
    }

    /* access modifiers changed from: protected */
    public Drawable buildDrawable(int resourceId2) {
        if (!isDrawableXml(resourceId2)) {
            return new BitmapDrawable(BitmapFactory.decodeResource(getResources(), resourceId2));
        }
        ResourceLoader resourceLoader = Robolectric.shadowOf(Robolectric.application).getResourceLoader();
        int[] resourceIds = resourceLoader.getDrawableIds(resourceId2);
        Drawable[] drawables = new Drawable[resourceIds.length];
        for (int i = 0; i < resourceIds.length; i++) {
            drawables[i] = buildDrawable(resourceIds[i]);
        }
        if (resourceLoader.isAnimatableXml(resourceId2)) {
            AnimationDrawable animationDrawable = new AnimationDrawable();
            for (Drawable drawable : drawables) {
                animationDrawable.addFrame(drawable, -1);
            }
            return animationDrawable;
        }
        LayerDrawable layerDrawable = new LayerDrawable(drawables);
        Robolectric.shadowOf(layerDrawable).setLoadedFromResourceId(resourceId2);
        return layerDrawable;
    }

    private boolean isDrawableXml(int resourceId2) {
        return Robolectric.shadowOf(Robolectric.application).getResourceLoader().isDrawableXml(resourceId2);
    }

    @Implementation
    public void setAlpha(int alpha2) {
        this.alpha = alpha2;
    }

    @Implementation
    public ImageView.ScaleType getScaleType() {
        return this.scaleType;
    }

    @Implementation
    public void setScaleType(ImageView.ScaleType scaleType2) {
        this.scaleType = scaleType2;
    }

    @Implementation
    public Drawable getDrawable() {
        return this.imageDrawable;
    }

    @Deprecated
    public Drawable getImageDrawable() {
        return this.imageDrawable;
    }

    public int getAlpha() {
        return this.alpha;
    }

    @Deprecated
    public int getResourceId() {
        return this.resourceId;
    }

    @Implementation
    public void setImageMatrix(Matrix matrix2) {
        this.matrix = new Matrix(matrix2);
    }

    @Implementation
    public void draw(Canvas canvas) {
        if (this.matrix != null) {
            canvas.translate(Robolectric.shadowOf(this.matrix).getTransX(), Robolectric.shadowOf(this.matrix).getTransY());
            canvas.scale(Robolectric.shadowOf(this.matrix).getScaleX(), Robolectric.shadowOf(this.matrix).getScaleY());
        }
        this.imageDrawable.draw(canvas);
    }

    private void applyImageAttribute() {
        String source = this.attributeSet.getAttributeValue("android", "src");
        if (source != null && source.startsWith("@drawable/")) {
            setImageResource(this.attributeSet.getAttributeResourceValue("android", "src", 0));
        }
    }

    @Implementation
    public void setImageLevel(int imageLevel2) {
        this.imageLevel = imageLevel2;
    }

    public int getImageLevel() {
        return this.imageLevel;
    }
}
