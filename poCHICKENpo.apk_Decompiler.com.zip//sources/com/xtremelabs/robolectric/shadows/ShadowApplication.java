package com.xtremelabs.robolectric.shadows;

import android.app.Application;
import android.appwidget.AppWidgetManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.res.AssetManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.widget.Toast;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;
import com.xtremelabs.robolectric.res.ResourceLoader;
import com.xtremelabs.robolectric.tester.org.apache.http.FakeHttpLayer;
import com.xtremelabs.robolectric.util.Scheduler;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

@Implements(Application.class)
public class ShadowApplication extends ShadowContextWrapper {
    private static final Map<String, String> SYSTEM_SERVICE_MAP = new HashMap();
    AppWidgetManager appWidgetManager;
    private Scheduler backgroundScheduler = new Scheduler();
    private Object bluetoothAdapter = Robolectric.newInstanceOf("android.bluetooth.BluetoothAdapter");
    private List<Intent> broadcastIntents = new ArrayList();
    /* access modifiers changed from: private */
    public ComponentName componentNameForBindService;
    private ContentResolver contentResolver;
    private FakeHttpLayer fakeHttpLayer = new FakeHttpLayer();
    private ShadowAlertDialog latestAlertDialog;
    private ShadowDialog latestDialog;
    LayoutInflater layoutInflater;
    private Looper mainLooper = ShadowLooper.myLooper();
    @RealObject
    private Application realApplication;
    private List<Wrapper> registeredReceivers = new ArrayList();
    private ResourceLoader resourceLoader;
    private Resources resources;
    private ServiceConnection serviceConnection;
    /* access modifiers changed from: private */
    public IBinder serviceForBindService;
    private Map<String, Map<String, Object>> sharedPreferenceMap = new HashMap();
    private ArrayList<Toast> shownToasts = new ArrayList<>();
    private List<Intent> startedActivities = new ArrayList();
    private List<Intent> startedServices = new ArrayList();
    private Map<String, Intent> stickyIntents = new HashMap();
    private List<Intent> stoppedServies = new ArrayList();
    private Map<String, Object> systemServices = new HashMap();
    private List<String> unbindableActions = new ArrayList();
    private List<ServiceConnection> unboundServiceConnections = new ArrayList();

    static {
        SYSTEM_SERVICE_MAP.put("window", "com.xtremelabs.robolectric.tester.android.view.TestWindowManager");
        SYSTEM_SERVICE_MAP.put("layout_inflater", "android.view.LayoutInflater");
        SYSTEM_SERVICE_MAP.put("activity", "android.app.ActivityManager");
        SYSTEM_SERVICE_MAP.put("power", "android.os.PowerManager");
        SYSTEM_SERVICE_MAP.put("alarm", "android.app.AlarmManager");
        SYSTEM_SERVICE_MAP.put("clipboard", "android.text.ClipboardManager");
        SYSTEM_SERVICE_MAP.put("notification", "android.app.NotificationManager");
        SYSTEM_SERVICE_MAP.put("keyguard", "android.app.KeyguardManager");
        SYSTEM_SERVICE_MAP.put("location", "android.location.LocationManager");
        SYSTEM_SERVICE_MAP.put("search", "android.app.SearchManager");
        SYSTEM_SERVICE_MAP.put("sensor", "android.hardware.SensorManager");
        SYSTEM_SERVICE_MAP.put("storage", "android.os.storage.StorageManager");
        SYSTEM_SERVICE_MAP.put("vibrator", "android.os.Vibrator");
        SYSTEM_SERVICE_MAP.put("connectivity", "android.net.ConnectivityManager");
        SYSTEM_SERVICE_MAP.put("wifi", "android.net.wifi.WifiManager");
        SYSTEM_SERVICE_MAP.put("audio", "android.media.AudioManager");
        SYSTEM_SERVICE_MAP.put("phone", "android.telephony.TelephonyManager");
        SYSTEM_SERVICE_MAP.put("input_method", "android.view.inputmethod.InputMethodManager");
        SYSTEM_SERVICE_MAP.put("uimode", "android.app.UiModeManager");
        SYSTEM_SERVICE_MAP.put("download", "android.app.DownloadManager");
    }

    public static Application bind(Application application, ResourceLoader resourceLoader2) {
        ShadowApplication shadowApplication = Robolectric.shadowOf(application);
        if (shadowApplication.resourceLoader != null) {
            throw new RuntimeException("ResourceLoader already set!");
        }
        shadowApplication.resourceLoader = resourceLoader2;
        shadowApplication.resources = ShadowResources.bind(new Resources((AssetManager) null, (DisplayMetrics) null, (Configuration) null), resourceLoader2);
        return application;
    }

    public List<Toast> getShownToasts() {
        return this.shownToasts;
    }

    public Scheduler getBackgroundScheduler() {
        return this.backgroundScheduler;
    }

    @Implementation
    public Context getApplicationContext() {
        return this.realApplication;
    }

    @Implementation
    public Resources getResources() {
        if (this.resources == null) {
            this.resources = ShadowResources.bind(new Resources((AssetManager) null, (DisplayMetrics) null, (Configuration) null), this.resourceLoader);
        }
        return this.resources;
    }

    @Implementation
    public ContentResolver getContentResolver() {
        if (this.contentResolver == null) {
            this.contentResolver = new ContentResolver(this.realApplication) {
            };
        }
        return this.contentResolver;
    }

    @Implementation
    public Object getSystemService(String name) {
        String serviceClassName;
        if (name.equals("layout_inflater")) {
            return LayoutInflater.from(this.realApplication);
        }
        Object service = this.systemServices.get(name);
        if (service != null || (serviceClassName = SYSTEM_SERVICE_MAP.get(name)) == null) {
            return service;
        }
        try {
            Object service2 = Robolectric.newInstanceOf(Class.forName(serviceClassName));
            this.systemServices.put(name, service2);
            return service2;
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    @Implementation
    public void startActivity(Intent intent) {
        this.startedActivities.add(intent);
    }

    @Implementation
    public ComponentName startService(Intent intent) {
        this.startedServices.add(intent);
        return new ComponentName("some.service.package", "SomeServiceName-FIXME");
    }

    @Implementation
    public boolean stopService(Intent name) {
        this.stoppedServies.add(name);
        return this.startedServices.contains(name);
    }

    public void setComponentNameAndServiceForBindService(ComponentName name, IBinder service) {
        this.componentNameForBindService = name;
        this.serviceForBindService = service;
    }

    @Implementation
    public boolean bindService(Intent intent, final ServiceConnection serviceConnection2, int i) {
        if (this.unbindableActions.contains(intent.getAction())) {
            return false;
        }
        this.startedServices.add(intent);
        Robolectric.shadowOf(Looper.getMainLooper()).post(new Runnable() {
            public void run() {
                serviceConnection2.onServiceConnected(ShadowApplication.this.componentNameForBindService, ShadowApplication.this.serviceForBindService);
            }
        }, 0);
        return true;
    }

    @Implementation
    public void unbindService(final ServiceConnection serviceConnection2) {
        this.unboundServiceConnections.add(serviceConnection2);
        Robolectric.shadowOf(Looper.getMainLooper()).post(new Runnable() {
            public void run() {
                serviceConnection2.onServiceDisconnected(ShadowApplication.this.componentNameForBindService);
            }
        }, 0);
    }

    public List<ServiceConnection> getUnboundServiceConnections() {
        return this.unboundServiceConnections;
    }

    public Intent getNextStartedActivity() {
        if (this.startedActivities.isEmpty()) {
            return null;
        }
        return this.startedActivities.remove(0);
    }

    public Intent peekNextStartedActivity() {
        if (this.startedActivities.isEmpty()) {
            return null;
        }
        return this.startedActivities.get(0);
    }

    public Intent getNextStartedService() {
        if (this.startedServices.isEmpty()) {
            return null;
        }
        return this.startedServices.remove(0);
    }

    public Intent peekNextStartedService() {
        if (this.startedServices.isEmpty()) {
            return null;
        }
        return this.startedServices.get(0);
    }

    public void clearStartedServices() {
        this.startedServices.clear();
    }

    public Intent getNextStoppedService() {
        if (this.stoppedServies.isEmpty()) {
            return null;
        }
        return this.stoppedServies.remove(0);
    }

    public ResourceLoader getResourceLoader() {
        return this.resourceLoader;
    }

    @Implementation
    public void sendBroadcast(Intent intent) {
        this.broadcastIntents.add(intent);
        List<Wrapper> copy = new ArrayList<>();
        copy.addAll(this.registeredReceivers);
        for (Wrapper wrapper : copy) {
            if (wrapper.intentFilter.matchAction(intent.getAction())) {
                wrapper.broadcastReceiver.onReceive(this.realApplication, intent);
            }
        }
    }

    public List<Intent> getBroadcastIntents() {
        return this.broadcastIntents;
    }

    @Implementation
    public void sendStickyBroadcast(Intent intent) {
        this.stickyIntents.put(intent.getAction(), intent);
        sendBroadcast(intent);
    }

    @Implementation
    public Intent registerReceiver(BroadcastReceiver receiver, IntentFilter filter) {
        return registerReceiverWithContext(receiver, filter, this.realApplication);
    }

    /* access modifiers changed from: package-private */
    public Intent registerReceiverWithContext(BroadcastReceiver receiver, IntentFilter filter, Context context) {
        if (receiver != null) {
            this.registeredReceivers.add(new Wrapper(receiver, filter, context));
        }
        return getStickyIntent(filter);
    }

    private Intent getStickyIntent(IntentFilter filter) {
        for (Intent stickyIntent : this.stickyIntents.values()) {
            int i = 0;
            while (true) {
                if (i < filter.countActions()) {
                    if (stickyIntent.getAction().equals(filter.getAction(i))) {
                        return stickyIntent;
                    }
                    i++;
                }
            }
        }
        return null;
    }

    @Implementation
    public void unregisterReceiver(BroadcastReceiver broadcastReceiver) {
        boolean found = false;
        Iterator<Wrapper> iterator = this.registeredReceivers.iterator();
        while (iterator.hasNext()) {
            if (iterator.next().broadcastReceiver == broadcastReceiver) {
                iterator.remove();
                found = true;
            }
        }
        if (!found) {
            throw new IllegalArgumentException("Receiver not registered: " + broadcastReceiver);
        }
    }

    public void assertNoBroadcastListenersRegistered(Context context, String type) {
        for (Wrapper registeredReceiver : this.registeredReceivers) {
            if (registeredReceiver.context == context) {
                RuntimeException e = new IllegalStateException(type + " " + context + " leaked has leaked IntentReceiver " + registeredReceiver.broadcastReceiver + " that was originally registered here. " + "Are you missing a call to unregisterReceiver()?");
                e.setStackTrace(registeredReceiver.exception.getStackTrace());
                throw e;
            }
        }
    }

    public void assertNoBroadcastListenersOfActionRegistered(Context context, String action) {
        for (Wrapper registeredReceiver : this.registeredReceivers) {
            if (registeredReceiver.context == context) {
                Iterator<String> actions = registeredReceiver.intentFilter.actionsIterator();
                while (actions.hasNext()) {
                    if (actions.next().equals(action)) {
                        RuntimeException e = new IllegalStateException("Unexpected BroadcastReceiver on " + context + " with action " + action + " " + registeredReceiver.broadcastReceiver + " that was originally registered here:");
                        e.setStackTrace(registeredReceiver.exception.getStackTrace());
                        throw e;
                    }
                }
                continue;
            }
        }
    }

    public List<Wrapper> getRegisteredReceivers() {
        return this.registeredReceivers;
    }

    public LayoutInflater getLayoutInflater() {
        return this.layoutInflater;
    }

    public AppWidgetManager getAppWidgetManager() {
        return this.appWidgetManager;
    }

    public FakeHttpLayer getFakeHttpLayer() {
        return this.fakeHttpLayer;
    }

    @Implementation
    public Looper getMainLooper() {
        return this.mainLooper;
    }

    public Map<String, Map<String, Object>> getSharedPreferenceMap() {
        return this.sharedPreferenceMap;
    }

    public ShadowAlertDialog getLatestAlertDialog() {
        return this.latestAlertDialog;
    }

    public void setLatestAlertDialog(ShadowAlertDialog latestAlertDialog2) {
        this.latestAlertDialog = latestAlertDialog2;
    }

    public ShadowDialog getLatestDialog() {
        return this.latestDialog;
    }

    public void setLatestDialog(ShadowDialog latestDialog2) {
        this.latestDialog = latestDialog2;
    }

    public Object getBluetoothAdapter() {
        return this.bluetoothAdapter;
    }

    public void declareActionUnbindable(String action) {
        this.unbindableActions.add(action);
    }

    public void setSystemService(String key, Object service) {
        this.systemServices.put(key, service);
    }

    public class Wrapper {
        public BroadcastReceiver broadcastReceiver;
        public Context context;
        public Throwable exception = new Throwable();
        public IntentFilter intentFilter;

        public Wrapper(BroadcastReceiver broadcastReceiver2, IntentFilter intentFilter2, Context context2) {
            this.broadcastReceiver = broadcastReceiver2;
            this.intentFilter = intentFilter2;
            this.context = context2;
        }

        public BroadcastReceiver getBroadcastReceiver() {
            return this.broadcastReceiver;
        }

        public IntentFilter getIntentFilter() {
            return this.intentFilter;
        }

        public Context getContext() {
            return this.context;
        }
    }
}
