package com.xtremelabs.robolectric.shadows;

import android.text.style.URLSpan;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;

@Implements(URLSpan.class)
public class ShadowURLSpan {
    private String url;

    public void __constructor__(String url2) {
        this.url = url2;
    }

    @Implementation
    public String getURL() {
        return this.url;
    }
}
