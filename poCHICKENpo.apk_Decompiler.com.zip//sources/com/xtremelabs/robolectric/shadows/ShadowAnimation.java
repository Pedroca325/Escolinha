package com.xtremelabs.robolectric.shadows;

import android.view.animation.Animation;
import android.view.animation.Interpolator;
import android.view.animation.ShadowAnimationBridge;
import android.view.animation.Transformation;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;

@Implements(Animation.class)
public class ShadowAnimation {
    private long durationMillis = 0;
    private Interpolator interpolator;
    private Animation.AnimationListener listener;
    @RealObject
    private Animation realAnimation;
    private int repeatCount;
    private int repeatMode;
    private boolean startFlag = false;
    private long startOffset;

    @Implementation
    public void setAnimationListener(Animation.AnimationListener l) {
        this.listener = l;
    }

    @Implementation
    public void start() {
        this.startFlag = true;
        if (this.listener != null) {
            this.listener.onAnimationStart(this.realAnimation);
        }
    }

    @Implementation
    public void cancel() {
        this.startFlag = false;
        if (this.listener != null) {
            this.listener.onAnimationEnd(this.realAnimation);
        }
    }

    @Implementation
    public boolean hasStarted() {
        return this.startFlag;
    }

    @Implementation
    public void setDuration(long durationMillis2) {
        this.durationMillis = durationMillis2;
    }

    @Implementation
    public long getDuration() {
        return this.durationMillis;
    }

    @Implementation
    public void setInterpolator(Interpolator interpolator2) {
        this.interpolator = interpolator2;
    }

    @Implementation
    public Interpolator getInterpolator() {
        return this.interpolator;
    }

    @Implementation
    public void setRepeatCount(int repeatCount2) {
        this.repeatCount = repeatCount2;
    }

    @Implementation
    public int getRepeatCount() {
        return this.repeatCount;
    }

    @Implementation
    public void setRepeatMode(int repeatMode2) {
        this.repeatMode = repeatMode2;
    }

    @Implementation
    public int getRepeatMode() {
        return this.repeatMode;
    }

    @Implementation
    public void setStartOffset(long startOffset2) {
        this.startOffset = startOffset2;
    }

    @Implementation
    public long getStartOffset() {
        return this.startOffset;
    }

    public Animation.AnimationListener getAnimationListener() {
        return this.listener;
    }

    public void invokeRepeat() {
        if (this.listener != null) {
            this.listener.onAnimationRepeat(this.realAnimation);
        }
    }

    public void invokeEnd() {
        if (this.listener != null) {
            this.listener.onAnimationEnd(this.realAnimation);
        }
        new ShadowAnimationBridge(this.realAnimation).applyTransformation(1.0f, new Transformation());
    }
}
