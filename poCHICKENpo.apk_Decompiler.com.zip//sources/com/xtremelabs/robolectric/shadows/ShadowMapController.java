package com.xtremelabs.robolectric.shadows;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapController;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;

@Implements(MapController.class)
public class ShadowMapController {
    private GeoPoint geoPointAnimatedTo;
    private ShadowMapView shadowMapView;

    @Implementation
    public void animateTo(GeoPoint geoPoint) {
        setCenter(geoPoint);
        this.geoPointAnimatedTo = geoPoint;
    }

    @Implementation
    public void animateTo(GeoPoint geoPoint, Runnable runnable) {
        animateTo(geoPoint);
        runnable.run();
    }

    @Implementation
    public void setCenter(GeoPoint geoPoint) {
        this.shadowMapView.mapCenter = geoPoint;
    }

    @Implementation
    public void zoomToSpan(int latSpan, int lngSpan) {
        this.shadowMapView.latitudeSpan = latSpan;
        this.shadowMapView.longitudeSpan = lngSpan;
    }

    @Implementation
    public boolean zoomIn() {
        this.shadowMapView.zoomLevel++;
        return true;
    }

    @Implementation
    public boolean zoomOut() {
        ShadowMapView shadowMapView2 = this.shadowMapView;
        shadowMapView2.zoomLevel--;
        return true;
    }

    @Implementation
    public int setZoom(int i) {
        this.shadowMapView.zoomLevel = i;
        return i;
    }

    public ShadowMapView getShadowMapView() {
        return this.shadowMapView;
    }

    public GeoPoint getGeoPointAnimatedTo() {
        return this.geoPointAnimatedTo;
    }

    /* access modifiers changed from: package-private */
    public void setShadowMapView(ShadowMapView shadowMapView2) {
        this.shadowMapView = shadowMapView2;
    }
}
