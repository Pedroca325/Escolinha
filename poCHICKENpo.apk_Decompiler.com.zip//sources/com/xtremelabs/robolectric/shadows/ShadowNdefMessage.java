package com.xtremelabs.robolectric.shadows;

import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;

@Implements(NdefMessage.class)
public class ShadowNdefMessage {
    private NdefRecord[] ndefRecords;
    @RealObject
    private NdefMessage realNdefMessage;

    public void __constructor__(NdefRecord[] ndefRecords2) {
        this.ndefRecords = ndefRecords2;
    }

    @Implementation
    public NdefRecord[] getRecords() {
        return this.ndefRecords;
    }
}
