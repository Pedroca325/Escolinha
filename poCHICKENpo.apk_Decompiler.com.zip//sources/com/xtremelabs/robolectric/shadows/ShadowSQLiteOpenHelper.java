package com.xtremelabs.robolectric.shadows;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;

@Implements(SQLiteOpenHelper.class)
public class ShadowSQLiteOpenHelper {
    private static SQLiteDatabase database;
    @RealObject
    private SQLiteOpenHelper realHelper;

    public void __constructor__(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        if (database != null) {
            database.close();
        }
        database = null;
    }

    @Implementation
    public synchronized void close() {
        if (database != null) {
            database.close();
        }
        database = null;
    }

    @Implementation
    public synchronized SQLiteDatabase getReadableDatabase() {
        if (database == null) {
            database = SQLiteDatabase.openDatabase("path", (SQLiteDatabase.CursorFactory) null, 0);
            this.realHelper.onCreate(database);
        }
        this.realHelper.onOpen(database);
        return database;
    }

    @Implementation
    public synchronized SQLiteDatabase getWritableDatabase() {
        if (database == null) {
            database = SQLiteDatabase.openDatabase("path", (SQLiteDatabase.CursorFactory) null, 0);
            this.realHelper.onCreate(database);
        }
        this.realHelper.onOpen(database);
        return database;
    }
}
