package com.xtremelabs.robolectric.shadows;

import android.util.Log;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

@Implements(Log.class)
public class ShadowLog {
    private static List<LogItem> logs = new ArrayList();
    public static PrintStream stream;

    @Implementation
    public static void e(String tag, String msg) {
        e(tag, msg, (Throwable) null);
    }

    @Implementation
    public static void e(String tag, String msg, Throwable throwable) {
        addLog(6, tag, msg, throwable);
    }

    @Implementation
    public static void d(String tag, String msg) {
        d(tag, msg, (Throwable) null);
    }

    @Implementation
    public static void d(String tag, String msg, Throwable throwable) {
        addLog(3, tag, msg, throwable);
    }

    @Implementation
    public static void i(String tag, String msg) {
        i(tag, msg, (Throwable) null);
    }

    @Implementation
    public static void i(String tag, String msg, Throwable throwable) {
        addLog(4, tag, msg, throwable);
    }

    @Implementation
    public static void v(String tag, String msg) {
        v(tag, msg, (Throwable) null);
    }

    @Implementation
    public static void v(String tag, String msg, Throwable throwable) {
        addLog(2, tag, msg, throwable);
    }

    @Implementation
    public static void w(String tag, String msg) {
        w(tag, msg, (Throwable) null);
    }

    @Implementation
    public static void w(String tag, Throwable throwable) {
        w(tag, (String) null, throwable);
    }

    @Implementation
    public static void w(String tag, String msg, Throwable throwable) {
        addLog(5, tag, msg, throwable);
    }

    @Implementation
    public static void wtf(String tag, String msg) {
        wtf(tag, msg, (Throwable) null);
    }

    @Implementation
    public static void wtf(String tag, String msg, Throwable throwable) {
        addLog(7, tag, msg, throwable);
    }

    @Implementation
    public static boolean isLoggable(String tag, int level) {
        return stream != null || level >= 4;
    }

    private static void addLog(int level, String tag, String msg, Throwable throwable) {
        if (stream != null) {
            logToStream(stream, level, tag, msg, throwable);
        }
        logs.add(new LogItem(level, tag, msg, throwable));
    }

    private static void logToStream(PrintStream ps, int level, String tag, String msg, Throwable throwable) {
        char c;
        switch (level) {
            case 2:
                c = 'V';
                break;
            case 3:
                c = 'D';
                break;
            case 4:
                c = 'I';
                break;
            case ShadowMediaRecorder.STATE_RECORDING /*5*/:
                c = 'W';
                break;
            case ShadowMediaRecorder.STATE_RELEASED /*6*/:
                c = 'E';
                break;
            case 7:
                c = 'A';
                break;
            default:
                c = '?';
                break;
        }
        ps.println(c + "/" + tag + ": " + msg);
        if (throwable != null) {
            throwable.printStackTrace(ps);
        }
    }

    public static List<LogItem> getLogs() {
        return logs;
    }

    public static void reset() {
        logs.clear();
    }

    public static class LogItem {
        public final String msg;
        public final String tag;
        public final Throwable throwable;
        public final int type;

        public LogItem(int type2, String tag2, String msg2, Throwable throwable2) {
            this.type = type2;
            this.tag = tag2;
            this.msg = msg2;
            this.throwable = throwable2;
        }
    }
}
