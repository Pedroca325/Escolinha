package com.xtremelabs.robolectric.shadows;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Implements(AlarmManager.class)
public class ShadowAlarmManager {
    private List<ScheduledAlarm> scheduledAlarms = new ArrayList();

    @Implementation
    public void set(int type, long triggerAtTime, PendingIntent operation) {
        Intent intent = Robolectric.shadowOf(operation).getSavedIntent();
        Iterator i$ = this.scheduledAlarms.iterator();
        while (true) {
            if (!i$.hasNext()) {
                break;
            }
            ScheduledAlarm scheduledAlarm = i$.next();
            if (Robolectric.shadowOf(scheduledAlarm.operation).getSavedIntent().filterEquals(intent)) {
                this.scheduledAlarms.remove(scheduledAlarm);
                break;
            }
        }
        this.scheduledAlarms.add(new ScheduledAlarm(this, type, triggerAtTime, operation));
    }

    public ScheduledAlarm getNextScheduledAlarm() {
        if (this.scheduledAlarms.isEmpty()) {
            return null;
        }
        return this.scheduledAlarms.remove(0);
    }

    public ScheduledAlarm peekNextScheduledAlarm() {
        if (this.scheduledAlarms.isEmpty()) {
            return null;
        }
        return this.scheduledAlarms.get(0);
    }

    public List<ScheduledAlarm> getScheduledAlarms() {
        return this.scheduledAlarms;
    }

    @Implementation
    public void cancel(PendingIntent pendingIntent) {
        Intent intentTypeToRemove = Robolectric.shadowOf(pendingIntent).getSavedIntent();
        Iterator i$ = new ArrayList(this.scheduledAlarms).iterator();
        while (i$.hasNext()) {
            ScheduledAlarm scheduledAlarm = (ScheduledAlarm) i$.next();
            if (intentTypeToRemove.filterEquals(Robolectric.shadowOf(scheduledAlarm.operation).getSavedIntent())) {
                this.scheduledAlarms.remove(scheduledAlarm);
            }
        }
    }

    public class ScheduledAlarm {
        public long interval;
        public PendingIntent operation;
        public long triggerAtTime;
        public int type;

        public ScheduledAlarm(ShadowAlarmManager shadowAlarmManager, int type2, long triggerAtTime2, PendingIntent operation2) {
            this(type2, triggerAtTime2, 0, operation2);
        }

        public ScheduledAlarm(int type2, long triggerAtTime2, long interval2, PendingIntent operation2) {
            this.type = type2;
            this.triggerAtTime = triggerAtTime2;
            this.operation = operation2;
            this.interval = interval2;
        }
    }
}
