package com.xtremelabs.robolectric.shadows;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import java.util.ArrayList;

@Implements(SensorManager.class)
public class ShadowSensorManager {
    public boolean forceListenersToFail = false;
    private ArrayList<SensorEventListener> listeners = new ArrayList<>();

    @Implementation
    public boolean registerListener(SensorEventListener listener, Sensor sensor, int rate) {
        if (this.forceListenersToFail) {
            return false;
        }
        if (!this.listeners.contains(listener)) {
            this.listeners.add(listener);
        }
        return true;
    }

    @Implementation
    public void unregisterListener(SensorEventListener listener, Sensor sensor) {
        this.listeners.remove(listener);
    }

    public boolean hasListener(SensorEventListener listener) {
        return this.listeners.contains(listener);
    }

    public SensorEvent createSensorEvent() {
        return (SensorEvent) Robolectric.newInstanceOf(SensorEvent.class);
    }
}
