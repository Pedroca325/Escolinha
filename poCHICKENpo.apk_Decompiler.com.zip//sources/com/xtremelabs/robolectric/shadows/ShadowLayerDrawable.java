package com.xtremelabs.robolectric.shadows;

import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;

@Implements(LayerDrawable.class)
public class ShadowLayerDrawable extends ShadowDrawable {
    protected Drawable[] drawables;
    @RealObject
    protected LayerDrawable realLayerDrawable;

    public void __constructor__(Drawable[] drawables2) {
        this.drawables = drawables2;
    }

    @Implementation
    public int getNumberOfLayers() {
        return this.drawables.length;
    }

    @Implementation
    public Drawable getDrawable(int idx) {
        if (idx >= this.drawables.length || idx < 0) {
            return null;
        }
        return this.drawables[idx];
    }
}
