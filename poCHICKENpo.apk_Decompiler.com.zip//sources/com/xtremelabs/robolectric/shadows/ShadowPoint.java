package com.xtremelabs.robolectric.shadows;

import android.graphics.Point;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;

@Implements(Point.class)
public class ShadowPoint {
    @RealObject
    private Point realPoint;

    public void __constructor__(int x, int y) {
        this.realPoint.x = x;
        this.realPoint.y = y;
    }

    public void __constructor__(Point src) {
        this.realPoint.x = src.x;
        this.realPoint.y = src.y;
    }

    @Implementation
    public void set(int x, int y) {
        this.realPoint.x = x;
        this.realPoint.y = y;
    }

    @Implementation
    public final void negate() {
        this.realPoint.x = -this.realPoint.x;
        this.realPoint.y = -this.realPoint.y;
    }

    @Implementation
    public final void offset(int dx, int dy) {
        this.realPoint.x += dx;
        this.realPoint.y += dy;
    }

    @Implementation
    public boolean equals(Object object) {
        Object o;
        if (object == null || (o = Robolectric.shadowOf_(object)) == null) {
            return false;
        }
        if (this == o) {
            return true;
        }
        if (getClass() != o.getClass()) {
            return false;
        }
        ShadowPoint that = (ShadowPoint) o;
        if (this.realPoint.x == that.realPoint.x && this.realPoint.y == that.realPoint.y) {
            return true;
        }
        return false;
    }

    @Implementation
    public int hashCode() {
        return (this.realPoint.x * 32713) + this.realPoint.y;
    }

    @Implementation
    public String toString() {
        return "Point(" + this.realPoint.x + ", " + this.realPoint.y + ")";
    }

    @Implementation
    public final boolean equals(int x, int y) {
        return this.realPoint.x == x && this.realPoint.y == y;
    }
}
