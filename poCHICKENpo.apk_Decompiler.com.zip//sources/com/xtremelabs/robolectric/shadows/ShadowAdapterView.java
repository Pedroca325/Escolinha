package com.xtremelabs.robolectric.shadows;

import android.database.DataSetObserver;
import android.os.Handler;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;
import java.util.ArrayList;
import java.util.List;

@Implements(AdapterView.class)
public class ShadowAdapterView extends ShadowViewGroup {
    private static boolean automaticallyUpdateRowViews = true;
    private static int ignoreRowsAtEndOfList = 0;
    private Adapter adapter;
    private int itemCount = 0;
    private View mEmptyView;
    private AdapterView.OnItemClickListener onItemClickListener;
    private AdapterView.OnItemLongClickListener onItemLongClickListener;
    /* access modifiers changed from: private */
    public AdapterView.OnItemSelectedListener onItemSelectedListener;
    private List<Object> previousItems = new ArrayList();
    /* access modifiers changed from: private */
    @RealObject
    public AdapterView realAdapterView;
    private int selectedPosition;
    /* access modifiers changed from: private */
    public boolean valid = false;

    @Implementation
    public void setAdapter(Adapter adapter2) {
        this.adapter = adapter2;
        if (adapter2 != null) {
            adapter2.registerDataSetObserver(new AdapterViewDataSetObserver());
        }
        invalidateAndScheduleUpdate();
        setSelection(0);
    }

    @Implementation
    public void setEmptyView(View emptyView) {
        this.mEmptyView = emptyView;
        updateEmptyStatus(this.adapter == null || this.adapter.isEmpty());
    }

    @Implementation
    public int getPositionForView(View view) {
        while (view.getParent() != null && view.getParent() != this.realView) {
            view = (View) view.getParent();
        }
        for (int i = 0; i < getChildCount(); i++) {
            if (view == getChildAt(i)) {
                return i;
            }
        }
        return -1;
    }

    /* access modifiers changed from: private */
    public void invalidateAndScheduleUpdate() {
        boolean z = false;
        this.valid = false;
        this.itemCount = this.adapter == null ? 0 : this.adapter.getCount();
        if (this.itemCount == 0) {
            z = true;
        }
        updateEmptyStatus(z);
        if (hasOnItemSelectedListener() && this.itemCount == 0) {
            this.onItemSelectedListener.onNothingSelected(this.realAdapterView);
        }
        new Handler().post(new Runnable() {
            public void run() {
                if (!ShadowAdapterView.this.valid) {
                    ShadowAdapterView.this.update();
                    boolean unused = ShadowAdapterView.this.valid = true;
                }
            }
        });
    }

    /* access modifiers changed from: private */
    public boolean hasOnItemSelectedListener() {
        return this.onItemSelectedListener != null;
    }

    private void updateEmptyStatus(boolean empty) {
        if (!empty) {
            if (this.mEmptyView != null) {
                this.mEmptyView.setVisibility(8);
            }
            setVisibility(0);
        } else if (this.mEmptyView != null) {
            this.mEmptyView.setVisibility(0);
            setVisibility(8);
        } else {
            setVisibility(0);
        }
    }

    public boolean checkValidity() {
        update();
        return this.valid;
    }

    public static void ignoreRowsAtEndOfListDuringValidation(int countOfRows) {
        ignoreRowsAtEndOfList = countOfRows;
    }

    public static void automaticallyUpdateRowViews(boolean shouldUpdate) {
        automaticallyUpdateRowViews = shouldUpdate;
    }

    @Implementation
    public int getSelectedItemPosition() {
        return this.selectedPosition;
    }

    @Implementation
    public Object getSelectedItem() {
        return getItemAtPosition(getSelectedItemPosition());
    }

    @Implementation
    public Adapter getAdapter() {
        return this.adapter;
    }

    @Implementation
    public int getCount() {
        return this.itemCount;
    }

    @Implementation
    public void setOnItemSelectedListener(AdapterView.OnItemSelectedListener listener) {
        this.onItemSelectedListener = listener;
    }

    @Implementation
    public final AdapterView.OnItemSelectedListener getOnItemSelectedListener() {
        return this.onItemSelectedListener;
    }

    @Implementation
    public void setOnItemClickListener(AdapterView.OnItemClickListener listener) {
        this.onItemClickListener = listener;
    }

    @Implementation
    public final AdapterView.OnItemClickListener getOnItemClickListener() {
        return this.onItemClickListener;
    }

    @Implementation
    public void setOnItemLongClickListener(AdapterView.OnItemLongClickListener listener) {
        this.onItemLongClickListener = listener;
    }

    @Implementation
    public Object getItemAtPosition(int position) {
        Adapter adapter2 = getAdapter();
        if (adapter2 == null || position < 0) {
            return null;
        }
        return adapter2.getItem(position);
    }

    @Implementation
    public long getItemIdAtPosition(int position) {
        Adapter adapter2 = getAdapter();
        if (adapter2 == null || position < 0) {
            return Long.MIN_VALUE;
        }
        return adapter2.getItemId(position);
    }

    @Implementation
    public void setSelection(final int position) {
        this.selectedPosition = position;
        if (this.selectedPosition >= 0) {
            new Handler().post(new Runnable() {
                public void run() {
                    if (ShadowAdapterView.this.hasOnItemSelectedListener()) {
                        ShadowAdapterView.this.onItemSelectedListener.onItemSelected(ShadowAdapterView.this.realAdapterView, ShadowAdapterView.this.getChildAt(position), position, ShadowAdapterView.this.getAdapter().getItemId(position));
                    }
                }
            });
        }
    }

    @Implementation
    public boolean performItemClick(View view, int position, long id) {
        if (this.onItemClickListener == null) {
            return false;
        }
        this.onItemClickListener.onItemClick(this.realAdapterView, view, position, id);
        return true;
    }

    public boolean performItemLongClick(View view, int position, long id) {
        if (this.onItemLongClickListener == null) {
            return false;
        }
        this.onItemLongClickListener.onItemLongClick(this.realAdapterView, view, position, id);
        return true;
    }

    public boolean performItemClick(int position) {
        return this.realAdapterView.performItemClick(this.realAdapterView.getChildAt(position), position, this.realAdapterView.getItemIdAtPosition(position));
    }

    public int findIndexOfItemContainingText(String targetText) {
        for (int i = 0; i < this.realAdapterView.getChildCount(); i++) {
            if (Robolectric.shadowOf(this.realAdapterView.getChildAt(i)).innerText().contains(targetText)) {
                return i;
            }
        }
        return -1;
    }

    public View findItemContainingText(String targetText) {
        int itemIndex = findIndexOfItemContainingText(targetText);
        if (itemIndex == -1) {
            return null;
        }
        return this.realAdapterView.getChildAt(itemIndex);
    }

    public void clickFirstItemContainingText(String targetText) {
        int itemIndex = findIndexOfItemContainingText(targetText);
        if (itemIndex == -1) {
            throw new IllegalArgumentException("No item found containing text \"" + targetText + "\"");
        }
        performItemClick(itemIndex);
    }

    @Implementation
    public View getEmptyView() {
        return this.mEmptyView;
    }

    /* access modifiers changed from: private */
    public void update() {
        if (automaticallyUpdateRowViews) {
            super.removeAllViews();
            addViews();
        }
    }

    /* access modifiers changed from: protected */
    public void addViews() {
        Adapter adapter2 = getAdapter();
        if (adapter2 == null) {
            return;
        }
        if (!this.valid || this.previousItems.size() - ignoreRowsAtEndOfList == adapter2.getCount() - ignoreRowsAtEndOfList) {
            List<Object> newItems = new ArrayList<>();
            for (int i = 0; i < adapter2.getCount() - ignoreRowsAtEndOfList; i++) {
                View view = adapter2.getView(i, (View) null, this.realAdapterView);
                if (view != null) {
                    addView(view);
                }
                newItems.add(adapter2.getItem(i));
            }
            if (!this.valid || newItems.equals(this.previousItems)) {
                this.previousItems = newItems;
                return;
            }
            throw new RuntimeException("view is valid but current items <" + newItems + "> don't match previous items <" + this.previousItems + ">");
        }
        throw new ArrayIndexOutOfBoundsException("view is valid but adapter.getCount() has changed from " + this.previousItems.size() + " to " + adapter2.getCount());
    }

    protected class AdapterViewDataSetObserver extends DataSetObserver {
        protected AdapterViewDataSetObserver() {
        }

        public void onChanged() {
            ShadowAdapterView.this.invalidateAndScheduleUpdate();
        }

        public void onInvalidated() {
            ShadowAdapterView.this.invalidateAndScheduleUpdate();
        }
    }
}
