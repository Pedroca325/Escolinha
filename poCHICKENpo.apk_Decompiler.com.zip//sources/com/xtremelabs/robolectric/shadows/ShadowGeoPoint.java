package com.xtremelabs.robolectric.shadows;

import com.google.android.maps.GeoPoint;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;

@Implements(GeoPoint.class)
public class ShadowGeoPoint {
    private int lat;
    private int lng;

    public void __constructor__(int lat2, int lng2) {
        this.lat = lat2;
        this.lng = lng2;
    }

    @Implementation
    public int getLatitudeE6() {
        return this.lat;
    }

    @Implementation
    public int getLongitudeE6() {
        return this.lng;
    }

    @Implementation
    public boolean equals(Object o) {
        Object o2;
        if (o == null || (o2 = Robolectric.shadowOf_(o)) == null) {
            return false;
        }
        if (this == o2) {
            return true;
        }
        if (getClass() != o2.getClass()) {
            return false;
        }
        ShadowGeoPoint that = (ShadowGeoPoint) o2;
        if (this.lat == that.lat && this.lng == that.lng) {
            return true;
        }
        return false;
    }

    @Implementation
    public int hashCode() {
        return (this.lat * 31) + this.lng;
    }

    @Implementation
    public String toString() {
        return "ShadowGeoPoint{lat=" + ShadowMapView.fromE6(this.lat) + ", lng=" + ShadowMapView.fromE6(this.lng) + '}';
    }

    public int getLat() {
        return this.lat;
    }

    public int getLng() {
        return this.lng;
    }
}
