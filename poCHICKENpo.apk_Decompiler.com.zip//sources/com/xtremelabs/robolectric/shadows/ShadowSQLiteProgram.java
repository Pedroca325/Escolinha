package com.xtremelabs.robolectric.shadows;

import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteProgram;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@Implements(SQLiteProgram.class)
public abstract class ShadowSQLiteProgram {
    PreparedStatement actualDBstatement;
    Connection connection;
    protected SQLiteDatabase mDatabase;
    @RealObject
    SQLiteProgram realSQLiteProgram;

    public void init(SQLiteDatabase db, String sql) {
        this.mDatabase = db;
        this.connection = Robolectric.shadowOf(db).getConnection();
        try {
            this.actualDBstatement = this.connection.prepareStatement(sql, 1);
            compile(sql, false);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Implementation
    public void compile(String sql, boolean forceCompilation) {
    }

    @Implementation
    public void bindNull(int index) {
        checkDatabaseIsOpen();
        try {
            this.actualDBstatement.setNull(index, 0);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Implementation
    public void bindLong(int index, long value) {
        checkDatabaseIsOpen();
        try {
            this.actualDBstatement.setLong(index, value);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    private void checkDatabaseIsOpen() {
        if (!this.mDatabase.isOpen()) {
            throw new IllegalStateException("database " + this.mDatabase.getPath() + " already closed");
        }
    }

    public PreparedStatement getStatement() {
        return this.actualDBstatement;
    }

    @Implementation
    public void bindDouble(int index, double value) {
        checkDatabaseIsOpen();
        try {
            this.actualDBstatement.setDouble(index, value);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Implementation
    public void bindString(int index, String value) {
        if (value == null) {
            throw new IllegalArgumentException("the bind value at index " + index + " is null");
        }
        checkDatabaseIsOpen();
        try {
            this.actualDBstatement.setString(index, value);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Implementation
    public void bindBlob(int index, byte[] value) {
        if (value == null) {
            throw new IllegalArgumentException("the bind value at index " + index + " is null");
        }
        checkDatabaseIsOpen();
        try {
            this.actualDBstatement.setBytes(index, value);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Implementation
    public void clearBindings() {
        checkDatabaseIsOpen();
        try {
            this.actualDBstatement.clearParameters();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
