package com.xtremelabs.robolectric.shadows;

import android.widget.Checkable;
import android.widget.CompoundButton;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;

@Implements(CompoundButton.class)
public class ShadowCompoundButton extends ShadowTextView implements Checkable {
    private boolean checked;
    private CompoundButton.OnCheckedChangeListener onCheckedChangeListener;

    public void applyAttributes() {
        super.applyAttributes();
        setChecked(this.attributeSet.getAttributeBooleanValue("android", "checked", false));
    }

    @Implementation
    public void toggle() {
        setChecked(!this.checked);
    }

    @Implementation
    public boolean performClick() {
        toggle();
        return super.performClick();
    }

    @Implementation
    public boolean isChecked() {
        return this.checked;
    }

    @Implementation
    public void setChecked(boolean checked2) {
        if (this.checked != checked2) {
            this.checked = checked2;
            if (this.onCheckedChangeListener != null) {
                this.onCheckedChangeListener.onCheckedChanged((CompoundButton) this.realView, this.checked);
            }
        }
    }

    @Implementation
    public void setOnCheckedChangeListener(CompoundButton.OnCheckedChangeListener listener) {
        this.onCheckedChangeListener = listener;
    }
}
