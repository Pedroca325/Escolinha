package com.xtremelabs.robolectric.shadows;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import com.google.android.maps.MapActivity;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;

@Implements(MapActivity.class)
public class ShadowMapActivity extends ShadowActivity {
    private ConnectivityBroadcastReceiver connectivityBroadcastReceiver = new ConnectivityBroadcastReceiver();

    @Implementation
    public void onResume() {
        registerReceiver(this.connectivityBroadcastReceiver, new IntentFilter());
    }

    @Implementation
    public void onPause() {
        unregisterReceiver(this.connectivityBroadcastReceiver);
    }

    @Implementation
    public boolean isRouteDisplayed() {
        return false;
    }

    private static class ConnectivityBroadcastReceiver extends BroadcastReceiver {
        private ConnectivityBroadcastReceiver() {
        }

        public void onReceive(Context context, Intent intent) {
        }
    }
}
