package com.xtremelabs.robolectric.shadows;

import android.content.Context;
import android.database.ContentObserver;
import android.database.Cursor;
import android.database.DataSetObserver;
import android.os.Handler;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.FilterQueryProvider;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import java.util.ArrayList;
import java.util.List;

@Implements(CursorAdapter.class)
public class ShadowCursorAdapter extends ShadowBaseAdapter {
    protected boolean mAutoRequery;
    protected ChangeObserver mChangeObserver;
    protected Context mContext;
    protected Cursor mCursor;
    protected DataSetObserver mDataSetObserver = new MyDataSetObserver();
    protected boolean mDataValid;
    protected FilterQueryProvider mFilterQueryProvider;
    protected int mRowIDColumn;
    private List<View> views = new ArrayList();

    @Implementation
    public View getView(int position, View convertView, ViewGroup parent) {
        if (this.mCursor == null || this.views.size() == 0) {
            return null;
        }
        return convertView == null ? this.views.get(position) : convertView;
    }

    public void setViews(List<View> views2) {
        this.views = views2;
    }

    public void __constructor__(Context context, Cursor c) {
        initialize(context, c, true);
    }

    public void __constructor__(Context context, Cursor c, boolean autoRequery) {
        initialize(context, c, autoRequery);
    }

    private void initialize(Context context, Cursor c, boolean autoRequery) {
        boolean cursorPresent = c != null;
        this.mAutoRequery = autoRequery;
        this.mCursor = c;
        this.mDataValid = cursorPresent;
        this.mContext = context;
        this.mRowIDColumn = cursorPresent ? c.getColumnIndexOrThrow("_id") : -1;
        this.mChangeObserver = new ChangeObserver();
        if (cursorPresent) {
            c.registerContentObserver(this.mChangeObserver);
            c.registerDataSetObserver(this.mDataSetObserver);
        }
    }

    @Implementation
    public Cursor getCursor() {
        return this.mCursor;
    }

    @Implementation
    public int getCount() {
        if (!this.mDataValid || this.mCursor == null) {
            return 0;
        }
        return this.mCursor.getCount();
    }

    @Implementation
    public Object getItem(int position) {
        if (!this.mDataValid || this.mCursor == null) {
            return null;
        }
        this.mCursor.moveToPosition(position);
        return this.mCursor;
    }

    @Implementation
    public long getItemId(int position) {
        if (!this.mDataValid || this.mCursor == null) {
            return 0;
        }
        this.mCursor.getColumnIndexOrThrow("_id");
        if (this.mCursor.moveToPosition(position)) {
            return this.mCursor.getLong(this.mRowIDColumn);
        }
        return 0;
    }

    @Implementation
    public boolean hasStableIds() {
        return true;
    }

    @Implementation
    public void changeCursor(Cursor cursor) {
        if (cursor != this.mCursor) {
            if (this.mCursor != null) {
                this.mCursor.unregisterContentObserver(this.mChangeObserver);
                this.mCursor.unregisterDataSetObserver(this.mDataSetObserver);
                this.mCursor.close();
            }
            this.mCursor = cursor;
            if (cursor != null) {
                cursor.registerContentObserver(this.mChangeObserver);
                cursor.registerDataSetObserver(this.mDataSetObserver);
                this.mRowIDColumn = cursor.getColumnIndexOrThrow("_id");
                this.mDataValid = true;
                notifyDataSetChanged();
                return;
            }
            this.mRowIDColumn = -1;
            this.mDataValid = false;
            notifyDataSetInvalidated();
        }
    }

    @Implementation
    public CharSequence convertToString(Cursor cursor) {
        return cursor == null ? "" : cursor.toString();
    }

    @Implementation
    public Cursor runQueryOnBackgroundThread(CharSequence constraint) {
        if (this.mFilterQueryProvider != null) {
            return this.mFilterQueryProvider.runQuery(constraint);
        }
        return this.mCursor;
    }

    @Implementation
    public FilterQueryProvider getFilterQueryProvider() {
        return this.mFilterQueryProvider;
    }

    @Implementation
    public void setFilterQueryProvider(FilterQueryProvider filterQueryProvider) {
        this.mFilterQueryProvider = filterQueryProvider;
    }

    /* access modifiers changed from: protected */
    public void onContentChangedInternal() {
        if (this.mAutoRequery && this.mCursor != null && !this.mCursor.isClosed()) {
            this.mDataValid = this.mCursor.requery();
        }
    }

    private class ChangeObserver extends ContentObserver {
        public ChangeObserver() {
            super(new Handler());
        }

        public boolean deliverSelfNotifications() {
            return true;
        }

        public void onChange(boolean selfChange) {
            ShadowCursorAdapter.this.onContentChangedInternal();
        }
    }

    private class MyDataSetObserver extends DataSetObserver {
        private MyDataSetObserver() {
        }

        public void onChanged() {
            ShadowCursorAdapter.this.mDataValid = true;
            ShadowCursorAdapter.this.notifyDataSetChanged();
        }

        public void onInvalidated() {
            ShadowCursorAdapter.this.mDataValid = false;
            ShadowCursorAdapter.this.notifyDataSetInvalidated();
        }
    }
}
