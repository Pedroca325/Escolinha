package com.xtremelabs.robolectric.shadows;

import android.app.Activity;
import android.view.View;
import android.widget.TabHost;
import android.widget.TabWidget;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;
import java.util.ArrayList;
import java.util.List;

@Implements(TabHost.class)
public class ShadowTabHost extends ShadowFrameLayout {
    private int currentTab = -1;
    private TabHost.OnTabChangeListener listener;
    @RealObject
    TabHost realObject;
    private List<TabHost.TabSpec> tabSpecs = new ArrayList();

    @Implementation
    public TabHost.TabSpec newTabSpec(String tag) {
        TabHost.TabSpec realTabSpec = (TabHost.TabSpec) Robolectric.newInstanceOf(TabHost.TabSpec.class);
        Robolectric.shadowOf(realTabSpec).setTag(tag);
        return realTabSpec;
    }

    @Implementation
    public void addTab(TabHost.TabSpec tabSpec) {
        this.tabSpecs.add(tabSpec);
        View indicatorAsView = Robolectric.shadowOf(tabSpec).getIndicatorAsView();
        if (indicatorAsView != null) {
            this.realObject.addView(indicatorAsView);
        }
    }

    @Implementation
    public void setCurrentTab(int index) {
        this.currentTab = index;
        if (this.listener != null) {
            this.listener.onTabChanged(getCurrentTabTag());
        }
    }

    @Implementation
    public void setCurrentTabByTag(String tag) {
        for (int x = 0; x < this.tabSpecs.size(); x++) {
            if (this.tabSpecs.get(x).getTag().equals(tag)) {
                this.currentTab = x;
            }
        }
        if (this.listener != null) {
            this.listener.onTabChanged(getCurrentTabTag());
        }
    }

    @Implementation
    public int getCurrentTab() {
        if (this.currentTab == -1 && this.tabSpecs.size() > 0) {
            this.currentTab = 0;
        }
        return this.currentTab;
    }

    public TabHost.TabSpec getCurrentTabSpec() {
        return this.tabSpecs.get(getCurrentTab());
    }

    @Implementation
    public String getCurrentTabTag() {
        int i = getCurrentTab();
        if (i < 0 || i >= this.tabSpecs.size()) {
            return null;
        }
        return this.tabSpecs.get(i).getTag();
    }

    @Implementation
    public void setOnTabChangedListener(TabHost.OnTabChangeListener listener2) {
        this.listener = listener2;
    }

    @Implementation
    public View getCurrentView() {
        ShadowTabSpec ts = Robolectric.shadowOf(getCurrentTabSpec());
        View v = ts.getContentView();
        if (v == null) {
            int viewId = ts.getContentViewId();
            if (!(getContext() instanceof Activity)) {
                return null;
            }
            v = ((Activity) getContext()).findViewById(viewId);
        }
        return v;
    }

    @Implementation
    public TabWidget getTabWidget() {
        if (this.context instanceof Activity) {
            return (TabWidget) ((Activity) this.context).findViewById(16908307);
        }
        return null;
    }

    public TabHost.TabSpec getSpecByTag(String tag) {
        for (TabHost.TabSpec tabSpec : this.tabSpecs) {
            if (tag.equals(tabSpec.getTag())) {
                return tabSpec;
            }
        }
        return null;
    }
}
