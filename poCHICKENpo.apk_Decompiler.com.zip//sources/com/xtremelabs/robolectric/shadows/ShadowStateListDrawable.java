package com.xtremelabs.robolectric.shadows;

import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.util.StateSet;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Implements(StateListDrawable.class)
public class ShadowStateListDrawable extends ShadowDrawable {
    private Map<List<Integer>, Drawable> stateToDrawable;
    private Map<Integer, Integer> stateToResource;

    public void __constructor__() {
        this.stateToResource = new HashMap();
        this.stateToDrawable = new HashMap();
    }

    public void addState(int stateId, int resId) {
        this.stateToResource.put(Integer.valueOf(stateId), Integer.valueOf(resId));
    }

    public int getResourceIdForState(int stateId) {
        return this.stateToResource.get(Integer.valueOf(stateId)).intValue();
    }

    @Implementation
    public void addState(int[] stateSet, Drawable drawable) {
        this.stateToDrawable.put(createStateList(stateSet), drawable);
    }

    public Drawable getDrawableForState(int[] stateSet) {
        return this.stateToDrawable.get(createStateList(stateSet));
    }

    private List<Integer> createStateList(int[] stateSet) {
        List<Integer> stateList = new ArrayList<>();
        if (stateSet == StateSet.WILD_CARD) {
            stateList.add(-1);
        } else {
            for (int state : stateSet) {
                stateList.add(Integer.valueOf(state));
            }
        }
        return stateList;
    }
}
