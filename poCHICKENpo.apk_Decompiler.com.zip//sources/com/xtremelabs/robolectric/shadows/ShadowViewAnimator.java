package com.xtremelabs.robolectric.shadows;

import android.view.View;
import android.widget.ViewAnimator;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;

@Implements(ViewAnimator.class)
public class ShadowViewAnimator extends ShadowFrameLayout {
    private int mWhichChild = 0;

    @Implementation
    public void showNext() {
        setDisplayedChild(this.mWhichChild + 1);
    }

    @Implementation
    public void showPrevious() {
        setDisplayedChild(this.mWhichChild - 1);
    }

    @Implementation
    public void setDisplayedChild(int whichChild) {
        this.mWhichChild = whichChild;
        if (whichChild >= getChildCount()) {
            this.mWhichChild = 0;
        } else if (whichChild < 0) {
            this.mWhichChild = getChildCount() - 1;
        }
    }

    @Implementation
    public int getDisplayedChild() {
        return this.mWhichChild;
    }

    @Implementation
    public View getCurrentView() {
        return getChildAt(this.mWhichChild);
    }
}
