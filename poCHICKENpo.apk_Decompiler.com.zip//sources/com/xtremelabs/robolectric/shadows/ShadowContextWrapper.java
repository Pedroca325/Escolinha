package com.xtremelabs.robolectric.shadows;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.os.Looper;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;
import com.xtremelabs.robolectric.tester.android.content.TestSharedPreferences;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Implements(ContextWrapper.class)
public class ShadowContextWrapper extends ShadowContext {
    private String appName;
    protected Context baseContext;
    private Set<String> grantedPermissions = new HashSet();
    private PackageManager packageManager;
    private String packageName;
    @RealObject
    private ContextWrapper realContextWrapper;

    public void __constructor__(Context baseContext2) {
        this.baseContext = baseContext2;
    }

    @Implementation
    public Context getApplicationContext() {
        return this.baseContext.getApplicationContext();
    }

    @Implementation
    public Resources.Theme getTheme() {
        return getResources().newTheme();
    }

    @Implementation
    public Resources getResources() {
        return getApplicationContext().getResources();
    }

    @Implementation
    public ContentResolver getContentResolver() {
        return getApplicationContext().getContentResolver();
    }

    @Implementation
    public Object getSystemService(String name) {
        return getApplicationContext().getSystemService(name);
    }

    @Implementation
    public void sendBroadcast(Intent intent) {
        getApplicationContext().sendBroadcast(intent);
    }

    public List<Intent> getBroadcastIntents() {
        return ((ShadowApplication) Robolectric.shadowOf(getApplicationContext())).getBroadcastIntents();
    }

    @Implementation
    public int checkPermission(String permission, int pid, int uid) {
        return this.grantedPermissions.contains(permission) ? 0 : -1;
    }

    @Implementation
    public Intent registerReceiver(BroadcastReceiver receiver, IntentFilter filter) {
        return ((ShadowApplication) Robolectric.shadowOf(getApplicationContext())).registerReceiverWithContext(receiver, filter, this.realContextWrapper);
    }

    @Implementation
    public void unregisterReceiver(BroadcastReceiver broadcastReceiver) {
        getApplicationContext().unregisterReceiver(broadcastReceiver);
    }

    @Implementation
    public String getPackageName() {
        return this.realContextWrapper == getApplicationContext() ? this.packageName : getApplicationContext().getPackageName();
    }

    @Implementation
    public ApplicationInfo getApplicationInfo() {
        ApplicationInfo appInfo = new ApplicationInfo();
        appInfo.name = this.appName;
        appInfo.packageName = this.packageName;
        appInfo.processName = this.packageName;
        return appInfo;
    }

    public void setApplicationName(String name) {
        this.appName = name;
    }

    @Implementation
    public PackageManager getPackageManager() {
        return this.realContextWrapper == getApplicationContext() ? this.packageManager : getApplicationContext().getPackageManager();
    }

    @Implementation
    public ComponentName startService(Intent service) {
        return getApplicationContext().startService(service);
    }

    @Implementation
    public boolean stopService(Intent name) {
        return getApplicationContext().stopService(name);
    }

    @Implementation
    public void startActivity(Intent intent) {
        getApplicationContext().startActivity(intent);
    }

    @Implementation
    public SharedPreferences getSharedPreferences(String name, int mode) {
        return new TestSharedPreferences(getShadowApplication().getSharedPreferenceMap(), name, mode);
    }

    @Implementation
    public AssetManager getAssets() {
        return getResources().getAssets();
    }

    public Intent getNextStartedActivity() {
        return getShadowApplication().getNextStartedActivity();
    }

    public Intent peekNextStartedActivity() {
        return getShadowApplication().peekNextStartedActivity();
    }

    public Intent getNextStartedService() {
        return getShadowApplication().getNextStartedService();
    }

    public void clearStartedServices() {
        getShadowApplication().clearStartedServices();
    }

    public Intent peekNextStartedService() {
        return getShadowApplication().peekNextStartedService();
    }

    public Intent getNextStoppedService() {
        return getShadowApplication().getNextStoppedService();
    }

    public void setPackageName(String packageName2) {
        this.packageName = packageName2;
    }

    public void setPackageManager(PackageManager packageManager2) {
        this.packageManager = packageManager2;
    }

    @Implementation
    public Looper getMainLooper() {
        return getShadowApplication().getMainLooper();
    }

    @Implementation
    public Context getBaseContext() {
        return this.baseContext;
    }

    @Implementation
    public void attachBaseContext(Context context) {
        this.baseContext = context;
    }

    private ShadowApplication getShadowApplication() {
        return (ShadowApplication) Robolectric.shadowOf(getApplicationContext());
    }

    @Implementation
    public boolean bindService(Intent intent, ServiceConnection serviceConnection, int i) {
        return getShadowApplication().bindService(intent, serviceConnection, i);
    }

    public void grantPermissions(String... permissionNames) {
        for (String permissionName : permissionNames) {
            this.grantedPermissions.add(permissionName);
        }
    }
}
