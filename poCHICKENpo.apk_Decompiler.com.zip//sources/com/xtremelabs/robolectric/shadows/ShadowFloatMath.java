package com.xtremelabs.robolectric.shadows;

import android.util.FloatMath;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;

@Implements(FloatMath.class)
public class ShadowFloatMath {
    @Implementation
    public static float floor(float value) {
        return (float) Math.floor((double) value);
    }

    @Implementation
    public static float ceil(float value) {
        return (float) Math.ceil((double) value);
    }

    @Implementation
    public static float sin(float angle) {
        return (float) Math.sin((double) angle);
    }

    @Implementation
    public static float cos(float angle) {
        return (float) Math.cos((double) angle);
    }

    @Implementation
    public static float sqrt(float value) {
        return (float) Math.sqrt((double) value);
    }
}
