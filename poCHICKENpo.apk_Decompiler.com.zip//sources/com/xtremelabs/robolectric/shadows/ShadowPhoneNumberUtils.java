package com.xtremelabs.robolectric.shadows;

import android.telephony.PhoneNumberUtils;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;

@Implements(PhoneNumberUtils.class)
public class ShadowPhoneNumberUtils {
    @Implementation
    public static String formatNumber(String source) {
        return source + "-formatted";
    }
}
