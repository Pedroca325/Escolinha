package com.xtremelabs.robolectric.shadows;

import android.text.Editable;
import android.text.SpannableStringBuilder;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;

@Implements(SpannableStringBuilder.class)
public class ShadowSpannableStringBuilder implements CharSequence {
    private StringBuilder builder = new StringBuilder();
    @RealObject
    private SpannableStringBuilder realSpannableStringBuilder;

    public void __constructor__(CharSequence text) {
        this.builder.append(text);
    }

    @Implementation
    public SpannableStringBuilder append(char text) {
        this.builder.append(text);
        return this.realSpannableStringBuilder;
    }

    @Implementation
    public Editable replace(int st, int en, CharSequence text) {
        this.builder.replace(st, en, text.toString());
        return this.realSpannableStringBuilder;
    }

    @Implementation
    public Editable insert(int where, CharSequence text) {
        this.builder.insert(where, text);
        return this.realSpannableStringBuilder;
    }

    @Implementation
    public SpannableStringBuilder append(CharSequence text) {
        this.builder.append(text);
        return this.realSpannableStringBuilder;
    }

    @Implementation
    public int length() {
        return this.builder.length();
    }

    @Implementation
    public char charAt(int index) {
        return this.builder.charAt(index);
    }

    @Implementation
    public CharSequence subSequence(int start, int end) {
        return this.builder.subSequence(start, end);
    }

    @Implementation
    public String toString() {
        return this.builder.toString();
    }

    @Implementation
    public SpannableStringBuilder delete(int start, int end) {
        this.builder.delete(start, end);
        return this.realSpannableStringBuilder;
    }
}
