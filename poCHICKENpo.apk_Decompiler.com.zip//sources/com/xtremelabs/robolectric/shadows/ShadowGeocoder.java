package com.xtremelabs.robolectric.shadows;

import android.location.Address;
import android.location.Geocoder;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

@Implements(Geocoder.class)
public class ShadowGeocoder {
    private String addressLine1;
    private String city;
    private String countryCode;
    private boolean didResolution;
    private boolean hasLatitude;
    private boolean hasLongitude;
    private double lastLatitude;
    private String lastLocationName;
    private double lastLongitude;
    private boolean returnNoResults = false;
    private boolean shouldSimulateGeocodeException;
    private double simulatedLatitude;
    private double simulatedLongitude;
    private String state;
    private boolean wasCalled;
    private String zip;

    @Implementation
    public List<Address> getFromLocation(double latitude, double longitude, int maxResults) throws IOException {
        this.wasCalled = true;
        this.lastLatitude = latitude;
        this.lastLongitude = longitude;
        if (this.shouldSimulateGeocodeException) {
            throw new IOException("Simulated geocode exception");
        }
        Address address = makeAddress();
        address.setAddressLine(0, this.addressLine1);
        address.setLocality(this.city);
        address.setAdminArea(this.state);
        address.setPostalCode(this.zip);
        address.setCountryCode(this.countryCode);
        return oneElementList(address);
    }

    @Implementation
    public List<Address> getFromLocationName(String locationName, int maxResults) throws IOException {
        this.didResolution = true;
        this.lastLocationName = locationName;
        if (this.shouldSimulateGeocodeException) {
            throw new IOException("Simulated geocode exception");
        } else if (this.returnNoResults) {
            return new ArrayList();
        } else {
            Address address = makeAddress();
            address.setLatitude(this.simulatedLatitude);
            address.setLongitude(this.simulatedLongitude);
            return oneElementList(address);
        }
    }

    private Address makeAddress() {
        Address address = new Address(Locale.getDefault());
        Robolectric.shadowOf(address).setSimulatedHasLatLong(this.hasLatitude, this.hasLongitude);
        return address;
    }

    public void setSimulatedResponse(String address, String city2, String state2, String zip2, String countryCode2) {
        this.addressLine1 = address;
        this.city = city2;
        this.state = state2;
        this.zip = zip2;
        this.countryCode = countryCode2;
    }

    public void setSimulatedLatLong(double lat, double lng) {
        this.simulatedLatitude = lat;
        this.simulatedLongitude = lng;
    }

    public void setShouldSimulateGeocodeException(boolean shouldSimulateException) {
        this.shouldSimulateGeocodeException = true;
    }

    public boolean wasGetFromLocationCalled() {
        return this.wasCalled;
    }

    public double getLastLongitude() {
        return this.lastLongitude;
    }

    public double getLastLatitude() {
        return this.lastLatitude;
    }

    public String getLastLocationName() {
        return this.lastLocationName;
    }

    private List<Address> oneElementList(Address address) {
        ArrayList<Address> addresses = new ArrayList<>();
        addresses.add(address);
        return addresses;
    }

    public void setSimulatedHasLatLong(boolean hasLatitude2, boolean hasLongitude2) {
        this.hasLatitude = hasLatitude2;
        this.hasLongitude = hasLongitude2;
    }

    public void setReturnNoResults(boolean returnNoResults2) {
        this.returnNoResults = returnNoResults2;
    }

    public boolean didResolution() {
        return this.didResolution;
    }
}
