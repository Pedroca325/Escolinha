package com.xtremelabs.robolectric.shadows;

import android.database.sqlite.SQLiteCursor;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

@Implements(SQLiteCursor.class)
public class ShadowSQLiteCursor extends ShadowAbstractCursor {
    private ResultSet resultSet;

    private void cacheColumnNames(ResultSet rs) {
        try {
            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();
            this.columnNameArray = new String[columnCount];
            for (int columnIndex = 1; columnIndex <= columnCount; columnIndex++) {
                String cName = metaData.getColumnName(columnIndex).toLowerCase();
                this.columnNames.put(cName, Integer.valueOf(columnIndex - 1));
                this.columnNameArray[columnIndex - 1] = cName;
            }
        } catch (SQLException e) {
            throw new RuntimeException("SQL exception in cacheColumnNames", e);
        }
    }

    private Integer getColIndex(String columnName) {
        if (columnName == null) {
            return -1;
        }
        Integer i = (Integer) this.columnNames.get(columnName.toLowerCase());
        if (i == null) {
            return -1;
        }
        return i;
    }

    @Implementation
    public int getColumnIndex(String columnName) {
        return getColIndex(columnName).intValue();
    }

    @Implementation
    public int getColumnIndexOrThrow(String columnName) {
        Integer columnIndex = getColIndex(columnName);
        if (columnIndex.intValue() != -1) {
            return columnIndex.intValue();
        }
        throw new IllegalArgumentException("Column index does not exist");
    }

    @Implementation
    public final boolean moveToLast() {
        return super.moveToLast();
    }

    @Implementation
    public final boolean moveToFirst() {
        return super.moveToFirst();
    }

    @Implementation
    public boolean moveToNext() {
        return super.moveToNext();
    }

    @Implementation
    public boolean moveToPrevious() {
        return super.moveToPrevious();
    }

    @Implementation
    public boolean moveToPosition(int pos) {
        return super.moveToPosition(pos);
    }

    @Implementation
    public byte[] getBlob(int columnIndex) {
        checkPosition();
        return (byte[]) this.currentRow.get(getColumnNames()[columnIndex]);
    }

    @Implementation
    public String getString(int columnIndex) {
        checkPosition();
        Object value = this.currentRow.get(getColumnNames()[columnIndex]);
        if (!(value instanceof Clob)) {
            return (String) value;
        }
        try {
            return ((Clob) value).getSubString(1, (int) ((Clob) value).length());
        } catch (SQLException x) {
            throw new RuntimeException(x);
        }
    }

    @Implementation
    public short getShort(int columnIndex) {
        checkPosition();
        Object o = this.currentRow.get(getColumnNames()[columnIndex]);
        if (o == null) {
            return 0;
        }
        return new Short(o.toString()).shortValue();
    }

    @Implementation
    public int getInt(int columnIndex) {
        checkPosition();
        Object o = this.currentRow.get(getColumnNames()[columnIndex]);
        if (o == null) {
            return 0;
        }
        return new Integer(o.toString()).intValue();
    }

    @Implementation
    public long getLong(int columnIndex) {
        checkPosition();
        Object o = this.currentRow.get(getColumnNames()[columnIndex]);
        if (o == null) {
            return 0;
        }
        return new Long(o.toString()).longValue();
    }

    @Implementation
    public float getFloat(int columnIndex) {
        checkPosition();
        Object o = this.currentRow.get(getColumnNames()[columnIndex]);
        if (o == null) {
            return 0.0f;
        }
        return new Float(o.toString()).floatValue();
    }

    @Implementation
    public double getDouble(int columnIndex) {
        checkPosition();
        Object o = this.currentRow.get(getColumnNames()[columnIndex]);
        if (o == null) {
            return 0.0d;
        }
        return new Double(o.toString()).doubleValue();
    }

    private void checkPosition() {
        if (-1 == this.currentRowNumber || getCount() == this.currentRowNumber) {
            throw new IndexOutOfBoundsException(this.currentRowNumber + " " + getCount());
        }
    }

    @Implementation
    public void close() {
        if (this.resultSet != null) {
            try {
                this.resultSet.close();
                this.resultSet = null;
                this.rows = null;
                this.currentRow = null;
            } catch (SQLException e) {
                throw new RuntimeException("SQL exception in close", e);
            }
        }
    }

    @Implementation
    public boolean isClosed() {
        return this.resultSet == null;
    }

    @Implementation
    public boolean isNull(int columnIndex) {
        return this.currentRow.get(getColumnNames()[columnIndex]) == null;
    }

    public ResultSet getResultSet() {
        return this.resultSet;
    }

    public ResultSet getResultSetMetaData() {
        return this.resultSet;
    }

    private Map<String, Object> fillRowValues(ResultSet rs) throws SQLException {
        Map<String, Object> row = new HashMap<>();
        for (String s : getColumnNames()) {
            row.put(s, rs.getObject(s));
        }
        return row;
    }

    private void fillRows(String sql, Connection connection) throws SQLException {
        ResultSet rs = connection.createStatement(1003, 1007).executeQuery(sql);
        int count = 0;
        if (rs.next()) {
            do {
                this.rows.put(Integer.valueOf(count), fillRowValues(rs));
                count++;
            } while (rs.next());
        } else {
            rs.close();
        }
        this.rowCount = count;
    }

    public void setResultSet(ResultSet result, String sql) {
        this.resultSet = result;
        this.rowCount = 0;
        if (this.resultSet != null) {
            cacheColumnNames(this.resultSet);
            try {
                fillRows(sql, result.getStatement().getConnection());
            } catch (SQLException e) {
                throw new RuntimeException("SQL exception in setResultSet", e);
            }
        }
    }
}
