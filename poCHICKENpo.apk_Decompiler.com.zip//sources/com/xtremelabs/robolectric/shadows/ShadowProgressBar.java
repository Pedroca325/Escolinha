package com.xtremelabs.robolectric.shadows;

import android.widget.ProgressBar;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;

@Implements(ProgressBar.class)
public class ShadowProgressBar extends ShadowView {
    private int max = 100;
    private int progress;
    private int secondaryProgress;

    public void applyAttributes() {
        super.applyAttributes();
        int max2 = this.attributeSet.getAttributeIntValue("android", "max", this.max);
        if (max2 >= 0) {
            setMax(max2);
        }
    }

    @Implementation
    public void setMax(int max2) {
        this.progress = 0;
        this.max = max2;
    }

    @Implementation
    public int getMax() {
        return this.max;
    }

    @Implementation
    public void setProgress(int progress2) {
        this.progress = progress2;
    }

    @Implementation
    public int getProgress() {
        return this.progress;
    }

    @Implementation
    public void setSecondaryProgress(int secondaryProgress2) {
        this.secondaryProgress = secondaryProgress2;
    }

    @Implementation
    public int getSecondaryProgress() {
        return this.secondaryProgress;
    }
}
