package com.xtremelabs.robolectric.shadows;

import android.widget.RatingBar;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;

@Implements(RatingBar.class)
public class ShadowRatingBar extends ShadowAbsSeekBar {
    private RatingBar.OnRatingBarChangeListener listener;
    private int mNumStars = 5;
    @RealObject
    private RatingBar realRatingBar;

    public void applyAttributes() {
        super.applyAttributes();
        setIsIndicator(this.attributeSet.getAttributeBooleanValue("android", "isIndicator", false));
        int numStars = this.attributeSet.getAttributeIntValue("android", "numStars", this.mNumStars);
        float rating = this.attributeSet.getAttributeFloatValue("android", "rating", -1.0f);
        float stepSize = this.attributeSet.getAttributeFloatValue("android", "stepSize", -1.0f);
        if (numStars > 0 && numStars != this.mNumStars) {
            setNumStars(numStars);
        }
        if (stepSize >= 0.0f) {
            setStepSize(stepSize);
        } else {
            setStepSize(0.5f);
        }
        if (rating >= 0.0f) {
            setRating(rating);
        }
    }

    @Implementation
    public void setNumStars(int numStars) {
        if (numStars > 0) {
            this.mNumStars = numStars;
        }
    }

    @Implementation
    public int getNumStars() {
        return this.mNumStars;
    }

    @Implementation
    public void setRating(float rating) {
        setProgress(Math.round(getProgressPerStar() * rating));
    }

    @Implementation
    public float getRating() {
        return ((float) getProgress()) / getProgressPerStar();
    }

    @Implementation
    public void setIsIndicator(boolean isIndicator) {
        boolean z;
        boolean z2 = true;
        if (!isIndicator) {
            z = true;
        } else {
            z = false;
        }
        this.mIsUserSeekable = z;
        if (isIndicator) {
            z2 = false;
        }
        setFocusable(z2);
    }

    @Implementation
    public boolean isIndicator() {
        return !this.mIsUserSeekable;
    }

    @Implementation
    public void setStepSize(float stepSize) {
        if (stepSize > 0.0f) {
            float newMax = ((float) this.mNumStars) / stepSize;
            int newProgress = (int) ((newMax / ((float) getMax())) * ((float) getProgress()));
            setMax((int) newMax);
            setProgress(newProgress);
        }
    }

    @Implementation
    public float getStepSize() {
        return ((float) getNumStars()) / ((float) getMax());
    }

    private float getProgressPerStar() {
        if (this.mNumStars > 0) {
            return (1.0f * ((float) getMax())) / ((float) this.mNumStars);
        }
        return 1.0f;
    }

    @Implementation
    public void setProgress(int progress) {
        super.setProgress(progress);
        if (this.listener != null) {
            this.listener.onRatingChanged(this.realRatingBar, getRating(), true);
        }
    }

    @Implementation
    public void setOnRatingBarChangeListener(RatingBar.OnRatingBarChangeListener listener2) {
        this.listener = listener2;
    }

    @Implementation
    public RatingBar.OnRatingBarChangeListener getOnRatingBarChangeListener() {
        return this.listener;
    }
}
