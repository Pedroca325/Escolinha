package com.xtremelabs.robolectric.shadows;

import android.os.IBinder;
import android.os.IInterface;
import android.os.RemoteCallbackList;
import android.os.RemoteException;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import java.util.HashMap;

@Implements(RemoteCallbackList.class)
public class ShadowRemoteCallbackList<E extends IInterface> {
    private Object[] activeBroadcast;
    private int broadcastCount = -1;
    /* access modifiers changed from: private */
    public HashMap<IBinder, ShadowRemoteCallbackList<E>.Callback> callbacks = new HashMap<>();
    private boolean killed = false;

    private final class Callback implements IBinder.DeathRecipient {
        final E callback;
        final Object cookie;

        Callback(E callback2, Object cookie2) {
            this.callback = callback2;
            this.cookie = cookie2;
        }

        public void binderDied() {
            synchronized (ShadowRemoteCallbackList.this.callbacks) {
                ShadowRemoteCallbackList.this.callbacks.remove(this.callback.asBinder());
            }
            ShadowRemoteCallbackList.this.onCallbackDied(this.callback, this.cookie);
        }
    }

    @Implementation
    public boolean register(E callback) {
        return register(callback, (Object) null);
    }

    @Implementation
    public boolean register(E callback, Object cookie) {
        boolean z = false;
        synchronized (this.callbacks) {
            if (!this.killed) {
                IBinder binder = callback.asBinder();
                try {
                    ShadowRemoteCallbackList<E>.Callback cb = new Callback(callback, cookie);
                    binder.linkToDeath(cb, 0);
                    this.callbacks.put(binder, cb);
                    z = true;
                } catch (RemoteException e) {
                }
            }
        }
        return z;
    }

    @Implementation
    public boolean unregister(E callback) {
        boolean z = false;
        synchronized (this.callbacks) {
            ShadowRemoteCallbackList<E>.Callback cb = this.callbacks.remove(callback.asBinder());
            if (cb != null) {
                cb.callback.asBinder().unlinkToDeath(cb, 0);
                z = true;
            }
        }
        return z;
    }

    @Implementation
    public void kill() {
        synchronized (this.callbacks) {
            for (ShadowRemoteCallbackList<E>.Callback cb : this.callbacks.values()) {
                cb.callback.asBinder().unlinkToDeath(cb, 0);
            }
            this.callbacks.clear();
            this.killed = true;
        }
    }

    @Implementation
    public void onCallbackDied(E e) {
    }

    @Implementation
    public void onCallbackDied(E callback, Object cookie) {
        onCallbackDied(callback);
    }

    @Implementation
    public int beginBroadcast() {
        int i;
        synchronized (this.callbacks) {
            if (this.broadcastCount > 0) {
                throw new IllegalStateException("beginBroadcast() called while already in a broadcast");
            }
            int N = this.callbacks.size();
            this.broadcastCount = N;
            if (N <= 0) {
                i = 0;
            } else {
                Object[] active = this.activeBroadcast;
                if (active == null || active.length < N) {
                    active = new Object[N];
                    this.activeBroadcast = active;
                }
                i = 0;
                for (ShadowRemoteCallbackList<E>.Callback cb : this.callbacks.values()) {
                    active[i] = cb;
                    i++;
                }
            }
        }
        return i;
    }

    @Implementation
    public E getBroadcastItem(int index) {
        return ((Callback) this.activeBroadcast[index]).callback;
    }

    @Implementation
    public Object getBroadcastCookie(int index) {
        return ((Callback) this.activeBroadcast[index]).cookie;
    }

    @Implementation
    public void finishBroadcast() {
        if (this.broadcastCount < 0) {
            throw new IllegalStateException("finishBroadcast() called outside of a broadcast");
        }
        Object[] active = this.activeBroadcast;
        if (active != null) {
            int N = this.broadcastCount;
            for (int i = 0; i < N; i++) {
                active[i] = null;
            }
        }
        this.broadcastCount = -1;
    }
}
