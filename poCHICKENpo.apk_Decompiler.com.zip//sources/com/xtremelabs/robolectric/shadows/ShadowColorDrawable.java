package com.xtremelabs.robolectric.shadows;

import android.graphics.drawable.ColorDrawable;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;

@Implements(ColorDrawable.class)
public class ShadowColorDrawable extends ShadowDrawable {
    int colorResourceId;

    public void __constructor__(int color) {
        this.colorResourceId = color;
    }

    @Implementation
    public boolean equals(Object o) {
        if (this.realObject == o) {
            return true;
        }
        if (o == null || this.realObject.getClass() != o.getClass()) {
            return false;
        }
        if (!super.equals(o)) {
            return false;
        }
        if (this.colorResourceId != Robolectric.shadowOf((ColorDrawable) o).colorResourceId) {
            return false;
        }
        return true;
    }

    @Implementation
    public int hashCode() {
        return (super.hashCode() * 31) + this.colorResourceId;
    }
}
