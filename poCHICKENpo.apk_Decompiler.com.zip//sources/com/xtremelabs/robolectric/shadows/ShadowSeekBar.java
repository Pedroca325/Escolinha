package com.xtremelabs.robolectric.shadows;

import android.widget.SeekBar;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;

@Implements(SeekBar.class)
public class ShadowSeekBar extends ShadowAbsSeekBar {
    private SeekBar.OnSeekBarChangeListener listener;
    @RealObject
    private SeekBar realSeekBar;

    @Implementation
    public void setOnSeekBarChangeListener(SeekBar.OnSeekBarChangeListener listener2) {
        this.listener = listener2;
    }

    @Implementation
    public void setProgress(int progress) {
        super.setProgress(progress);
        if (this.listener != null) {
            this.listener.onProgressChanged(this.realSeekBar, progress, true);
        }
    }

    public SeekBar.OnSeekBarChangeListener getOnSeekBarChangeListener() {
        return this.listener;
    }
}
