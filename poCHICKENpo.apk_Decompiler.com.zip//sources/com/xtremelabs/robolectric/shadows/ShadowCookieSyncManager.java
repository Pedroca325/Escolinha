package com.xtremelabs.robolectric.shadows;

import android.content.Context;
import android.webkit.CookieSyncManager;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;

@Implements(CookieSyncManager.class)
public class ShadowCookieSyncManager {
    private static CookieSyncManager sRef;
    private boolean synced = false;

    @Implementation
    public static synchronized CookieSyncManager createInstance(Context ctx) {
        CookieSyncManager cookieSyncManager;
        synchronized (ShadowCookieSyncManager.class) {
            if (sRef == null) {
                sRef = (CookieSyncManager) Robolectric.newInstanceOf(CookieSyncManager.class);
            }
            cookieSyncManager = sRef;
        }
        return cookieSyncManager;
    }

    @Implementation
    public static CookieSyncManager getInstance() {
        if (sRef != null) {
            return sRef;
        }
        throw new IllegalStateException("createInstance must be called first");
    }

    @Implementation
    public void sync() {
        this.synced = true;
    }

    public boolean synced() {
        return this.synced;
    }

    public void reset() {
        this.synced = false;
    }
}
