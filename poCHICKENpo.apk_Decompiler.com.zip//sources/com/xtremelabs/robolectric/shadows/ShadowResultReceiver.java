package com.xtremelabs.robolectric.shadows;

import android.os.Bundle;
import android.os.ResultReceiver;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

@Implements(ResultReceiver.class)
public class ShadowResultReceiver {
    @RealObject
    private ResultReceiver realResultReceiver;

    @Implementation
    public void send(int resultCode, Bundle resultData) {
        Class<ResultReceiver> cls = ResultReceiver.class;
        try {
            Method onReceiveResult = cls.getDeclaredMethod("onReceiveResult", new Class[]{Integer.TYPE, Bundle.class});
            onReceiveResult.setAccessible(true);
            onReceiveResult.invoke(this.realResultReceiver, new Object[]{Integer.valueOf(resultCode), resultData});
        } catch (NoSuchMethodException e) {
            throw new RuntimeException(e);
        } catch (InvocationTargetException e2) {
            throw new RuntimeException(e2);
        } catch (IllegalAccessException e3) {
            throw new RuntimeException(e3);
        }
    }
}
