package com.xtremelabs.robolectric.shadows;

import android.widget.AbsSpinner;
import android.widget.SpinnerAdapter;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;

@Implements(AbsSpinner.class)
public class ShadowAbsSpinner extends ShadowAdapterView {
    private boolean animatedTransition;

    @Implementation
    public void setAdapter(SpinnerAdapter adapter) {
        super.setAdapter(adapter);
    }

    @Implementation
    public SpinnerAdapter getAdapter() {
        return (SpinnerAdapter) super.getAdapter();
    }

    @Implementation
    public void setSelection(int position, boolean animate) {
        super.setSelection(position);
        this.animatedTransition = animate;
    }

    public boolean isAnimatedTransition() {
        return this.animatedTransition;
    }
}
