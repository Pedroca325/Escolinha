package com.xtremelabs.robolectric.shadows;

import android.content.res.Configuration;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;
import java.util.Locale;

@Implements(Configuration.class)
public class ShadowConfiguration {
    public int orientation;
    @RealObject
    private Configuration realConfiguration;
    public int screenLayout;
    public int touchscreen;

    @Implementation
    public void setToDefaults() {
        this.realConfiguration.screenLayout = 18;
    }

    public void setLocale(Locale l) {
        this.realConfiguration.locale = l;
    }
}
