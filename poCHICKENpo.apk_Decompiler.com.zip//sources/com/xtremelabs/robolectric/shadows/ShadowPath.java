package com.xtremelabs.robolectric.shadows;

import android.graphics.Path;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import java.util.ArrayList;
import java.util.List;

@Implements(Path.class)
public class ShadowPath {
    private List<Point> points = new ArrayList();
    private List<Point> pointsLinedTo = new ArrayList();
    private List<Point> pointsMovedTo = new ArrayList();
    private String quadDescription = "";
    private Point wasMovedTo;

    @Implementation
    public void moveTo(float x, float y) {
        Point p = new Point(x, y, Point.Type.MOVE_TO);
        this.points.add(p);
        this.wasMovedTo = p;
    }

    @Implementation
    public void lineTo(float x, float y) {
        this.points.add(new Point(x, y, Point.Type.LINE_TO));
    }

    @Implementation
    public void quadTo(float x1, float y1, float x2, float y2) {
        this.quadDescription = "Add a quadratic bezier from last point, approaching (" + x1 + "," + y1 + "), " + "ending at (" + x2 + "," + y2 + ")";
    }

    public String getQuadDescription() {
        return this.quadDescription;
    }

    public List<Point> getPoints() {
        return this.points;
    }

    public Point getWasMovedTo() {
        return this.wasMovedTo;
    }

    public static class Point {
        private Type type;
        float x;
        float y;

        public enum Type {
            MOVE_TO,
            LINE_TO
        }

        public Point(float x2, float y2, Type type2) {
            this.x = x2;
            this.y = y2;
            this.type = type2;
        }

        public boolean equals(Object o) {
            if (this == o) {
                return true;
            }
            if (!(o instanceof Point)) {
                return false;
            }
            Point point = (Point) o;
            if (Float.compare(point.x, this.x) != 0) {
                return false;
            }
            if (Float.compare(point.y, this.y) != 0) {
                return false;
            }
            if (this.type != point.type) {
                return false;
            }
            return true;
        }

        public int hashCode() {
            int result;
            int i;
            int i2 = 0;
            if (this.x != 0.0f) {
                result = Float.floatToIntBits(this.x);
            } else {
                result = 0;
            }
            int i3 = result * 31;
            if (this.y != 0.0f) {
                i = Float.floatToIntBits(this.y);
            } else {
                i = 0;
            }
            int i4 = (i3 + i) * 31;
            if (this.type != null) {
                i2 = this.type.hashCode();
            }
            return i4 + i2;
        }

        public String toString() {
            return "Point(" + this.x + "," + this.y + "," + this.type + ")";
        }

        public float getX() {
            return this.x;
        }

        public float getY() {
            return this.y;
        }

        public Type getType() {
            return this.type;
        }
    }
}
