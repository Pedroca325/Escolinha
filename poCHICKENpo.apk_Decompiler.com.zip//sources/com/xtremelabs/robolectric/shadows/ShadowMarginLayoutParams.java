package com.xtremelabs.robolectric.shadows;

import android.view.ViewGroup;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;

@Implements(ViewGroup.MarginLayoutParams.class)
public class ShadowMarginLayoutParams extends ShadowLayoutParams {
    @RealObject
    private ViewGroup.MarginLayoutParams realMarginLayoutParams;

    @Implementation
    public void setMargins(int left, int top, int right, int bottom) {
        this.realMarginLayoutParams.leftMargin = left;
        this.realMarginLayoutParams.topMargin = top;
        this.realMarginLayoutParams.rightMargin = right;
        this.realMarginLayoutParams.bottomMargin = bottom;
    }
}
