package com.xtremelabs.robolectric.shadows;

import android.content.ComponentName;
import android.content.Context;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;

@Implements(ComponentName.class)
public class ShadowComponentName {
    private String cls;
    private String pkg;

    public void __constructor__(String pkg2, String cls2) {
        if (pkg2 == null) {
            throw new NullPointerException("package name is null");
        } else if (cls2 == null) {
            throw new NullPointerException("class name is null");
        } else {
            this.pkg = pkg2;
            this.cls = cls2;
        }
    }

    public void __constructor__(Context pkg2, String cls2) {
        if (cls2 == null) {
            throw new NullPointerException("class name is null");
        }
        this.pkg = pkg2.getPackageName();
        this.cls = cls2;
    }

    public void __constructor__(Context pkg2, Class<?> cls2) {
        this.pkg = pkg2.getPackageName();
        this.cls = cls2.getName();
    }

    @Implementation
    public String getPackageName() {
        return this.pkg;
    }

    @Implementation
    public String getClassName() {
        return this.cls;
    }

    @Implementation
    public boolean equals(Object o) {
        Object o2;
        if (o == null || (o2 = Robolectric.shadowOf_(o)) == null) {
            return false;
        }
        if (this == o2) {
            return true;
        }
        if (getClass() != o2.getClass()) {
            return false;
        }
        ShadowComponentName that = (ShadowComponentName) o2;
        if (this.cls != null) {
            if (!this.cls.equals(that.cls)) {
                return false;
            }
        } else if (that.cls != null) {
            return false;
        }
        if (this.pkg != null) {
            if (!this.pkg.equals(that.pkg)) {
                return false;
            }
        } else if (that.pkg != null) {
            return false;
        }
        return true;
    }

    @Implementation
    public int hashCode() {
        int result;
        int i = 0;
        if (this.pkg != null) {
            result = this.pkg.hashCode();
        } else {
            result = 0;
        }
        int i2 = result * 31;
        if (this.cls != null) {
            i = this.cls.hashCode();
        }
        return i2 + i;
    }

    @Implementation
    public String toString() {
        return "ComponentName{pkg='" + this.pkg + '\'' + ", cls='" + this.cls + '\'' + '}';
    }
}
