package com.xtremelabs.robolectric.shadows;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.view.View;
import android.widget.ImageView;
import android.widget.RemoteViews;
import android.widget.TextView;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.res.ResourceLoader;
import java.util.ArrayList;
import java.util.List;

@Implements(RemoteViews.class)
public class ShadowRemoteViews {
    private int layoutId;
    private String packageName;
    private List<ViewUpdater> viewUpdaters = new ArrayList();

    public void __constructor__(String packageName2, int layoutId2) {
        this.packageName = packageName2;
        this.layoutId = layoutId2;
    }

    @Implementation
    public String getPackage() {
        return this.packageName;
    }

    @Implementation
    public int getLayoutId() {
        return this.layoutId;
    }

    @Implementation
    public void setTextViewText(int viewId, final CharSequence text) {
        this.viewUpdaters.add(new ViewUpdater(viewId) {
            public void doUpdate(View view) {
                ((TextView) view).setText(text);
            }
        });
    }

    @Implementation
    public void setOnClickPendingIntent(int viewId, final PendingIntent pendingIntent) {
        this.viewUpdaters.add(new ViewUpdater(viewId) {
            /* access modifiers changed from: package-private */
            public void doUpdate(final View view) {
                view.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        try {
                            pendingIntent.send(view.getContext(), 0, (Intent) null);
                        } catch (PendingIntent.CanceledException e) {
                            throw new RuntimeException(e);
                        }
                    }
                });
            }
        });
    }

    @Implementation
    public void setViewVisibility(int viewId, final int visibility) {
        this.viewUpdaters.add(new ViewUpdater(viewId) {
            public void doUpdate(View view) {
                view.setVisibility(visibility);
            }
        });
    }

    @Implementation
    public void setImageViewResource(int viewId, final int resourceId) {
        this.viewUpdaters.add(new ViewUpdater(viewId) {
            public void doUpdate(View view) {
                ((ImageView) view).setImageResource(resourceId);
            }
        });
    }

    @Implementation
    public void setImageViewBitmap(int viewId, final Bitmap bitmap) {
        this.viewUpdaters.add(new ViewUpdater(viewId) {
            public void doUpdate(View view) {
                ((ImageView) view).setImageBitmap(bitmap);
            }
        });
    }

    @Implementation
    public void reapply(Context context, View v) {
        for (ViewUpdater viewUpdater : this.viewUpdaters) {
            viewUpdater.update(v);
        }
    }

    private abstract class ViewUpdater {
        private int viewId;

        /* access modifiers changed from: package-private */
        public abstract void doUpdate(View view);

        public ViewUpdater(int viewId2) {
            this.viewId = viewId2;
        }

        /* access modifiers changed from: package-private */
        public final void update(View parent) {
            View view = parent.findViewById(this.viewId);
            if (view == null) {
                throw new NullPointerException("couldn't find view " + this.viewId + " (" + ResourceLoader.getFrom(parent.getContext()).getNameForId(this.viewId) + ")");
            }
            doUpdate(view);
        }
    }
}
