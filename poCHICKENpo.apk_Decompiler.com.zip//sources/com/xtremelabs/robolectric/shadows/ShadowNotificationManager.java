package com.xtremelabs.robolectric.shadows;

import android.app.Notification;
import android.app.NotificationManager;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Implements(NotificationManager.class)
public class ShadowNotificationManager {
    private Map<String, Integer> idForTag = new HashMap();
    private Map<Integer, Notification> notifications = new HashMap();

    @Implementation
    public void notify(int id, Notification notification) {
        notify((String) null, id, notification);
    }

    @Implementation
    public void notify(String tag, int id, Notification notification) {
        if (tag != null) {
            this.idForTag.put(tag, Integer.valueOf(id));
        }
        this.notifications.put(Integer.valueOf(id), notification);
    }

    @Implementation
    public void cancel(int id) {
        cancel((String) null, id);
    }

    @Implementation
    public void cancel(String tag, int id) {
        Integer tagId = this.idForTag.remove(tag);
        if (this.notifications.containsKey(Integer.valueOf(id))) {
            this.notifications.remove(Integer.valueOf(id));
        } else {
            this.notifications.remove(tagId);
        }
    }

    @Implementation
    public void cancelAll() {
        this.notifications.clear();
        this.idForTag.clear();
    }

    public int size() {
        return this.notifications.size();
    }

    public Notification getNotification(int id) {
        return this.notifications.get(Integer.valueOf(id));
    }

    public Notification getNotification(String tag) {
        return this.notifications.get(this.idForTag.get(tag));
    }

    public List<Notification> getAllNotifications() {
        return new ArrayList(this.notifications.values());
    }
}
