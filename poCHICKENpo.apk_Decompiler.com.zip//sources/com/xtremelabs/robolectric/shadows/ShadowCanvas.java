package com.xtremelabs.robolectric.shadows;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import java.util.ArrayList;
import java.util.List;

@Implements(Canvas.class)
public class ShadowCanvas {
    private List<CirclePaintHistoryEvent> circlePaintEvents = new ArrayList();
    private Paint drawnPaint;
    private List<PathPaintHistoryEvent> pathPaintEvents = new ArrayList();
    private float scaleX = 1.0f;
    private float scaleY = 1.0f;
    private Bitmap targetBitmap = ((Bitmap) Robolectric.newInstanceOf(Bitmap.class));
    private float translateX;
    private float translateY;

    public void __constructor__(Bitmap bitmap) {
        this.targetBitmap = bitmap;
    }

    public void appendDescription(String s) {
        Robolectric.shadowOf(this.targetBitmap).appendDescription(s);
    }

    public String getDescription() {
        return Robolectric.shadowOf(this.targetBitmap).getDescription();
    }

    @Implementation
    public void translate(float x, float y) {
        this.translateX = x;
        this.translateY = y;
    }

    @Implementation
    public void scale(float sx, float sy) {
        this.scaleX = sx;
        this.scaleY = sy;
    }

    @Implementation
    public void scale(float sx, float sy, float px, float py) {
        this.scaleX = sx;
        this.scaleY = sy;
    }

    @Implementation
    public void drawPaint(Paint paint) {
        this.drawnPaint = paint;
    }

    @Implementation
    public void drawColor(int color) {
        appendDescription("draw color " + color);
    }

    @Implementation
    public void drawBitmap(Bitmap bitmap, float left, float top, Paint paint) {
        describeBitmap(bitmap, paint);
        int x = (int) (this.translateX + left);
        int y = (int) (this.translateY + top);
        if (!(x == 0 || y == 0)) {
            appendDescription(" at (" + x + "," + y + ")");
        }
        if (this.scaleX != 1.0f && this.scaleY != 1.0f) {
            appendDescription(" scaled by (" + this.scaleX + "," + this.scaleY + ")");
        }
    }

    @Implementation
    public void drawPath(Path path, Paint paint) {
        this.pathPaintEvents.add(new PathPaintHistoryEvent(path, paint));
        separateLines();
        appendDescription("Path " + Robolectric.shadowOf(path).getPoints().toString());
    }

    private void describeBitmap(Bitmap bitmap, Paint paint) {
        ColorFilter colorFilter;
        separateLines();
        appendDescription(Robolectric.shadowOf(bitmap).getDescription());
        if (paint != null && (colorFilter = paint.getColorFilter()) != null) {
            appendDescription(" with " + colorFilter);
        }
    }

    private void separateLines() {
        if (getDescription().length() != 0) {
            appendDescription("\n");
        }
    }

    @Implementation
    public void drawBitmap(Bitmap bitmap, Matrix matrix, Paint paint) {
        describeBitmap(bitmap, paint);
        appendDescription(" transformed by matrix");
    }

    public int getPathPaintHistoryCount() {
        return this.pathPaintEvents.size();
    }

    public int getCirclePaintHistoryCount() {
        return this.circlePaintEvents.size();
    }

    public boolean hasDrawnPath() {
        return getPathPaintHistoryCount() > 0;
    }

    public boolean hasDrawnCircle() {
        return this.circlePaintEvents.size() > 0;
    }

    public Paint getDrawnPathPaint(int i) {
        return this.pathPaintEvents.get(i).pathPaint;
    }

    public Path getDrawnPath(int i) {
        return this.pathPaintEvents.get(i).drawnPath;
    }

    public CirclePaintHistoryEvent getDrawnCircle(int i) {
        return this.circlePaintEvents.get(i);
    }

    public void resetCanvasHistory() {
        this.pathPaintEvents.clear();
        this.circlePaintEvents.clear();
    }

    public Paint getDrawnPaint() {
        return this.drawnPaint;
    }

    private static class PathPaintHistoryEvent {
        /* access modifiers changed from: private */
        public Path drawnPath;
        /* access modifiers changed from: private */
        public Paint pathPaint;

        PathPaintHistoryEvent(Path drawnPath2, Paint pathPaint2) {
            this.drawnPath = drawnPath2;
            this.pathPaint = pathPaint2;
        }
    }

    public static class CirclePaintHistoryEvent {
        public float centerX;
        public float centerY;
        public Paint paint;
        public float radius;

        private CirclePaintHistoryEvent(float centerX2, float centerY2, float radius2, Paint paint2) {
            this.paint = paint2;
            this.centerX = centerX2;
            this.centerY = centerY2;
            this.radius = radius2;
        }
    }
}
