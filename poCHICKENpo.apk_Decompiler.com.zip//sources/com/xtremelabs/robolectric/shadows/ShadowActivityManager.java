package com.xtremelabs.robolectric.shadows;

import android.app.ActivityManager;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import java.util.ArrayList;
import java.util.List;

@Implements(ActivityManager.class)
public class ShadowActivityManager {
    private String backgroundPackage;
    private ActivityManager.MemoryInfo memoryInfo;
    private List<ActivityManager.RunningAppProcessInfo> processes = new ArrayList();
    private List<ActivityManager.RunningTaskInfo> tasks = new ArrayList();

    @Implementation
    public List<ActivityManager.RunningTaskInfo> getRunningTasks(int maxNum) {
        return this.tasks;
    }

    @Implementation
    public List<ActivityManager.RunningAppProcessInfo> getRunningAppProcesses() {
        return this.processes;
    }

    @Implementation
    public void killBackgroundProcesses(String packageName) {
        this.backgroundPackage = packageName;
    }

    @Implementation
    public void getMemoryInfo(ActivityManager.MemoryInfo outInfo) {
        if (this.memoryInfo != null) {
            outInfo.lowMemory = this.memoryInfo.lowMemory;
        }
    }

    public void setTasks(List<ActivityManager.RunningTaskInfo> tasks2) {
        this.tasks = tasks2;
    }

    public void setProcesses(List<ActivityManager.RunningAppProcessInfo> processes2) {
        this.processes = processes2;
    }

    public String getBackgroundPackage() {
        return this.backgroundPackage;
    }

    public void setMemoryInfo(ActivityManager.MemoryInfo memoryInfo2) {
        this.memoryInfo = memoryInfo2;
    }

    @Implements(ActivityManager.MemoryInfo.class)
    public static class ShadowMemoryInfo {
        public boolean lowMemory;

        public void setLowMemory(boolean lowMemory2) {
            this.lowMemory = lowMemory2;
        }
    }
}
