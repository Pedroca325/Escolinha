package com.xtremelabs.robolectric.shadows;

import android.os.Environment;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import java.io.File;

@Implements(Environment.class)
public class ShadowEnvironment {
    private static final String MEDIA_REMOVED = "removed";
    private static String externalStorageState = MEDIA_REMOVED;

    @Implementation
    public static String getExternalStorageState() {
        return externalStorageState;
    }

    public static void setExternalStorageState(String externalStorageState2) {
        externalStorageState = externalStorageState2;
    }

    @Implementation
    public static File getExternalStorageDirectory() {
        ShadowContext.EXTERNAL_CACHE_DIR.mkdirs();
        return ShadowContext.EXTERNAL_CACHE_DIR;
    }

    @Implementation
    public static File getExternalStoragePublicDirectory(String type) {
        File f = type == null ? ShadowContext.EXTERNAL_FILES_DIR : new File(ShadowContext.EXTERNAL_FILES_DIR, type);
        f.mkdirs();
        return f;
    }
}
