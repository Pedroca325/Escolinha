package com.xtremelabs.robolectric.shadows;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import br.com.tectoy.pochickenpo.core.Constants;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;
import java.lang.reflect.Constructor;

@Implements(AlertDialog.class)
public class ShadowAlertDialog extends ShadowDialog {
    /* access modifiers changed from: private */
    public ListAdapter adapter;
    /* access modifiers changed from: private */
    public int checkedItemIndex;
    /* access modifiers changed from: private */
    public boolean[] checkedItems;
    /* access modifiers changed from: private */
    public DialogInterface.OnClickListener clickListener;
    /* access modifiers changed from: private */
    public View customTitleView;
    /* access modifiers changed from: private */
    public boolean isMultiItem;
    /* access modifiers changed from: private */
    public boolean isSingleItem;
    /* access modifiers changed from: private */
    public CharSequence[] items;
    private ListView listView;
    /* access modifiers changed from: private */
    public String message;
    /* access modifiers changed from: private */
    public DialogInterface.OnMultiChoiceClickListener multiChoiceClickListener;
    /* access modifiers changed from: private */
    public Button negativeButton;
    /* access modifiers changed from: private */
    public Button neutralButton;
    /* access modifiers changed from: private */
    public Button positiveButton;
    /* access modifiers changed from: private */
    @RealObject
    public AlertDialog realAlertDialog;
    private View view;

    public static AlertDialog getLatestAlertDialog() {
        ShadowAlertDialog dialog = Robolectric.getShadowApplication().getLatestAlertDialog();
        if (dialog == null) {
            return null;
        }
        return dialog.realAlertDialog;
    }

    @Implementation
    public View findViewById(int viewId) {
        if (this.view == null) {
            return super.findViewById(viewId);
        }
        return this.view.findViewById(viewId);
    }

    @Implementation
    public void setView(View view2) {
        this.view = view2;
    }

    public static void reset() {
        Robolectric.getShadowApplication().setLatestAlertDialog((ShadowAlertDialog) null);
    }

    public void clickOnItem(int index) {
        Robolectric.shadowOf(this.realAlertDialog.getListView()).performItemClick(index);
    }

    @Implementation
    public Button getButton(int whichButton) {
        switch (whichButton) {
            case Constants.LIM_PONTA_CABECA:
                return this.neutralButton;
            case -2:
                return this.negativeButton;
            case ShadowMediaRecorder.STATE_ERROR /*-1*/:
                return this.positiveButton;
            default:
                throw new RuntimeException("Only positive, negative, or neutral button choices are recognized");
        }
    }

    @Implementation
    public ListView getListView() {
        if (this.listView == null) {
            this.listView = new ListView(this.context);
            this.listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                    if (ShadowAlertDialog.this.isMultiItem) {
                        ShadowAlertDialog.this.checkedItems[position] = !ShadowAlertDialog.this.checkedItems[position];
                        ShadowAlertDialog.this.multiChoiceClickListener.onClick(ShadowAlertDialog.this.realAlertDialog, position, ShadowAlertDialog.this.checkedItems[position]);
                        return;
                    }
                    if (ShadowAlertDialog.this.isSingleItem) {
                        int unused = ShadowAlertDialog.this.checkedItemIndex = position;
                    }
                    ShadowAlertDialog.this.clickListener.onClick(ShadowAlertDialog.this.realAlertDialog, position);
                }
            });
        }
        return this.listView;
    }

    public CharSequence[] getItems() {
        return this.items;
    }

    public Adapter getAdapter() {
        return this.adapter;
    }

    public String getMessage() {
        return this.message;
    }

    @Implementation
    public void setMessage(CharSequence message2) {
        this.message = message2 == null ? null : message2.toString();
    }

    public boolean[] getCheckedItems() {
        return this.checkedItems;
    }

    public int getCheckedItemIndex() {
        return this.checkedItemIndex;
    }

    @Implementation
    public void show() {
        super.show();
        if (this.items != null) {
            this.adapter = new ArrayAdapter(this.context, 17367045, 16908308, this.items);
        }
        if (this.adapter != null) {
            getListView().setAdapter(this.adapter);
        }
        Robolectric.getShadowApplication().setLatestAlertDialog(this);
    }

    public View getView() {
        return this.view;
    }

    public View getCustomTitleView() {
        return this.customTitleView;
    }

    @Implements(AlertDialog.Builder.class)
    public static class ShadowBuilder {
        private ListAdapter adapter;
        private DialogInterface.OnCancelListener cancelListener;
        private int checkedItem;
        private boolean[] checkedItems;
        private DialogInterface.OnClickListener clickListener;
        private Context context;
        private View customTitleView;
        private boolean isCancelable;
        private boolean isMultiItem;
        private boolean isSingleItem;
        private CharSequence[] items;
        private String message;
        private DialogInterface.OnMultiChoiceClickListener multiChoiceClickListener;
        private DialogInterface.OnClickListener negativeListener;
        private CharSequence negativeText;
        private DialogInterface.OnClickListener neutralListener;
        private CharSequence neutralText;
        private DialogInterface.OnClickListener positiveListener;
        private CharSequence positiveText;
        @RealObject
        private AlertDialog.Builder realBuilder;
        private String title;
        private View view;

        public void __constructor__(Context context2) {
            this.context = context2;
        }

        @Implementation
        public AlertDialog.Builder setItems(int itemsId, DialogInterface.OnClickListener listener) {
            this.isMultiItem = false;
            this.items = this.context.getResources().getTextArray(itemsId);
            this.clickListener = listener;
            return this.realBuilder;
        }

        @Implementation(i18nSafe = false)
        public AlertDialog.Builder setItems(CharSequence[] items2, DialogInterface.OnClickListener listener) {
            this.isMultiItem = false;
            this.items = items2;
            this.clickListener = listener;
            return this.realBuilder;
        }

        @Implementation(i18nSafe = false)
        public AlertDialog.Builder setSingleChoiceItems(CharSequence[] items2, int checkedItem2, DialogInterface.OnClickListener listener) {
            this.isSingleItem = true;
            this.checkedItem = checkedItem2;
            this.items = items2;
            this.clickListener = listener;
            return this.realBuilder;
        }

        @Implementation(i18nSafe = false)
        public AlertDialog.Builder setSingleChoiceItems(ListAdapter adapter2, int checkedItem2, DialogInterface.OnClickListener listener) {
            this.isSingleItem = true;
            this.checkedItem = checkedItem2;
            this.items = null;
            this.adapter = adapter2;
            this.clickListener = listener;
            return this.realBuilder;
        }

        @Implementation(i18nSafe = false)
        public AlertDialog.Builder setMultiChoiceItems(CharSequence[] items2, boolean[] checkedItems2, DialogInterface.OnMultiChoiceClickListener listener) {
            this.isMultiItem = true;
            this.items = items2;
            this.multiChoiceClickListener = listener;
            if (checkedItems2 == null) {
                checkedItems2 = new boolean[items2.length];
            } else if (checkedItems2.length != items2.length) {
                throw new IllegalArgumentException("checkedItems must be the same length as items, or pass null to specify no checked items");
            }
            this.checkedItems = checkedItems2;
            return this.realBuilder;
        }

        @Implementation(i18nSafe = false)
        public AlertDialog.Builder setTitle(CharSequence title2) {
            this.title = title2.toString();
            return this.realBuilder;
        }

        @Implementation
        public AlertDialog.Builder setCustomTitle(View customTitleView2) {
            this.customTitleView = customTitleView2;
            return this.realBuilder;
        }

        @Implementation
        public AlertDialog.Builder setTitle(int titleId) {
            return setTitle((CharSequence) this.context.getResources().getString(titleId));
        }

        @Implementation(i18nSafe = false)
        public AlertDialog.Builder setMessage(CharSequence message2) {
            this.message = message2.toString();
            return this.realBuilder;
        }

        @Implementation
        public AlertDialog.Builder setMessage(int messageId) {
            setMessage((CharSequence) this.context.getResources().getString(messageId));
            return this.realBuilder;
        }

        @Implementation
        public AlertDialog.Builder setIcon(int iconId) {
            return this.realBuilder;
        }

        @Implementation
        public AlertDialog.Builder setView(View view2) {
            this.view = view2;
            return this.realBuilder;
        }

        @Implementation(i18nSafe = false)
        public AlertDialog.Builder setPositiveButton(CharSequence text, DialogInterface.OnClickListener listener) {
            this.positiveText = text;
            this.positiveListener = listener;
            return this.realBuilder;
        }

        @Implementation
        public AlertDialog.Builder setPositiveButton(int positiveTextId, DialogInterface.OnClickListener listener) {
            return setPositiveButton(this.context.getResources().getText(positiveTextId), listener);
        }

        @Implementation(i18nSafe = false)
        public AlertDialog.Builder setNegativeButton(CharSequence text, DialogInterface.OnClickListener listener) {
            this.negativeText = text;
            this.negativeListener = listener;
            return this.realBuilder;
        }

        @Implementation
        public AlertDialog.Builder setNegativeButton(int negativeTextId, DialogInterface.OnClickListener listener) {
            return setNegativeButton((CharSequence) this.context.getResources().getString(negativeTextId), listener);
        }

        @Implementation(i18nSafe = false)
        public AlertDialog.Builder setNeutralButton(CharSequence text, DialogInterface.OnClickListener listener) {
            this.neutralText = text;
            this.neutralListener = listener;
            return this.realBuilder;
        }

        @Implementation
        public AlertDialog.Builder setNeutralButton(int neutralTextId, DialogInterface.OnClickListener listener) {
            return setNeutralButton(this.context.getResources().getText(neutralTextId), listener);
        }

        @Implementation
        public AlertDialog.Builder setCancelable(boolean cancelable) {
            this.isCancelable = cancelable;
            return this.realBuilder;
        }

        @Implementation
        public AlertDialog.Builder setOnCancelListener(DialogInterface.OnCancelListener listener) {
            this.cancelListener = listener;
            return this.realBuilder;
        }

        @Implementation
        public AlertDialog create() {
            try {
                Constructor<AlertDialog> c = AlertDialog.class.getDeclaredConstructor(new Class[]{Context.class});
                c.setAccessible(true);
                AlertDialog realDialog = c.newInstance(new Object[]{null});
                ShadowAlertDialog latestAlertDialog = Robolectric.shadowOf(realDialog);
                latestAlertDialog.context = this.context;
                CharSequence[] unused = latestAlertDialog.items = this.items;
                ListAdapter unused2 = latestAlertDialog.adapter = this.adapter;
                latestAlertDialog.setTitle((CharSequence) this.title);
                String unused3 = latestAlertDialog.message = this.message;
                DialogInterface.OnClickListener unused4 = latestAlertDialog.clickListener = this.clickListener;
                latestAlertDialog.setOnCancelListener(this.cancelListener);
                boolean unused5 = latestAlertDialog.isMultiItem = this.isMultiItem;
                boolean unused6 = latestAlertDialog.isSingleItem = this.isSingleItem;
                int unused7 = latestAlertDialog.checkedItemIndex = this.checkedItem;
                DialogInterface.OnMultiChoiceClickListener unused8 = latestAlertDialog.multiChoiceClickListener = this.multiChoiceClickListener;
                boolean[] unused9 = latestAlertDialog.checkedItems = this.checkedItems;
                latestAlertDialog.setView(this.view);
                Button unused10 = latestAlertDialog.positiveButton = createButton(realDialog, -1, this.positiveText, this.positiveListener);
                Button unused11 = latestAlertDialog.negativeButton = createButton(realDialog, -2, this.negativeText, this.negativeListener);
                Button unused12 = latestAlertDialog.neutralButton = createButton(realDialog, -3, this.neutralText, this.neutralListener);
                latestAlertDialog.setCancelable(this.isCancelable);
                View unused13 = latestAlertDialog.customTitleView = this.customTitleView;
                return realDialog;
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }

        @Implementation
        public AlertDialog show() {
            AlertDialog dialog = this.realBuilder.create();
            dialog.show();
            return dialog;
        }

        private Button createButton(final DialogInterface dialog, final int which, CharSequence text, final DialogInterface.OnClickListener listener) {
            if (text == null && listener == null) {
                return null;
            }
            Button button = new Button(this.context);
            Robolectric.shadowOf((TextView) button).setText(text);
            button.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    if (listener != null) {
                        listener.onClick(dialog, which);
                    }
                    dialog.dismiss();
                }
            });
            return button;
        }

        /* access modifiers changed from: protected */
        public Context getContext() {
            return this.context;
        }
    }
}
