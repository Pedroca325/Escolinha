package com.xtremelabs.robolectric.shadows;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;

@Implements(Message.class)
public class ShadowMessage {
    private Bundle data;
    @RealObject
    private Message message;
    private Handler target;

    @Implementation
    public void setData(Bundle data2) {
        this.data = data2;
    }

    @Implementation
    public void setTarget(Handler target2) {
        this.target = target2;
    }

    @Implementation
    public Bundle peekData() {
        return this.data;
    }

    @Implementation
    public Bundle getData() {
        if (this.data == null) {
            this.data = new Bundle();
        }
        return this.data;
    }

    @Implementation
    public Handler getTarget() {
        return this.target;
    }

    @Implementation
    public void copyFrom(Message m) {
        this.message.arg1 = m.arg1;
        this.message.arg2 = m.arg2;
        this.message.obj = m.obj;
        this.message.setData(m.getData());
    }

    @Implementation
    public static Message obtain() {
        return new Message();
    }

    @Implementation
    public static Message obtain(Handler h) {
        Message m = new Message();
        m.setTarget(h);
        return m;
    }

    @Implementation
    public static Message obtain(Handler h, int what) {
        Message m = obtain(h);
        m.what = what;
        return m;
    }

    @Implementation
    public static Message obtain(Handler h, int what, Object obj) {
        Message m = obtain(h, what);
        m.obj = obj;
        return m;
    }

    @Implementation
    public static Message obtain(Handler h, int what, int arg1, int arg2) {
        Message m = obtain(h, what);
        m.arg1 = arg1;
        m.arg2 = arg2;
        return m;
    }

    @Implementation
    public static Message obtain(Handler h, int what, int arg1, int arg2, Object obj) {
        Message m = obtain(h, what, arg1, arg2);
        m.obj = obj;
        return m;
    }

    @Implementation
    public void sendToTarget() {
        this.target.sendMessage(this.message);
    }
}
