package com.xtremelabs.robolectric.shadows;

import android.view.View;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;
import java.util.ArrayList;
import java.util.List;

@Implements(ListView.class)
public class ShadowListView extends ShadowAbsListView {
    private List<View> footerViews = new ArrayList();
    private List<View> headerViews = new ArrayList();
    private boolean itemsCanFocus;
    @RealObject
    private ListView realListView;

    @Implementation
    public View findViewById(int id) {
        View child = super.findViewById(id);
        if (child != null) {
            return child;
        }
        View child2 = findView(this.headerViews, id);
        if (child2 == null) {
            return findView(this.footerViews, id);
        }
        return child2;
    }

    /* JADX WARNING: Removed duplicated region for block: B:1:0x0005 A[LOOP:0: B:1:0x0005->B:4:0x0015, LOOP_START, PHI: r0 
      PHI: (r0v1 'child' android.view.View) = (r0v0 'child' android.view.View), (r0v3 'child' android.view.View) binds: [B:0:0x0000, B:4:0x0015] A[DONT_GENERATE, DONT_INLINE]] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private android.view.View findView(java.util.List<android.view.View> r5, int r6) {
        /*
            r4 = this;
            r0 = 0
            java.util.Iterator r1 = r5.iterator()
        L_0x0005:
            boolean r3 = r1.hasNext()
            if (r3 == 0) goto L_0x0017
            java.lang.Object r2 = r1.next()
            android.view.View r2 = (android.view.View) r2
            android.view.View r0 = r2.findViewById(r6)
            if (r0 == 0) goto L_0x0005
        L_0x0017:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.xtremelabs.robolectric.shadows.ShadowListView.findView(java.util.List, int):android.view.View");
    }

    @Implementation
    public void setItemsCanFocus(boolean itemsCanFocus2) {
        this.itemsCanFocus = itemsCanFocus2;
    }

    @Implementation
    public boolean performItemClick(View view, int position, long id) {
        AdapterView.OnItemClickListener onItemClickListener = getOnItemClickListener();
        if (onItemClickListener == null) {
            return false;
        }
        onItemClickListener.onItemClick(this.realListView, view, position, id);
        return true;
    }

    @Implementation
    public void setAdapter(ListAdapter adapter) {
        super.setAdapter(adapter);
    }

    @Implementation
    public void addHeaderView(View headerView) {
        addHeaderView(headerView, (Object) null, true);
    }

    @Implementation
    public void addHeaderView(View headerView, Object data, boolean isSelectable) {
        ensureAdapterNotSet("header");
        this.headerViews.add(headerView);
        this.realListView.addView(headerView);
    }

    @Implementation
    public int getHeaderViewsCount() {
        return this.headerViews.size();
    }

    @Implementation
    public int getFooterViewsCount() {
        return this.footerViews.size();
    }

    @Implementation
    public void addFooterView(View footerView, Object data, boolean isSelectable) {
        ensureAdapterNotSet("footer");
        this.footerViews.add(footerView);
        this.realListView.addView(footerView);
    }

    @Implementation
    public void addFooterView(View footerView) {
        addFooterView(footerView, (Object) null, false);
    }

    @Implementation
    public void removeAllViews() {
        throw new UnsupportedOperationException();
    }

    @Implementation
    public void removeView(View view) {
        throw new UnsupportedOperationException();
    }

    @Implementation
    public void removeViewAt(int index) {
        throw new UnsupportedOperationException();
    }

    private void ensureAdapterNotSet(String view) {
        if (getAdapter() != null) {
            throw new IllegalStateException("Cannot add " + view + " view to list -- setAdapter has already been called");
        }
    }

    public boolean isItemsCanFocus() {
        return this.itemsCanFocus;
    }

    public List<View> getHeaderViews() {
        return this.headerViews;
    }

    public void setHeaderViews(List<View> headerViews2) {
        this.headerViews = headerViews2;
    }

    public List<View> getFooterViews() {
        return this.footerViews;
    }

    public void setFooterViews(List<View> footerViews2) {
        this.footerViews = footerViews2;
    }

    /* access modifiers changed from: protected */
    public void addViews() {
        for (View headerView : this.headerViews) {
            addView(headerView);
        }
        super.addViews();
        for (View footerView : this.footerViews) {
            addView(footerView);
        }
    }
}
