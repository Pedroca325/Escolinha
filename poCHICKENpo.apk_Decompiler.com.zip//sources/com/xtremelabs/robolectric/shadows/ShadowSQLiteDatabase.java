package com.xtremelabs.robolectric.shadows;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.SQLException;
import android.database.sqlite.SQLiteClosable;
import android.database.sqlite.SQLiteCursor;
import android.database.sqlite.SQLiteCursorDriver;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabaseCorruptException;
import android.database.sqlite.SQLiteQuery;
import android.database.sqlite.SQLiteQueryBuilder;
import android.database.sqlite.SQLiteStatement;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;
import com.xtremelabs.robolectric.util.DatabaseConfig;
import com.xtremelabs.robolectric.util.SQLite;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.WeakHashMap;
import java.util.concurrent.locks.ReentrantLock;

@Implements(SQLiteDatabase.class)
public class ShadowSQLiteDatabase {
    private static Connection connection;
    private final ReentrantLock mLock = new ReentrantLock(true);
    private boolean mLockingEnabled = true;
    private WeakHashMap<SQLiteClosable, Object> mPrograms;
    @RealObject
    SQLiteDatabase realSQLiteDatabase;
    private boolean throwOnInsert;
    private boolean transactionSuccess = false;

    @Implementation
    public void setLockingEnabled(boolean lockingEnabled) {
        this.mLockingEnabled = lockingEnabled;
    }

    public void lock() {
        if (this.mLockingEnabled) {
            this.mLock.lock();
        }
    }

    public void unlock() {
        if (this.mLockingEnabled) {
            this.mLock.unlock();
        }
    }

    public void setThrowOnInsert(boolean throwOnInsert2) {
        this.throwOnInsert = throwOnInsert2;
    }

    @Implementation
    public static SQLiteDatabase openDatabase(String path, SQLiteDatabase.CursorFactory factory, int flags) {
        connection = DatabaseConfig.getMemoryConnection();
        return (SQLiteDatabase) Robolectric.newInstanceOf(SQLiteDatabase.class);
    }

    @Implementation
    public long insert(String table, String nullColumnHack, ContentValues values) {
        return insertWithOnConflict(table, nullColumnHack, values, 0);
    }

    @Implementation
    public long insertOrThrow(String table, String nullColumnHack, ContentValues values) {
        if (!this.throwOnInsert) {
            return insertWithOnConflict(table, nullColumnHack, values, 0);
        }
        throw new SQLException();
    }

    @Implementation
    public long replace(String table, String nullColumnHack, ContentValues values) {
        return insertWithOnConflict(table, nullColumnHack, values, 5);
    }

    @Implementation
    public long insertWithOnConflict(String table, String nullColumnHack, ContentValues initialValues, int conflictAlgorithm) {
        try {
            SQLite.SQLStringAndBindings sqlInsertString = SQLite.buildInsertString(table, initialValues, conflictAlgorithm);
            PreparedStatement insert = connection.prepareStatement(sqlInsertString.sql, 1);
            long result = -1;
            int i = 1;
            for (Object object : sqlInsertString.columnValues) {
                insert.setObject(i, object);
                i++;
            }
            insert.executeUpdate();
            ResultSet resultSet = insert.getGeneratedKeys();
            if (resultSet.next()) {
                result = resultSet.getLong(1);
            }
            resultSet.close();
            return result;
        } catch (java.sql.SQLException e) {
            return -1;
        }
    }

    @Implementation
    public Cursor query(boolean distinct, String table, String[] columns, String selection, String[] selectionArgs, String groupBy, String having, String orderBy, String limit) {
        String where = selection;
        if (!(selection == null || selectionArgs == null)) {
            where = SQLite.buildWhereClause(selection, selectionArgs);
        }
        String sql = SQLiteQueryBuilder.buildQueryString(distinct, table, columns, where, groupBy, having, orderBy, limit);
        try {
            ResultSet resultSet = connection.createStatement(DatabaseConfig.getResultSetType(), 1007).executeQuery(sql);
            SQLiteCursor cursor = new SQLiteCursor((SQLiteDatabase) null, (SQLiteCursorDriver) null, (String) null, (SQLiteQuery) null);
            Robolectric.shadowOf(cursor).setResultSet(resultSet, sql);
            return cursor;
        } catch (java.sql.SQLException e) {
            throw new RuntimeException("SQL exception in query", e);
        }
    }

    @Implementation
    public Cursor query(String table, String[] columns, String selection, String[] selectionArgs, String groupBy, String having, String orderBy) {
        return query(false, table, columns, selection, selectionArgs, groupBy, having, orderBy, (String) null);
    }

    @Implementation
    public Cursor query(String table, String[] columns, String selection, String[] selectionArgs, String groupBy, String having, String orderBy, String limit) {
        return query(false, table, columns, selection, selectionArgs, groupBy, having, orderBy, limit);
    }

    @Implementation
    public int update(String table, ContentValues values, String whereClause, String[] whereArgs) {
        SQLite.SQLStringAndBindings sqlUpdateString = SQLite.buildUpdateString(table, values, whereClause, whereArgs);
        try {
            PreparedStatement statement = connection.prepareStatement(sqlUpdateString.sql);
            int i = 1;
            for (Object object : sqlUpdateString.columnValues) {
                statement.setObject(i, object);
                i++;
            }
            return statement.executeUpdate();
        } catch (java.sql.SQLException e) {
            throw new RuntimeException("SQL exception in update", e);
        }
    }

    @Implementation
    public int delete(String table, String whereClause, String[] whereArgs) {
        try {
            return connection.prepareStatement(SQLite.buildDeleteString(table, whereClause, whereArgs)).executeUpdate();
        } catch (java.sql.SQLException e) {
            throw new RuntimeException("SQL exception in delete", e);
        }
    }

    @Implementation
    public void execSQL(String sql) throws SQLException {
        if (!isOpen()) {
            throw new IllegalStateException("database not open");
        }
        try {
            connection.createStatement().execute(DatabaseConfig.getScrubSQL(sql));
        } catch (java.sql.SQLException e) {
            SQLException ase = new SQLException();
            ase.initCause(e);
            throw ase;
        }
    }

    @Implementation
    public void execSQL(String sql, Object[] bindArgs) throws java.sql.SQLException {
        if (bindArgs == null) {
            throw new IllegalArgumentException("Empty bindArgs");
        }
        SQLiteStatement statement = null;
        try {
            SQLiteStatement statement2 = compileStatement(DatabaseConfig.getScrubSQL(sql));
            if (bindArgs != null) {
                int numArgs = bindArgs.length;
                for (int i = 0; i < numArgs; i++) {
                    DatabaseUtils.bindObjectToProgram(statement2, i + 1, bindArgs[i]);
                }
            }
            statement2.execute();
            if (statement2 != null) {
                statement2.close();
            }
        } catch (SQLiteDatabaseCorruptException e) {
            throw e;
        } catch (Throwable th) {
            if (statement != null) {
                statement.close();
            }
            throw th;
        }
    }

    @Implementation
    public Cursor rawQuery(String sql, String[] selectionArgs) {
        String sqlBody = sql;
        if (sql != null) {
            sqlBody = SQLite.buildWhereClause(sql, selectionArgs);
        }
        try {
            SQLiteStatement stmt = compileStatement(sql);
            int numArgs = selectionArgs == null ? 0 : selectionArgs.length;
            for (int i = 0; i < numArgs; i++) {
                stmt.bindString(i + 1, selectionArgs[i]);
            }
            ResultSet resultSet = Robolectric.shadowOf(stmt).getStatement().executeQuery();
            SQLiteCursor cursor = new SQLiteCursor((SQLiteDatabase) null, (SQLiteCursorDriver) null, (String) null, (SQLiteQuery) null);
            Robolectric.shadowOf(cursor).setResultSet(resultSet, sqlBody);
            return cursor;
        } catch (java.sql.SQLException e) {
            throw new RuntimeException("SQL exception in query", e);
        }
    }

    @Implementation
    public boolean isOpen() {
        return connection != null;
    }

    @Implementation
    public void close() {
        if (isOpen()) {
            try {
                connection.close();
                connection = null;
            } catch (java.sql.SQLException e) {
                throw new RuntimeException("SQL exception in close", e);
            }
        }
    }

    @Implementation
    public void beginTransaction() {
        try {
            connection.setAutoCommit(false);
        } catch (java.sql.SQLException e) {
            throw new RuntimeException("SQL exception in beginTransaction", e);
        }
    }

    @Implementation
    public void setTransactionSuccessful() {
        if (!isOpen()) {
            throw new IllegalStateException("connection is not opened");
        } else if (this.transactionSuccess) {
            throw new IllegalStateException("transaction already successfully");
        } else {
            this.transactionSuccess = true;
        }
    }

    @Implementation
    public void endTransaction() {
        try {
            if (this.transactionSuccess) {
                this.transactionSuccess = false;
                connection.commit();
            } else {
                connection.rollback();
            }
            connection.setAutoCommit(true);
        } catch (java.sql.SQLException e) {
            throw new RuntimeException("SQL exception in beginTransaction", e);
        }
    }

    public boolean isTransactionSuccess() {
        return this.transactionSuccess;
    }

    public Connection getConnection() {
        return connection;
    }

    @Implementation
    public SQLiteStatement compileStatement(String sql) throws java.sql.SQLException {
        lock();
        String scrubbedSql = DatabaseConfig.getScrubSQL(sql);
        try {
            SQLiteStatement stmt = (SQLiteStatement) Robolectric.newInstanceOf(SQLiteStatement.class);
            Robolectric.shadowOf(stmt).init(this.realSQLiteDatabase, scrubbedSql);
            unlock();
            return stmt;
        } catch (Exception e) {
            throw new RuntimeException(e);
        } catch (Throwable th) {
            unlock();
            throw th;
        }
    }

    /* access modifiers changed from: package-private */
    public void addSQLiteClosable(SQLiteClosable closable) {
        lock();
        try {
            this.mPrograms.put(closable, (Object) null);
        } finally {
            unlock();
        }
    }

    /* access modifiers changed from: package-private */
    public void removeSQLiteClosable(SQLiteClosable closable) {
        lock();
        try {
            this.mPrograms.remove(closable);
        } finally {
            unlock();
        }
    }
}
