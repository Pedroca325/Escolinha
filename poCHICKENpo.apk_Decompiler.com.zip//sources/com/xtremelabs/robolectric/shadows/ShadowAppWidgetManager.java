package com.xtremelabs.robolectric.shadows;

import android.app.Activity;
import android.app.Application;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RemoteViews;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.AppSingletonizer;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Implements(AppWidgetManager.class)
public class ShadowAppWidgetManager {
    private static AppSingletonizer<AppWidgetManager> instances = new AppSingletonizer<AppWidgetManager>(AppWidgetManager.class) {
        /* access modifiers changed from: protected */
        public AppWidgetManager get(ShadowApplication shadowApplication) {
            return shadowApplication.appWidgetManager;
        }

        /* access modifiers changed from: protected */
        public void set(ShadowApplication shadowApplication, AppWidgetManager instance) {
            shadowApplication.appWidgetManager = instance;
        }

        /* access modifiers changed from: protected */
        public AppWidgetManager createInstance(Application applicationContext) {
            AppWidgetManager appWidgetManager = (AppWidgetManager) super.createInstance(applicationContext);
            Context unused = Robolectric.shadowOf(appWidgetManager).context = applicationContext;
            return appWidgetManager;
        }
    };
    private boolean alwaysRecreateViewsDuringUpdate = false;
    /* access modifiers changed from: private */
    public Context context;
    private int nextWidgetId = 1;
    @RealObject
    private AppWidgetManager realAppWidgetManager;
    private Map<Integer, WidgetInfo> widgetInfos = new HashMap();

    private static void bind(AppWidgetManager appWidgetManager, Context context2) {
    }

    @Implementation
    public static AppWidgetManager getInstance(Context context2) {
        return instances.getInstance(context2);
    }

    @Implementation
    public void updateAppWidget(int[] appWidgetIds, RemoteViews views) {
        for (int appWidgetId : appWidgetIds) {
            updateAppWidget(appWidgetId, views);
        }
    }

    @Implementation
    public void updateAppWidget(int appWidgetId, RemoteViews views) {
        WidgetInfo widgetInfo = getWidgetInfo(appWidgetId);
        int layoutId = views.getLayoutId();
        if (widgetInfo.layoutId != layoutId || this.alwaysRecreateViewsDuringUpdate) {
            View unused = widgetInfo.view = createWidgetView(layoutId);
            int unused2 = widgetInfo.layoutId = layoutId;
        }
        RemoteViews unused3 = widgetInfo.lastRemoteViews = views;
        views.reapply(this.context, widgetInfo.view);
    }

    @Implementation
    public int[] getAppWidgetIds(ComponentName provider) {
        List<Integer> idList = new ArrayList<>();
        for (Integer intValue : this.widgetInfos.keySet()) {
            int id = intValue.intValue();
            WidgetInfo widgetInfo = this.widgetInfos.get(Integer.valueOf(id));
            String widgetClass = widgetInfo.appWidgetProvider.getClass().getName();
            String widgetPackage = widgetInfo.appWidgetProvider.getClass().getPackage().getName();
            if (provider.getClassName().equals(widgetClass) && provider.getPackageName().equals(widgetPackage)) {
                idList.add(Integer.valueOf(id));
            }
        }
        int[] ids = new int[idList.size()];
        for (int i = 0; i < idList.size(); i++) {
            ids[i] = idList.get(i).intValue();
        }
        return ids;
    }

    public void reconstructWidgetViewAsIfPhoneWasRotated(int appWidgetId) {
        WidgetInfo widgetInfo = getWidgetInfo(appWidgetId);
        View unused = widgetInfo.view = createWidgetView(widgetInfo.layoutId);
        widgetInfo.lastRemoteViews.reapply(this.context, widgetInfo.view);
    }

    public int createWidget(Class<? extends AppWidgetProvider> appWidgetProviderClass, int widgetLayoutId) {
        return createWidgets(appWidgetProviderClass, widgetLayoutId, 1)[0];
    }

    public int[] createWidgets(Class<? extends AppWidgetProvider> appWidgetProviderClass, int widgetLayoutId, int howManyToCreate) {
        AppWidgetProvider appWidgetProvider = (AppWidgetProvider) Robolectric.newInstanceOf(appWidgetProviderClass);
        int[] newWidgetIds = new int[howManyToCreate];
        for (int i = 0; i < howManyToCreate; i++) {
            View widgetView = createWidgetView(widgetLayoutId);
            int myWidgetId = this.nextWidgetId;
            this.nextWidgetId = myWidgetId + 1;
            this.widgetInfos.put(Integer.valueOf(myWidgetId), new WidgetInfo(widgetView, widgetLayoutId, appWidgetProvider));
            newWidgetIds[i] = myWidgetId;
        }
        appWidgetProvider.onUpdate(this.context, this.realAppWidgetManager, newWidgetIds);
        return newWidgetIds;
    }

    private void createWidgetProvider(Class<? extends AppWidgetProvider> appWidgetProviderClass, int... newWidgetIds) {
        ((AppWidgetProvider) Robolectric.newInstanceOf(appWidgetProviderClass)).onUpdate(this.context, this.realAppWidgetManager, newWidgetIds);
    }

    private View createWidgetView(int widgetLayoutId) {
        return new Activity().getLayoutInflater().inflate(widgetLayoutId, (ViewGroup) null);
    }

    public View getViewFor(int widgetId) {
        return getWidgetInfo(widgetId).view;
    }

    public AppWidgetProvider getAppWidgetProviderFor(int widgetId) {
        return getWidgetInfo(widgetId).appWidgetProvider;
    }

    public void setAlwaysRecreateViewsDuringUpdate(boolean alwaysRecreate) {
        this.alwaysRecreateViewsDuringUpdate = alwaysRecreate;
    }

    public boolean getAlwaysRecreateViewsDuringUpdate() {
        return this.alwaysRecreateViewsDuringUpdate;
    }

    private WidgetInfo getWidgetInfo(int widgetId) {
        return this.widgetInfos.get(Integer.valueOf(widgetId));
    }

    private class WidgetInfo {
        /* access modifiers changed from: private */
        public AppWidgetProvider appWidgetProvider;
        /* access modifiers changed from: private */
        public RemoteViews lastRemoteViews;
        /* access modifiers changed from: private */
        public int layoutId;
        /* access modifiers changed from: private */
        public View view;

        public WidgetInfo(View view2, int layoutId2, AppWidgetProvider appWidgetProvider2) {
            this.view = view2;
            this.layoutId = layoutId2;
            this.appWidgetProvider = appWidgetProvider2;
        }
    }
}
