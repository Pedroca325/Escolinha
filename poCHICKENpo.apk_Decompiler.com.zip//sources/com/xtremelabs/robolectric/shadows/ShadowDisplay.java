package com.xtremelabs.robolectric.shadows;

import android.util.DisplayMetrics;
import android.view.Display;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;

@Implements(Display.class)
public class ShadowDisplay {
    private float density = 1.5f;
    private int densityDpi = 240;
    private int displayId;
    private int height = 800;
    private int pixelFormat = 7;
    private float refreshRate = 60.0f;
    private int rotation = 0;
    private float scaledDensity = 1.0f;
    private int width = 480;
    private float xdpi = 240.0f;
    private float ydpi = 240.0f;

    @Implementation
    public int getHeight() {
        return this.height;
    }

    @Implementation
    public void getMetrics(DisplayMetrics outMetrics) {
        outMetrics.density = this.density;
        outMetrics.densityDpi = this.densityDpi;
        outMetrics.scaledDensity = this.scaledDensity;
        outMetrics.widthPixels = this.width;
        outMetrics.heightPixels = this.height;
        outMetrics.xdpi = this.xdpi;
        outMetrics.ydpi = this.ydpi;
    }

    @Implementation
    public int getWidth() {
        return this.width;
    }

    @Implementation
    public int getDisplayId() {
        return this.displayId;
    }

    @Implementation
    public float getRefreshRate() {
        return this.refreshRate;
    }

    @Implementation
    public int getRotation() {
        return this.rotation;
    }

    @Implementation
    public int getPixelFormat() {
        return this.pixelFormat;
    }

    public float getDensity() {
        return this.density;
    }

    public void setDensity(float density2) {
        this.density = density2;
    }

    public int getDensityDpi() {
        return this.densityDpi;
    }

    public void setDensityDpi(int densityDpi2) {
        this.densityDpi = densityDpi2;
    }

    public float getXdpi() {
        return this.xdpi;
    }

    public void setXdpi(float xdpi2) {
        this.xdpi = xdpi2;
    }

    public float getYdpi() {
        return this.ydpi;
    }

    public void setYdpi(float ydpi2) {
        this.ydpi = ydpi2;
    }

    public float getScaledDensity() {
        return this.scaledDensity;
    }

    public void setScaledDensity(float scaledDensity2) {
        this.scaledDensity = scaledDensity2;
    }

    public void setDisplayId(int displayId2) {
        this.displayId = displayId2;
    }

    public void setWidth(int width2) {
        this.width = width2;
    }

    public void setHeight(int height2) {
        this.height = height2;
    }

    public void setRefreshRate(float refreshRate2) {
        this.refreshRate = refreshRate2;
    }

    public void setRotation(int rotation2) {
        this.rotation = rotation2;
    }

    public void setPixelFormat(int pixelFormat2) {
        this.pixelFormat = pixelFormat2;
    }
}
