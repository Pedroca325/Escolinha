package com.xtremelabs.robolectric.shadows;

import android.nfc.NdefRecord;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;

@Implements(NdefRecord.class)
public class ShadowNdefRecord {
    private byte[] data;
    @RealObject
    private NdefRecord realNdefRecord;

    public void __constructor__(byte[] data2) {
        this.data = data2;
    }

    @Implementation
    public byte[] getPayload() {
        return this.data;
    }
}
