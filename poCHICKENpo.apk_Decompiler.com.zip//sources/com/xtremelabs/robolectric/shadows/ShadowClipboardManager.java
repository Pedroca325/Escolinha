package com.xtremelabs.robolectric.shadows;

import android.text.ClipboardManager;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;

@Implements(ClipboardManager.class)
public class ShadowClipboardManager {
    private CharSequence text;

    @Implementation
    public void setText(CharSequence text2) {
        this.text = text2;
    }

    @Implementation
    public CharSequence getText() {
        return this.text;
    }

    @Implementation
    public boolean hasText() {
        return this.text != null && this.text.length() > 0;
    }
}
