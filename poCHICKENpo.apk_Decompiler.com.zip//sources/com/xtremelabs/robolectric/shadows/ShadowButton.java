package com.xtremelabs.robolectric.shadows;

import android.widget.Button;
import com.xtremelabs.robolectric.internal.Implements;

@Implements(Button.class)
public class ShadowButton extends ShadowTextView {
    public void applyAttributes() {
        super.applyAttributes();
        if (getBackground() == null) {
            setBackgroundColor(17170445);
        }
    }
}
