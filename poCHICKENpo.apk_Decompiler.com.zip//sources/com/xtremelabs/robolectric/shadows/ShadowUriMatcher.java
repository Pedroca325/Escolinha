package com.xtremelabs.robolectric.shadows;

import android.content.UriMatcher;
import android.net.Uri;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

@Implements(UriMatcher.class)
public class ShadowUriMatcher {
    public MatchNode rootNode;

    public static class MatchNode {
        public int code = -1;
        public HashMap<String, MatchNode> map = new HashMap<>();
        public MatchNode number;
        public MatchNode text;

        public MatchNode(int code2) {
            this.code = code2;
        }
    }

    public void __constructor__(int code) {
        this.rootNode = new MatchNode(code);
    }

    @Implementation
    public void addURI(String authority, String path, int code) {
        MatchNode authNode = this.rootNode.map.get(authority);
        if (authNode == null) {
            authNode = new MatchNode(this.rootNode.code);
            this.rootNode.map.put(authority, authNode);
        }
        addNodes(authNode, Arrays.asList(path.split("/")), code);
    }

    @Implementation
    public int match(Uri uri) {
        String auth = uri.getAuthority();
        List<String> segments = uri.getPathSegments();
        if (!this.rootNode.map.containsKey(auth)) {
            return this.rootNode.code;
        }
        return matchSegments(this.rootNode.map.get(auth), segments);
    }

    private int matchSegments(MatchNode node, List<String> segments) {
        if (segments.isEmpty()) {
            return node.code;
        }
        String segment = segments.get(0);
        List<String> segments2 = segments.subList(1, segments.size());
        if (node.map.containsKey(segment)) {
            return matchSegments(node.map.get(segment), segments2);
        }
        if (node.number != null) {
            try {
                if (Long.parseLong(segment) >= 0) {
                    return matchSegments(node.number, segments2);
                }
            } catch (NumberFormatException e) {
            }
        }
        if (node.text != null) {
            return matchSegments(node.text, segments2);
        }
        return this.rootNode.code;
    }

    private void addNodes(MatchNode baseNode, List<String> segments, int code) {
        MatchNode nextNode;
        String segment = segments.get(0);
        if (segment.equals("#")) {
            nextNode = baseNode.number;
            if (nextNode == null) {
                nextNode = new MatchNode(this.rootNode.code);
                baseNode.number = nextNode;
            }
        } else if (segment.equals("*")) {
            nextNode = baseNode.text;
            if (nextNode == null) {
                nextNode = new MatchNode(this.rootNode.code);
                baseNode.text = nextNode;
            }
        } else {
            nextNode = baseNode.map.get(segment);
            if (nextNode == null) {
                nextNode = new MatchNode(this.rootNode.code);
                baseNode.map.put(segment, nextNode);
            }
        }
        if (segments.size() > 1) {
            addNodes(nextNode, segments.subList(1, segments.size()), code);
        } else {
            nextNode.code = code;
        }
    }
}
