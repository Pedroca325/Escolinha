package com.xtremelabs.robolectric.shadows;

import android.content.Context;
import android.content.Intent;
import android.preference.Preference;
import android.util.AttributeSet;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;

@Implements(Preference.class)
public class ShadowPreference {
    protected AttributeSet attrs;
    protected Object callChangeListenerValue = null;
    protected Context context;
    protected int defStyle;
    protected Object defaultValue;
    protected String dependencyKey;
    protected boolean enabled = true;
    private Intent intent;
    protected String key;
    protected Preference.OnPreferenceClickListener onClickListener;
    protected int order;
    protected int persistedInt;
    protected boolean persistent = false;
    @RealObject
    private Preference realPreference;
    protected CharSequence summary;
    protected CharSequence title;

    public void __constructor__(Context context2) {
        __constructor__(context2, (AttributeSet) null, 0);
    }

    public void __constructor__(Context context2, AttributeSet attributeSet) {
        __constructor__(context2, attributeSet, 0);
    }

    public void __constructor__(Context context2, AttributeSet attributeSet, int defStyle2) {
        this.context = context2;
        this.attrs = attributeSet;
        this.defStyle = defStyle2;
        if (attributeSet != null) {
            this.key = attributeSet.getAttributeValue("android", "key");
        }
    }

    @Implementation
    public Context getContext() {
        return this.context;
    }

    public AttributeSet getAttrs() {
        return this.attrs;
    }

    public int getDefStyle() {
        return this.defStyle;
    }

    @Implementation
    public void setEnabled(boolean enabled2) {
        this.enabled = enabled2;
    }

    @Implementation
    public boolean isEnabled() {
        return this.enabled;
    }

    @Implementation
    public boolean shouldPersist() {
        return this.persistent;
    }

    @Implementation
    public boolean isPersistent() {
        return this.persistent;
    }

    @Implementation
    public void setPersistent(boolean persistent2) {
        this.persistent = persistent2;
    }

    @Implementation
    public int getPersistedInt(int defaultReturnValue) {
        return this.persistent ? this.persistedInt : defaultReturnValue;
    }

    @Implementation
    public boolean persistInt(int value) {
        this.persistedInt = value;
        return this.persistent;
    }

    @Implementation
    public boolean callChangeListener(Object newValue) {
        this.callChangeListenerValue = newValue;
        return true;
    }

    public Object getCallChangeListenerValue() {
        return this.callChangeListenerValue;
    }

    @Implementation
    public void setSummary(int summaryResId) {
        this.summary = this.context.getResources().getText(summaryResId);
    }

    @Implementation
    public void setSummary(CharSequence summary2) {
        this.summary = summary2;
    }

    @Implementation
    public CharSequence getSummary() {
        return this.summary;
    }

    @Implementation
    public void setTitle(int titleResId) {
        this.title = this.context.getResources().getText(titleResId);
    }

    @Implementation
    public void setTitle(CharSequence title2) {
        this.title = title2;
    }

    @Implementation
    public CharSequence getTitle() {
        return this.title;
    }

    @Implementation
    public void setKey(String key2) {
        this.key = key2;
    }

    @Implementation
    public String getKey() {
        return this.key;
    }

    @Implementation
    public void setDefaultValue(Object defaultValue2) {
        this.defaultValue = defaultValue2;
    }

    public Object getDefaultValue() {
        return this.defaultValue;
    }

    @Implementation
    public int getOrder() {
        return this.order;
    }

    @Implementation
    public void setOrder(int order2) {
        this.order = order2;
    }

    @Implementation
    public void setOnPreferenceClickListener(Preference.OnPreferenceClickListener onPreferenceClickListener) {
        this.onClickListener = onPreferenceClickListener;
    }

    @Implementation
    public Preference.OnPreferenceClickListener getOnPreferenceClickListener() {
        return this.onClickListener;
    }

    public boolean click() {
        return this.onClickListener.onPreferenceClick(this.realPreference);
    }

    @Implementation
    public void setIntent(Intent i) {
        this.intent = i;
    }

    @Implementation
    public Intent getIntent() {
        return this.intent;
    }

    @Implementation
    public void setDependency(String dependencyKey2) {
        this.dependencyKey = dependencyKey2;
    }

    @Implementation
    public String getDependency() {
        return this.dependencyKey;
    }
}
