package com.xtremelabs.robolectric.shadows;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.OverlayItem;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.util.Strings;

@Implements(OverlayItem.class)
public class ShadowOverlayItem {
    private GeoPoint geoPoint;
    private String snippet;
    private String title;

    public void __constructor__(GeoPoint geoPoint2, String title2, String snippet2) {
        this.geoPoint = geoPoint2;
        this.title = title2;
        this.snippet = snippet2;
    }

    @Implementation
    public GeoPoint getPoint() {
        return this.geoPoint;
    }

    @Implementation
    public String getTitle() {
        return this.title;
    }

    @Implementation
    public String getSnippet() {
        return this.snippet;
    }

    @Implementation
    public boolean equals(Object o) {
        Object o2;
        boolean z = true;
        if (o == null || (o2 = Robolectric.shadowOf_(o)) == null) {
            return false;
        }
        if (this == o2) {
            return true;
        }
        if (getClass() != o2.getClass()) {
            return false;
        }
        ShadowOverlayItem that = (ShadowOverlayItem) o2;
        if (!Strings.equals(this.title, that.title) || !Strings.equals(this.snippet, that.snippet) || this.geoPoint != null) {
            z = this.geoPoint.equals(that.geoPoint);
        } else if (that.geoPoint != null) {
            z = false;
        }
        return z;
    }

    @Implementation
    public int hashCode() {
        int result = 13;
        if (this.title != null) {
            result = this.title.hashCode() + 247;
        }
        if (this.snippet != null) {
            result = (result * 19) + this.snippet.hashCode();
        }
        if (this.geoPoint == null) {
            return result;
        }
        return (result * 19) + this.geoPoint.hashCode();
    }
}
