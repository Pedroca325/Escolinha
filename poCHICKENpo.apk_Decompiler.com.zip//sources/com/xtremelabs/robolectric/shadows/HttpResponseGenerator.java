package com.xtremelabs.robolectric.shadows;

import org.apache.http.HttpRequest;
import org.apache.http.HttpResponse;

public interface HttpResponseGenerator {
    HttpResponse getResponse(HttpRequest httpRequest);
}
