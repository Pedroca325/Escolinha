package com.xtremelabs.robolectric.shadows;

import android.database.CursorIndexOutOfBoundsException;
import android.database.MatrixCursor;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import java.util.ArrayList;
import java.util.List;

@Implements(MatrixCursor.class)
public class ShadowMatrixCursor extends ShadowAbstractCursor {
    private List<Object[]> data = new ArrayList();

    public void __constructor__(String[] columns) {
        __constructor__(columns, 0);
    }

    public void __constructor__(String[] columns, int initialCapacity) {
        this.columnNameArray = columns;
    }

    @Implementation
    public void addRow(Object[] data2) {
        this.rowCount++;
        this.data.add(data2);
    }

    @Implementation
    public String getString(int column) {
        return (String) get(column);
    }

    @Implementation
    public long getLong(int column) {
        return ((Long) get(column)).longValue();
    }

    @Implementation
    public short getShort(int column) {
        return ((Short) get(column)).shortValue();
    }

    @Implementation
    public int getInt(int column) {
        return ((Integer) get(column)).intValue();
    }

    @Implementation
    public float getFloat(int column) {
        return ((Float) get(column)).floatValue();
    }

    @Implementation
    public double getDouble(int column) {
        return ((Double) get(column)).doubleValue();
    }

    @Implementation
    public boolean isNull(int column) {
        return get(column) == null;
    }

    private Object get(int column) {
        if (column < 0 || column >= this.columnNameArray.length) {
            throw new CursorIndexOutOfBoundsException((String) null);
        } else if (this.currentRowNumber < 0) {
            throw new CursorIndexOutOfBoundsException("Before first row.");
        } else if (this.currentRowNumber < this.rowCount) {
            return this.data.get(this.currentRowNumber)[column];
        } else {
            throw new CursorIndexOutOfBoundsException("After last row.");
        }
    }
}
