package com.xtremelabs.robolectric.shadows;

import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.Drawable;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import java.util.ArrayList;
import java.util.List;

@Implements(AnimationDrawable.class)
public class ShadowAnimationDrawable extends ShadowDrawable {
    private List<Drawable> frames = new ArrayList();

    @Implementation
    public void addFrame(Drawable frame, int duration) {
        this.frames.add(frame);
    }

    @Implementation
    public int getNumberOfFrames() {
        return this.frames.size();
    }
}
