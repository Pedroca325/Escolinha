package com.xtremelabs.robolectric.shadows;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;

@Implements(SimpleCursorAdapter.class)
public class ShadowSimpleCursorAdapter extends ShadowResourceCursorAdapter {
    private SimpleCursorAdapter.CursorToStringConverter mCursorToStringConverter;
    protected int[] mFrom;
    private String[] mOriginalFrom;
    private int mStringConversionColumn = -1;
    protected int[] mTo;
    private SimpleCursorAdapter.ViewBinder mViewBinder;
    @RealObject
    private SimpleCursorAdapter realSimpleCursorAdapter;

    public void __constructor__(Context context, int layout, Cursor c, String[] from, int[] to) {
        super.__constructor__(context, layout, c);
        this.mTo = to;
        this.mOriginalFrom = from;
        findColumns(from);
    }

    @Implementation
    public void bindView(View view, Context context, Cursor cursor) {
        SimpleCursorAdapter.ViewBinder binder = this.mViewBinder;
        int count = this.mTo.length;
        int[] from = this.mFrom;
        int[] to = this.mTo;
        for (int i = 0; i < count; i++) {
            View v = view.findViewById(to[i]);
            if (v != null) {
                boolean bound = false;
                if (binder != null) {
                    bound = binder.setViewValue(v, cursor, from[i]);
                }
                if (bound) {
                    continue;
                } else {
                    String text = cursor.getString(from[i]);
                    if (text == null) {
                        text = "";
                    }
                    if (v instanceof TextView) {
                        setViewText((TextView) v, text);
                    } else if (v instanceof ImageView) {
                        setViewImage((ImageView) v, text);
                    } else {
                        throw new IllegalStateException(v.getClass().getName() + " is not a " + " view that can be bounds by this SimpleCursorAdapter");
                    }
                }
            }
        }
    }

    @Implementation
    public SimpleCursorAdapter.ViewBinder getViewBinder() {
        return this.mViewBinder;
    }

    @Implementation
    public void setViewBinder(SimpleCursorAdapter.ViewBinder viewBinder) {
        this.mViewBinder = viewBinder;
    }

    @Implementation
    public void setViewImage(ImageView v, String value) {
        try {
            v.setImageResource(Integer.parseInt(value));
        } catch (NumberFormatException e) {
            v.setImageURI(Uri.parse(value));
        }
    }

    @Implementation
    public void setViewText(TextView v, String text) {
        v.setText(text);
    }

    @Implementation
    public int getStringConversionColumn() {
        return this.mStringConversionColumn;
    }

    @Implementation
    public void setStringConversionColumn(int stringConversionColumn) {
        this.mStringConversionColumn = stringConversionColumn;
    }

    @Implementation
    public SimpleCursorAdapter.CursorToStringConverter getCursorToStringConverter() {
        return this.mCursorToStringConverter;
    }

    @Implementation
    public void setCursorToStringConverter(SimpleCursorAdapter.CursorToStringConverter cursorToStringConverter) {
        this.mCursorToStringConverter = cursorToStringConverter;
    }

    @Implementation
    public CharSequence convertToString(Cursor cursor) {
        if (this.mCursorToStringConverter != null) {
            return this.mCursorToStringConverter.convertToString(cursor);
        }
        if (this.mStringConversionColumn > -1) {
            return cursor.getString(this.mStringConversionColumn);
        }
        return this.realSimpleCursorAdapter.convertToString(cursor);
    }

    private void findColumns(String[] from) {
        if (this.mCursor != null) {
            int count = from.length;
            if (this.mFrom == null || this.mFrom.length != count) {
                this.mFrom = new int[count];
            }
            for (int i = 0; i < count; i++) {
                this.mFrom[i] = this.mCursor.getColumnIndexOrThrow(from[i]);
            }
            return;
        }
        this.mFrom = null;
    }

    @Implementation
    public void changeCursor(Cursor c) {
        this.realSimpleCursorAdapter.changeCursor(c);
        findColumns(this.mOriginalFrom);
    }

    @Implementation
    public void changeCursorAndColumns(Cursor c, String[] from, int[] to) {
        this.mOriginalFrom = from;
        this.mTo = to;
        this.realSimpleCursorAdapter.changeCursor(c);
        findColumns(this.mOriginalFrom);
    }

    @Implementation
    public View getView(int position, View convertView, ViewGroup parent) {
        View v;
        if (!this.mDataValid) {
            throw new IllegalStateException("this should only be called when the cursor is valid");
        } else if (!this.mCursor.moveToPosition(position)) {
            throw new IllegalStateException("couldn't move cursor to position " + position);
        } else {
            if (convertView == null) {
                v = newView(this.mContext, this.mCursor, parent);
            } else {
                v = convertView;
            }
            bindView(v, this.mContext, this.mCursor);
            return v;
        }
    }

    @Implementation
    public View getDropDownView(int position, View convertView, ViewGroup parent) {
        View v;
        if (!this.mDataValid) {
            return null;
        }
        this.mCursor.moveToPosition(position);
        if (convertView == null) {
            v = newDropDownView(this.mContext, this.mCursor, parent);
        } else {
            v = convertView;
        }
        bindView(v, this.mContext, this.mCursor);
        return v;
    }
}
