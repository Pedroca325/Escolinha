package com.xtremelabs.robolectric.shadows;

import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

@Implements(ViewGroup.class)
public class ShadowViewGroup extends ShadowView {
    private Animation.AnimationListener animListener;
    private List<View> children = new ArrayList();
    private boolean disallowInterceptTouchEvent = false;

    @Implementation
    public View findViewById(int id) {
        if (id == getId()) {
            return this.realView;
        }
        for (View child : this.children) {
            View found = child.findViewById(id);
            if (found != null) {
                return found;
            }
        }
        return null;
    }

    @Implementation
    public View findViewWithTag(Object obj) {
        if (obj.equals(getTag())) {
            return this.realView;
        }
        for (View child : this.children) {
            View found = child.findViewWithTag(obj);
            if (found != null) {
                return found;
            }
        }
        return null;
    }

    @Implementation
    public void addView(View child) {
        ((ViewGroup) this.realView).addView(child, -1);
    }

    @Implementation
    public void addView(View child, int index) {
        if (index == -1) {
            this.children.add(child);
        } else {
            this.children.add(index, child);
        }
        Robolectric.shadowOf(child).parent = this;
    }

    @Implementation
    public void addView(View child, int width, int height) {
        ((ViewGroup) this.realView).addView(child, -1);
    }

    @Implementation
    public void addView(View child, ViewGroup.LayoutParams params) {
        ((ViewGroup) this.realView).addView(child, -1);
    }

    @Implementation
    public void addView(View child, int index, ViewGroup.LayoutParams params) {
        ((ViewGroup) this.realView).addView(child, index);
    }

    @Implementation
    public int indexOfChild(View child) {
        int count = getChildCount();
        for (int i = 0; i < count; i++) {
            if (this.children.get(i) == child) {
                return i;
            }
        }
        return -1;
    }

    @Implementation
    public int getChildCount() {
        return this.children.size();
    }

    @Implementation
    public View getChildAt(int index) {
        return this.children.get(index);
    }

    @Implementation
    public void removeAllViews() {
        for (View child : this.children) {
            Robolectric.shadowOf(child).parent = null;
        }
        this.children.clear();
    }

    @Implementation
    public void removeViewAt(int position) {
        Robolectric.shadowOf(this.children.remove(position)).parent = null;
    }

    @Implementation
    public boolean hasFocus() {
        if (super.hasFocus()) {
            return true;
        }
        for (View child : this.children) {
            if (child.hasFocus()) {
                return true;
            }
        }
        return false;
    }

    @Implementation
    public void clearFocus() {
        if (hasFocus()) {
            super.clearFocus();
            for (View child : this.children) {
                child.clearFocus();
            }
        }
    }

    public String innerText() {
        String innerText = "";
        String delimiter = "";
        for (int i = 0; i < getChildCount(); i++) {
            String childText = Robolectric.shadowOf(getChildAt(i)).innerText();
            if (childText.length() > 0) {
                innerText = innerText + delimiter;
                delimiter = " ";
            }
            innerText = innerText + childText;
        }
        return innerText;
    }

    public void dump(PrintStream out, int indent) {
        dumpFirstPart(out, indent);
        if (this.children.size() > 0) {
            out.println(">");
            for (View child : this.children) {
                Robolectric.shadowOf(child).dump(out, indent + 2);
            }
            dumpIndent(out, indent);
            out.println("</" + this.realView.getClass().getSimpleName() + ">");
            return;
        }
        out.println("/>");
    }

    @Implementation
    public void setLayoutAnimationListener(Animation.AnimationListener listener) {
        this.animListener = listener;
    }

    @Implementation
    public Animation.AnimationListener getLayoutAnimationListener() {
        return this.animListener;
    }

    @Implementation
    public void requestDisallowInterceptTouchEvent(boolean disallowIntercept) {
        this.disallowInterceptTouchEvent = disallowIntercept;
    }

    public boolean getDisallowInterceptTouchEvent() {
        return this.disallowInterceptTouchEvent;
    }
}
