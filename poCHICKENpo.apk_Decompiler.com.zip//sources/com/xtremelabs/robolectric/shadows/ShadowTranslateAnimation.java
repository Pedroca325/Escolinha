package com.xtremelabs.robolectric.shadows;

import android.view.animation.TranslateAnimation;
import com.xtremelabs.robolectric.internal.Implements;

@Implements(TranslateAnimation.class)
public class ShadowTranslateAnimation extends ShadowAnimation {
    private int fromXType;
    private float fromXValue;
    private int fromYType;
    private float fromYValue;
    private int toXType;
    private float toXValue;
    private int toYType;
    private float toYValue;

    public void __constructor__(int fromXType2, float fromXValue2, int toXType2, float toXValue2, int fromYType2, float fromYValue2, int toYType2, float toYValue2) {
        this.fromXType = fromXType2;
        this.fromXValue = fromXValue2;
        this.toXType = toXType2;
        this.toXValue = toXValue2;
        this.fromYType = fromYType2;
        this.fromYValue = fromYValue2;
        this.toYType = toYType2;
        this.toYValue = toYValue2;
    }

    public int getFromXType() {
        return this.fromXType;
    }

    public float getFromXValue() {
        return this.fromXValue;
    }

    public int getToXType() {
        return this.toXType;
    }

    public float getToXValue() {
        return this.toXValue;
    }

    public int getFromYType() {
        return this.fromYType;
    }

    public float getFromYValue() {
        return this.fromYValue;
    }

    public int getToYType() {
        return this.toYType;
    }

    public float getToYValue() {
        return this.toYValue;
    }
}
