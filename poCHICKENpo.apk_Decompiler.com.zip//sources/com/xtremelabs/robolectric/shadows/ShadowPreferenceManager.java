package com.xtremelabs.robolectric.shadows;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.tester.android.content.TestSharedPreferences;

@Implements(PreferenceManager.class)
public class ShadowPreferenceManager {
    @Implementation
    public static SharedPreferences getDefaultSharedPreferences(Context context) {
        return new TestSharedPreferences(Robolectric.shadowOf((Application) context.getApplicationContext()).getSharedPreferenceMap(), "__default__", 0);
    }
}
