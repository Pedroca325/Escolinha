package com.xtremelabs.robolectric.shadows;

import android.support.v4.app.Fragment;
import java.io.Serializable;

public class SerializedFragmentState implements Serializable {
    public final int containerId;
    public final Class<? extends Fragment> fragmentClass;
    public final int id;
    public final String tag;

    public SerializedFragmentState(Integer containerId2, Fragment fragment) {
        this.containerId = containerId2.intValue();
        this.id = fragment.getId();
        this.tag = fragment.getTag();
        this.fragmentClass = fragment.getClass();
    }
}
