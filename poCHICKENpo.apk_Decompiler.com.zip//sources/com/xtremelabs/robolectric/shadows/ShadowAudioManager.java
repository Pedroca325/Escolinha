package com.xtremelabs.robolectric.shadows;

import android.media.AudioManager;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;

@Implements(AudioManager.class)
public class ShadowAudioManager {
    private int flags;
    private AudioManager.OnAudioFocusChangeListener lastAbandonedAudioFocusListener;
    private AudioFocusRequest lastAudioFocusRequest;
    private int nextResponseValue = 1;
    private int streamMaxVolume = 15;
    private int streamVolume = 7;

    @Implementation
    public int getStreamMaxVolume(int streamType) {
        return this.streamMaxVolume;
    }

    @Implementation
    public int getStreamVolume(int streamType) {
        return this.streamVolume;
    }

    @Implementation
    public void setStreamVolume(int streamType, int index, int flags2) {
        this.streamVolume = index;
        this.flags = flags2;
    }

    @Implementation
    public int requestAudioFocus(AudioManager.OnAudioFocusChangeListener l, int streamType, int durationHint) {
        this.lastAudioFocusRequest = new AudioFocusRequest(l, streamType, durationHint);
        return this.nextResponseValue;
    }

    @Implementation
    public int abandonAudioFocus(AudioManager.OnAudioFocusChangeListener l) {
        this.lastAbandonedAudioFocusListener = l;
        return this.nextResponseValue;
    }

    public int getStreamMaxVolume() {
        return this.streamMaxVolume;
    }

    public void setStreamMaxVolume(int streamMaxVolume2) {
        this.streamMaxVolume = streamMaxVolume2;
    }

    public int getStreamVolume() {
        return this.streamVolume;
    }

    public void setStreamVolume(int streamVolume2) {
        this.streamVolume = streamVolume2;
    }

    public int getFlags() {
        return this.flags;
    }

    public void setFlags(int flags2) {
        this.flags = flags2;
    }

    public AudioFocusRequest getLastAudioFocusRequest() {
        return this.lastAudioFocusRequest;
    }

    public void setNextFocusRequestResponse(int nextResponseValue2) {
        this.nextResponseValue = nextResponseValue2;
    }

    public AudioManager.OnAudioFocusChangeListener getLastAbandonedAudioFocusListener() {
        return this.lastAbandonedAudioFocusListener;
    }

    public static class AudioFocusRequest {
        public final int durationHint;
        public final AudioManager.OnAudioFocusChangeListener listener;
        public final int streamType;

        private AudioFocusRequest(AudioManager.OnAudioFocusChangeListener listener2, int streamType2, int durationHint2) {
            this.listener = listener2;
            this.streamType = streamType2;
            this.durationHint = durationHint2;
        }
    }
}
