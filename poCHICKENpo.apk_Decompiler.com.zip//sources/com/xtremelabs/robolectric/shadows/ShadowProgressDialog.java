package com.xtremelabs.robolectric.shadows;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;

@Implements(ProgressDialog.class)
public class ShadowProgressDialog extends ShadowAlertDialog {
    private boolean indeterminate;

    @Implementation
    public static ProgressDialog show(Context context, CharSequence title, CharSequence message) {
        return show(context, title, message, false);
    }

    @Implementation
    public static ProgressDialog show(Context context, CharSequence title, CharSequence message, boolean indeterminate2) {
        return show(context, title, message, indeterminate2, false, (DialogInterface.OnCancelListener) null);
    }

    @Implementation
    public static ProgressDialog show(Context context, CharSequence title, CharSequence message, boolean indeterminate2, boolean cancelable) {
        return show(context, title, message, indeterminate2, cancelable, (DialogInterface.OnCancelListener) null);
    }

    @Implementation
    public static ProgressDialog show(Context context, CharSequence title, CharSequence message, boolean indeterminate2, boolean cancelable, DialogInterface.OnCancelListener onCancelListener) {
        ProgressDialog progressDialog = new ProgressDialog(context);
        progressDialog.setTitle(title);
        progressDialog.setMessage(message);
        progressDialog.setIndeterminate(indeterminate2);
        progressDialog.setCancelable(cancelable);
        progressDialog.setOnCancelListener(onCancelListener);
        progressDialog.show();
        Robolectric.getShadowApplication().setLatestAlertDialog(Robolectric.shadowOf(progressDialog));
        return progressDialog;
    }

    @Implementation
    public void setIndeterminate(boolean indeterminate2) {
        this.indeterminate = indeterminate2;
    }

    @Implementation
    public boolean isIndeterminate() {
        return this.indeterminate;
    }
}
