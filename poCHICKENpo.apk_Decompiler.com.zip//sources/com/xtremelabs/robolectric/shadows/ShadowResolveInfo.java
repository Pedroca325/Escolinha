package com.xtremelabs.robolectric.shadows;

import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;

@Implements(ResolveInfo.class)
public class ShadowResolveInfo {
    private String label;

    @Implementation
    public String loadLabel(PackageManager mgr) {
        return this.label;
    }

    public void setLabel(String l) {
        this.label = l;
    }

    public static ResolveInfo newResolveInfo(String displayName, String packageName) {
        return newResolveInfo(displayName, packageName, (String) null);
    }

    public static ResolveInfo newResolveInfo(String displayName, String packageName, String activityName) {
        ResolveInfo resInfo = new ResolveInfo();
        ActivityInfo actInfo = new ActivityInfo();
        actInfo.packageName = packageName;
        actInfo.name = activityName;
        resInfo.activityInfo = actInfo;
        Robolectric.shadowOf(resInfo).setLabel(displayName);
        return resInfo;
    }
}
