package com.xtremelabs.robolectric.shadows;

import android.widget.Filter;
import com.xtremelabs.robolectric.internal.Implements;

@Implements(Filter.class)
public class ShadowFilter {
}
