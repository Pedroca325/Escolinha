package com.xtremelabs.robolectric.shadows;

import android.preference.PreferenceActivity;
import android.preference.PreferenceScreen;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;

@Implements(PreferenceActivity.class)
public class ShadowPreferenceActivity extends ShadowListActivity {
    private PreferenceScreen preferenceScreen;
    private int preferencesResId = -1;

    @Implementation
    public void addPreferencesFromResource(int preferencesResId2) {
        this.preferencesResId = preferencesResId2;
        this.preferenceScreen = getResourceLoader().inflatePreferences(getApplicationContext(), preferencesResId2);
    }

    public int getPreferencesResId() {
        return this.preferencesResId;
    }

    @Implementation
    public PreferenceScreen getPreferenceScreen() {
        return this.preferenceScreen;
    }
}
