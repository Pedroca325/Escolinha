package com.xtremelabs.robolectric.shadows;

import android.hardware.Camera;
import android.media.MediaRecorder;
import android.view.Surface;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;

@Implements(MediaRecorder.class)
public class ShadowMediaRecorder {
    public static final int STATE_DATA_SOURCE_CONFIGURED = 3;
    public static final int STATE_ERROR = -1;
    public static final int STATE_INITIAL = 1;
    public static final int STATE_INITIALIZED = 2;
    public static final int STATE_PREPARED = 4;
    public static final int STATE_RECORDING = 5;
    public static final int STATE_RELEASED = 6;
    private int audioBitRate;
    private int audioChannels;
    private int audioEncoder;
    private int audioSamplingRate;
    private int audioSource;
    private Camera camera;
    private MediaRecorder.OnErrorListener errorListener;
    private MediaRecorder.OnInfoListener infoListener;
    private int maxDuration;
    private long maxFileSize;
    private int outputFormat;
    private String outputPath;
    private Surface previewDisplay;
    private int state;
    private int videoBitRate;
    private int videoEncoder;
    private int videoFrameRate;
    private int videoHeight;
    private int videoSource;
    private int videoWidth;

    public void __constructor__() {
        this.state = 1;
    }

    @Implementation
    public void setAudioChannels(int numChannels) {
        this.audioChannels = numChannels;
    }

    @Implementation
    public void setAudioEncoder(int audio_encoder) {
        this.audioEncoder = audio_encoder;
        this.state = 3;
    }

    @Implementation
    public void setAudioEncodingBitRate(int bitRate) {
        this.audioBitRate = bitRate;
    }

    @Implementation
    public void setAudioSamplingRate(int samplingRate) {
        this.audioSamplingRate = samplingRate;
    }

    @Implementation
    public void setAudioSource(int audio_source) {
        this.audioSource = audio_source;
        this.state = 2;
    }

    @Implementation
    public void setCamera(Camera c) {
        this.camera = c;
    }

    @Implementation
    public void setMaxDuration(int max_duration_ms) {
        this.maxDuration = max_duration_ms;
    }

    @Implementation
    public void setMaxFileSize(long max_filesize_bytes) {
        this.maxFileSize = max_filesize_bytes;
    }

    @Implementation
    public void setOnErrorListener(MediaRecorder.OnErrorListener l) {
        this.errorListener = l;
    }

    @Implementation
    public void setOnInfoListener(MediaRecorder.OnInfoListener listener) {
        this.infoListener = listener;
    }

    @Implementation
    public void setOutputFile(String path) {
        this.outputPath = path;
        this.state = 3;
    }

    @Implementation
    public void setOutputFormat(int output_format) {
        this.outputFormat = output_format;
        this.state = 3;
    }

    @Implementation
    public void setPreviewDisplay(Surface sv) {
        this.previewDisplay = sv;
        this.state = 3;
    }

    @Implementation
    public void setVideoEncoder(int video_encoder) {
        this.videoEncoder = video_encoder;
        this.state = 3;
    }

    @Implementation
    public void setVideoEncodingBitRate(int bitRate) {
        this.videoBitRate = bitRate;
    }

    @Implementation
    public void setVideoFrameRate(int rate) {
        this.videoFrameRate = rate;
        this.state = 3;
    }

    @Implementation
    public void setVideoSize(int width, int height) {
        this.videoWidth = width;
        this.videoHeight = height;
        this.state = 3;
    }

    @Implementation
    public void setVideoSource(int video_source) {
        this.videoSource = video_source;
        this.state = 2;
    }

    @Implementation
    public void prepare() {
        this.state = 4;
    }

    @Implementation
    public void start() {
        this.state = 5;
    }

    @Implementation
    public void stop() {
        this.state = 1;
    }

    @Implementation
    public void reset() {
        this.state = 1;
    }

    @Implementation
    public void release() {
        this.state = 6;
    }

    public Camera getCamera() {
        return this.camera;
    }

    public int getAudioChannels() {
        return this.audioChannels;
    }

    public int getAudioEncoder() {
        return this.audioEncoder;
    }

    public int getAudioEncodingBitRate() {
        return this.audioBitRate;
    }

    public int getAudioSamplingRate() {
        return this.audioSamplingRate;
    }

    public int getAudioSource() {
        return this.audioSource;
    }

    public int getMaxDuration() {
        return this.maxDuration;
    }

    public long getMaxFileSize() {
        return this.maxFileSize;
    }

    public String getOutputPath() {
        return this.outputPath;
    }

    public int getOutputFormat() {
        return this.outputFormat;
    }

    public int getVideoEncoder() {
        return this.videoEncoder;
    }

    public int getVideoEncodingBitRate() {
        return this.videoBitRate;
    }

    public int getVideoFrameRate() {
        return this.videoFrameRate;
    }

    public int getVideoWidth() {
        return this.videoWidth;
    }

    public int getVideoHeight() {
        return this.videoHeight;
    }

    public int getVideoSource() {
        return this.videoSource;
    }

    public Surface getPreviewDisplay() {
        return this.previewDisplay;
    }

    public MediaRecorder.OnErrorListener getErrorListener() {
        return this.errorListener;
    }

    public MediaRecorder.OnInfoListener getInfoListener() {
        return this.infoListener;
    }

    public int getState() {
        return this.state;
    }
}
