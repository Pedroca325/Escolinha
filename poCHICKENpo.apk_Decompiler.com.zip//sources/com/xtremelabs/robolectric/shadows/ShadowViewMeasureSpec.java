package com.xtremelabs.robolectric.shadows;

import android.view.View;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;

@Implements(View.MeasureSpec.class)
public class ShadowViewMeasureSpec {
    private static final int MODE_MASK = -1073741824;
    private static final int MODE_SHIFT = 30;

    @Implementation
    public static int getMode(int measureSpec) {
        return MODE_MASK & measureSpec;
    }

    @Implementation
    public static int getSize(int measureSpec) {
        return 1073741823 & measureSpec;
    }

    @Implementation
    public static int makeMeasureSpec(int size, int mode) {
        return size + mode;
    }

    @Implementation
    public static String toString(int measureSpec) {
        int mode = getMode(measureSpec);
        int size = getSize(measureSpec);
        StringBuilder sb = new StringBuilder("MeasureSpec: ");
        if (mode == 0) {
            sb.append("UNSPECIFIED ");
        } else if (mode == 1073741824) {
            sb.append("EXACTLY ");
        } else if (mode == Integer.MIN_VALUE) {
            sb.append("AT_MOST ");
        } else {
            sb.append(mode).append(" ");
        }
        sb.append(size);
        return sb.toString();
    }
}
