package com.xtremelabs.robolectric.shadows;

import android.content.SyncResult;
import android.content.SyncStats;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;
import java.lang.reflect.Field;

@Implements(SyncResult.class)
public class ShadowSyncResult {
    @RealObject
    private SyncResult result;

    public void __constructor__() {
        try {
            Field f = SyncResult.class.getDeclaredField("stats");
            f.setAccessible(true);
            f.set(this.result, new SyncStats());
        } catch (NoSuchFieldException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException e2) {
            throw new RuntimeException(e2);
        }
    }

    @Implementation
    public boolean hasSoftError() {
        return this.result.syncAlreadyInProgress || this.result.stats.numIoExceptions > 0;
    }

    @Implementation
    public boolean hasHardError() {
        return this.result.stats.numParseExceptions > 0 || this.result.stats.numConflictDetectedExceptions > 0 || this.result.stats.numAuthExceptions > 0 || this.result.tooManyDeletions || this.result.tooManyRetries || this.result.databaseError;
    }

    @Implementation
    public boolean hasError() {
        return hasSoftError() || hasHardError();
    }

    @Implementation
    public boolean madeSomeProgress() {
        return (this.result.stats.numDeletes > 0 && !this.result.tooManyDeletions) || this.result.stats.numInserts > 0 || this.result.stats.numUpdates > 0;
    }

    @Implementation
    public void clear() {
        if (this.result.syncAlreadyInProgress) {
            throw new UnsupportedOperationException("you are not allowed to clear the ALREADY_IN_PROGRESS SyncStats");
        }
        this.result.tooManyDeletions = false;
        this.result.tooManyRetries = false;
        this.result.databaseError = false;
        this.result.fullSyncRequested = false;
        this.result.partialSyncUnavailable = false;
        this.result.moreRecordsToGet = false;
        this.result.delayUntil = 0;
        this.result.stats.clear();
    }

    @Implements(SyncStats.class)
    public static class ShadowSyncStats {
        @RealObject
        private SyncStats stats;

        @Implementation
        public void clear() {
            this.stats.numAuthExceptions = 0;
            this.stats.numIoExceptions = 0;
            this.stats.numParseExceptions = 0;
            this.stats.numConflictDetectedExceptions = 0;
            this.stats.numInserts = 0;
            this.stats.numUpdates = 0;
            this.stats.numDeletes = 0;
            this.stats.numEntries = 0;
            this.stats.numSkippedEntries = 0;
        }
    }
}
