package com.xtremelabs.robolectric.shadows;

import android.content.IntentFilter;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;

@Implements(IntentFilter.AuthorityEntry.class)
public class ShadowIntentFilterAuthorityEntry {
    private String host;
    private int port;

    public void __constructor__(String host2, String port2) {
        this.host = host2;
        if (port2 == null) {
            this.port = -1;
        } else {
            this.port = Integer.parseInt(port2);
        }
    }

    @Implementation
    public String getHost() {
        return this.host;
    }

    @Implementation
    public int getPort() {
        return this.port;
    }
}
