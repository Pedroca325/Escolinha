package com.xtremelabs.robolectric.shadows;

import android.os.PowerManager;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;

@Implements(PowerManager.class)
public class ShadowPowerManager {
    private boolean isScreenOn = true;

    @Implementation
    public PowerManager.WakeLock newWakeLock(int flags, String tag) {
        return (PowerManager.WakeLock) Robolectric.newInstanceOf(PowerManager.WakeLock.class);
    }

    @Implementation
    public boolean isScreenOn() {
        return this.isScreenOn;
    }

    public void setIsScreenOn(boolean screenOn) {
        this.isScreenOn = screenOn;
    }
}
