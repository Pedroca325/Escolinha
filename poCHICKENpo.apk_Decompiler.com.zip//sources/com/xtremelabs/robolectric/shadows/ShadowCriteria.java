package com.xtremelabs.robolectric.shadows;

import android.location.Criteria;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;

@Implements(Criteria.class)
public class ShadowCriteria {
    private int accuracy = 0;
    private int powerRequirement = 0;

    public void __constructor__(Criteria criteria) {
        this.accuracy = criteria.getAccuracy();
        this.powerRequirement = criteria.getPowerRequirement();
    }

    @Implementation
    public int getAccuracy() {
        return this.accuracy;
    }

    @Implementation
    public void setAccuracy(int accuracy2) {
        this.accuracy = accuracy2;
    }

    @Implementation
    public int getPowerRequirement() {
        return this.powerRequirement;
    }

    @Implementation
    public void setPowerRequirement(int powerRequirement2) {
        this.powerRequirement = powerRequirement2;
    }

    @Implementation
    public boolean equals(Object obj) {
        if (!(obj instanceof Criteria)) {
            return false;
        }
        Criteria criteria = (Criteria) obj;
        if (criteria.getAccuracy() == this.accuracy && criteria.getPowerRequirement() == this.powerRequirement) {
            return true;
        }
        return false;
    }
}
