package com.xtremelabs.robolectric.shadows;

import android.app.PendingIntent;
import android.telephony.SmsManager;
import android.text.TextUtils;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;

@Implements(SmsManager.class)
public class ShadowSmsManager {
    @RealObject
    private static SmsManager realManager = ((SmsManager) Robolectric.newInstanceOf(SmsManager.class));
    private TextSmsParams lastTextSmsParams = null;

    @Implementation
    public static SmsManager getDefault() {
        return realManager;
    }

    @Implementation
    public void sendTextMessage(String destinationAddress, String scAddress, String text, PendingIntent sentIntent, PendingIntent deliveryIntent) {
        if (TextUtils.isEmpty(destinationAddress)) {
            throw new IllegalArgumentException("Invalid destinationAddress");
        } else if (TextUtils.isEmpty(text)) {
            throw new IllegalArgumentException("Invalid message body");
        } else {
            this.lastTextSmsParams = new TextSmsParams(destinationAddress, scAddress, text, sentIntent, deliveryIntent);
        }
    }

    public TextSmsParams getLastSentTextMessageParams() {
        return this.lastTextSmsParams;
    }

    public void clearLastSentTextMessageParams() {
        this.lastTextSmsParams = null;
    }

    public class TextSmsParams {
        private PendingIntent deliveryIntent;
        private String destinationAddress;
        private String scAddress;
        private PendingIntent sentIntent;
        private String text;

        public TextSmsParams(String destinationAddress2, String scAddress2, String text2, PendingIntent sentIntent2, PendingIntent deliveryIntent2) {
            this.destinationAddress = destinationAddress2;
            this.scAddress = scAddress2;
            this.text = text2;
            this.sentIntent = sentIntent2;
            this.deliveryIntent = deliveryIntent2;
        }

        public String getDestinationAddress() {
            return this.destinationAddress;
        }

        public String getScAddress() {
            return this.scAddress;
        }

        public String getText() {
            return this.text;
        }

        public PendingIntent getSentIntent() {
            return this.sentIntent;
        }

        public PendingIntent getDeliveryIntent() {
            return this.deliveryIntent;
        }
    }
}
