package com.xtremelabs.robolectric.shadows;

import android.graphics.Point;
import android.graphics.PointF;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;

@Implements(PointF.class)
public class ShadowPointF {
    @RealObject
    private PointF realPointF;

    public void __constructor__(float x, float y) {
        this.realPointF.x = x;
        this.realPointF.y = y;
    }

    public void __constructor__(Point src) {
        this.realPointF.x = (float) src.x;
        this.realPointF.y = (float) src.y;
    }

    @Implementation
    public void set(float x, float y) {
        this.realPointF.x = x;
        this.realPointF.y = y;
    }

    @Implementation
    public final void negate() {
        this.realPointF.x = -this.realPointF.x;
        this.realPointF.y = -this.realPointF.y;
    }

    @Implementation
    public final void offset(float dx, float dy) {
        this.realPointF.x += dx;
        this.realPointF.y += dy;
    }

    @Implementation
    public boolean equals(Object object) {
        Object o;
        if (object == null || (o = Robolectric.shadowOf_(object)) == null) {
            return false;
        }
        if (this == o) {
            return true;
        }
        if (getClass() != o.getClass()) {
            return false;
        }
        ShadowPointF that = (ShadowPointF) o;
        if (this.realPointF.x == that.realPointF.x && this.realPointF.y == that.realPointF.y) {
            return true;
        }
        return false;
    }

    @Implementation
    public int hashCode() {
        return (int) ((this.realPointF.x * 32713.0f) + this.realPointF.y);
    }

    @Implementation
    public String toString() {
        return "Point(" + this.realPointF.x + ", " + this.realPointF.y + ")";
    }

    @Implementation
    public final boolean equals(float x, float y) {
        return this.realPointF.x == x && this.realPointF.y == y;
    }
}
