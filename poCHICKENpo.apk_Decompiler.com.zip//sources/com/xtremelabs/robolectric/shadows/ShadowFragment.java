package com.xtremelabs.robolectric.shadows;

import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.view.View;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;

@Implements(Fragment.class)
public class ShadowFragment {
    protected FragmentActivity activity;
    private int containerViewId;
    private Bundle savedInstanceState;
    private boolean shouldReplace;
    private String tag;
    protected View view;

    public void setView(View view2) {
        this.view = view2;
    }

    public void setActivity(FragmentActivity activity2) {
        this.activity = activity2;
    }

    @Implementation
    public View getView() {
        return this.view;
    }

    @Implementation
    public FragmentActivity getActivity() {
        return this.activity;
    }

    @Implementation
    public void startActivity(Intent intent) {
        this.activity.startActivity(intent);
    }

    @Implementation
    public void startActivityForResult(Intent intent, int requestCode) {
        this.activity.startActivityForResult(intent, requestCode);
    }

    @Implementation
    public final FragmentManager getFragmentManager() {
        return this.activity.getSupportFragmentManager();
    }

    @Implementation
    public String getTag() {
        return this.tag;
    }

    @Implementation
    public Resources getResources() {
        return getActivity().getResources();
    }

    public void setTag(String tag2) {
        this.tag = tag2;
    }

    public void setSavedInstanceState(Bundle savedInstanceState2) {
        this.savedInstanceState = savedInstanceState2;
    }

    public Bundle getSavedInstanceState() {
        return this.savedInstanceState;
    }

    public void setContainerViewId(int containerViewId2) {
        this.containerViewId = containerViewId2;
    }

    public int getContainerViewId() {
        return this.containerViewId;
    }

    public void setShouldReplace(boolean shouldReplace2) {
        this.shouldReplace = shouldReplace2;
    }

    public boolean getShouldReplace() {
        return this.shouldReplace;
    }
}
