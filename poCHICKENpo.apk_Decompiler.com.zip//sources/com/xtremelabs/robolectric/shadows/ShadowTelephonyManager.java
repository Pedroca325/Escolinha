package com.xtremelabs.robolectric.shadows;

import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;

@Implements(TelephonyManager.class)
public class ShadowTelephonyManager {
    private String deviceId;
    private int eventFlags;
    private PhoneStateListener listener;
    private String networkCountryIso;
    private String networkOperator;
    private String networkOperatorName;
    private int phoneType = 1;
    private boolean readPhoneStatePermission = true;
    private String simCountryIso;

    @Implementation
    public void listen(PhoneStateListener listener2, int events) {
        this.listener = listener2;
        this.eventFlags = events;
    }

    public PhoneStateListener getListener() {
        return this.listener;
    }

    public int getEventFlags() {
        return this.eventFlags;
    }

    @Implementation
    public String getDeviceId() {
        checkReadPhoneStatePermission();
        return this.deviceId;
    }

    public void setDeviceId(String newDeviceId) {
        this.deviceId = newDeviceId;
    }

    public void setNetworkOperatorName(String networkOperatorName2) {
        this.networkOperatorName = networkOperatorName2;
    }

    @Implementation
    public String getNetworkOperatorName() {
        return this.networkOperatorName;
    }

    public void setNetworkCountryIso(String networkCountryIso2) {
        this.networkCountryIso = networkCountryIso2;
    }

    @Implementation
    public String getNetworkCountryIso() {
        return this.networkCountryIso;
    }

    public void setNetworkOperator(String networkOperator2) {
        this.networkOperator = networkOperator2;
    }

    @Implementation
    public String getNetworkOperator() {
        return this.networkOperator;
    }

    @Implementation
    public String getSimCountryIso() {
        return this.simCountryIso;
    }

    public void setSimCountryIso(String simCountryIso2) {
        this.simCountryIso = simCountryIso2;
    }

    public void setReadPhoneStatePermission(boolean readPhoneStatePermission2) {
        this.readPhoneStatePermission = readPhoneStatePermission2;
    }

    private void checkReadPhoneStatePermission() {
        if (!this.readPhoneStatePermission) {
            throw new SecurityException();
        }
    }

    @Implementation
    public int getPhoneType() {
        return this.phoneType;
    }

    public void setPhoneType(int phoneType2) {
        this.phoneType = phoneType2;
    }
}
