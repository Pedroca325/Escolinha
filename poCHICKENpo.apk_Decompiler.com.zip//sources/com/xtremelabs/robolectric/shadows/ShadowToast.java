package com.xtremelabs.robolectric.shadows;

import android.content.Context;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;
import java.util.List;

@Implements(Toast.class)
public class ShadowToast {
    private int gravity;
    private String text;
    @RealObject
    Toast toast;
    private View view;

    @Implementation
    public static Toast makeText(Context context, int resId, int duration) {
        return makeText(context, (CharSequence) context.getResources().getString(resId), duration);
    }

    @Implementation(i18nSafe = false)
    public static Toast makeText(Context context, CharSequence text2, int duration) {
        Toast toast2 = new Toast((Context) null);
        Robolectric.shadowOf(toast2).text = text2.toString();
        return toast2;
    }

    @Implementation
    public void show() {
        Robolectric.getShadowApplication().getShownToasts().add(this.toast);
    }

    @Implementation
    public void setView(View view2) {
        this.view = view2;
    }

    @Implementation
    public View getView() {
        return this.view;
    }

    @Implementation
    public void setGravity(int gravity2, int xOffset, int yOffset) {
        this.gravity = gravity2;
    }

    @Implementation
    public int getGravity() {
        return this.gravity;
    }

    public static void reset() {
        Robolectric.getShadowApplication().getShownToasts().clear();
    }

    public static int shownToastCount() {
        return Robolectric.getShadowApplication().getShownToasts().size();
    }

    public static boolean showedCustomToast(CharSequence message, int layoutResourceIdToCheckForMessage) {
        for (Toast toast2 : Robolectric.getShadowApplication().getShownToasts()) {
            if (((TextView) toast2.getView().findViewById(layoutResourceIdToCheckForMessage)).getText().toString().equals(message.toString())) {
                return true;
            }
        }
        return false;
    }

    public static boolean showedToast(CharSequence message) {
        for (Toast toast2 : Robolectric.getShadowApplication().getShownToasts()) {
            String text2 = Robolectric.shadowOf(toast2).text;
            if (text2 != null && text2.equals(message.toString())) {
                return true;
            }
        }
        return false;
    }

    public static String getTextOfLatestToast() {
        List<Toast> shownToasts = Robolectric.getShadowApplication().getShownToasts();
        if (shownToasts.size() == 0) {
            return null;
        }
        return Robolectric.shadowOf(shownToasts.get(shownToasts.size() - 1)).text;
    }

    public static Toast getLatestToast() {
        List<Toast> shownToasts = Robolectric.getShadowApplication().getShownToasts();
        if (shownToasts.size() == 0) {
            return null;
        }
        return shownToasts.get(shownToasts.size() - 1);
    }
}
