package com.xtremelabs.robolectric.shadows;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.widget.TabHost;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;

@Implements(TabHost.TabSpec.class)
public class ShadowTabSpec {
    private View contentView;
    private Drawable icon;
    private View indicatorView;
    private Intent intent;
    private CharSequence label;
    @RealObject
    TabHost.TabSpec realObject;
    private String tag;
    private int viewId;

    public void setTag(String tag2) {
        this.tag = tag2;
    }

    @Implementation
    public String getTag() {
        return this.tag;
    }

    public View getIndicatorAsView() {
        return this.indicatorView;
    }

    public String getIndicatorLabel() {
        return this.label.toString();
    }

    public Drawable getIndicatorIcon() {
        return this.icon;
    }

    public String getText() {
        return this.label.toString();
    }

    @Implementation
    public TabHost.TabSpec setIndicator(View view) {
        this.indicatorView = view;
        return this.realObject;
    }

    @Implementation
    public TabHost.TabSpec setIndicator(CharSequence label2) {
        this.label = label2;
        return this.realObject;
    }

    @Implementation
    public TabHost.TabSpec setIndicator(CharSequence label2, Drawable icon2) {
        this.label = label2;
        this.icon = icon2;
        return this.realObject;
    }

    public Intent getContentAsIntent() {
        return this.intent;
    }

    @Implementation
    public TabHost.TabSpec setContent(Intent intent2) {
        this.intent = intent2;
        return this.realObject;
    }

    @Implementation
    public TabHost.TabSpec setContent(TabHost.TabContentFactory factory) {
        this.contentView = factory.createTabContent(this.tag);
        return this.realObject;
    }

    @Implementation
    public TabHost.TabSpec setContent(int viewId2) {
        this.viewId = viewId2;
        return this.realObject;
    }

    public int getContentViewId() {
        return this.viewId;
    }

    public View getContentView() {
        return this.contentView;
    }
}
