package com.xtremelabs.robolectric.shadows;

import android.preference.ListPreference;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;

@Implements(ListPreference.class)
public class ShadowListPreference extends ShadowDialogPreference {
    CharSequence[] entries;
    CharSequence[] entryValues;

    @Implementation
    public CharSequence[] getEntries() {
        return this.entries;
    }

    @Implementation
    public void setEntries(CharSequence[] entries2) {
        this.entries = entries2;
    }

    @Implementation
    public void setEntries(int entriesResId) {
        this.entries = this.context.getResources().getStringArray(entriesResId);
    }

    @Implementation
    public CharSequence[] getEntryValues() {
        return this.entryValues;
    }

    @Implementation
    public void setEntryValues(CharSequence[] entryValues2) {
        this.entryValues = entryValues2;
    }

    @Implementation
    public void setEntryValues(int entryValuesResId) {
        this.entryValues = this.context.getResources().getStringArray(entryValuesResId);
    }
}
