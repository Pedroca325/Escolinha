package com.xtremelabs.robolectric.shadows;

import android.content.ContentResolver;
import android.provider.Settings;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import java.util.HashMap;
import java.util.Map;
import java.util.WeakHashMap;

@Implements(Settings.class)
public class ShadowSettings {

    @Implements(Settings.class)
    private static class SettingsImpl {
        private static final WeakHashMap<ContentResolver, Map<String, Object>> dataMap = new WeakHashMap<>();

        private SettingsImpl() {
        }

        @Implementation
        public static boolean putInt(ContentResolver cr, String name, int value) {
            get(cr).put(name, Integer.valueOf(value));
            return true;
        }

        @Implementation
        public static int getInt(ContentResolver cr, String name, int def) {
            if (get(cr).get(name) instanceof Integer) {
                return ((Integer) get(cr).get(name)).intValue();
            }
            return def;
        }

        @Implementation
        public static int getInt(ContentResolver cr, String name) throws Settings.SettingNotFoundException {
            if (get(cr).get(name) instanceof Integer) {
                return ((Integer) get(cr).get(name)).intValue();
            }
            throw new Settings.SettingNotFoundException(name);
        }

        @Implementation
        public static boolean putString(ContentResolver cr, String name, String value) {
            get(cr).put(name, value);
            return true;
        }

        @Implementation
        public static String getString(ContentResolver cr, String name) {
            if (get(cr).get(name) instanceof String) {
                return (String) get(cr).get(name);
            }
            return null;
        }

        @Implementation
        public static boolean putLong(ContentResolver cr, String name, long value) {
            get(cr).put(name, Long.valueOf(value));
            return true;
        }

        @Implementation
        public static long getLong(ContentResolver cr, String name, long def) {
            if (get(cr).get(name) instanceof Long) {
                return ((Long) get(cr).get(name)).longValue();
            }
            return def;
        }

        @Implementation
        public static long getLong(ContentResolver cr, String name) throws Settings.SettingNotFoundException {
            if (get(cr).get(name) instanceof Long) {
                return ((Long) get(cr).get(name)).longValue();
            }
            throw new Settings.SettingNotFoundException(name);
        }

        @Implementation
        public static boolean putFloat(ContentResolver cr, String name, float value) {
            get(cr).put(name, Float.valueOf(value));
            return true;
        }

        @Implementation
        public static float getFloat(ContentResolver cr, String name, float def) {
            if (get(cr).get(name) instanceof Float) {
                return ((Float) get(cr).get(name)).floatValue();
            }
            return def;
        }

        @Implementation
        public static float getFloat(ContentResolver cr, String name) throws Settings.SettingNotFoundException {
            if (get(cr).get(name) instanceof Float) {
                return ((Float) get(cr).get(name)).floatValue();
            }
            throw new Settings.SettingNotFoundException(name);
        }

        @Implementation
        private static Map<String, Object> get(ContentResolver cr) {
            Map<String, Object> map = dataMap.get(cr);
            if (map != null) {
                return map;
            }
            Map<String, Object> map2 = new HashMap<>();
            dataMap.put(cr, map2);
            return map2;
        }
    }

    @Implements(Settings.System.class)
    public static class ShadowSystem extends SettingsImpl {
        public ShadowSystem() {
            super();
        }
    }

    @Implements(Settings.Secure.class)
    public static class ShadowSecure extends SettingsImpl {
        public ShadowSecure() {
            super();
        }
    }

    public static void setAirplaneMode(boolean isAirplaneMode) {
        Settings.System.putInt(Robolectric.application.getContentResolver(), "airplane_mode_on", isAirplaneMode ? 1 : 0);
    }

    public static void setWifiOn(boolean isOn) {
        Settings.Secure.putInt(Robolectric.application.getContentResolver(), "wifi_on", isOn ? 1 : 0);
    }

    public static void set24HourTimeFormat(boolean use24HourTimeFormat) {
        Settings.System.putInt(Robolectric.application.getContentResolver(), "time_12_24", use24HourTimeFormat ? 24 : 12);
    }
}
