package com.xtremelabs.robolectric.shadows;

import android.hardware.Camera;
import android.view.SurfaceHolder;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;
import java.util.HashMap;
import java.util.Map;

@Implements(Camera.class)
public class ShadowCamera {
    private static Map<Integer, Camera.CameraInfo> cameras = new HashMap();
    private boolean locked;
    private Camera.Parameters parameters;
    private Camera.PreviewCallback previewCallback;
    private boolean previewing;
    @RealObject
    private Camera realCamera;
    private boolean released;
    private SurfaceHolder surfaceHolder;

    public void __constructor__() {
        this.locked = true;
        this.previewing = false;
        this.released = false;
    }

    @Implementation
    public static Camera open() {
        return (Camera) Robolectric.newInstanceOf(Camera.class);
    }

    @Implementation
    public void unlock() {
        this.locked = false;
    }

    @Implementation
    public void reconnect() {
        this.locked = true;
    }

    @Implementation
    public Camera.Parameters getParameters() {
        if (this.parameters == null) {
            this.parameters = (Camera.Parameters) Robolectric.newInstanceOf(Camera.Parameters.class);
        }
        return this.parameters;
    }

    @Implementation
    public void setParameters(Camera.Parameters params) {
        this.parameters = params;
    }

    @Implementation
    public void setPreviewDisplay(SurfaceHolder holder) {
        this.surfaceHolder = holder;
    }

    @Implementation
    public void startPreview() {
        this.previewing = true;
    }

    @Implementation
    public void stopPreview() {
        this.previewing = false;
    }

    @Implementation
    public void release() {
        this.released = true;
    }

    @Implementation
    public void setPreviewCallback(Camera.PreviewCallback cb) {
        this.previewCallback = cb;
    }

    @Implementation
    public void setOneShotPreviewCallback(Camera.PreviewCallback cb) {
        this.previewCallback = cb;
    }

    @Implementation
    public void setPreviewCallbackWithBuffer(Camera.PreviewCallback cb) {
        this.previewCallback = cb;
    }

    @Implementation
    public static void getCameraInfo(int cameraId, Camera.CameraInfo cameraInfo) {
        Camera.CameraInfo foundCam = cameras.get(Integer.valueOf(cameraId));
        cameraInfo.facing = foundCam.facing;
        cameraInfo.orientation = foundCam.orientation;
    }

    @Implementation
    public static int getNumberOfCameras() {
        return cameras.size();
    }

    public void invokePreviewCallback(byte[] data) {
        if (this.previewCallback != null) {
            this.previewCallback.onPreviewFrame(data, this.realCamera);
        }
    }

    public boolean isLocked() {
        return this.locked;
    }

    public boolean isPreviewing() {
        return this.previewing;
    }

    public boolean isReleased() {
        return this.released;
    }

    public SurfaceHolder getPreviewDisplay() {
        return this.surfaceHolder;
    }

    public static void addCameraInfo(int id, Camera.CameraInfo camInfo) {
        cameras.put(Integer.valueOf(id), camInfo);
    }

    public static void clearCameraInfo() {
        cameras.clear();
    }
}
