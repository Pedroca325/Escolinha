package com.xtremelabs.robolectric.shadows;

import android.app.Application;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.AppSingletonizer;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.res.ResourceLoader;

@Implements(LayoutInflater.class)
public class ShadowLayoutInflater {
    private static AppSingletonizer<LayoutInflater> instances = new LayoutInflaterAppSingletonizer();
    private Context context;

    /* access modifiers changed from: private */
    public static LayoutInflater bind(LayoutInflater layoutInflater, Context context2) {
        Robolectric.shadowOf(layoutInflater).context = context2;
        return layoutInflater;
    }

    @Implementation
    public static LayoutInflater from(Context context2) {
        return bind(instances.getInstance(context2), context2);
    }

    @Implementation
    public Context getContext() {
        return this.context;
    }

    @Implementation
    public View inflate(int resource, ViewGroup root, boolean attachToRoot) {
        ResourceLoader resourceLoader = getResourceLoader();
        Context context2 = this.context;
        if (!attachToRoot) {
            root = null;
        }
        return resourceLoader.inflateView(context2, resource, root);
    }

    @Implementation
    public View inflate(int resource, ViewGroup root) {
        return inflate(resource, root, root != null);
    }

    private ResourceLoader getResourceLoader() {
        return Robolectric.shadowOf(this.context.getApplicationContext()).getResourceLoader();
    }

    private static class LayoutInflaterAppSingletonizer extends AppSingletonizer<LayoutInflater> {
        public LayoutInflaterAppSingletonizer() {
            super(LayoutInflater.class);
        }

        /* access modifiers changed from: protected */
        public LayoutInflater get(ShadowApplication shadowApplication) {
            return shadowApplication.getLayoutInflater();
        }

        /* access modifiers changed from: protected */
        public void set(ShadowApplication shadowApplication, LayoutInflater instance) {
            shadowApplication.layoutInflater = instance;
        }

        /* access modifiers changed from: protected */
        public LayoutInflater createInstance(Application applicationContext) {
            return new MyLayoutInflater(applicationContext);
        }

        private static class MyLayoutInflater extends LayoutInflater {
            public MyLayoutInflater(Context context) {
                super(context);
            }

            public LayoutInflater cloneInContext(Context newContext) {
                return ShadowLayoutInflater.bind(new MyLayoutInflater(newContext), newContext);
            }
        }
    }
}
