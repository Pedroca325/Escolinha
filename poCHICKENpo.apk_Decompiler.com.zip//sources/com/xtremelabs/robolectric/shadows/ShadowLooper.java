package com.xtremelabs.robolectric.shadows;

import android.os.Looper;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.util.Scheduler;

@Implements(Looper.class)
public class ShadowLooper {
    private static ThreadLocal<Looper> looperForThread = makeThreadLocalLoopers();
    private Scheduler scheduler = new Scheduler();

    private static synchronized ThreadLocal<Looper> makeThreadLocalLoopers() {
        AnonymousClass1 r0;
        synchronized (ShadowLooper.class) {
            r0 = new ThreadLocal<Looper>() {
                /* access modifiers changed from: protected */
                public Looper initialValue() {
                    return (Looper) Robolectric.Reflection.newInstanceOf(Looper.class);
                }
            };
        }
        return r0;
    }

    public static void resetThreadLoopers() {
        looperForThread = makeThreadLocalLoopers();
    }

    @Implementation
    public static Looper getMainLooper() {
        return Robolectric.getShadowApplication().getMainLooper();
    }

    @Implementation
    public static synchronized Looper myLooper() {
        Looper looper;
        synchronized (ShadowLooper.class) {
            looper = looperForThread.get();
        }
        return looper;
    }

    public static void pauseLooper(Looper looper) {
        Robolectric.shadowOf(looper).pause();
    }

    public static void unPauseLooper(Looper looper) {
        Robolectric.shadowOf(looper).unPause();
    }

    public static void pauseMainLooper() {
        pauseLooper(Looper.getMainLooper());
    }

    public static void unPauseMainLooper() {
        unPauseLooper(Looper.getMainLooper());
    }

    public static void idleMainLooper(long interval) {
        Robolectric.shadowOf(Looper.getMainLooper()).idle(interval);
    }

    public void idle() {
        this.scheduler.advanceBy(0);
    }

    public void idle(long intervalMillis) {
        this.scheduler.advanceBy(intervalMillis);
    }

    public void runToEndOfTasks() {
        this.scheduler.advanceToLastPostedRunnable();
    }

    public void runToNextTask() {
        this.scheduler.advanceToNextPostedRunnable();
    }

    public void runOneTask() {
        this.scheduler.runOneTask();
    }

    public void post(Runnable runnable, long delayMillis) {
        this.scheduler.postDelayed(runnable, delayMillis);
    }

    public void postAtFrontOfQueue(Runnable runnable) {
        this.scheduler.postAtFrontOfQueue(runnable);
    }

    public void pause() {
        this.scheduler.pause();
    }

    public void unPause() {
        this.scheduler.unPause();
    }

    public void reset() {
        this.scheduler.reset();
    }

    public Scheduler getScheduler() {
        return this.scheduler;
    }
}
