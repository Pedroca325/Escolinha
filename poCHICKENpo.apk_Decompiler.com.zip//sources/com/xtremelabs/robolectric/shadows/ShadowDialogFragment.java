package com.xtremelabs.robolectric.shadows;

import android.app.Dialog;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.view.ViewGroup;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;
import com.xtremelabs.robolectric.tester.android.util.TestFragmentManager;

@Implements(DialogFragment.class)
public class ShadowDialogFragment extends ShadowFragment {
    private Dialog dialog;
    @RealObject
    private DialogFragment realDialogFragment;

    @Implementation
    public void show(FragmentManager manager, String tag) {
        TestFragmentManager testFragmentManager = (TestFragmentManager) manager;
        FragmentActivity activityFromManager = testFragmentManager.getActivity();
        Robolectric.shadowOf(this.realDialogFragment).setActivity(activityFromManager);
        this.realDialogFragment.onAttach(this.activity);
        this.realDialogFragment.onCreate((Bundle) null);
        this.dialog = this.realDialogFragment.onCreateDialog((Bundle) null);
        this.view = this.realDialogFragment.onCreateView(ShadowLayoutInflater.from(this.activity), (ViewGroup) null, (Bundle) null);
        if (this.dialog == null) {
            this.dialog = new Dialog(activityFromManager);
            this.dialog.setContentView(this.view);
        }
        testFragmentManager.addDialogFragment(tag, this.realDialogFragment);
        this.realDialogFragment.onViewCreated(this.view, (Bundle) null);
        this.realDialogFragment.onActivityCreated((Bundle) null);
        this.realDialogFragment.onStart();
        this.realDialogFragment.onResume();
    }

    @Implementation
    public void onStart() {
        if (this.dialog != null) {
            this.dialog.show();
        }
    }

    @Implementation
    public void dismiss() {
        if (this.dialog != null) {
            this.dialog.dismiss();
        }
    }

    @Implementation
    public Dialog getDialog() {
        return this.dialog;
    }
}
