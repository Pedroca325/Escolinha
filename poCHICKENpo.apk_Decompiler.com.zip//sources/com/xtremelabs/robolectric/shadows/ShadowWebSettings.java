package com.xtremelabs.robolectric.shadows;

import android.webkit.WebSettings;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;

@Implements(WebSettings.class)
public class ShadowWebSettings {
    private boolean allowFileAccess = true;
    private boolean blockNetworkImage = false;
    private boolean blockNetworkLoads = false;
    private boolean builtInZoomControls = true;
    private boolean databaseEnabled = false;
    private boolean domStorageEnabled = false;
    private boolean javaScriptEnabled = false;
    private boolean lightTouchEnabled = false;
    private boolean loadWithOverviewMode = false;
    private boolean needInitialFocus = false;
    private WebSettings.PluginState pluginState = WebSettings.PluginState.OFF;
    private boolean pluginsEnabled = false;
    private boolean supportMultipleWindows = false;
    private boolean supportZoom = true;

    @Implementation
    public boolean getAllowFileAccess() {
        return this.allowFileAccess;
    }

    @Implementation
    public void setAllowFileAccess(boolean allow) {
        this.allowFileAccess = allow;
    }

    @Implementation
    public synchronized boolean getBlockNetworkImage() {
        return this.blockNetworkImage;
    }

    @Implementation
    public synchronized void setBlockNetworkImage(boolean flag) {
        this.blockNetworkImage = flag;
    }

    @Implementation
    public synchronized boolean getBlockNetworkLoads() {
        return this.blockNetworkLoads;
    }

    @Implementation
    public synchronized void setBlockNetworkLoads(boolean flag) {
        this.blockNetworkLoads = flag;
    }

    @Implementation
    public boolean getBuiltInZoomControls() {
        return this.builtInZoomControls;
    }

    @Implementation
    public void setBuiltInZoomControls(boolean enabled) {
        this.builtInZoomControls = enabled;
    }

    @Implementation
    public synchronized boolean getDatabaseEnabled() {
        return this.databaseEnabled;
    }

    @Implementation
    public synchronized void setDatabaseEnabled(boolean flag) {
        this.databaseEnabled = flag;
    }

    @Implementation
    public synchronized boolean getDomStorageEnabled() {
        return this.domStorageEnabled;
    }

    @Implementation
    public synchronized void setDomStorageEnabled(boolean flag) {
        this.domStorageEnabled = flag;
    }

    @Implementation
    public synchronized boolean getJavaScriptEnabled() {
        return this.javaScriptEnabled;
    }

    @Implementation
    public synchronized void setJavaScriptEnabled(boolean flag) {
        this.javaScriptEnabled = flag;
    }

    @Implementation
    public boolean getLightTouchEnabled() {
        return this.lightTouchEnabled;
    }

    @Implementation
    public void setLightTouchEnabled(boolean flag) {
        this.lightTouchEnabled = flag;
    }

    @Implementation
    public boolean getLoadWithOverviewMode() {
        return this.loadWithOverviewMode;
    }

    @Implementation
    public void setLoadWithOverviewMode(boolean flag) {
        this.loadWithOverviewMode = flag;
    }

    public boolean getNeedInitialFocus() {
        return this.needInitialFocus;
    }

    @Implementation
    public void setNeedInitialFocus(boolean flag) {
        this.needInitialFocus = flag;
    }

    @Implementation
    public synchronized boolean getPluginsEnabled() {
        return this.pluginsEnabled;
    }

    @Implementation
    public synchronized void setPluginsEnabled(boolean flag) {
        this.pluginsEnabled = flag;
    }

    @Implementation
    public synchronized WebSettings.PluginState getPluginState() {
        return this.pluginState;
    }

    @Implementation
    public synchronized void setPluginState(WebSettings.PluginState state) {
        this.pluginState = state;
    }

    public boolean getSupportMultipleWindows() {
        return this.supportMultipleWindows;
    }

    @Implementation
    public synchronized void setSupportMultipleWindows(boolean support) {
        this.supportMultipleWindows = support;
    }

    public boolean getSupportZoom() {
        return this.supportZoom;
    }

    @Implementation
    public void setSupportZoom(boolean support) {
        this.supportZoom = support;
    }
}
