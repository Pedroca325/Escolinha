package com.xtremelabs.robolectric.shadows;

import android.app.PendingIntent;
import android.content.Intent;
import android.location.Criteria;
import android.location.GpsStatus;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Looper;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Implements(LocationManager.class)
public class ShadowLocationManager {
    private String bestDisabledProvider;
    private String bestEnabledProvider;
    private final ArrayList<GpsStatus.Listener> gpsStatusListeners = new ArrayList<>();
    private Criteria lastBestProviderCriteria;
    private boolean lastBestProviderEnabled;
    private final Map<String, Location> lastKnownLocations = new HashMap();
    private final Map<String, LocationProviderEntry> providersEnabled = new LinkedHashMap();
    private final Map<PendingIntent, Criteria> requestLocationUdpateCriteriaPendingIntents = new HashMap();
    private final List<LocationListener> requestLocationUdpateListeners = new ArrayList();
    private final Map<PendingIntent, String> requestLocationUdpateProviderPendingIntents = new HashMap();

    @Implementation
    public boolean isProviderEnabled(String provider) {
        LocationProviderEntry map = this.providersEnabled.get(provider);
        if (map == null) {
            return false;
        }
        Boolean isEnabled = map.getKey();
        if (isEnabled == null) {
            return true;
        }
        return isEnabled.booleanValue();
    }

    @Implementation
    public List<String> getAllProviders() {
        Set<String> allKnownProviders = new LinkedHashSet<>(this.providersEnabled.keySet());
        allKnownProviders.add("gps");
        allKnownProviders.add("network");
        allKnownProviders.add("passive");
        return new ArrayList(allKnownProviders);
    }

    public void setProviderEnabled(String provider, boolean isEnabled) {
        setProviderEnabled(provider, isEnabled, (List<Criteria>) null);
    }

    public void setProviderEnabled(String provider, boolean isEnabled, List<Criteria> criteria) {
        LocationProviderEntry providerEntry = this.providersEnabled.get(provider);
        if (providerEntry == null) {
            providerEntry = new LocationProviderEntry();
        }
        Boolean unused = providerEntry.enabled = Boolean.valueOf(isEnabled);
        List unused2 = providerEntry.criteria = criteria;
        this.providersEnabled.put(provider, providerEntry);
        for (LocationListener locationUpdateListener : this.requestLocationUdpateListeners) {
            if (isEnabled) {
                locationUpdateListener.onProviderEnabled(provider);
            } else {
                locationUpdateListener.onProviderDisabled(provider);
            }
        }
        Intent intent = new Intent();
        intent.putExtra("providerEnabled", isEnabled);
        Robolectric.getShadowApplication().sendBroadcast(intent);
        for (PendingIntent requestLocationUdpatePendingIntent : this.requestLocationUdpateCriteriaPendingIntents.keySet()) {
            try {
                requestLocationUdpatePendingIntent.send();
            } catch (PendingIntent.CanceledException e) {
                this.requestLocationUdpateCriteriaPendingIntents.remove(requestLocationUdpatePendingIntent);
            }
        }
        if (provider.equals(this.bestEnabledProvider) && !isEnabled) {
            this.bestEnabledProvider = null;
        }
    }

    @Implementation
    public List<String> getProviders(boolean enabledOnly) {
        ArrayList<String> enabledProviders = new ArrayList<>();
        for (String provider : this.providersEnabled.keySet()) {
            if (!enabledOnly || this.providersEnabled.get(provider).getKey().booleanValue()) {
                enabledProviders.add(provider);
            }
        }
        return enabledProviders;
    }

    @Implementation
    public Location getLastKnownLocation(String provider) {
        return this.lastKnownLocations.get(provider);
    }

    @Implementation
    public boolean addGpsStatusListener(GpsStatus.Listener listener) {
        if (this.gpsStatusListeners.contains(listener)) {
            return true;
        }
        this.gpsStatusListeners.add(listener);
        return true;
    }

    @Implementation
    public void removeGpsStatusListener(GpsStatus.Listener listener) {
        this.gpsStatusListeners.remove(listener);
    }

    @Implementation
    public String getBestProvider(Criteria criteria, boolean enabled) {
        this.lastBestProviderCriteria = criteria;
        this.lastBestProviderEnabled = enabled;
        if (criteria == null) {
            return getBestProviderWithNoCriteria(enabled);
        }
        return getBestProviderWithCriteria(criteria, enabled);
    }

    /* JADX WARNING: Removed duplicated region for block: B:10:0x0037  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private java.lang.String getBestProviderWithCriteria(android.location.Criteria r12, boolean r13) {
        /*
            r11 = this;
            r10 = 1
            java.util.List r8 = r11.getProviders(r13)
            int r6 = r12.getPowerRequirement()
            int r0 = r12.getAccuracy()
            java.util.Iterator r3 = r8.iterator()
        L_0x0011:
            boolean r9 = r3.hasNext()
            if (r9 == 0) goto L_0x0051
            java.lang.Object r7 = r3.next()
            java.lang.String r7 = (java.lang.String) r7
            java.util.Map<java.lang.String, com.xtremelabs.robolectric.shadows.ShadowLocationManager$LocationProviderEntry> r9 = r11.providersEnabled
            java.lang.Object r5 = r9.get(r7)
            com.xtremelabs.robolectric.shadows.ShadowLocationManager$LocationProviderEntry r5 = (com.xtremelabs.robolectric.shadows.ShadowLocationManager.LocationProviderEntry) r5
            if (r5 == 0) goto L_0x0011
            java.util.List r1 = r5.getValue()
            if (r1 == 0) goto L_0x0011
            java.util.Iterator r4 = r1.iterator()
        L_0x0031:
            boolean r9 = r4.hasNext()
            if (r9 == 0) goto L_0x0011
            java.lang.Object r2 = r4.next()
            android.location.Criteria r2 = (android.location.Criteria) r2
            boolean r9 = r12.equals(r2)
            if (r9 == 0) goto L_0x0044
        L_0x0043:
            return r7
        L_0x0044:
            int r9 = r2.getAccuracy()
            if (r9 == r0) goto L_0x0043
            int r9 = r2.getPowerRequirement()
            if (r9 != r6) goto L_0x0031
            goto L_0x0043
        L_0x0051:
            java.util.Iterator r3 = r8.iterator()
        L_0x0055:
            boolean r9 = r3.hasNext()
            if (r9 == 0) goto L_0x007b
            java.lang.Object r7 = r3.next()
            java.lang.String r7 = (java.lang.String) r7
            java.lang.String r9 = "network"
            boolean r9 = r7.equals(r9)
            if (r9 == 0) goto L_0x006e
            r9 = 2
            if (r0 == r9) goto L_0x0043
            if (r6 == r10) goto L_0x0043
        L_0x006e:
            java.lang.String r9 = "gps"
            boolean r9 = r7.equals(r9)
            if (r9 == 0) goto L_0x0055
            if (r0 != r10) goto L_0x0055
            if (r6 == r10) goto L_0x0055
            goto L_0x0043
        L_0x007b:
            boolean r9 = r8.isEmpty()
            if (r9 == 0) goto L_0x0084
            r9 = 0
        L_0x0082:
            r7 = r9
            goto L_0x0043
        L_0x0084:
            r9 = 0
            java.lang.Object r9 = r8.get(r9)
            java.lang.String r9 = (java.lang.String) r9
            goto L_0x0082
        */
        throw new UnsupportedOperationException("Method not decompiled: com.xtremelabs.robolectric.shadows.ShadowLocationManager.getBestProviderWithCriteria(android.location.Criteria, boolean):java.lang.String");
    }

    private String getBestProviderWithNoCriteria(boolean enabled) {
        List<String> providers = getProviders(enabled);
        if (enabled && this.bestEnabledProvider != null) {
            return this.bestEnabledProvider;
        }
        if (this.bestDisabledProvider != null) {
            return this.bestDisabledProvider;
        }
        if (providers.contains("gps")) {
            return "gps";
        }
        if (providers.contains("network")) {
            return "network";
        }
        return null;
    }

    @Implementation
    public void requestLocationUpdates(String provider, long minTime, float minDistance, LocationListener listener) {
        this.requestLocationUdpateListeners.add(listener);
    }

    @Implementation
    public void requestLocationUpdates(String provider, long minTime, float minDistance, LocationListener listener, Looper looper) {
        this.requestLocationUdpateListeners.add(listener);
    }

    @Implementation
    public void requestLocationUpdates(long minTime, float minDistance, Criteria criteria, PendingIntent pendingIntent) {
        if (pendingIntent == null) {
            throw new IllegalStateException("Intent must not be null");
        } else if (getBestProvider(criteria, true) == null) {
            throw new IllegalArgumentException("no providers found for criteria");
        } else {
            this.requestLocationUdpateCriteriaPendingIntents.put(pendingIntent, criteria);
        }
    }

    @Implementation
    public void requestLocationUpdates(String provider, long minTime, float minDistance, PendingIntent pendingIntent) {
        if (pendingIntent == null) {
            throw new IllegalStateException("Intent must not be null");
        } else if (!this.providersEnabled.containsKey(provider)) {
            throw new IllegalArgumentException("no providers found");
        } else {
            this.requestLocationUdpateProviderPendingIntents.put(pendingIntent, provider);
        }
    }

    @Implementation
    public void removeUpdates(LocationListener listener) {
        do {
        } while (this.requestLocationUdpateListeners.remove(listener));
    }

    @Implementation
    public void removeUpdates(PendingIntent pendingIntent) {
        do {
        } while (this.requestLocationUdpateCriteriaPendingIntents.remove(pendingIntent) != null);
        do {
        } while (this.requestLocationUdpateProviderPendingIntents.remove(pendingIntent) != null);
    }

    public boolean hasGpsStatusListener(GpsStatus.Listener listener) {
        return this.gpsStatusListeners.contains(listener);
    }

    public Criteria getLastBestProviderCriteria() {
        return this.lastBestProviderCriteria;
    }

    public boolean getLastBestProviderEnabledOnly() {
        return this.lastBestProviderEnabled;
    }

    public boolean setBestProvider(String provider, boolean enabled, List<Criteria> criteria) throws Exception {
        LocationProviderEntry entry;
        if (!getAllProviders().contains(provider)) {
            throw new IllegalStateException("Best provider is not a known provider");
        }
        for (String prvdr : this.providersEnabled.keySet()) {
            if (provider.equals(prvdr) && this.providersEnabled.get(prvdr).enabled.booleanValue() != enabled) {
                return false;
            }
        }
        if (enabled) {
            this.bestEnabledProvider = provider;
            if (provider.equals(this.bestDisabledProvider)) {
                this.bestDisabledProvider = null;
            }
        } else {
            this.bestDisabledProvider = provider;
            if (provider.equals(this.bestEnabledProvider)) {
                this.bestEnabledProvider = null;
            }
        }
        if (criteria == null) {
            return true;
        }
        if (!this.providersEnabled.containsKey(provider)) {
            entry = new LocationProviderEntry();
            Boolean unused = entry.enabled = Boolean.valueOf(enabled);
            List unused2 = entry.criteria = criteria;
        } else {
            entry = this.providersEnabled.get(provider);
        }
        this.providersEnabled.put(provider, entry);
        return true;
    }

    public boolean setBestProvider(String provider, boolean enabled) throws Exception {
        return setBestProvider(provider, enabled, (List<Criteria>) null);
    }

    public void setLastKnownLocation(String provider, Location location) {
        this.lastKnownLocations.put(provider, location);
    }

    public List<LocationListener> getRequestLocationUpdateListeners() {
        return this.requestLocationUdpateListeners;
    }

    public Map<PendingIntent, Criteria> getRequestLocationUdpateCriteriaPendingIntents() {
        return this.requestLocationUdpateCriteriaPendingIntents;
    }

    public Map<PendingIntent, String> getRequestLocationUdpateProviderPendingIntents() {
        return this.requestLocationUdpateProviderPendingIntents;
    }

    private final class LocationProviderEntry implements Map.Entry<Boolean, List<Criteria>> {
        /* access modifiers changed from: private */
        public List<Criteria> criteria;
        /* access modifiers changed from: private */
        public Boolean enabled;

        private LocationProviderEntry() {
        }

        public Boolean getKey() {
            return this.enabled;
        }

        public List<Criteria> getValue() {
            return this.criteria;
        }

        public List<Criteria> setValue(List<Criteria> criteria2) {
            List<Criteria> oldCriteria = this.criteria;
            this.criteria = criteria2;
            return oldCriteria;
        }
    }
}
