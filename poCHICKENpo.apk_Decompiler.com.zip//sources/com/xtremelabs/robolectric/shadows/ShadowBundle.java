package com.xtremelabs.robolectric.shadows;

import android.os.Bundle;
import android.os.Parcelable;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

@Implements(Bundle.class)
public class ShadowBundle {
    Map<String, Object> map = new HashMap();

    @Implementation
    public Object get(String key) {
        return this.map.get(key);
    }

    @Implementation
    public void putString(String key, String value) {
        this.map.put(key, value);
    }

    @Implementation
    public String getString(String key) {
        return (String) this.map.get(key);
    }

    @Implementation
    public void putLong(String key, long value) {
        this.map.put(key, Long.valueOf(value));
    }

    @Implementation
    public long getLong(String key) {
        Object value = this.map.get(key);
        if (value == null) {
            return 0;
        }
        return ((Long) value).longValue();
    }

    @Implementation
    public long getLong(String key, long defaultValue) {
        Object value = this.map.get(key);
        return value == null ? defaultValue : ((Long) value).longValue();
    }

    @Implementation
    public void putInt(String key, int value) {
        this.map.put(key, Integer.valueOf(value));
    }

    @Implementation
    public int getInt(String key) {
        Object value = this.map.get(key);
        if (value == null) {
            return 0;
        }
        return ((Integer) value).intValue();
    }

    @Implementation
    public int getInt(String key, int defaultValue) {
        Object value = this.map.get(key);
        return value == null ? defaultValue : ((Integer) value).intValue();
    }

    @Implementation
    public void putDouble(String key, double value) {
        this.map.put(key, Double.valueOf(value));
    }

    @Implementation
    public double getDouble(String key) {
        Object value = this.map.get(key);
        if (value == null) {
            return 0.0d;
        }
        return ((Double) value).doubleValue();
    }

    @Implementation
    public double getDouble(String key, double defaultValue) {
        Object value = this.map.get(key);
        return value == null ? defaultValue : ((Double) value).doubleValue();
    }

    @Implementation
    public void putBoolean(String key, boolean value) {
        this.map.put(key, Boolean.valueOf(value));
    }

    @Implementation
    public boolean getBoolean(String key) {
        Object value = this.map.get(key);
        if (value == null) {
            return false;
        }
        return ((Boolean) value).booleanValue();
    }

    @Implementation
    public boolean getBoolean(String key, boolean defaultValue) {
        Object value = this.map.get(key);
        return value == null ? defaultValue : ((Boolean) value).booleanValue();
    }

    @Implementation
    public void putFloat(String key, float value) {
        this.map.put(key, Float.valueOf(value));
    }

    @Implementation
    public float getFloat(String key) {
        Object value = this.map.get(key);
        if (value == null) {
            return 0.0f;
        }
        return ((Float) value).floatValue();
    }

    @Implementation
    public float getFloat(String key, float defaultValue) {
        Object value = this.map.get(key);
        return value == null ? defaultValue : ((Float) value).floatValue();
    }

    @Implementation
    public void putSerializable(String key, Serializable value) {
        this.map.put(key, value);
    }

    @Implementation
    public Serializable getSerializable(String key) {
        return (Serializable) this.map.get(key);
    }

    @Implementation
    public void putParcelable(String key, Parcelable value) {
        this.map.put(key, value);
    }

    @Implementation
    public void putParcelableArrayList(String key, ArrayList<? extends Parcelable> value) {
        this.map.put(key, value);
    }

    @Implementation
    public Parcelable getParcelable(String key) {
        return (Parcelable) this.map.get(key);
    }

    @Implementation
    public ArrayList<Parcelable> getParcelableArrayList(String key) {
        return (ArrayList) this.map.get(key);
    }

    @Implementation
    public void putStringArrayList(String key, ArrayList<String> value) {
        this.map.put(key, value);
    }

    @Implementation
    public ArrayList<String> getStringArrayList(String key) {
        return (ArrayList) this.map.get(key);
    }

    @Implementation
    public void putIntegerArrayList(String key, ArrayList<Integer> value) {
        this.map.put(key, value);
    }

    @Implementation
    public ArrayList<Integer> getIntegerArrayList(String key) {
        return (ArrayList) this.map.get(key);
    }

    @Implementation
    public void putAll(Bundle bundle) {
        this.map.putAll(((ShadowBundle) Robolectric.shadowOf_(bundle)).map);
    }

    @Implementation
    public void putStringArray(String key, String[] value) {
        this.map.put(key, value);
    }

    @Implementation
    public String[] getStringArray(String key) {
        return (String[]) this.map.get(key);
    }

    @Implementation
    public boolean containsKey(String key) {
        return this.map.containsKey(key);
    }

    @Implementation
    public boolean isEmpty() {
        return this.map.isEmpty();
    }

    @Implementation
    public Set<String> keySet() {
        return this.map.keySet();
    }

    @Implementation
    public boolean equals(Object o) {
        Object o2;
        if (o == null || (o2 = Robolectric.shadowOf_(o)) == null) {
            return false;
        }
        if (this == o2) {
            return true;
        }
        if (getClass() != o2.getClass()) {
            return false;
        }
        ShadowBundle that = (ShadowBundle) o2;
        if (this.map != null) {
            if (!this.map.equals(that.map)) {
                return false;
            }
        } else if (that.map != null) {
            return false;
        }
        return true;
    }

    @Implementation
    public int hashCode() {
        if (this.map != null) {
            return this.map.hashCode();
        }
        return 0;
    }
}
