package com.xtremelabs.robolectric.shadows;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewStub;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;
import java.lang.ref.WeakReference;

@Implements(ViewStub.class)
public class ShadowViewStub extends ShadowView {
    private ViewStub.OnInflateListener mInflateListener;
    private int mInflatedId;
    private WeakReference<View> mInflatedViewRef;
    private int mLayoutResource = 0;
    @RealObject
    ViewStub viewStub;

    public void applyAttributes() {
        super.applyAttributes();
        String inflatedId = this.attributeSet.getAttributeValue("android", "inflatedId");
        if (inflatedId != null) {
            this.mInflatedId = getResourceId(inflatedId).intValue();
        }
        String layoutResId = this.attributeSet.getAttributeValue("android", "layout");
        if (layoutResId != null) {
            this.mLayoutResource = getResourceId(layoutResId).intValue();
        }
    }

    private Integer getResourceId(String inflatedId) {
        return Robolectric.getShadowApplication().getResourceLoader().getResourceExtractor().getResourceId(inflatedId, false);
    }

    @Implementation
    public int getInflatedId() {
        return this.mInflatedId;
    }

    @Implementation
    public void setInflatedId(int inflatedId) {
        this.mInflatedId = inflatedId;
    }

    @Implementation
    public int getLayoutResource() {
        return this.mLayoutResource;
    }

    @Implementation
    public void setLayoutResource(int layoutResource) {
        this.mLayoutResource = layoutResource;
    }

    @Implementation
    public View inflate() {
        ViewParent viewParent = this.viewStub.getParent();
        if (viewParent == null || !(viewParent instanceof ViewGroup)) {
            throw new IllegalStateException("ViewStub must have a non-null ViewGroup viewParent");
        } else if (this.mLayoutResource != 0) {
            ViewGroup parent = (ViewGroup) viewParent;
            View view = LayoutInflater.from(this.viewStub.getContext()).inflate(this.mLayoutResource, parent, false);
            if (this.mInflatedId != -1) {
                view.setId(this.mInflatedId);
            }
            int index = parent.indexOfChild(this.viewStub);
            parent.removeViewAt(index);
            ViewGroup.LayoutParams layoutParams = getLayoutParams();
            if (layoutParams != null) {
                parent.addView(view, index, layoutParams);
            } else {
                parent.addView(view, index);
            }
            this.mInflatedViewRef = new WeakReference<>(view);
            if (this.mInflateListener != null) {
                this.mInflateListener.onInflate(this.viewStub, view);
            }
            return view;
        } else {
            throw new IllegalArgumentException("ViewStub must have a valid layoutResource");
        }
    }
}
