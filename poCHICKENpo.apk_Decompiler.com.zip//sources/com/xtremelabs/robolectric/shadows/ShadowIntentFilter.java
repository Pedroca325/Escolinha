package com.xtremelabs.robolectric.shadows;

import android.content.IntentFilter;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Implements(IntentFilter.class)
public class ShadowIntentFilter {
    List<String> actions = new ArrayList();
    List<IntentFilter.AuthorityEntry> authoritites = new ArrayList();
    List<String> schemes = new ArrayList();

    public void __constructor__(String action) {
        this.actions.add(action);
    }

    @Implementation
    public void addAction(String action) {
        this.actions.add(action);
    }

    @Implementation
    public String getAction(int index) {
        return this.actions.get(index);
    }

    @Implementation
    public int countActions() {
        return this.actions.size();
    }

    @Implementation
    public Iterator<String> actionsIterator() {
        return this.actions.iterator();
    }

    @Implementation
    public boolean matchAction(String action) {
        return this.actions.contains(action);
    }

    @Implementation
    public void addDataAuthority(String host, String port) {
        this.authoritites.add(new IntentFilter.AuthorityEntry(host, port));
    }

    @Implementation
    public final IntentFilter.AuthorityEntry getDataAuthority(int index) {
        return this.authoritites.get(index);
    }

    @Implementation
    public void addDataScheme(String scheme) {
        this.schemes.add(scheme);
    }

    @Implementation
    public String getDataScheme(int index) {
        return this.schemes.get(index);
    }
}
