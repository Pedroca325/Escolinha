package com.xtremelabs.robolectric.shadows;

import org.apache.http.ProtocolVersion;
import org.apache.http.StatusLine;

public class StatusLineStub implements StatusLine {
    public ProtocolVersion getProtocolVersion() {
        throw new UnsupportedOperationException();
    }

    public int getStatusCode() {
        throw new UnsupportedOperationException();
    }

    public String getReasonPhrase() {
        throw new UnsupportedOperationException();
    }
}
