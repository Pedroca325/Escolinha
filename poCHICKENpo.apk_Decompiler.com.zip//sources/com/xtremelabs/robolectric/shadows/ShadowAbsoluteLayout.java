package com.xtremelabs.robolectric.shadows;

import android.widget.AbsoluteLayout;
import com.xtremelabs.robolectric.internal.Implements;

@Implements(AbsoluteLayout.class)
public class ShadowAbsoluteLayout extends ShadowViewGroup {
}
