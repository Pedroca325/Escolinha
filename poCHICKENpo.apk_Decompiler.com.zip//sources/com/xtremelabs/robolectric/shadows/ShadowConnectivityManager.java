package com.xtremelabs.robolectric.shadows;

import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import java.util.HashMap;
import java.util.Map;

@Implements(ConnectivityManager.class)
public class ShadowConnectivityManager {
    private NetworkInfo activeNetwork;
    private boolean backgroundDataSetting;
    private NetworkInfo[] networkInfo;
    private Map<Integer, NetworkInfo> networkTypeToNetworkInfo = new HashMap();

    @Implementation
    public NetworkInfo getActiveNetworkInfo() {
        if (this.activeNetwork != null) {
            return this.activeNetwork;
        }
        NetworkInfo networkInfo2 = (NetworkInfo) Robolectric.newInstanceOf(NetworkInfo.class);
        this.activeNetwork = networkInfo2;
        return networkInfo2;
    }

    @Implementation
    public NetworkInfo[] getAllNetworkInfo() {
        if (this.networkInfo != null) {
            return this.networkInfo;
        }
        NetworkInfo[] networkInfoArr = {getActiveNetworkInfo()};
        this.networkInfo = networkInfoArr;
        return networkInfoArr;
    }

    @Implementation
    public NetworkInfo getNetworkInfo(int networkType) {
        return this.networkTypeToNetworkInfo.get(Integer.valueOf(networkType));
    }

    public void setNetworkInfo(int networkType, NetworkInfo networkInfo2) {
        this.networkTypeToNetworkInfo.put(Integer.valueOf(networkType), networkInfo2);
    }

    @Implementation
    public boolean getBackgroundDataSetting() {
        return this.backgroundDataSetting;
    }

    public void setBackgroundDataSetting(boolean b) {
        this.backgroundDataSetting = b;
    }
}
