package com.xtremelabs.robolectric.shadows;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.internal.RealObject;
import com.xtremelabs.robolectric.util.Join;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

@Implements(Intent.class)
public class ShadowIntent {
    private String action;
    private Set<String> categories = new HashSet();
    private ComponentName componentName;
    private Uri data;
    private HashMap<String, Object> extras = new HashMap<>();
    private int flags;
    private Class<?> intentClass;
    private String packageName;
    @RealObject
    private Intent realIntent;
    private String type;
    private String uri;

    public void __constructor__(Context packageContext, Class cls) {
        this.componentName = new ComponentName(packageContext, cls);
        this.intentClass = cls;
    }

    public void __constructor__(String action2, Uri uri2) {
        this.action = action2;
        this.data = uri2;
    }

    public void __constructor__(String action2) {
        __constructor__(action2, (Uri) null);
    }

    public void __constructor__(Intent intent) {
        ShadowIntent other = Robolectric.shadowOf(intent);
        this.extras.putAll(other.extras);
        this.action = other.action;
        this.componentName = other.componentName;
        this.type = other.type;
        this.data = other.data;
        this.flags = other.flags;
        this.intentClass = other.intentClass;
        this.packageName = other.packageName;
        this.categories.addAll(other.categories);
        this.uri = other.uri;
    }

    @Implementation
    public static Intent createChooser(Intent target, CharSequence title) {
        Intent intent = new Intent("android.intent.action.CHOOSER");
        intent.putExtra("android.intent.extra.INTENT", target);
        if (title != null) {
            intent.putExtra("android.intent.extra.TITLE", title);
        }
        return intent;
    }

    @Implementation
    public Intent setAction(String action2) {
        this.action = action2;
        return this.realIntent;
    }

    @Implementation
    public String getAction() {
        return this.action;
    }

    @Implementation
    public Intent setType(String type2) {
        this.type = type2;
        return this.realIntent;
    }

    @Implementation
    public String getType() {
        return this.type;
    }

    @Implementation
    public Intent addCategory(String category) {
        this.categories.add(category);
        return this.realIntent;
    }

    @Implementation
    public void removeCategory(String category) {
        this.categories.remove(category);
    }

    @Implementation
    public boolean hasCategory(String category) {
        return this.categories.contains(category);
    }

    @Implementation
    public Set<String> getCategories() {
        return this.categories;
    }

    @Implementation
    public Intent setPackage(String packageName2) {
        this.packageName = packageName2;
        return this.realIntent;
    }

    @Implementation
    public String getPackage() {
        return this.packageName;
    }

    @Implementation
    public Uri getData() {
        return this.data;
    }

    @Implementation
    public Intent setClass(Context packageContext, Class<?> cls) {
        this.intentClass = cls;
        return this.realIntent;
    }

    @Implementation
    public Intent setClassName(String packageName2, String className) {
        this.componentName = new ComponentName(packageName2, className);
        try {
            this.intentClass = Class.forName(className);
        } catch (ClassNotFoundException e) {
        }
        return this.realIntent;
    }

    @Implementation
    public Intent setClassName(Context packageContext, String className) {
        this.componentName = new ComponentName(packageContext.getPackageName(), className);
        return this.realIntent;
    }

    @Implementation
    public Intent setData(Uri data2) {
        this.data = data2;
        return this.realIntent;
    }

    @Implementation
    public int getFlags() {
        return this.flags;
    }

    @Implementation
    public Intent setFlags(int flags2) {
        this.flags = flags2;
        return this.realIntent;
    }

    @Implementation
    public Intent addFlags(int flags2) {
        this.flags |= flags2;
        return this.realIntent;
    }

    @Implementation
    public Intent putExtras(Bundle src) {
        this.extras = new HashMap<>(((ShadowBundle) Robolectric.shadowOf_(src)).map);
        return this.realIntent;
    }

    @Implementation
    public Intent putExtras(Intent src) {
        this.extras = new HashMap<>(Robolectric.shadowOf(src).extras);
        return this.realIntent;
    }

    @Implementation
    public Bundle getExtras() {
        Bundle bundle = new Bundle();
        ((ShadowBundle) Robolectric.shadowOf_(bundle)).map.putAll(this.extras);
        return bundle;
    }

    @Implementation
    public Intent putExtra(String key, int value) {
        this.extras.put(key, Integer.valueOf(value));
        return this.realIntent;
    }

    @Implementation
    public Intent putExtra(String key, double value) {
        this.extras.put(key, Double.valueOf(value));
        return this.realIntent;
    }

    @Implementation
    public Intent putExtra(String key, float value) {
        this.extras.put(key, Float.valueOf(value));
        return this.realIntent;
    }

    @Implementation
    public Intent putExtra(String key, long value) {
        this.extras.put(key, Long.valueOf(value));
        return this.realIntent;
    }

    @Implementation
    public Intent putExtra(String key, Serializable value) {
        this.extras.put(key, serializeCycle(value));
        return this.realIntent;
    }

    @Implementation
    public Intent putExtra(String key, Parcelable value) {
        this.extras.put(key, value);
        return this.realIntent;
    }

    @Implementation
    public Intent putExtra(String key, Parcelable[] value) {
        this.extras.put(key, value);
        return this.realIntent;
    }

    @Implementation
    public Intent putExtra(String key, String value) {
        this.extras.put(key, value);
        return this.realIntent;
    }

    @Implementation
    public Intent putExtra(String key, String[] value) {
        this.extras.put(key, value);
        return this.realIntent;
    }

    @Implementation
    public Intent putExtra(String key, boolean value) {
        this.extras.put(key, Boolean.valueOf(value));
        return this.realIntent;
    }

    @Implementation
    public Intent putExtra(String key, int[] value) {
        this.extras.put(key, value);
        return this.realIntent;
    }

    @Implementation
    public Intent putExtra(String key, long[] value) {
        this.extras.put(key, value);
        return this.realIntent;
    }

    @Implementation
    public int[] getIntArrayExtra(String name) {
        return (int[]) this.extras.get(name);
    }

    @Implementation
    public long[] getLongArrayExtra(String name) {
        return (long[]) this.extras.get(name);
    }

    @Implementation
    public boolean getBooleanExtra(String name, boolean defaultValue) {
        return this.extras.containsKey(name) ? ((Boolean) this.extras.get(name)).booleanValue() : defaultValue;
    }

    @Implementation
    public String[] getStringArrayExtra(String name) {
        return (String[]) this.extras.get(name);
    }

    @Implementation
    public Intent putExtra(String key, CharSequence value) {
        this.extras.put(key, value);
        return this.realIntent;
    }

    @Implementation
    public CharSequence getCharSequenceExtra(String name) {
        return (CharSequence) this.extras.get(name);
    }

    @Implementation
    public void putExtra(String key, byte[] value) {
        this.extras.put(key, value);
    }

    @Implementation
    public Intent putStringArrayListExtra(String key, ArrayList<String> value) {
        this.extras.put(key, value);
        return this.realIntent;
    }

    @Implementation
    public ArrayList<String> getStringArrayListExtra(String name) {
        return (ArrayList) this.extras.get(name);
    }

    @Implementation
    public Intent putIntegerArrayListExtra(String key, ArrayList<Integer> value) {
        this.extras.put(key, value);
        return this.realIntent;
    }

    @Implementation
    public ArrayList<Integer> getIntegerArrayListExtra(String name) {
        return (ArrayList) this.extras.get(name);
    }

    @Implementation
    public Intent putParcelableArrayListExtra(String key, ArrayList<Parcelable> value) {
        this.extras.put(key, value);
        return this.realIntent;
    }

    @Implementation
    public ArrayList<Parcelable> getParcelableArrayListExtra(String key) {
        return (ArrayList) this.extras.get(key);
    }

    @Implementation
    public boolean hasExtra(String name) {
        return this.extras.containsKey(name);
    }

    @Implementation
    public String getStringExtra(String name) {
        return (String) this.extras.get(name);
    }

    @Implementation
    public Parcelable getParcelableExtra(String name) {
        return (Parcelable) this.extras.get(name);
    }

    @Implementation
    public Parcelable[] getParcelableArrayExtra(String name) {
        if (this.extras.get(name) instanceof Parcelable[]) {
            return (Parcelable[]) this.extras.get(name);
        }
        return null;
    }

    @Implementation
    public int getIntExtra(String name, int defaultValue) {
        Integer foundValue = (Integer) this.extras.get(name);
        return foundValue == null ? defaultValue : foundValue.intValue();
    }

    @Implementation
    public long getLongExtra(String name, long defaultValue) {
        Long foundValue = (Long) this.extras.get(name);
        return foundValue == null ? defaultValue : foundValue.longValue();
    }

    @Implementation
    public double getDoubleExtra(String name, double defaultValue) {
        Double foundValue = (Double) this.extras.get(name);
        return foundValue == null ? defaultValue : foundValue.doubleValue();
    }

    @Implementation
    public float getFloatExtra(String name, float defaultValue) {
        Float foundValue = (Float) this.extras.get(name);
        return foundValue == null ? defaultValue : foundValue.floatValue();
    }

    @Implementation
    public byte[] getByteArrayExtra(String name) {
        return (byte[]) this.extras.get(name);
    }

    @Implementation
    public Serializable getSerializableExtra(String name) {
        return (Serializable) this.extras.get(name);
    }

    @Implementation
    public void removeExtra(String name) {
        this.extras.remove(name);
    }

    @Implementation
    public Intent setComponent(ComponentName componentName2) {
        this.componentName = componentName2;
        return this.realIntent;
    }

    @Implementation
    public ComponentName getComponent() {
        return this.componentName;
    }

    @Implementation
    public String toURI() {
        return this.uri;
    }

    @Implementation
    public int fillIn(Intent otherIntent, int flags2) {
        int changes = 0;
        ShadowIntent other = Robolectric.shadowOf(otherIntent);
        if (other.action != null && (this.action == null || (flags2 & 1) != 0)) {
            this.action = other.action;
            changes = 0 | 1;
        }
        if (!(other.data == null && other.type == null) && ((this.data == null && this.type == null) || (flags2 & 2) != 0)) {
            this.data = other.data;
            this.type = other.type;
            changes |= 2;
        }
        if (!other.categories.isEmpty() && (this.categories.isEmpty() || (flags2 & 4) != 0)) {
            this.categories.addAll(other.categories);
            changes |= 4;
        }
        if (other.packageName != null && (this.packageName == null || (flags2 & 16) != 0)) {
            this.packageName = other.packageName;
            changes |= 16;
        }
        if (!(other.componentName == null || (flags2 & 8) == 0)) {
            this.componentName = other.componentName;
            changes |= 8;
        }
        this.extras.putAll(other.extras);
        return changes;
    }

    @Implementation
    public boolean filterEquals(Intent other) {
        if (other == null) {
            return false;
        }
        if (getAction() != other.getAction()) {
            if (getAction() != null) {
                if (!getAction().equals(other.getAction())) {
                    return false;
                }
            } else if (!other.getAction().equals(getAction())) {
                return false;
            }
        }
        if (getData() != other.getData()) {
            if (getData() != null) {
                if (!getData().equals(other.getData())) {
                    return false;
                }
            } else if (!other.getData().equals(getData())) {
                return false;
            }
        }
        if (getType() != other.getType()) {
            if (getType() != null) {
                if (!getType().equals(other.getType())) {
                    return false;
                }
            } else if (!other.getType().equals(getType())) {
                return false;
            }
        }
        if (getPackage() != other.getPackage()) {
            if (getPackage() != null) {
                if (!getPackage().equals(other.getPackage())) {
                    return false;
                }
            } else if (!other.getPackage().equals(getPackage())) {
                return false;
            }
        }
        if (getComponent() != other.getComponent()) {
            if (getComponent() != null) {
                if (!getComponent().equals(other.getComponent())) {
                    return false;
                }
            } else if (!other.getComponent().equals(getComponent())) {
                return false;
            }
        }
        if (getCategories() != other.getCategories()) {
            if (getCategories() != null) {
                if (getCategories().equals(other.getCategories())) {
                    return true;
                }
                return false;
            } else if (!other.getCategories().equals(getCategories())) {
                return false;
            }
        }
        return true;
    }

    @Deprecated
    public boolean realIntentEquals(ShadowIntent o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        if (this.action == null ? o.action != null : !this.action.equals(o.action)) {
            return false;
        }
        if (this.componentName == null ? o.componentName != null : !this.componentName.equals(o.componentName)) {
            return false;
        }
        if (this.data == null ? o.data != null : !this.data.equals(o.data)) {
            return false;
        }
        if (this.extras == null ? o.extras != null : !this.extras.equals(o.extras)) {
            return false;
        }
        if (this.type == null ? o.type != null : !this.type.equals(o.type)) {
            return false;
        }
        if (this.categories != null) {
            if (this.categories.equals(o.categories)) {
                return true;
            }
        } else if (o.categories == null) {
            return true;
        }
        return false;
    }

    @Implementation
    public int hashCode() {
        int result;
        int i;
        int i2;
        int i3;
        int i4 = 0;
        if (this.extras != null) {
            result = this.extras.hashCode();
        } else {
            result = 0;
        }
        int i5 = result * 31;
        if (this.action != null) {
            i = this.action.hashCode();
        } else {
            i = 0;
        }
        int i6 = (i5 + i) * 31;
        if (this.componentName != null) {
            i2 = this.componentName.hashCode();
        } else {
            i2 = 0;
        }
        int i7 = (i6 + i2) * 31;
        if (this.data != null) {
            i3 = this.data.hashCode();
        } else {
            i3 = 0;
        }
        int i8 = (i7 + i3) * 31;
        if (this.type != null) {
            i4 = this.type.hashCode();
        }
        return ((i8 + i4) * 31) + this.flags;
    }

    @Implementation
    public boolean equals(Object o) {
        if (!(o instanceof Intent)) {
            return false;
        }
        return realIntentEquals(Robolectric.shadowOf((Intent) o));
    }

    public Class<?> getIntentClass() {
        return this.intentClass;
    }

    @Implementation
    public String toString() {
        return "Intent{" + Join.join(", ", ifWeHave(this.componentName, "componentName"), ifWeHave(this.action, "action"), ifWeHave(this.extras, "extras"), ifWeHave(this.data, "data"), ifWeHave(this.type, "type")) + '}';
    }

    private Serializable serializeCycle(Serializable serializable) {
        try {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            ObjectOutputStream output = new ObjectOutputStream(byteArrayOutputStream);
            output.writeObject(serializable);
            output.close();
            return (Serializable) new ObjectInputStream(new ByteArrayInputStream(byteArrayOutputStream.toByteArray())).readObject();
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e2) {
            throw new RuntimeException(e2);
        }
    }

    private String ifWeHave(Object o, String name) {
        if (o == null) {
            return null;
        }
        if (!(o instanceof Map) || !((Map) o).isEmpty()) {
            return name + "=" + o;
        }
        return null;
    }

    public void setURI(String uri2) {
        this.uri = uri2;
    }
}
