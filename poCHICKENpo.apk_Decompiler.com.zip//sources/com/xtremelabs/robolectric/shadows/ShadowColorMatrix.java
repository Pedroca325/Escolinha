package com.xtremelabs.robolectric.shadows;

import android.graphics.ColorMatrix;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.util.Join;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@Implements(ColorMatrix.class)
public class ShadowColorMatrix {
    private float[] src;

    public void __constructor__(float[] src2) {
        this.src = src2;
    }

    public void __constructor__() {
        reset();
    }

    public void __constructor__(ColorMatrix src2) {
        this.src = Robolectric.shadowOf(src2).src;
    }

    @Implementation
    public void reset() {
        this.src = new float[20];
        float[] fArr = this.src;
        float[] fArr2 = this.src;
        float[] fArr3 = this.src;
        this.src[18] = 1.0f;
        fArr3[12] = 1.0f;
        fArr2[6] = 1.0f;
        fArr[0] = 1.0f;
    }

    @Implementation
    public void setSaturation(float sat) {
        reset();
        float[] m = this.src;
        float invSat = 1.0f - sat;
        float R = 0.213f * invSat;
        float G = 0.715f * invSat;
        float B = 0.072f * invSat;
        m[0] = R + sat;
        m[1] = G;
        m[2] = B;
        m[5] = R;
        m[6] = G + sat;
        m[7] = B;
        m[10] = R;
        m[11] = G;
        m[12] = B + sat;
    }

    @Implementation
    public String toString() {
        List<String> floats = new ArrayList<>();
        float[] arr$ = this.src;
        int len$ = arr$.length;
        for (int i$ = 0; i$ < len$; i$++) {
            floats.add(String.format("%.2f", new Object[]{Float.valueOf(arr$[i$])}).replace(".00", ""));
        }
        return Join.join(",", (Collection) floats);
    }
}
