package com.xtremelabs.robolectric.tester.android.view;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;
import java.util.ArrayList;
import java.util.List;

public class TestMenu implements Menu {
    private Context context;
    private List<MenuItem> menuItems;

    public TestMenu() {
        this((Context) null);
    }

    public TestMenu(Context context2) {
        this.menuItems = new ArrayList();
        this.context = context2;
    }

    public MenuItem add(CharSequence title) {
        return add(0, 0, 0, title);
    }

    public MenuItem add(int titleRes) {
        return add(0, 0, 0, titleRes);
    }

    public MenuItem add(int groupId, int itemId, int order, CharSequence title) {
        TestMenuItem menuItem = new TestMenuItem();
        this.menuItems.add(menuItem);
        menuItem.setItemId(itemId);
        menuItem.setTitle(title);
        return menuItem;
    }

    public MenuItem add(int groupId, int itemId, int order, int titleRes) {
        return add(groupId, itemId, order, (CharSequence) this.context.getResources().getString(titleRes));
    }

    public SubMenu addSubMenu(CharSequence title) {
        TestSubMenu tsm = new TestSubMenu();
        TestMenuItem menuItem = new TestMenuItem();
        this.menuItems.add(menuItem);
        menuItem.setTitle(title);
        menuItem.setSubMenu(tsm);
        return tsm;
    }

    public SubMenu addSubMenu(int titleRes) {
        TestSubMenu tsm = new TestSubMenu();
        TestMenuItem menuItem = new TestMenuItem();
        this.menuItems.add(menuItem);
        menuItem.setTitle(titleRes);
        menuItem.setSubMenu(tsm);
        return tsm;
    }

    public SubMenu addSubMenu(int groupId, int itemId, int order, CharSequence title) {
        TestSubMenu tsm = new TestSubMenu();
        TestMenuItem menuItem = new TestMenuItem();
        this.menuItems.add(menuItem);
        menuItem.setItemId(itemId);
        menuItem.setTitle(title);
        menuItem.setSubMenu(tsm);
        return tsm;
    }

    public SubMenu addSubMenu(int groupId, int itemId, int order, int titleRes) {
        TestSubMenu tsm = new TestSubMenu();
        TestMenuItem menuItem = new TestMenuItem();
        this.menuItems.add(menuItem);
        menuItem.setItemId(itemId);
        menuItem.setTitle(titleRes);
        menuItem.setSubMenu(tsm);
        return tsm;
    }

    public int addIntentOptions(int groupId, int itemId, int order, ComponentName caller, Intent[] specifics, Intent intent, int flags, MenuItem[] outSpecificItems) {
        return 0;
    }

    public void removeItem(int id) {
        this.menuItems.remove(findItem(id));
    }

    public void removeGroup(int groupId) {
    }

    public void clear() {
        this.menuItems.clear();
    }

    public void setGroupCheckable(int group, boolean checkable, boolean exclusive) {
    }

    public void setGroupVisible(int group, boolean visible) {
    }

    public void setGroupEnabled(int group, boolean enabled) {
    }

    public boolean hasVisibleItems() {
        return false;
    }

    public MenuItem findItem(int id) {
        for (MenuItem item : this.menuItems) {
            if (item.getItemId() == id) {
                return item;
            }
        }
        return null;
    }

    public int size() {
        return this.menuItems.size();
    }

    public MenuItem getItem(int index) {
        return this.menuItems.get(index);
    }

    public void close() {
    }

    public boolean performShortcut(int keyCode, KeyEvent event, int flags) {
        return false;
    }

    public boolean isShortcutKey(int keyCode, KeyEvent event) {
        return false;
    }

    public boolean performIdentifierAction(int id, int flags) {
        return false;
    }

    public void setQwertyMode(boolean isQwerty) {
    }

    public TestMenuItem findMenuItem(CharSequence title) {
        for (int i = 0; i < size(); i++) {
            TestMenuItem menuItem = (TestMenuItem) getItem(i);
            if (menuItem.getTitle().equals(title)) {
                return menuItem;
            }
        }
        return null;
    }
}
