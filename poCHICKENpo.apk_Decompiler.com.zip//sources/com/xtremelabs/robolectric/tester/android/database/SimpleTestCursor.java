package com.xtremelabs.robolectric.tester.android.database;

import android.net.Uri;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class SimpleTestCursor extends TestCursor {
    boolean closeWasCalled;
    List<String> columnNames = new ArrayList();
    public String[] projection;
    Object[][] results = ((Object[][]) Array.newInstance(Object.class, new int[]{0, 0}));
    int resultsIndex = -1;
    public String selection;
    public String[] selectionArgs;
    public String sortOrder;
    public Uri uri;

    public void setQuery(Uri uri2, String[] projection2, String selection2, String[] selectionArgs2, String sortOrder2) {
        this.uri = uri2;
        this.projection = projection2;
        this.selection = selection2;
        this.selectionArgs = selectionArgs2;
        this.sortOrder = sortOrder2;
    }

    public int getColumnIndex(String columnName) {
        return this.columnNames.indexOf(columnName);
    }

    public String getString(int columnIndex) {
        return (String) this.results[this.resultsIndex][columnIndex];
    }

    public long getLong(int columnIndex) {
        return ((Long) this.results[this.resultsIndex][columnIndex]).longValue();
    }

    public boolean moveToNext() {
        this.resultsIndex++;
        return this.resultsIndex < this.results.length;
    }

    public void close() {
        this.closeWasCalled = true;
    }

    public void setColumnNames(ArrayList<String> columnNames2) {
        this.columnNames = columnNames2;
    }

    public void setResults(Object[][] results2) {
        this.results = results2;
    }

    public boolean getCloseWasCalled() {
        return this.closeWasCalled;
    }
}
