package com.xtremelabs.robolectric.tester.android.util;

import android.util.AttributeSet;
import android.view.View;
import com.xtremelabs.robolectric.res.AttrResourceLoader;
import com.xtremelabs.robolectric.res.ResourceExtractor;
import com.xtremelabs.robolectric.util.I18nException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class TestAttributeSet implements AttributeSet {
    private static final String[] strictI18nAttrs = {"android:text", "android:title", "android:titleCondensed", "android:summary"};
    private AttrResourceLoader attrResourceLoader;
    Map<String, String> attributes;
    private boolean isSystem;
    private ResourceExtractor resourceExtractor;
    private Class<? extends View> viewClass;

    public TestAttributeSet() {
        this.attributes = new HashMap();
        this.isSystem = false;
        this.attributes = new HashMap();
    }

    public TestAttributeSet(Map<String, String> attributes2, ResourceExtractor resourceExtractor2, AttrResourceLoader attrResourceLoader2, Class<? extends View> viewClass2, boolean isSystem2) {
        this.attributes = new HashMap();
        this.isSystem = false;
        this.attributes = attributes2;
        this.resourceExtractor = resourceExtractor2;
        this.attrResourceLoader = attrResourceLoader2;
        this.viewClass = viewClass2;
        this.isSystem = isSystem2;
    }

    public TestAttributeSet(Map<String, String> attributes2) {
        this.attributes = new HashMap();
        this.isSystem = false;
        this.attributes = attributes2;
        this.resourceExtractor = new ResourceExtractor();
        this.attrResourceLoader = new AttrResourceLoader(this.resourceExtractor);
        this.viewClass = null;
    }

    public TestAttributeSet put(String name, String value) {
        this.attributes.put(name, value);
        return this;
    }

    public boolean getAttributeBooleanValue(String namespace, String attribute, boolean defaultValue) {
        String value = getAttributeValueInMap(namespace, attribute);
        return value != null ? Boolean.valueOf(value).booleanValue() : defaultValue;
    }

    public String getAttributeValue(String namespace, String attribute) {
        return getAttributeValueInMap(namespace, attribute);
    }

    public int getAttributeIntValue(String namespace, String attribute, int defaultValue) {
        String value = getAttributeValueInMap(namespace, attribute);
        if (this.attrResourceLoader.hasAttributeFor(this.viewClass, "xxx", attribute)) {
            value = this.attrResourceLoader.convertValueToEnum(this.viewClass, "xxx", attribute, value);
        }
        return value != null ? Integer.valueOf(value).intValue() : defaultValue;
    }

    public int getAttributeCount() {
        throw new UnsupportedOperationException();
    }

    public String getAttributeName(int index) {
        throw new UnsupportedOperationException();
    }

    public String getAttributeValue(int index) {
        throw new UnsupportedOperationException();
    }

    public String getPositionDescription() {
        throw new UnsupportedOperationException();
    }

    public int getAttributeNameResource(int index) {
        throw new UnsupportedOperationException();
    }

    public int getAttributeListValue(String namespace, String attribute, String[] options, int defaultValue) {
        throw new UnsupportedOperationException();
    }

    public int getAttributeUnsignedIntValue(String namespace, String attribute, int defaultValue) {
        throw new UnsupportedOperationException();
    }

    public float getAttributeFloatValue(String namespace, String attribute, float defaultValue) {
        String value = getAttributeValueInMap(namespace, attribute);
        if (this.attrResourceLoader.hasAttributeFor(this.viewClass, "xxx", attribute)) {
            value = this.attrResourceLoader.convertValueToEnum(this.viewClass, "xxx", attribute, value);
        }
        return value != null ? Float.valueOf(value).floatValue() : defaultValue;
    }

    public int getAttributeListValue(int index, String[] options, int defaultValue) {
        throw new UnsupportedOperationException();
    }

    public boolean getAttributeBooleanValue(int resourceId, boolean defaultValue) {
        throw new UnsupportedOperationException();
    }

    public int getAttributeResourceValue(String namespace, String attribute, int defaultValue) {
        String value = getAttributeValueInMap(namespace, attribute);
        Integer resourceId = Integer.valueOf(defaultValue);
        if (value != null) {
            resourceId = this.resourceExtractor.getResourceId(value);
        }
        return resourceId == null ? defaultValue : resourceId.intValue();
    }

    public int getAttributeResourceValue(int resourceId, int defaultValue) {
        String value = getAttributeValueInMap((String) null, this.resourceExtractor.getResourceName(resourceId));
        return value == null ? defaultValue : this.resourceExtractor.getResourceId(value).intValue();
    }

    public int getAttributeIntValue(int index, int defaultValue) {
        throw new UnsupportedOperationException();
    }

    public int getAttributeUnsignedIntValue(int index, int defaultValue) {
        throw new UnsupportedOperationException();
    }

    public float getAttributeFloatValue(int index, float defaultValue) {
        throw new UnsupportedOperationException();
    }

    public String getIdAttribute() {
        throw new UnsupportedOperationException();
    }

    public String getClassAttribute() {
        throw new UnsupportedOperationException();
    }

    public int getIdAttributeResourceValue(int defaultValue) {
        throw new UnsupportedOperationException();
    }

    public int getStyleAttribute() {
        throw new UnsupportedOperationException();
    }

    public void validateStrictI18n() {
        for (String key : strictI18nAttrs) {
            if (this.attributes.containsKey(key)) {
                String value = this.attributes.get(key);
                if (!value.startsWith("@string/")) {
                    throw new I18nException("View class: " + (this.viewClass != null ? this.viewClass.getName() : "") + " has attribute: " + key + " with hardcoded value: \"" + value + "\" and is not i18n-safe.");
                }
            }
        }
    }

    private String getAttributeValueInMap(String namespace, String attribute) {
        String key;
        String value = null;
        Iterator i$ = this.attributes.keySet().iterator();
        while (true) {
            if (!i$.hasNext()) {
                break;
            }
            key = i$.next();
            String[] mappedKeys = {null, key};
            if (key.contains(":")) {
                mappedKeys = key.split(":");
            }
            if (!mappedKeys[1].equals(attribute) || (namespace != null && namespace == "android" && (!namespace.equals("android") || !namespace.equals(mappedKeys[0])))) {
            }
        }
        value = this.attributes.get(key);
        if (value == null || !this.isSystem || !value.startsWith("@+id")) {
            return value;
        }
        return value.replace("@+id", "@+android:id");
    }
}
