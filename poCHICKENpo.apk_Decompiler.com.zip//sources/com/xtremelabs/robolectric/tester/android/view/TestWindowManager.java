package com.xtremelabs.robolectric.tester.android.view;

import android.view.Display;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import com.xtremelabs.robolectric.Robolectric;

public class TestWindowManager implements WindowManager {
    private Display display;

    public void addView(View arg0, ViewGroup.LayoutParams arg1) {
    }

    public void removeView(View arg0) {
    }

    public void updateViewLayout(View arg0, ViewGroup.LayoutParams arg1) {
    }

    public Display getDefaultDisplay() {
        if (this.display != null) {
            return this.display;
        }
        Display display2 = (Display) Robolectric.newInstanceOf(Display.class);
        this.display = display2;
        return display2;
    }

    public void removeViewImmediate(View arg0) {
    }
}
