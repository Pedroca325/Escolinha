package com.xtremelabs.robolectric.tester.android.database;

import android.content.ContentResolver;
import android.database.CharArrayBuffer;
import android.database.ContentObserver;
import android.database.Cursor;
import android.database.DataSetObserver;
import android.net.Uri;
import android.os.Bundle;

public class TestCursor implements Cursor {
    public int getCount() {
        throw new UnsupportedOperationException();
    }

    public int getPosition() {
        throw new UnsupportedOperationException();
    }

    public boolean move(int offset) {
        throw new UnsupportedOperationException();
    }

    public boolean moveToPosition(int position) {
        throw new UnsupportedOperationException();
    }

    public boolean moveToFirst() {
        throw new UnsupportedOperationException();
    }

    public boolean moveToLast() {
        throw new UnsupportedOperationException();
    }

    public boolean moveToNext() {
        throw new UnsupportedOperationException();
    }

    public boolean moveToPrevious() {
        throw new UnsupportedOperationException();
    }

    public boolean isFirst() {
        throw new UnsupportedOperationException();
    }

    public boolean isLast() {
        throw new UnsupportedOperationException();
    }

    public boolean isBeforeFirst() {
        throw new UnsupportedOperationException();
    }

    public boolean isAfterLast() {
        throw new UnsupportedOperationException();
    }

    public int getColumnIndex(String columnName) {
        throw new UnsupportedOperationException();
    }

    public int getColumnIndexOrThrow(String columnName) throws IllegalArgumentException {
        throw new UnsupportedOperationException();
    }

    public String getColumnName(int columnIndex) {
        throw new UnsupportedOperationException();
    }

    public String[] getColumnNames() {
        throw new UnsupportedOperationException();
    }

    public int getColumnCount() {
        throw new UnsupportedOperationException();
    }

    public byte[] getBlob(int columnIndex) {
        throw new UnsupportedOperationException();
    }

    public String getString(int columnIndex) {
        throw new UnsupportedOperationException();
    }

    public void copyStringToBuffer(int columnIndex, CharArrayBuffer buffer) {
        throw new UnsupportedOperationException();
    }

    public short getShort(int columnIndex) {
        throw new UnsupportedOperationException();
    }

    public int getInt(int columnIndex) {
        throw new UnsupportedOperationException();
    }

    public long getLong(int columnIndex) {
        throw new UnsupportedOperationException();
    }

    public float getFloat(int columnIndex) {
        throw new UnsupportedOperationException();
    }

    public double getDouble(int columnIndex) {
        throw new UnsupportedOperationException();
    }

    public boolean isNull(int columnIndex) {
        throw new UnsupportedOperationException();
    }

    public void deactivate() {
        throw new UnsupportedOperationException();
    }

    public boolean requery() {
        throw new UnsupportedOperationException();
    }

    public void close() {
        throw new UnsupportedOperationException();
    }

    public boolean isClosed() {
        throw new UnsupportedOperationException();
    }

    public void registerContentObserver(ContentObserver observer) {
        throw new UnsupportedOperationException();
    }

    public void unregisterContentObserver(ContentObserver observer) {
        throw new UnsupportedOperationException();
    }

    public void registerDataSetObserver(DataSetObserver observer) {
        throw new UnsupportedOperationException();
    }

    public void unregisterDataSetObserver(DataSetObserver observer) {
        throw new UnsupportedOperationException();
    }

    public void setNotificationUri(ContentResolver cr, Uri uri) {
        throw new UnsupportedOperationException();
    }

    public boolean getWantsAllOnMoveCalls() {
        throw new UnsupportedOperationException();
    }

    public Bundle getExtras() {
        throw new UnsupportedOperationException();
    }

    public Bundle respond(Bundle extras) {
        throw new UnsupportedOperationException();
    }

    public void setQuery(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
    }
}
