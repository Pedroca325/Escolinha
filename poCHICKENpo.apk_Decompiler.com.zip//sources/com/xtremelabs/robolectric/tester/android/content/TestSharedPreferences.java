package com.xtremelabs.robolectric.tester.android.content;

import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class TestSharedPreferences implements SharedPreferences {
    public Map<String, Map<String, Object>> content;
    protected String filename;
    private ArrayList<SharedPreferences.OnSharedPreferenceChangeListener> listeners;
    public int mode;

    public TestSharedPreferences(Map<String, Map<String, Object>> content2, String name, int mode2) {
        this.content = content2;
        this.filename = name;
        this.mode = mode2;
        if (!content2.containsKey(name)) {
            content2.put(name, new HashMap());
        }
        this.listeners = new ArrayList<>();
    }

    public Map<String, ?> getAll() {
        return new HashMap(this.content.get(this.filename));
    }

    public String getString(String key, String defValue) {
        return (String) getValue(key, defValue);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x000c, code lost:
        r1 = r0.get(r5);
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private java.lang.Object getValue(java.lang.String r5, java.lang.Object r6) {
        /*
            r4 = this;
            java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.lang.Object>> r2 = r4.content
            java.lang.String r3 = r4.filename
            java.lang.Object r0 = r2.get(r3)
            java.util.Map r0 = (java.util.Map) r0
            if (r0 == 0) goto L_0x0013
            java.lang.Object r1 = r0.get(r5)
            if (r1 == 0) goto L_0x0013
        L_0x0012:
            return r1
        L_0x0013:
            r1 = r6
            goto L_0x0012
        */
        throw new UnsupportedOperationException("Method not decompiled: com.xtremelabs.robolectric.tester.android.content.TestSharedPreferences.getValue(java.lang.String, java.lang.Object):java.lang.Object");
    }

    public int getInt(String key, int defValue) {
        return ((Integer) getValue(key, Integer.valueOf(defValue))).intValue();
    }

    public long getLong(String key, long defValue) {
        return ((Long) getValue(key, Long.valueOf(defValue))).longValue();
    }

    public float getFloat(String key, float defValue) {
        return ((Float) getValue(key, Float.valueOf(defValue))).floatValue();
    }

    public boolean getBoolean(String key, boolean defValue) {
        return ((Boolean) getValue(key, Boolean.valueOf(defValue))).booleanValue();
    }

    public boolean contains(String key) {
        return this.content.get(this.filename).containsKey(key);
    }

    public SharedPreferences.Editor edit() {
        return new TestSharedPreferencesEditor();
    }

    public void registerOnSharedPreferenceChangeListener(SharedPreferences.OnSharedPreferenceChangeListener listener) {
        if (!this.listeners.contains(listener)) {
            this.listeners.add(listener);
        }
    }

    public void unregisterOnSharedPreferenceChangeListener(SharedPreferences.OnSharedPreferenceChangeListener listener) {
        if (this.listeners.contains(listener)) {
            this.listeners.remove(listener);
        }
    }

    public boolean hasListener(SharedPreferences.OnSharedPreferenceChangeListener listener) {
        return this.listeners.contains(listener);
    }

    private class TestSharedPreferencesEditor implements SharedPreferences.Editor {
        Map<String, Object> editsThatNeedCommit;
        Set<String> editsThatNeedRemove;
        private boolean shouldClearOnCommit;

        private TestSharedPreferencesEditor() {
            this.editsThatNeedCommit = new HashMap();
            this.editsThatNeedRemove = new HashSet();
            this.shouldClearOnCommit = false;
        }

        public SharedPreferences.Editor putString(String key, String value) {
            this.editsThatNeedCommit.put(key, value);
            this.editsThatNeedRemove.remove(key);
            return this;
        }

        public SharedPreferences.Editor putInt(String key, int value) {
            this.editsThatNeedCommit.put(key, Integer.valueOf(value));
            this.editsThatNeedRemove.remove(key);
            return this;
        }

        public SharedPreferences.Editor putLong(String key, long value) {
            this.editsThatNeedCommit.put(key, Long.valueOf(value));
            this.editsThatNeedRemove.remove(key);
            return this;
        }

        public SharedPreferences.Editor putFloat(String key, float value) {
            this.editsThatNeedCommit.put(key, Float.valueOf(value));
            this.editsThatNeedRemove.remove(key);
            return this;
        }

        public SharedPreferences.Editor putBoolean(String key, boolean value) {
            this.editsThatNeedCommit.put(key, Boolean.valueOf(value));
            this.editsThatNeedRemove.remove(key);
            return this;
        }

        public SharedPreferences.Editor remove(String key) {
            this.editsThatNeedRemove.add(key);
            return this;
        }

        public SharedPreferences.Editor clear() {
            this.shouldClearOnCommit = true;
            return this;
        }

        public boolean commit() {
            Map<String, Object> previousContent = TestSharedPreferences.this.content.get(TestSharedPreferences.this.filename);
            if (this.shouldClearOnCommit) {
                previousContent.clear();
            } else {
                for (String key : this.editsThatNeedCommit.keySet()) {
                    previousContent.put(key, this.editsThatNeedCommit.get(key));
                }
                for (String key2 : this.editsThatNeedRemove) {
                    previousContent.remove(key2);
                }
            }
            for (String key3 : this.editsThatNeedCommit.keySet()) {
                previousContent.put(key3, this.editsThatNeedCommit.get(key3));
            }
            return true;
        }

        public void apply() {
            commit();
        }
    }
}
