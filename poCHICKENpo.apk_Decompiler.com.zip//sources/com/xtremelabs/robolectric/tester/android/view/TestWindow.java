package com.xtremelabs.robolectric.tester.android.view;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.InputQueue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import com.xtremelabs.robolectric.Robolectric;

public class TestWindow extends Window {
    public int featureDrawableResourceFeatureId;
    public int featureDrawableResourceResId;
    public int flags;
    public int requestedFeatureId;
    public int softInputMode;
    private TestWindowManager windowManager = new TestWindowManager();

    public TestWindow(Context context) {
        super(context);
    }

    public boolean requestFeature(int featureId) {
        this.requestedFeatureId = featureId;
        return true;
    }

    public void setFlags(int flags2, int mask) {
        this.flags = ((mask ^ -1) & flags2) | (flags2 & mask);
    }

    public void addFlags(int flags2) {
        setFlags(flags2, flags2);
    }

    public WindowManager getWindowManager() {
        return this.windowManager;
    }

    public boolean isFloating() {
        return false;
    }

    public void takeSurface(SurfaceHolder.Callback2 callback2) {
    }

    public void takeInputQueue(InputQueue.Callback callback) {
    }

    public void setContentView(int layoutResID) {
    }

    public void setContentView(View view) {
    }

    public void setContentView(View view, ViewGroup.LayoutParams params) {
    }

    public void addContentView(View view, ViewGroup.LayoutParams params) {
    }

    public View getCurrentFocus() {
        return null;
    }

    public LayoutInflater getLayoutInflater() {
        return null;
    }

    public void setTitle(CharSequence title) {
    }

    public void setTitleColor(int textColor) {
    }

    public void openPanel(int featureId, KeyEvent event) {
    }

    public void closePanel(int featureId) {
    }

    public void togglePanel(int featureId, KeyEvent event) {
    }

    public boolean performPanelShortcut(int featureId, int keyCode, KeyEvent event, int flags2) {
        return false;
    }

    public boolean performPanelIdentifierAction(int featureId, int id, int flags2) {
        return false;
    }

    public void closeAllPanels() {
    }

    public boolean performContextMenuIdentifierAction(int id, int flags2) {
        return false;
    }

    public void onConfigurationChanged(Configuration newConfig) {
    }

    public void setBackgroundDrawable(Drawable drawable) {
    }

    public void setFeatureDrawableResource(int featureId, int resId) {
        this.featureDrawableResourceFeatureId = featureId;
        this.featureDrawableResourceResId = resId;
    }

    public void setFeatureDrawableUri(int featureId, Uri uri) {
    }

    public void setFeatureDrawable(int featureId, Drawable drawable) {
    }

    public void setFeatureDrawableAlpha(int featureId, int alpha) {
    }

    public void setFeatureInt(int featureId, int value) {
    }

    public void takeKeyEvents(boolean get) {
    }

    public boolean superDispatchKeyEvent(KeyEvent event) {
        return false;
    }

    public boolean superDispatchTouchEvent(MotionEvent event) {
        return false;
    }

    public boolean superDispatchTrackballEvent(MotionEvent event) {
        return false;
    }

    public View getDecorView() {
        return new View(Robolectric.application);
    }

    public View peekDecorView() {
        return null;
    }

    public Bundle saveHierarchyState() {
        return null;
    }

    public void restoreHierarchyState(Bundle savedInstanceState) {
    }

    /* access modifiers changed from: protected */
    public void onActive() {
    }

    public void setChildDrawable(int featureId, Drawable drawable) {
    }

    public void setChildInt(int featureId, int value) {
    }

    public boolean isShortcutKey(int keyCode, KeyEvent event) {
        return false;
    }

    public void setVolumeControlStream(int streamType) {
    }

    public int getVolumeControlStream() {
        return 0;
    }

    public void setSoftInputMode(int softInputMode2) {
        this.softInputMode = softInputMode2;
    }
}
