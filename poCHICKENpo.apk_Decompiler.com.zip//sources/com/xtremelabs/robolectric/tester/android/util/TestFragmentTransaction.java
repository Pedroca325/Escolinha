package com.xtremelabs.robolectric.tester.android.util;

import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;

public class TestFragmentTransaction extends FragmentTransaction {
    /* access modifiers changed from: private */
    public int containerViewId;
    /* access modifiers changed from: private */
    public Fragment fragment;
    /* access modifiers changed from: private */
    public TestFragmentManager fragmentManager;
    /* access modifiers changed from: private */
    public boolean isReplacing;
    /* access modifiers changed from: private */
    public String tag;

    public TestFragmentTransaction(TestFragmentManager fragmentManager2) {
        this.fragmentManager = fragmentManager2;
    }

    public FragmentTransaction add(Fragment fragment2, String tag2) {
        this.containerViewId = -1;
        this.tag = tag2;
        this.fragment = fragment2;
        return this;
    }

    public FragmentTransaction add(int containerViewId2, Fragment fragment2) {
        this.containerViewId = containerViewId2;
        this.fragment = fragment2;
        return this;
    }

    public FragmentTransaction add(int containerViewId2, Fragment fragment2, String tag2) {
        this.containerViewId = containerViewId2;
        this.tag = tag2;
        this.fragment = fragment2;
        return this;
    }

    public FragmentTransaction replace(int containerViewId2, Fragment fragment2) {
        this.containerViewId = containerViewId2;
        this.fragment = fragment2;
        this.isReplacing = true;
        return this;
    }

    public FragmentTransaction replace(int containerViewId2, Fragment fragment2, String tag2) {
        this.containerViewId = containerViewId2;
        this.tag = tag2;
        this.fragment = fragment2;
        this.isReplacing = true;
        return this;
    }

    public FragmentTransaction remove(Fragment fragment2) {
        return null;
    }

    public FragmentTransaction hide(Fragment fragment2) {
        return null;
    }

    public FragmentTransaction show(Fragment fragment2) {
        return null;
    }

    public FragmentTransaction detach(Fragment fragment2) {
        return null;
    }

    public FragmentTransaction attach(Fragment fragment2) {
        return null;
    }

    public boolean isEmpty() {
        return false;
    }

    public FragmentTransaction setCustomAnimations(int enter, int exit) {
        return null;
    }

    public FragmentTransaction setCustomAnimations(int enter, int exit, int popEnter, int popExit) {
        return null;
    }

    public FragmentTransaction setTransition(int transit) {
        return null;
    }

    public FragmentTransaction setTransitionStyle(int styleRes) {
        return null;
    }

    public FragmentTransaction addToBackStack(String name) {
        return null;
    }

    public boolean isAddToBackStackAllowed() {
        return false;
    }

    public FragmentTransaction disallowAddToBackStack() {
        return null;
    }

    public FragmentTransaction setBreadCrumbTitle(int res) {
        return null;
    }

    public FragmentTransaction setBreadCrumbTitle(CharSequence text) {
        return null;
    }

    public FragmentTransaction setBreadCrumbShortTitle(int res) {
        return null;
    }

    public FragmentTransaction setBreadCrumbShortTitle(CharSequence text) {
        return null;
    }

    public int commit() {
        new Handler().post(new Runnable() {
            public void run() {
                TestFragmentTransaction.this.fragmentManager.addFragment(TestFragmentTransaction.this.containerViewId, TestFragmentTransaction.this.tag, TestFragmentTransaction.this.fragment, TestFragmentTransaction.this.isReplacing);
                TestFragmentTransaction.this.fragmentManager.startFragment(TestFragmentTransaction.this.fragment);
            }
        });
        return 0;
    }

    public int commitAllowingStateLoss() {
        return 0;
    }
}
