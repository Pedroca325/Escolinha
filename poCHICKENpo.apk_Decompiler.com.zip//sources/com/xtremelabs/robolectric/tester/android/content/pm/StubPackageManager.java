package com.xtremelabs.robolectric.tester.android.content.pm;

import android.content.ComponentName;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.FeatureInfo;
import android.content.pm.InstrumentationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PermissionGroupInfo;
import android.content.pm.PermissionInfo;
import android.content.pm.ProviderInfo;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.content.res.Resources;
import android.content.res.XmlResourceParser;
import android.graphics.drawable.Drawable;
import java.util.List;

public class StubPackageManager extends PackageManager {
    public PackageInfo getPackageInfo(String packageName, int flags) throws PackageManager.NameNotFoundException {
        return null;
    }

    public String[] currentToCanonicalPackageNames(String[] strings) {
        return new String[0];
    }

    public String[] canonicalToCurrentPackageNames(String[] strings) {
        return new String[0];
    }

    public Intent getLaunchIntentForPackage(String packageName) {
        return null;
    }

    public int[] getPackageGids(String packageName) throws PackageManager.NameNotFoundException {
        return new int[0];
    }

    public PermissionInfo getPermissionInfo(String name, int flags) throws PackageManager.NameNotFoundException {
        return null;
    }

    public List<PermissionInfo> queryPermissionsByGroup(String group, int flags) throws PackageManager.NameNotFoundException {
        return null;
    }

    public PermissionGroupInfo getPermissionGroupInfo(String name, int flags) throws PackageManager.NameNotFoundException {
        return null;
    }

    public List<PermissionGroupInfo> getAllPermissionGroups(int flags) {
        return null;
    }

    public ApplicationInfo getApplicationInfo(String packageName, int flags) throws PackageManager.NameNotFoundException {
        return null;
    }

    public ActivityInfo getActivityInfo(ComponentName className, int flags) throws PackageManager.NameNotFoundException {
        return null;
    }

    public ActivityInfo getReceiverInfo(ComponentName className, int flags) throws PackageManager.NameNotFoundException {
        return null;
    }

    public ServiceInfo getServiceInfo(ComponentName className, int flags) throws PackageManager.NameNotFoundException {
        return null;
    }

    public ProviderInfo getProviderInfo(ComponentName componentName, int i) throws PackageManager.NameNotFoundException {
        return null;
    }

    public List<PackageInfo> getInstalledPackages(int flags) {
        return null;
    }

    public int checkPermission(String permName, String pkgName) {
        return 0;
    }

    public boolean addPermission(PermissionInfo info) {
        return false;
    }

    public boolean addPermissionAsync(PermissionInfo permissionInfo) {
        return false;
    }

    public void removePermission(String name) {
    }

    public int checkSignatures(String pkg1, String pkg2) {
        return 0;
    }

    public int checkSignatures(int uid1, int uid2) {
        return 0;
    }

    public String[] getPackagesForUid(int uid) {
        return new String[0];
    }

    public String getNameForUid(int uid) {
        return null;
    }

    public List<ApplicationInfo> getInstalledApplications(int flags) {
        return null;
    }

    public String[] getSystemSharedLibraryNames() {
        return new String[0];
    }

    public FeatureInfo[] getSystemAvailableFeatures() {
        return new FeatureInfo[0];
    }

    public boolean hasSystemFeature(String name) {
        return false;
    }

    public ResolveInfo resolveActivity(Intent intent, int flags) {
        return null;
    }

    public List<ResolveInfo> queryIntentActivities(Intent intent, int flags) {
        return null;
    }

    public List<ResolveInfo> queryIntentActivityOptions(ComponentName caller, Intent[] specifics, Intent intent, int flags) {
        return null;
    }

    public List<ResolveInfo> queryBroadcastReceivers(Intent intent, int flags) {
        return null;
    }

    public ResolveInfo resolveService(Intent intent, int flags) {
        return null;
    }

    public List<ResolveInfo> queryIntentServices(Intent intent, int flags) {
        return null;
    }

    public ProviderInfo resolveContentProvider(String name, int flags) {
        return null;
    }

    public List<ProviderInfo> queryContentProviders(String processName, int uid, int flags) {
        return null;
    }

    public InstrumentationInfo getInstrumentationInfo(ComponentName className, int flags) throws PackageManager.NameNotFoundException {
        return null;
    }

    public List<InstrumentationInfo> queryInstrumentation(String targetPackage, int flags) {
        return null;
    }

    public Drawable getDrawable(String packageName, int resid, ApplicationInfo appInfo) {
        return null;
    }

    public Drawable getActivityIcon(ComponentName activityName) throws PackageManager.NameNotFoundException {
        return null;
    }

    public Drawable getActivityIcon(Intent intent) throws PackageManager.NameNotFoundException {
        return null;
    }

    public Drawable getDefaultActivityIcon() {
        return null;
    }

    public Drawable getApplicationIcon(ApplicationInfo info) {
        return null;
    }

    public Drawable getApplicationIcon(String packageName) throws PackageManager.NameNotFoundException {
        return null;
    }

    public Drawable getActivityLogo(ComponentName componentName) throws PackageManager.NameNotFoundException {
        return null;
    }

    public Drawable getActivityLogo(Intent intent) throws PackageManager.NameNotFoundException {
        return null;
    }

    public Drawable getApplicationLogo(ApplicationInfo applicationInfo) {
        return null;
    }

    public Drawable getApplicationLogo(String s) throws PackageManager.NameNotFoundException {
        return null;
    }

    public CharSequence getText(String packageName, int resid, ApplicationInfo appInfo) {
        return null;
    }

    public XmlResourceParser getXml(String packageName, int resid, ApplicationInfo appInfo) {
        return null;
    }

    public CharSequence getApplicationLabel(ApplicationInfo info) {
        return null;
    }

    public Resources getResourcesForActivity(ComponentName activityName) throws PackageManager.NameNotFoundException {
        return null;
    }

    public Resources getResourcesForApplication(ApplicationInfo app) throws PackageManager.NameNotFoundException {
        return null;
    }

    public Resources getResourcesForApplication(String appPackageName) throws PackageManager.NameNotFoundException {
        return null;
    }

    public String getInstallerPackageName(String packageName) {
        return null;
    }

    public void addPackageToPreferred(String packageName) {
    }

    public void removePackageFromPreferred(String packageName) {
    }

    public List<PackageInfo> getPreferredPackages(int flags) {
        return null;
    }

    public void addPreferredActivity(IntentFilter filter, int match, ComponentName[] set, ComponentName activity) {
    }

    public void clearPackagePreferredActivities(String packageName) {
    }

    public int getPreferredActivities(List<IntentFilter> list, List<ComponentName> list2, String packageName) {
        return 0;
    }

    public void setComponentEnabledSetting(ComponentName componentName, int newState, int flags) {
    }

    public int getComponentEnabledSetting(ComponentName componentName) {
        return 0;
    }

    public void setApplicationEnabledSetting(String packageName, int newState, int flags) {
    }

    public int getApplicationEnabledSetting(String packageName) {
        return 0;
    }

    public boolean isSafeMode() {
        return false;
    }
}
