package com.xtremelabs.robolectric.tester.android.view;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.SubMenu;
import com.xtremelabs.robolectric.Robolectric;

public class TestMenuItem implements MenuItem {
    private boolean enabled = true;
    public int iconRes;
    private Intent intent;
    private int itemId;
    private MenuItem.OnMenuItemClickListener menuItemClickListener;
    private SubMenu subMenu;
    private CharSequence title;

    public TestMenuItem() {
    }

    public TestMenuItem(int itemId2) {
        this.itemId = itemId2;
    }

    public void setItemId(int itemId2) {
        this.itemId = itemId2;
    }

    public int getItemId() {
        return this.itemId;
    }

    public int getGroupId() {
        return 0;
    }

    public int getOrder() {
        return 0;
    }

    public MenuItem setTitle(CharSequence title2) {
        this.title = title2;
        return this;
    }

    public MenuItem setTitle(int title2) {
        return null;
    }

    public CharSequence getTitle() {
        return this.title;
    }

    public MenuItem setTitleCondensed(CharSequence title2) {
        return null;
    }

    public CharSequence getTitleCondensed() {
        return null;
    }

    public MenuItem setIcon(Drawable icon) {
        return null;
    }

    public MenuItem setIcon(int iconRes2) {
        this.iconRes = iconRes2;
        return this;
    }

    public Drawable getIcon() {
        return null;
    }

    public MenuItem setIntent(Intent intent2) {
        this.intent = intent2;
        return this;
    }

    public Intent getIntent() {
        return this.intent;
    }

    public MenuItem setShortcut(char numericChar, char alphaChar) {
        return null;
    }

    public MenuItem setNumericShortcut(char numericChar) {
        return null;
    }

    public char getNumericShortcut() {
        return 0;
    }

    public MenuItem setAlphabeticShortcut(char alphaChar) {
        return null;
    }

    public char getAlphabeticShortcut() {
        return 0;
    }

    public MenuItem setCheckable(boolean checkable) {
        return null;
    }

    public boolean isCheckable() {
        return false;
    }

    public MenuItem setChecked(boolean checked) {
        return null;
    }

    public boolean isChecked() {
        return false;
    }

    public MenuItem setVisible(boolean visible) {
        return null;
    }

    public boolean isVisible() {
        return false;
    }

    public MenuItem setEnabled(boolean enabled2) {
        this.enabled = enabled2;
        return this;
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public boolean hasSubMenu() {
        return this.subMenu != null;
    }

    public SubMenu getSubMenu() {
        return this.subMenu;
    }

    public void setSubMenu(SubMenu subMenu2) {
        this.subMenu = subMenu2;
    }

    public MenuItem setOnMenuItemClickListener(MenuItem.OnMenuItemClickListener menuItemClickListener2) {
        this.menuItemClickListener = menuItemClickListener2;
        return this;
    }

    public ContextMenu.ContextMenuInfo getMenuInfo() {
        return null;
    }

    public void click() {
        if (this.enabled && this.menuItemClickListener != null) {
            this.menuItemClickListener.onMenuItemClick(this);
        } else if (this.enabled && this.intent != null) {
            Robolectric.application.startActivity(this.intent);
        }
    }
}
