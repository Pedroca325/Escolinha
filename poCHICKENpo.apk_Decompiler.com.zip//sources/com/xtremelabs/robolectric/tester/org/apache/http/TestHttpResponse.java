package com.xtremelabs.robolectric.tester.org.apache.http;

import br.com.tectoy.pochickenpo.core.Constants;
import com.xtremelabs.robolectric.shadows.StatusLineStub;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.NoSuchElementException;
import org.apache.http.Header;
import org.apache.http.HeaderIterator;
import org.apache.http.HttpEntity;
import org.apache.http.HttpVersion;
import org.apache.http.ProtocolVersion;
import org.apache.http.StatusLine;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpParams;

public class TestHttpResponse extends HttpResponseStub {
    /* access modifiers changed from: private */
    public Header[] headers;
    private TestHttpEntity httpEntity;
    private int openEntityContentStreamCount;
    private HttpParams params;
    /* access modifiers changed from: private */
    public byte[] responseBody;
    /* access modifiers changed from: private */
    public int statusCode;
    private TestStatusLine statusLine;

    static /* synthetic */ int access$208(TestHttpResponse x0) {
        int i = x0.openEntityContentStreamCount;
        x0.openEntityContentStreamCount = i + 1;
        return i;
    }

    static /* synthetic */ int access$210(TestHttpResponse x0) {
        int i = x0.openEntityContentStreamCount;
        x0.openEntityContentStreamCount = i - 1;
        return i;
    }

    public TestHttpResponse() {
        this.statusLine = new TestStatusLine();
        this.httpEntity = new TestHttpEntity();
        this.openEntityContentStreamCount = 0;
        this.headers = new Header[0];
        this.params = new BasicHttpParams();
        this.statusCode = Constants.DELAY_ANIM2_PARADA;
        this.responseBody = new byte[0];
    }

    public TestHttpResponse(int statusCode2, String responseBody2) {
        this.statusLine = new TestStatusLine();
        this.httpEntity = new TestHttpEntity();
        this.openEntityContentStreamCount = 0;
        this.headers = new Header[0];
        this.params = new BasicHttpParams();
        this.statusCode = statusCode2;
        this.responseBody = responseBody2.getBytes();
    }

    public TestHttpResponse(int statusCode2, String responseBody2, Header... headers2) {
        this(statusCode2, responseBody2.getBytes(), headers2);
    }

    public TestHttpResponse(int statusCode2, byte[] responseBody2, Header... headers2) {
        this.statusLine = new TestStatusLine();
        this.httpEntity = new TestHttpEntity();
        this.openEntityContentStreamCount = 0;
        this.headers = new Header[0];
        this.params = new BasicHttpParams();
        this.statusCode = statusCode2;
        this.responseBody = (byte[]) responseBody2.clone();
        this.headers = headers2;
    }

    /* access modifiers changed from: protected */
    public void setResponseBody(String responseBody2) {
        this.responseBody = responseBody2.getBytes();
    }

    public StatusLine getStatusLine() {
        return this.statusLine;
    }

    public HttpEntity getEntity() {
        return this.httpEntity;
    }

    public Header[] getAllHeaders() {
        return this.headers;
    }

    public Header getFirstHeader(String s) {
        for (Header h : this.headers) {
            if (s.equalsIgnoreCase(h.getName())) {
                return h;
            }
        }
        return null;
    }

    public Header getLastHeader(String s) {
        for (int i = this.headers.length - 1; i >= 0; i--) {
            if (this.headers[i].getName().equalsIgnoreCase(s)) {
                return this.headers[i];
            }
        }
        return null;
    }

    public Header[] getHeaders(String s) {
        List<Header> found = new ArrayList<>();
        for (Header h : this.headers) {
            if (h.getName().equalsIgnoreCase(s)) {
                found.add(h);
            }
        }
        return (Header[]) found.toArray(new Header[found.size()]);
    }

    public void addHeader(Header header) {
        List<Header> temp = new ArrayList<>();
        Collections.addAll(temp, this.headers);
        temp.add(header);
        this.headers = (Header[]) temp.toArray(new Header[temp.size()]);
    }

    public void setHeader(Header newHeader) {
        for (int i = 0; i < this.headers.length; i++) {
            if (this.headers[i].getName().equals(newHeader.getName())) {
                this.headers[i] = newHeader;
                return;
            }
        }
    }

    public HeaderIterator headerIterator() {
        return new HeaderIterator() {
            int index = 0;

            public boolean hasNext() {
                return this.index < TestHttpResponse.this.headers.length;
            }

            public Header nextHeader() {
                if (this.index >= TestHttpResponse.this.headers.length) {
                    throw new NoSuchElementException();
                }
                Header[] access$000 = TestHttpResponse.this.headers;
                int i = this.index;
                this.index = i + 1;
                return access$000[i];
            }

            public Object next() {
                return nextHeader();
            }

            public void remove() {
                throw new UnsupportedOperationException();
            }
        };
    }

    public HeaderIterator headerIterator(final String s) {
        return new HeaderIterator() {
            int index = 0;

            public boolean hasNext() {
                return nextIndex() != -1;
            }

            private int nextIndex() {
                for (int i = this.index; i < TestHttpResponse.this.headers.length; i++) {
                    if (TestHttpResponse.this.headers[i].getName().equalsIgnoreCase(s)) {
                        return i;
                    }
                }
                return -1;
            }

            public Header nextHeader() {
                this.index = nextIndex();
                if (this.index == -1) {
                    throw new NoSuchElementException();
                }
                Header[] access$000 = TestHttpResponse.this.headers;
                int i = this.index;
                this.index = i + 1;
                return access$000[i];
            }

            public Object next() {
                return nextHeader();
            }

            public void remove() {
                throw new UnsupportedOperationException();
            }
        };
    }

    public boolean containsHeader(String s) {
        return getFirstHeader(s) != null;
    }

    public HttpParams getParams() {
        return this.params;
    }

    public void setParams(HttpParams httpParams) {
        this.params = httpParams;
    }

    public boolean entityContentStreamsHaveBeenClosed() {
        return this.openEntityContentStreamCount == 0;
    }

    public class TestHttpEntity extends HttpEntityStub {
        private ByteArrayInputStream inputStream;

        public TestHttpEntity() {
        }

        public long getContentLength() {
            return (long) TestHttpResponse.this.responseBody.length;
        }

        public Header getContentType() {
            for (Header header : TestHttpResponse.this.headers) {
                if (header.getName().equals("Content-Type")) {
                    return header;
                }
            }
            return null;
        }

        public boolean isStreaming() {
            return true;
        }

        public boolean isRepeatable() {
            return true;
        }

        public InputStream getContent() throws IOException, IllegalStateException {
            TestHttpResponse.access$208(TestHttpResponse.this);
            this.inputStream = new ByteArrayInputStream(TestHttpResponse.this.responseBody) {
                public void close() throws IOException {
                    TestHttpResponse.access$210(TestHttpResponse.this);
                    super.close();
                }
            };
            return this.inputStream;
        }

        public void writeTo(OutputStream outputStream) throws IOException {
            outputStream.write(TestHttpResponse.this.responseBody);
        }

        public void consumeContent() throws IOException {
        }
    }

    public class TestStatusLine extends StatusLineStub {
        public TestStatusLine() {
        }

        public ProtocolVersion getProtocolVersion() {
            return new HttpVersion(1, 0);
        }

        public int getStatusCode() {
            return TestHttpResponse.this.statusCode;
        }

        public String getReasonPhrase() {
            return "HTTP status " + TestHttpResponse.this.statusCode;
        }

        public String toString() {
            return "TestStatusLine[" + getReasonPhrase() + "]";
        }
    }
}
