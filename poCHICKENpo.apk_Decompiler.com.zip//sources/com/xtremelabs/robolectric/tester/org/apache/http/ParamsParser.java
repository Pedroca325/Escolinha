package com.xtremelabs.robolectric.tester.org.apache.http;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Field;
import java.net.URI;
import java.net.URLDecoder;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.StringTokenizer;
import org.apache.http.HttpRequest;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpParams;
import org.apache.http.util.EntityUtils;

public class ParamsParser {
    public static Map<String, String> parseParams(HttpRequest request) {
        Map<String, String> params;
        String rawQuery = URI.create(request.getRequestLine().getUri()).getRawQuery();
        if (rawQuery != null) {
            params = parseParamsFromQuery(rawQuery);
        } else if (!(request instanceof HttpPost) || ((HttpPost) request).getEntity() == null) {
            HttpParams httpParams = request.getParams();
            if (httpParams instanceof BasicHttpParams) {
                return new LinkedHashMap<>((Map) getPrivateMember(httpParams, "parameters"));
            }
            throw new RuntimeException("Was expecting a " + BasicHttpParams.class.getName());
        } else {
            try {
                params = parseParamsFromQuery(EntityUtils.toString(((HttpPost) request).getEntity()));
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        return params;
    }

    private static Map<String, String> parseParamsFromQuery(String rawQuery) {
        String name;
        String value;
        Map<String, String> params = new LinkedHashMap<>();
        StringTokenizer tok = new StringTokenizer(rawQuery, "&", false);
        while (tok.hasMoreTokens()) {
            String nextParam = tok.nextToken();
            if (nextParam.contains("=")) {
                String[] nameAndValue = nextParam.split("=");
                name = nameAndValue[0];
                try {
                    value = URLDecoder.decode(nameAndValue[1], "UTF-8");
                } catch (UnsupportedEncodingException e) {
                    throw new RuntimeException(e);
                }
            } else {
                name = nextParam;
                value = "";
            }
            params.put(name, value);
        }
        return params;
    }

    private static <T> T getPrivateMember(Object obj, String name) {
        try {
            Field f = obj.getClass().getDeclaredField(name);
            f.setAccessible(true);
            return f.get(obj);
        } catch (NoSuchFieldException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException e2) {
            throw new RuntimeException(e2);
        }
    }
}
