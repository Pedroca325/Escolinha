package com.xtremelabs.robolectric.tester.org.apache.http;

import org.apache.http.HttpHost;
import org.apache.http.HttpRequest;
import org.apache.http.client.RequestDirector;
import org.apache.http.protocol.HttpContext;

public class HttpRequestInfo {
    HttpContext httpContext;
    HttpHost httpHost;
    HttpRequest httpRequest;
    RequestDirector requestDirector;

    public HttpRequestInfo(HttpRequest httpRequest2, HttpHost httpHost2, HttpContext httpContext2, RequestDirector requestDirector2) {
        this.httpRequest = httpRequest2;
        this.httpHost = httpHost2;
        this.httpContext = httpContext2;
        this.requestDirector = requestDirector2;
    }

    public HttpRequest getHttpRequest() {
        return this.httpRequest;
    }

    public HttpHost getHttpHost() {
        return this.httpHost;
    }

    public HttpContext getHttpContext() {
        return this.httpContext;
    }

    public RequestDirector getRequestDirector() {
        return this.requestDirector;
    }
}
