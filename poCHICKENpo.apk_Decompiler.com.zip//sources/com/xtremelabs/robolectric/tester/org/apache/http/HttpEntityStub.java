package com.xtremelabs.robolectric.tester.org.apache.http;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpException;
import org.apache.http.HttpRequest;
import org.apache.http.HttpResponse;

public class HttpEntityStub implements HttpEntity {

    public interface ResponseRule {
        HttpResponse getResponse() throws HttpException, IOException;

        boolean matches(HttpRequest httpRequest);
    }

    public boolean isRepeatable() {
        throw new UnsupportedOperationException();
    }

    public boolean isChunked() {
        throw new UnsupportedOperationException();
    }

    public long getContentLength() {
        throw new UnsupportedOperationException();
    }

    public Header getContentType() {
        throw new UnsupportedOperationException();
    }

    public Header getContentEncoding() {
        throw new UnsupportedOperationException();
    }

    public InputStream getContent() throws IOException, IllegalStateException {
        throw new UnsupportedOperationException();
    }

    public void writeTo(OutputStream outputStream) throws IOException {
        throw new UnsupportedOperationException();
    }

    public boolean isStreaming() {
        throw new UnsupportedOperationException();
    }

    public void consumeContent() throws IOException {
        throw new UnsupportedOperationException();
    }
}
