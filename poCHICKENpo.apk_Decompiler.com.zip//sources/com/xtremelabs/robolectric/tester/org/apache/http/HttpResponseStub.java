package com.xtremelabs.robolectric.tester.org.apache.http;

import java.util.Locale;
import org.apache.http.Header;
import org.apache.http.HeaderIterator;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.ProtocolVersion;
import org.apache.http.StatusLine;
import org.apache.http.params.HttpParams;

public class HttpResponseStub implements HttpResponse {
    public StatusLine getStatusLine() {
        throw new UnsupportedOperationException();
    }

    public void setStatusLine(StatusLine statusLine) {
        throw new UnsupportedOperationException();
    }

    public void setStatusLine(ProtocolVersion protocolVersion, int i) {
        throw new UnsupportedOperationException();
    }

    public void setStatusLine(ProtocolVersion protocolVersion, int i, String s) {
        throw new UnsupportedOperationException();
    }

    public void setStatusCode(int i) throws IllegalStateException {
        throw new UnsupportedOperationException();
    }

    public void setReasonPhrase(String s) throws IllegalStateException {
        throw new UnsupportedOperationException();
    }

    public HttpEntity getEntity() {
        throw new UnsupportedOperationException();
    }

    public void setEntity(HttpEntity httpEntity) {
        throw new UnsupportedOperationException();
    }

    public Locale getLocale() {
        throw new UnsupportedOperationException();
    }

    public void setLocale(Locale locale) {
        throw new UnsupportedOperationException();
    }

    public ProtocolVersion getProtocolVersion() {
        throw new UnsupportedOperationException();
    }

    public boolean containsHeader(String s) {
        throw new UnsupportedOperationException();
    }

    public Header[] getHeaders(String s) {
        throw new UnsupportedOperationException();
    }

    public Header getFirstHeader(String s) {
        throw new UnsupportedOperationException();
    }

    public Header getLastHeader(String s) {
        throw new UnsupportedOperationException();
    }

    public Header[] getAllHeaders() {
        throw new UnsupportedOperationException();
    }

    public void addHeader(Header header) {
        throw new UnsupportedOperationException();
    }

    public void addHeader(String s, String s1) {
        throw new UnsupportedOperationException();
    }

    public void setHeader(Header header) {
        throw new UnsupportedOperationException();
    }

    public void setHeader(String s, String s1) {
        throw new UnsupportedOperationException();
    }

    public void setHeaders(Header[] headers) {
        throw new UnsupportedOperationException();
    }

    public void removeHeader(Header header) {
        throw new UnsupportedOperationException();
    }

    public void removeHeaders(String s) {
        throw new UnsupportedOperationException();
    }

    public HeaderIterator headerIterator() {
        throw new UnsupportedOperationException();
    }

    public HeaderIterator headerIterator(String s) {
        throw new UnsupportedOperationException();
    }

    public HttpParams getParams() {
        throw new UnsupportedOperationException();
    }

    public void setParams(HttpParams httpParams) {
        throw new UnsupportedOperationException();
    }
}
