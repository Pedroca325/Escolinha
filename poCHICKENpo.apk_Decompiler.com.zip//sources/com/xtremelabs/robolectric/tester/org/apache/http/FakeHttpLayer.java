package com.xtremelabs.robolectric.tester.org.apache.http;

import br.com.tectoy.pochickenpo.core.Constants;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.shadows.HttpResponseGenerator;
import com.xtremelabs.robolectric.tester.org.apache.http.HttpEntityStub;
import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpException;
import org.apache.http.HttpHost;
import org.apache.http.HttpRequest;
import org.apache.http.HttpResponse;
import org.apache.http.client.RequestDirector;
import org.apache.http.client.methods.HttpEntityEnclosingRequestBase;
import org.apache.http.conn.ConnectTimeoutException;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.protocol.HttpContext;

public class FakeHttpLayer {
    HttpResponse defaultHttpResponse;
    private HttpResponse defaultResponse;
    List<HttpRequestInfo> httpRequestInfos = new ArrayList();
    List<HttpEntityStub.ResponseRule> httpResponseRules = new ArrayList();
    private boolean interceptHttpRequests = true;
    List<HttpResponseGenerator> pendingHttpResponses = new ArrayList();

    public HttpRequestInfo getLastSentHttpRequestInfo() {
        List<HttpRequestInfo> requestInfos = Robolectric.getFakeHttpLayer().getSentHttpRequestInfos();
        if (requestInfos.isEmpty()) {
            return null;
        }
        return requestInfos.get(requestInfos.size() - 1);
    }

    public void addPendingHttpResponse(int statusCode, String responseBody, Header... headers) {
        addPendingHttpResponse((HttpResponse) new TestHttpResponse(statusCode, responseBody, headers));
    }

    public void addPendingHttpResponse(final HttpResponse httpResponse) {
        addPendingHttpResponse((HttpResponseGenerator) new HttpResponseGenerator() {
            public HttpResponse getResponse(HttpRequest request) {
                return httpResponse;
            }
        });
    }

    public void addPendingHttpResponse(HttpResponseGenerator httpResponseGenerator) {
        this.pendingHttpResponses.add(httpResponseGenerator);
    }

    public void addHttpResponseRule(String method, String uri, HttpResponse response) {
        addHttpResponseRule((RequestMatcher) new DefaultRequestMatcher(method, uri), response);
    }

    public void addHttpResponseRule(String uri, HttpResponse response) {
        addHttpResponseRule((RequestMatcher) new UriRequestMatcher(uri), response);
    }

    public void addHttpResponseRule(String uri, String response) {
        addHttpResponseRule((RequestMatcher) new UriRequestMatcher(uri), (HttpResponse) new TestHttpResponse(Constants.DELAY_ANIM2_PARADA, response));
    }

    public void addHttpResponseRule(RequestMatcher requestMatcher, HttpResponse response) {
        addHttpResponseRule(new RequestMatcherResponseRule(requestMatcher, response));
    }

    public void addHttpResponseRule(RequestMatcher requestMatcher, List<? extends HttpResponse> responses) {
        addHttpResponseRule(new RequestMatcherResponseRule(requestMatcher, responses));
    }

    public void addHttpResponseRule(HttpEntityStub.ResponseRule responseRule) {
        this.httpResponseRules.add(0, responseRule);
    }

    public void setDefaultHttpResponse(HttpResponse defaultHttpResponse2) {
        this.defaultHttpResponse = defaultHttpResponse2;
    }

    public void setDefaultHttpResponse(int statusCode, String responseBody) {
        setDefaultHttpResponse(new TestHttpResponse(statusCode, responseBody));
    }

    private HttpResponse findResponse(HttpRequest httpRequest) throws HttpException, IOException {
        if (!this.pendingHttpResponses.isEmpty()) {
            return this.pendingHttpResponses.remove(0).getResponse(httpRequest);
        }
        for (HttpEntityStub.ResponseRule httpResponseRule : this.httpResponseRules) {
            if (httpResponseRule.matches(httpRequest)) {
                return httpResponseRule.getResponse();
            }
        }
        return this.defaultHttpResponse;
    }

    public HttpResponse emulateRequest(HttpHost httpHost, HttpRequest httpRequest, HttpContext httpContext, RequestDirector requestDirector) throws HttpException, IOException {
        HttpResponse httpResponse = findResponse(httpRequest);
        if (httpResponse == null) {
            throw new RuntimeException("Unexpected call to execute, no pending responses are available. See Robolectric.addPendingResponse(). Request was: " + httpRequest.getRequestLine().getMethod() + " " + httpRequest.getRequestLine().getUri());
        }
        HttpParams params = httpResponse.getParams();
        if (HttpConnectionParams.getConnectionTimeout(params) < 0) {
            throw new ConnectTimeoutException("Socket is not connected");
        } else if (HttpConnectionParams.getSoTimeout(params) < 0) {
            throw new ConnectTimeoutException("The operation timed out");
        } else {
            this.httpRequestInfos.add(new HttpRequestInfo(httpRequest, httpHost, httpContext, requestDirector));
            return httpResponse;
        }
    }

    public boolean hasPendingResponses() {
        return !this.pendingHttpResponses.isEmpty();
    }

    public boolean hasRequestInfos() {
        return !this.httpRequestInfos.isEmpty();
    }

    public void clearRequestInfos() {
        this.httpRequestInfos.clear();
    }

    public boolean hasResponseRules() {
        return !this.httpResponseRules.isEmpty();
    }

    public boolean hasRequestMatchingRule(RequestMatcher rule) {
        for (HttpRequestInfo requestInfo : this.httpRequestInfos) {
            if (rule.matches(requestInfo.httpRequest)) {
                return true;
            }
        }
        return false;
    }

    public HttpResponse getDefaultResponse() {
        return this.defaultResponse;
    }

    public HttpRequestInfo getSentHttpRequestInfo(int index) {
        return this.httpRequestInfos.get(index);
    }

    public List<HttpRequestInfo> getSentHttpRequestInfos() {
        return new ArrayList(this.httpRequestInfos);
    }

    public void clearHttpResponseRules() {
        this.httpResponseRules.clear();
    }

    public void clearPendingHttpResponses() {
        this.pendingHttpResponses.clear();
    }

    public void interceptHttpRequests(boolean interceptHttpRequests2) {
        this.interceptHttpRequests = interceptHttpRequests2;
    }

    public boolean isInterceptingHttpRequests() {
        return this.interceptHttpRequests;
    }

    public static class RequestMatcherResponseRule implements HttpEntityStub.ResponseRule {
        private HttpException httpException;
        private IOException ioException;
        private RequestMatcher requestMatcher;
        private HttpResponse responseToGive;
        private List<? extends HttpResponse> responses;

        public RequestMatcherResponseRule(RequestMatcher requestMatcher2, HttpResponse responseToGive2) {
            this.requestMatcher = requestMatcher2;
            this.responseToGive = responseToGive2;
        }

        public RequestMatcherResponseRule(RequestMatcher requestMatcher2, IOException ioException2) {
            this.requestMatcher = requestMatcher2;
            this.ioException = ioException2;
        }

        public RequestMatcherResponseRule(RequestMatcher requestMatcher2, HttpException httpException2) {
            this.requestMatcher = requestMatcher2;
            this.httpException = httpException2;
        }

        public RequestMatcherResponseRule(RequestMatcher requestMatcher2, List<? extends HttpResponse> responses2) {
            this.requestMatcher = requestMatcher2;
            this.responses = responses2;
        }

        public boolean matches(HttpRequest request) {
            return this.requestMatcher.matches(request);
        }

        public HttpResponse getResponse() throws HttpException, IOException {
            if (this.httpException != null) {
                throw this.httpException;
            } else if (this.ioException != null) {
                throw this.ioException;
            } else if (this.responseToGive != null) {
                return this.responseToGive;
            } else {
                if (!this.responses.isEmpty()) {
                    return this.responses.remove(0);
                }
                throw new RuntimeException("No more responses left to give");
            }
        }
    }

    public static class DefaultRequestMatcher implements RequestMatcher {
        private String method;
        private String uri;

        public DefaultRequestMatcher(String method2, String uri2) {
            this.method = method2;
            this.uri = uri2;
        }

        public boolean matches(HttpRequest request) {
            return request.getRequestLine().getMethod().equals(this.method) && request.getRequestLine().getUri().equals(this.uri);
        }
    }

    public static class UriRequestMatcher implements RequestMatcher {
        private String uri;

        public UriRequestMatcher(String uri2) {
            this.uri = uri2;
        }

        public boolean matches(HttpRequest request) {
            return request.getRequestLine().getUri().equals(this.uri);
        }
    }

    public static class RequestMatcherBuilder implements RequestMatcher {
        private Map<String, String> headers = new HashMap();
        private String hostname;
        private String method;
        private boolean noParams;
        private Map<String, String> params = new HashMap();
        private String path;
        private PostBodyMatcher postBodyMatcher;

        public interface PostBodyMatcher {
            boolean matches(HttpEntity httpEntity) throws IOException;
        }

        public RequestMatcherBuilder method(String method2) {
            this.method = method2;
            return this;
        }

        public RequestMatcherBuilder host(String hostname2) {
            this.hostname = hostname2;
            return this;
        }

        public RequestMatcherBuilder path(String path2) {
            if (path2.startsWith("/")) {
                throw new RuntimeException("Path should not start with '/'");
            }
            this.path = "/" + path2;
            return this;
        }

        public RequestMatcherBuilder param(String name, String value) {
            this.params.put(name, value);
            return this;
        }

        public RequestMatcherBuilder noParams() {
            this.noParams = true;
            return this;
        }

        public RequestMatcherBuilder postBody(PostBodyMatcher postBodyMatcher2) {
            this.postBodyMatcher = postBodyMatcher2;
            return this;
        }

        public RequestMatcherBuilder header(String name, String value) {
            this.headers.put(name, value);
            return this;
        }

        public boolean matches(HttpRequest request) {
            URI uri = URI.create(request.getRequestLine().getUri());
            if (this.method != null && !this.method.equals(request.getRequestLine().getMethod())) {
                return false;
            }
            if (this.hostname != null && !this.hostname.equals(uri.getHost())) {
                return false;
            }
            if (this.path != null && !this.path.equals(uri.getRawPath())) {
                return false;
            }
            if (this.noParams && !uri.getRawQuery().equals((Object) null)) {
                return false;
            }
            if (this.params.size() > 0 && !ParamsParser.parseParams(request).equals(this.params)) {
                return false;
            }
            if (this.headers.size() > 0) {
                Map<String, String> actualRequestHeaders = new HashMap<>();
                for (Header header : request.getAllHeaders()) {
                    actualRequestHeaders.put(header.getName(), header.getValue());
                }
                if (!this.headers.equals(actualRequestHeaders)) {
                    return false;
                }
            }
            if (this.postBodyMatcher != null) {
                if (!(request instanceof HttpEntityEnclosingRequestBase)) {
                    return false;
                }
                try {
                    if (this.postBodyMatcher.matches(((HttpEntityEnclosingRequestBase) request).getEntity())) {
                        return true;
                    }
                    return false;
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            return true;
        }

        /* access modifiers changed from: package-private */
        public String getHostname() {
            return this.hostname;
        }

        /* access modifiers changed from: package-private */
        public String getPath() {
            return this.path;
        }

        /* access modifiers changed from: package-private */
        public String getParam(String key) {
            return this.params.get(key);
        }

        /* access modifiers changed from: package-private */
        public String getHeader(String key) {
            return this.headers.get(key);
        }

        /* access modifiers changed from: package-private */
        public boolean isNoParams() {
            return this.noParams;
        }

        /* access modifiers changed from: package-private */
        public String getMethod() {
            return this.method;
        }
    }

    public static class UriRegexMatcher implements RequestMatcher {
        private String method;
        private final Pattern uriRegex;

        public UriRegexMatcher(String method2, String uriRegex2) {
            this.method = method2;
            this.uriRegex = Pattern.compile(uriRegex2);
        }

        public boolean matches(HttpRequest request) {
            return request.getRequestLine().getMethod().equals(this.method) && this.uriRegex.matcher(request.getRequestLine().getUri()).matches();
        }
    }
}
