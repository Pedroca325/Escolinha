package com.xtremelabs.robolectric.matchers;

import android.widget.TextView;
import org.hamcrest.Description;
import org.hamcrest.Factory;
import org.hamcrest.Matcher;
import org.junit.internal.matchers.TypeSafeMatcher;

public class TextViewHasTextMatcher<T extends TextView> extends TypeSafeMatcher<T> {
    private String actualText;
    private String expected;

    public TextViewHasTextMatcher(String expected2) {
        this.expected = expected2;
    }

    public boolean matchesSafely(T actual) {
        CharSequence charSequence;
        if (actual == null || (charSequence = actual.getText()) == null || charSequence.toString() == null) {
            return false;
        }
        this.actualText = charSequence.toString();
        return this.actualText.equals(this.expected);
    }

    public void describeTo(Description description) {
        description.appendText("[" + this.actualText + "]");
        description.appendText(" to equal ");
        description.appendText("[" + this.expected + "]");
    }

    @Factory
    public static <T extends TextView> Matcher<T> hasText(String expectedTextViewText) {
        return new TextViewHasTextMatcher(expectedTextViewText);
    }
}
