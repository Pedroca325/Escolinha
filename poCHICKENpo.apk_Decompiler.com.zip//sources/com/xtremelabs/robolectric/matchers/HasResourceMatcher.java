package com.xtremelabs.robolectric.matchers;

import android.widget.ImageView;
import com.xtremelabs.robolectric.Robolectric;
import org.hamcrest.Description;
import org.hamcrest.Factory;
import org.hamcrest.Matcher;
import org.junit.internal.matchers.TypeSafeMatcher;

public class HasResourceMatcher extends TypeSafeMatcher<ImageView> {
    private Integer actualResourceId;
    private int expectedResourceId;

    public HasResourceMatcher(int expectedResourceId2) {
        this.expectedResourceId = expectedResourceId2;
    }

    public boolean matchesSafely(ImageView actual) {
        if (actual == null) {
            return false;
        }
        this.actualResourceId = Integer.valueOf(Robolectric.shadowOf(actual).getResourceId());
        if (this.actualResourceId.intValue() == this.expectedResourceId) {
            return true;
        }
        return false;
    }

    public void describeTo(Description description) {
        if (this.actualResourceId == null) {
            description.appendText("actual view was null");
            return;
        }
        description.appendText("[" + this.actualResourceId + "]");
        description.appendText(" to equal ");
        description.appendText("[" + this.expectedResourceId + "]");
    }

    @Factory
    public static Matcher<ImageView> hasResource(int expectedResourceId2) {
        return new HasResourceMatcher(expectedResourceId2);
    }
}
