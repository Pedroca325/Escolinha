package com.xtremelabs.robolectric.matchers;

import android.app.Service;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.shadows.ShadowIntent;
import org.hamcrest.Description;
import org.junit.internal.matchers.TypeSafeMatcher;

public class StartedServiceMatcher extends TypeSafeMatcher<Context> {
    private final Intent expectedIntent;
    private String message;

    public StartedServiceMatcher(Intent expectedIntent2) {
        this.expectedIntent = expectedIntent2;
    }

    public StartedServiceMatcher(String packageName, Class<? extends Service> expectedServiceClass) {
        this(createIntent(packageName, expectedServiceClass));
    }

    public StartedServiceMatcher(Class<? extends Service> expectedServiceClass) {
        this(createIntent(expectedServiceClass));
    }

    public StartedServiceMatcher(Class<? extends Service> expectedServiceClass, String expectedAction) {
        this(createIntent(expectedServiceClass));
        this.expectedIntent.setAction(expectedAction);
    }

    public boolean matchesSafely(Context actualContext) {
        boolean intentsMatch = false;
        if (this.expectedIntent == null) {
            this.message = "null intent (did you mean to expect null?)";
        } else {
            this.message = "to start " + this.expectedIntent.toString() + ", but ";
            Intent actualStartedIntent = Robolectric.shadowOf((ContextWrapper) actualContext).getNextStartedService();
            if (actualStartedIntent == null) {
                this.message += "didn't start anything";
            } else {
                ShadowIntent shadowIntent = Robolectric.shadowOf(actualStartedIntent);
                intentsMatch = Robolectric.shadowOf(this.expectedIntent).getIntentClass().equals(shadowIntent.getIntentClass());
                if (!intentsMatch) {
                    this.message += "started " + actualStartedIntent;
                } else {
                    intentsMatch = shadowIntent.getExtras().keySet().equals(Robolectric.shadowOf(this.expectedIntent).getExtras().keySet());
                    if (!intentsMatch) {
                        this.message += "did not get the same extras keys";
                    }
                }
            }
        }
        return intentsMatch;
    }

    public void describeTo(Description description) {
        description.appendText(this.message);
    }

    public static Intent createIntent(Class<? extends Service> serviceClass, String extraKey, String extraValue) {
        Intent intent = createIntent(serviceClass);
        intent.putExtra(extraKey, extraValue);
        return intent;
    }

    public static Intent createIntent(Class<? extends Service> serviceClass, String action) {
        Intent intent = createIntent(serviceClass);
        intent.setAction(action);
        return intent;
    }

    public static Intent createIntent(Class<? extends Service> serviceClass) {
        Package pack = serviceClass.getPackage();
        if (pack != null) {
            pack.getName();
        }
        return createIntent("android.service", serviceClass);
    }

    public static Intent createIntent(String packageName, Class<? extends Service> serviceClass) {
        Intent intent = new Intent();
        intent.setClassName(packageName, serviceClass.getName());
        intent.setClass(Robolectric.getShadowApplication().getApplicationContext(), serviceClass);
        return intent;
    }
}
