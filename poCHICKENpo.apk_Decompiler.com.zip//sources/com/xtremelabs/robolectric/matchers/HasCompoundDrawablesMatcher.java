package com.xtremelabs.robolectric.matchers;

import android.widget.TextView;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.shadows.ShadowTextView;
import org.hamcrest.Description;
import org.hamcrest.Factory;
import org.hamcrest.Matcher;
import org.junit.internal.matchers.TypeSafeMatcher;

public class HasCompoundDrawablesMatcher extends TypeSafeMatcher<TextView> {
    private ShadowTextView.CompoundDrawables expectedCompoundDrawables;
    private String message;

    public HasCompoundDrawablesMatcher(int left, int top, int right, int bottom) {
        this.expectedCompoundDrawables = new ShadowTextView.CompoundDrawables(left, top, right, bottom);
    }

    public boolean matchesSafely(TextView actual) {
        if (actual == null) {
            this.message = "actual view was null";
            return false;
        }
        ShadowTextView.CompoundDrawables actualCompoundDrawables = Robolectric.shadowOf(actual).getCompoundDrawablesImpl();
        if (this.expectedCompoundDrawables.equals(actualCompoundDrawables)) {
            return true;
        }
        this.message = "[" + actualCompoundDrawables + "] to equal [" + this.expectedCompoundDrawables + "]";
        return false;
    }

    public void describeTo(Description description) {
        description.appendText(this.message);
    }

    @Factory
    public static Matcher<TextView> hasCompoundDrawables(int left, int top, int right, int bottom) {
        return new HasCompoundDrawablesMatcher(left, top, right, bottom);
    }
}
