package com.xtremelabs.robolectric.matchers;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import com.xtremelabs.robolectric.Robolectric;
import org.hamcrest.Description;
import org.junit.internal.matchers.TypeSafeMatcher;

public class StartedMatcher extends TypeSafeMatcher<Context> {
    private final Intent expectedIntent;
    private String message;

    public StartedMatcher(Intent expectedIntent2) {
        this.expectedIntent = expectedIntent2;
    }

    public StartedMatcher(String packageName, Class<? extends Activity> expectedActivityClass) {
        this(createIntent(packageName, expectedActivityClass));
    }

    public StartedMatcher(Class<? extends Activity> expectedActivityClass) {
        this(createIntent(expectedActivityClass));
    }

    public StartedMatcher(Class<? extends Activity> expectedActivityClass, String expectedAction) {
        this(createIntent(expectedActivityClass));
        this.expectedIntent.setAction(expectedAction);
    }

    public boolean matchesSafely(Context actualContext) {
        boolean intentsMatch = false;
        if (this.expectedIntent == null) {
            this.message = "null intent (did you mean to expect null?)";
        } else {
            this.message = "to start " + this.expectedIntent.toString() + ", but ";
            Intent actualStartedIntent = Robolectric.shadowOf((ContextWrapper) actualContext).getNextStartedActivity();
            if (actualStartedIntent == null) {
                this.message += "didn't start anything";
            } else {
                intentsMatch = Robolectric.shadowOf(this.expectedIntent).realIntentEquals(Robolectric.shadowOf(actualStartedIntent));
                if (!intentsMatch) {
                    this.message += "started " + actualStartedIntent;
                }
            }
        }
        return intentsMatch;
    }

    public void describeTo(Description description) {
        description.appendText(this.message);
    }

    public static Intent createIntent(Class<? extends Activity> activityClass, String extraKey, String extraValue) {
        Intent intent = createIntent(activityClass);
        intent.putExtra(extraKey, extraValue);
        return intent;
    }

    public static Intent createIntent(Class<? extends Activity> activityClass, String action) {
        Intent intent = createIntent(activityClass);
        intent.setAction(action);
        return intent;
    }

    public static Intent createIntent(Class<? extends Activity> activityClass) {
        return createIntent(activityClass.getPackage().getName(), activityClass);
    }

    public static Intent createIntent(String packageName, Class<? extends Activity> activityClass) {
        Intent intent = new Intent();
        intent.setClassName(packageName, activityClass.getName());
        return intent;
    }
}
