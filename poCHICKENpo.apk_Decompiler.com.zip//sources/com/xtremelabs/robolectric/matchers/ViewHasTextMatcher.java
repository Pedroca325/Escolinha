package com.xtremelabs.robolectric.matchers;

import android.view.View;
import com.xtremelabs.robolectric.Robolectric;
import org.hamcrest.Description;
import org.hamcrest.Factory;
import org.hamcrest.Matcher;
import org.junit.internal.matchers.TypeSafeMatcher;

public class ViewHasTextMatcher<T extends View> extends TypeSafeMatcher<T> {
    private String actualText;
    private String expected;
    private int expectedResourceId;

    public ViewHasTextMatcher(String expected2) {
        this.expected = expected2;
        this.expectedResourceId = -1;
    }

    public ViewHasTextMatcher(int expectedResourceId2) {
        this.expected = null;
        this.expectedResourceId = expectedResourceId2;
    }

    public boolean matchesSafely(View actual) {
        if (actual == null) {
            return false;
        }
        if (this.expectedResourceId != -1) {
            this.expected = actual.getContext().getResources().getString(this.expectedResourceId);
        }
        CharSequence charSequence = Robolectric.shadowOf(actual).innerText();
        if (charSequence == null || charSequence.toString() == null) {
            return false;
        }
        this.actualText = charSequence.toString();
        return this.actualText.equals(this.expected);
    }

    public void describeTo(Description description) {
        description.appendText("[" + this.actualText + "]");
        description.appendText(" to equal ");
        description.appendText("[" + this.expected + "]");
    }

    @Factory
    public static <T extends View> Matcher<T> hasText(String expectedTextViewText) {
        return new ViewHasTextMatcher(expectedTextViewText);
    }

    @Factory
    public static <T extends View> Matcher<T> hasText(int expectedTextViewResourceId) {
        return new ViewHasTextMatcher(expectedTextViewResourceId);
    }
}
