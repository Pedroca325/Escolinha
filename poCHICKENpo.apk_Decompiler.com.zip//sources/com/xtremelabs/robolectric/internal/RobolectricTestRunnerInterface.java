package com.xtremelabs.robolectric.internal;

import com.xtremelabs.robolectric.RobolectricConfig;
import com.xtremelabs.robolectric.util.DatabaseConfig;
import java.lang.reflect.Method;

public interface RobolectricTestRunnerInterface {
    Object createTest() throws Exception;

    void internalAfterTest(Method method);

    void internalBeforeTest(Method method);

    void setDatabaseMap(DatabaseConfig.DatabaseMap databaseMap);

    void setRobolectricConfig(RobolectricConfig robolectricConfig);
}
