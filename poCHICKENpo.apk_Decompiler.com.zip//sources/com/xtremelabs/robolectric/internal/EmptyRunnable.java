package com.xtremelabs.robolectric.internal;

public class EmptyRunnable implements Runnable {
    public void run() {
    }
}
