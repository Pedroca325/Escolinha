package com.xtremelabs.robolectric.internal;

import android.app.Application;
import android.content.Context;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.shadows.ShadowApplication;

public abstract class AppSingletonizer<T> {
    private Class<T> clazz;

    /* access modifiers changed from: protected */
    public abstract T get(ShadowApplication shadowApplication);

    /* access modifiers changed from: protected */
    public abstract void set(ShadowApplication shadowApplication, T t);

    public AppSingletonizer(Class<T> clazz2) {
        this.clazz = clazz2;
    }

    public synchronized T getInstance(Context context) {
        T instance;
        Application applicationContext = (Application) context.getApplicationContext();
        ShadowApplication shadowApplication = Robolectric.shadowOf(applicationContext);
        instance = get(shadowApplication);
        if (instance == null) {
            instance = createInstance(applicationContext);
            set(shadowApplication, instance);
        }
        return instance;
    }

    /* access modifiers changed from: protected */
    public T createInstance(Application applicationContext) {
        return Robolectric.newInstanceOf(this.clazz);
    }
}
