package com.xtremelabs.robolectric.internal;

public class ClassNameResolver<T> {
    private String className;
    private String packageName;

    public ClassNameResolver(String packageName2, String className2) {
        this.packageName = packageName2;
        this.className = className2;
    }

    public Class<? extends T> resolve() {
        Class<? extends T> aClass;
        if (looksFullyQualified(this.className)) {
            aClass = safeClassForName(this.className);
        } else {
            aClass = safeClassForName(this.packageName + "." + this.className);
            if (aClass == null) {
                aClass = safeClassForName(this.packageName + this.className);
            }
        }
        if (aClass != null) {
            return aClass;
        }
        throw new RuntimeException("Could not find a class for package: " + this.packageName + " and class name: " + this.className);
    }

    private boolean looksFullyQualified(String className2) {
        return className2.contains(".") && !className2.startsWith(".");
    }

    private Class<? extends T> safeClassForName(String classNamePath) {
        try {
            return Class.forName(classNamePath);
        } catch (ClassNotFoundException e) {
            return null;
        }
    }
}
