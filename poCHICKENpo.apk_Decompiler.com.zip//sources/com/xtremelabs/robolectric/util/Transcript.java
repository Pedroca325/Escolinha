package com.xtremelabs.robolectric.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.junit.Assert;

public class Transcript {
    private List<String> events = new ArrayList();

    public void add(String event) {
        this.events.add(event);
    }

    public void assertNoEventsSoFar() {
        Assert.assertEquals("Expected no events but got " + this.events + ".", 0, (long) this.events.size());
    }

    public void assertEventsSoFar(String... expectedEvents) {
        Assert.assertEquals(Arrays.asList(expectedEvents), this.events);
        this.events.clear();
    }

    public void clear() {
        this.events.clear();
    }

    public List<String> getEvents() {
        return this.events;
    }
}
