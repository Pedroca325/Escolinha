package com.xtremelabs.robolectric.util;

import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConfig {
    private static DatabaseMap dbMap = null;
    private static boolean isLoaded = false;

    public interface DatabaseMap {
        String getConnectionString();

        String getDriverClassName();

        int getResultSetType();

        String getScrubSQL(String str) throws SQLException;

        String getSelectLastInsertIdentity();
    }

    @Inherited
    @Target({ElementType.TYPE})
    @Retention(RetentionPolicy.RUNTIME)
    public @interface UsingDatabaseMap {
        Class<? extends DatabaseMap> value();
    }

    public static void setDatabaseMap(DatabaseMap map) {
        dbMap = map;
        isLoaded = false;
    }

    public static DatabaseMap getDatabaseMap() {
        return dbMap;
    }

    public static boolean isMapLoaded() {
        return isLoaded;
    }

    public static boolean isMapNull() {
        return dbMap == null;
    }

    private static void LoadSQLiteDriver() {
        if (isMapNull()) {
            throw new NullDatabaseMapException("Error in DatabaseConfig: DatabaseMap has not been set.");
        }
        try {
            Class.forName(dbMap.getDriverClassName()).newInstance();
            isLoaded = true;
        } catch (InstantiationException e) {
            throw new CannotLoadDatabaseMapDriverException("Error in DatabaseConfig: SQLite driver could not be instantiated;", e);
        } catch (IllegalAccessException e2) {
            throw new CannotLoadDatabaseMapDriverException("Error in DatabaseConfig: SQLite driver could not be accessed;", e2);
        } catch (ClassNotFoundException e3) {
            throw new CannotLoadDatabaseMapDriverException("Error in DatabaseConfig: SQLite driver class could not be found;", e3);
        }
    }

    public static Connection getMemoryConnection() {
        if (!isMapLoaded()) {
            LoadSQLiteDriver();
        }
        try {
            return DriverManager.getConnection(dbMap.getConnectionString());
        } catch (SQLException e) {
            throw new CannotLoadDatabaseMapDriverException("Error in DatabaseConfig, could not retrieve connection to in memory database.", e);
        }
    }

    public static String getScrubSQL(String sql) throws SQLException {
        if (!isMapNull()) {
            return dbMap.getScrubSQL(sql);
        }
        throw new NullDatabaseMapException("No database map set!");
    }

    public static String getSelectLastInsertIdentity() {
        if (!isMapNull()) {
            return dbMap.getSelectLastInsertIdentity();
        }
        throw new NullDatabaseMapException("No database map set!");
    }

    public static int getResultSetType() {
        if (!isMapNull()) {
            return dbMap.getResultSetType();
        }
        throw new NullDatabaseMapException("No database map set!");
    }

    public static class NullDatabaseMapException extends RuntimeException {
        private static final long serialVersionUID = -4580960157495617424L;

        public NullDatabaseMapException(String message) {
            super(message);
        }
    }

    public static class CannotLoadDatabaseMapDriverException extends RuntimeException {
        private static final long serialVersionUID = 2614876121296128364L;

        public CannotLoadDatabaseMapDriverException(String message, Throwable cause) {
            super(message, cause);
        }
    }
}
