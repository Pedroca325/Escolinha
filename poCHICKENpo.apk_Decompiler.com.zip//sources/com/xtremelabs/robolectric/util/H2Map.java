package com.xtremelabs.robolectric.util;

import com.xtremelabs.robolectric.util.DatabaseConfig;
import java.sql.DriverManager;
import java.sql.SQLException;

public class H2Map implements DatabaseConfig.DatabaseMap {
    public String getDriverClassName() {
        return "org.h2.Driver";
    }

    public String getConnectionString() {
        return "jdbc:h2:mem:";
    }

    public String getScrubSQL(String sql) throws SQLException {
        if (!sql.contains("PRIMARY KEY AUTOINCREMENT") || sql.contains("INTEGER PRIMARY KEY AUTOINCREMENT")) {
            return sql.replaceAll("(?i:autoincrement)", "auto_increment").replaceAll("(?i:integer)", "bigint(19)").replaceAll("INSERT OR ROLLBACK INTO", "INSERT INTO").replaceAll("INSERT OR ABORT INTO", "INSERT INTO").replaceAll("INSERT OR FAIL INTO", "INSERT INTO").replaceAll("INSERT OR IGNORE INTO", "INSERT INTO").replaceAll("INSERT OR REPLACE INTO", "INSERT INTO");
        }
        throw new SQLException("AUTOINCREMENT is only allowed on an INTEGER PRIMARY KEY");
    }

    public String getSelectLastInsertIdentity() {
        return "SELECT IDENTITY();";
    }

    public void DeregisterDriver() {
        try {
            DriverManager.deregisterDriver(DriverManager.getDriver(getDriverClassName()));
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    /* access modifiers changed from: protected */
    public void finalize() throws Throwable {
        super.finalize();
        DeregisterDriver();
    }

    public int getResultSetType() {
        return 1004;
    }
}
