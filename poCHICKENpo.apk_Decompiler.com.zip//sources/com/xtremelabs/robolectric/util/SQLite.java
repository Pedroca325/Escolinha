package com.xtremelabs.robolectric.util;

import android.content.ContentValues;
import android.database.sqlite.SQLiteException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class SQLite {
    private static final String[] CONFLICT_VALUES = {"", "OR ROLLBACK ", "OR ABORT ", "OR FAIL ", "OR IGNORE ", "OR REPLACE "};

    public static SQLStringAndBindings buildInsertString(String table, ContentValues values, int conflictAlgorithm) throws SQLException {
        StringBuilder sb = new StringBuilder();
        sb.append("INSERT ");
        sb.append(CONFLICT_VALUES[conflictAlgorithm]);
        sb.append("INTO ");
        sb.append(table);
        sb.append(" ");
        SQLStringAndBindings columnsValueClause = buildColumnValuesClause(values);
        sb.append(columnsValueClause.sql);
        sb.append(";");
        return new SQLStringAndBindings(DatabaseConfig.getScrubSQL(sb.toString()), columnsValueClause.columnValues);
    }

    public static SQLStringAndBindings buildUpdateString(String table, ContentValues values, String whereClause, String[] whereArgs) {
        StringBuilder sb = new StringBuilder();
        sb.append("UPDATE ");
        sb.append(table);
        sb.append(" SET ");
        SQLStringAndBindings columnAssignmentsClause = buildColumnAssignmentsClause(values);
        sb.append(columnAssignmentsClause.sql);
        if (whereClause != null) {
            String where = whereClause;
            if (whereArgs != null) {
                where = buildWhereClause(whereClause, whereArgs);
            }
            sb.append(" WHERE ");
            sb.append(where);
        }
        sb.append(";");
        return new SQLStringAndBindings(sb.toString(), columnAssignmentsClause.columnValues);
    }

    public static String buildDeleteString(String table, String whereClause, String[] whereArgs) {
        StringBuilder sb = new StringBuilder();
        sb.append("DELETE FROM ");
        sb.append(table);
        if (whereClause != null) {
            String where = whereClause;
            if (whereArgs != null) {
                where = buildWhereClause(whereClause, whereArgs);
            }
            sb.append(" WHERE ");
            sb.append(where);
        }
        sb.append(";");
        return sb.toString();
    }

    public static String buildWhereClause(String selection, String[] selectionArgs) throws SQLiteException {
        String whereClause = selection;
        int argsNeeded = 0;
        int args = 0;
        for (char c : selection.toCharArray()) {
            if (c == '?') {
                argsNeeded++;
            }
        }
        if (selectionArgs != null) {
            for (int x = 0; x < selectionArgs.length; x++) {
                if (selectionArgs[x] == null) {
                    throw new IllegalArgumentException("the bind value at index " + x + " is null");
                }
                args++;
                whereClause = whereClause.replaceFirst("\\?", "'" + selectionArgs[x] + "'");
            }
        }
        if (argsNeeded == args) {
            return whereClause;
        }
        throw new SQLiteException("bind or column index out of range: count of selectionArgs does not match count of (?) placeholders for given sql statement!");
    }

    public static SQLStringAndBindings buildColumnValuesClause(ContentValues values) {
        StringBuilder clause = new StringBuilder("(");
        List<Object> columnValues = new ArrayList<>(values.size());
        Iterator<Map.Entry<String, Object>> itemEntries = values.valueSet().iterator();
        while (itemEntries.hasNext()) {
            Map.Entry<String, Object> entry = itemEntries.next();
            clause.append(entry.getKey());
            if (itemEntries.hasNext()) {
                clause.append(", ");
            }
            columnValues.add(entry.getValue());
        }
        clause.append(") VALUES (");
        for (int i = 0; i < values.size() - 1; i++) {
            clause.append("?, ");
        }
        clause.append("?)");
        return new SQLStringAndBindings(clause.toString(), columnValues);
    }

    public static SQLStringAndBindings buildColumnAssignmentsClause(ContentValues values) {
        StringBuilder clause = new StringBuilder();
        List<Object> columnValues = new ArrayList<>(values.size());
        Iterator<Map.Entry<String, Object>> itemsEntries = values.valueSet().iterator();
        while (itemsEntries.hasNext()) {
            Map.Entry<String, Object> entry = itemsEntries.next();
            clause.append(entry.getKey());
            clause.append("=?");
            if (itemsEntries.hasNext()) {
                clause.append(", ");
            }
            columnValues.add(entry.getValue());
        }
        return new SQLStringAndBindings(clause.toString(), columnValues);
    }

    public static class SQLStringAndBindings {
        public List<Object> columnValues;
        public String sql;

        public SQLStringAndBindings(String sql2, List<Object> columnValues2) {
            this.sql = sql2;
            this.columnValues = columnValues2;
        }
    }
}
