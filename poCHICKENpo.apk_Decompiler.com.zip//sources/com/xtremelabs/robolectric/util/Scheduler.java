package com.xtremelabs.robolectric.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.ListIterator;

public class Scheduler {
    private long currentTime = 0;
    private boolean paused = false;
    private List<PostedRunnable> postedRunnables = new ArrayList();

    public long getCurrentTime() {
        return this.currentTime;
    }

    public void pause() {
        this.paused = true;
    }

    public void unPause() {
        this.paused = false;
        advanceToLastPostedRunnable();
    }

    public boolean isPaused() {
        return this.paused;
    }

    public void postDelayed(Runnable runnable, long delayMillis) {
        if (this.paused || delayMillis > 0) {
            this.postedRunnables.add(new PostedRunnable(runnable, this.currentTime + delayMillis));
            Collections.sort(this.postedRunnables);
            return;
        }
        runnable.run();
    }

    public void post(Runnable runnable) {
        postDelayed(runnable, 0);
    }

    public void postAtFrontOfQueue(Runnable runnable) {
        if (this.paused) {
            this.postedRunnables.add(0, new PostedRunnable(runnable, this.currentTime));
        } else {
            runnable.run();
        }
    }

    public void remove(Runnable runnable) {
        ListIterator<PostedRunnable> iterator = this.postedRunnables.listIterator();
        while (iterator.hasNext()) {
            if (iterator.next().runnable == runnable) {
                iterator.remove();
            }
        }
    }

    public boolean advanceToLastPostedRunnable() {
        if (enqueuedTaskCount() < 1) {
            return false;
        }
        return advanceTo(this.postedRunnables.get(this.postedRunnables.size() - 1).scheduledTime);
    }

    public boolean advanceToNextPostedRunnable() {
        if (enqueuedTaskCount() < 1) {
            return false;
        }
        return advanceTo(this.postedRunnables.get(0).scheduledTime);
    }

    public boolean advanceBy(long intervalMs) {
        return advanceTo(this.currentTime + intervalMs);
    }

    public boolean advanceTo(long endingTime) {
        if (endingTime - this.currentTime < 0 || enqueuedTaskCount() < 1) {
            return false;
        }
        int runCount = 0;
        while (nextTaskIsScheduledBefore(endingTime)) {
            runOneTask();
            runCount++;
        }
        this.currentTime = endingTime;
        if (runCount <= 0) {
            return false;
        }
        return true;
    }

    public boolean runOneTask() {
        if (enqueuedTaskCount() < 1) {
            return false;
        }
        PostedRunnable postedRunnable = this.postedRunnables.remove(0);
        this.currentTime = postedRunnable.scheduledTime;
        postedRunnable.run();
        return true;
    }

    public boolean runTasks(int howMany) {
        if (enqueuedTaskCount() < howMany) {
            return false;
        }
        while (howMany > 0) {
            PostedRunnable postedRunnable = this.postedRunnables.remove(0);
            this.currentTime = postedRunnable.scheduledTime;
            postedRunnable.run();
            howMany--;
        }
        return true;
    }

    public int enqueuedTaskCount() {
        return this.postedRunnables.size();
    }

    public boolean areAnyRunnable() {
        return nextTaskIsScheduledBefore(this.currentTime);
    }

    public void reset() {
        this.postedRunnables.clear();
        this.paused = false;
    }

    public int size() {
        return this.postedRunnables.size();
    }

    class PostedRunnable implements Comparable<PostedRunnable> {
        Runnable runnable;
        long scheduledTime;

        PostedRunnable(Runnable runnable2, long scheduledTime2) {
            this.runnable = runnable2;
            this.scheduledTime = scheduledTime2;
        }

        public int compareTo(PostedRunnable postedRunnable) {
            return (int) (this.scheduledTime - postedRunnable.scheduledTime);
        }

        public void run() {
            this.runnable.run();
        }
    }

    private boolean nextTaskIsScheduledBefore(long endingTime) {
        return enqueuedTaskCount() > 0 && this.postedRunnables.get(0).scheduledTime <= endingTime;
    }
}
