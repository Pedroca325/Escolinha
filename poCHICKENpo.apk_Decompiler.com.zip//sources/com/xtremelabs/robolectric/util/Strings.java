package com.xtremelabs.robolectric.util;

import java.io.IOException;
import java.io.InputStream;

public class Strings {
    public static String fromStream(InputStream inputStream) throws IOException {
        byte[] buffer = new byte[1028];
        StringBuilder stringBuilder = new StringBuilder();
        while (true) {
            int inSize = inputStream.read(buffer);
            if (inSize <= 0) {
                return stringBuilder.toString();
            }
            stringBuilder.append(new String(buffer, 0, inSize));
        }
    }

    public static boolean equals(String a, String b) {
        if (a == null) {
            return b == null;
        }
        return a.equals(b);
    }
}
