package com.xtremelabs.robolectric.util;

import com.xtremelabs.robolectric.util.DatabaseConfig;

public class H2Map_TypeForwardOnly extends H2Map implements DatabaseConfig.DatabaseMap {
    public int getResultSetType() {
        return 1003;
    }
}
