package com.xtremelabs.robolectric.util;

import java.util.Collection;
import java.util.Iterator;

public class Join {
    public static String join(String delimiter, Collection collection) {
        String del = "";
        StringBuilder sb = new StringBuilder();
        Iterator i$ = collection.iterator();
        while (i$.hasNext()) {
            Object obj = i$.next();
            String asString = obj == null ? null : obj.toString();
            if (obj != null && asString.length() > 0) {
                sb.append(del).append(obj);
                del = delimiter;
            }
        }
        return sb.toString();
    }

    public static String join(String delimiter, Object... collection) {
        String del = "";
        StringBuilder sb = new StringBuilder();
        Object[] arr$ = collection;
        int len$ = arr$.length;
        for (int i$ = 0; i$ < len$; i$++) {
            Object obj = arr$[i$];
            String asString = obj == null ? null : obj.toString();
            if (asString != null && asString.length() > 0) {
                sb.append(del).append(asString);
                del = delimiter;
            }
        }
        return sb.toString();
    }
}
