package com.xtremelabs.robolectric;

import android.app.Activity;
import android.app.ActivityGroup;
import android.app.ActivityManager;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.Application;
import android.app.Dialog;
import android.app.KeyguardManager;
import android.app.ListActivity;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.app.Service;
import android.appwidget.AppWidgetManager;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.ContentProviderOperation;
import android.content.ContentProviderResult;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.UriMatcher;
import android.content.pm.ResolveInfo;
import android.content.res.AssetManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.database.sqlite.SQLiteCursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteProgram;
import android.database.sqlite.SQLiteQueryBuilder;
import android.database.sqlite.SQLiteStatement;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.StateListDrawable;
import android.hardware.Camera;
import android.hardware.SensorManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.LocationManager;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Parcel;
import android.os.PowerManager;
import android.os.ResultReceiver;
import android.preference.DialogPreference;
import android.preference.ListPreference;
import android.preference.Preference;
import android.preference.PreferenceActivity;
import android.preference.PreferenceCategory;
import android.preference.PreferenceGroup;
import android.preference.PreferenceScreen;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.content.CursorLoader;
import android.telephony.PhoneNumberUtils;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.text.ClipboardManager;
import android.text.TextPaint;
import android.text.format.DateFormat;
import android.text.method.PasswordTransformationMethod;
import android.util.SparseArray;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.TranslateAnimation;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.SslErrorHandler;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.AbsListView;
import android.widget.AbsSeekBar;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CursorAdapter;
import android.widget.ExpandableListView;
import android.widget.Filter;
import android.widget.FrameLayout;
import android.widget.Gallery;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.RemoteViews;
import android.widget.ResourceCursorAdapter;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.SimpleCursorAdapter;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;
import android.widget.ViewAnimator;
import android.widget.ViewFlipper;
import android.widget.ZoomButtonsController;
import com.xtremelabs.robolectric.bytecode.RobolectricInternals;
import com.xtremelabs.robolectric.bytecode.ShadowWrangler;
import com.xtremelabs.robolectric.shadows.HttpResponseGenerator;
import com.xtremelabs.robolectric.shadows.ShadowAbsListView;
import com.xtremelabs.robolectric.shadows.ShadowAbsSeekBar;
import com.xtremelabs.robolectric.shadows.ShadowAbsSpinner;
import com.xtremelabs.robolectric.shadows.ShadowAbsoluteLayout;
import com.xtremelabs.robolectric.shadows.ShadowAbstractCursor;
import com.xtremelabs.robolectric.shadows.ShadowAccount;
import com.xtremelabs.robolectric.shadows.ShadowActivity;
import com.xtremelabs.robolectric.shadows.ShadowActivityGroup;
import com.xtremelabs.robolectric.shadows.ShadowActivityInfo;
import com.xtremelabs.robolectric.shadows.ShadowActivityManager;
import com.xtremelabs.robolectric.shadows.ShadowAdapterView;
import com.xtremelabs.robolectric.shadows.ShadowAddress;
import com.xtremelabs.robolectric.shadows.ShadowAlarmManager;
import com.xtremelabs.robolectric.shadows.ShadowAlertDialog;
import com.xtremelabs.robolectric.shadows.ShadowAndroidHttpClient;
import com.xtremelabs.robolectric.shadows.ShadowAnimation;
import com.xtremelabs.robolectric.shadows.ShadowAnimationDrawable;
import com.xtremelabs.robolectric.shadows.ShadowAnimationUtils;
import com.xtremelabs.robolectric.shadows.ShadowAppWidgetManager;
import com.xtremelabs.robolectric.shadows.ShadowApplication;
import com.xtremelabs.robolectric.shadows.ShadowArrayAdapter;
import com.xtremelabs.robolectric.shadows.ShadowAssetManager;
import com.xtremelabs.robolectric.shadows.ShadowAsyncTask;
import com.xtremelabs.robolectric.shadows.ShadowAudioManager;
import com.xtremelabs.robolectric.shadows.ShadowBaseAdapter;
import com.xtremelabs.robolectric.shadows.ShadowBitmap;
import com.xtremelabs.robolectric.shadows.ShadowBitmapDrawable;
import com.xtremelabs.robolectric.shadows.ShadowBitmapFactory;
import com.xtremelabs.robolectric.shadows.ShadowBluetoothAdapter;
import com.xtremelabs.robolectric.shadows.ShadowBluetoothDevice;
import com.xtremelabs.robolectric.shadows.ShadowBundle;
import com.xtremelabs.robolectric.shadows.ShadowButton;
import com.xtremelabs.robolectric.shadows.ShadowCamera;
import com.xtremelabs.robolectric.shadows.ShadowCameraParameters;
import com.xtremelabs.robolectric.shadows.ShadowCameraSize;
import com.xtremelabs.robolectric.shadows.ShadowCanvas;
import com.xtremelabs.robolectric.shadows.ShadowClipboardManager;
import com.xtremelabs.robolectric.shadows.ShadowColor;
import com.xtremelabs.robolectric.shadows.ShadowColorDrawable;
import com.xtremelabs.robolectric.shadows.ShadowColorMatrix;
import com.xtremelabs.robolectric.shadows.ShadowColorMatrixColorFilter;
import com.xtremelabs.robolectric.shadows.ShadowColorStateList;
import com.xtremelabs.robolectric.shadows.ShadowComponentName;
import com.xtremelabs.robolectric.shadows.ShadowCompoundButton;
import com.xtremelabs.robolectric.shadows.ShadowConfiguration;
import com.xtremelabs.robolectric.shadows.ShadowConnectivityManager;
import com.xtremelabs.robolectric.shadows.ShadowContentProvider;
import com.xtremelabs.robolectric.shadows.ShadowContentProviderOperation;
import com.xtremelabs.robolectric.shadows.ShadowContentProviderOperationBuilder;
import com.xtremelabs.robolectric.shadows.ShadowContentProviderResult;
import com.xtremelabs.robolectric.shadows.ShadowContentResolver;
import com.xtremelabs.robolectric.shadows.ShadowContentUris;
import com.xtremelabs.robolectric.shadows.ShadowContentValues;
import com.xtremelabs.robolectric.shadows.ShadowContext;
import com.xtremelabs.robolectric.shadows.ShadowContextThemeWrapper;
import com.xtremelabs.robolectric.shadows.ShadowContextWrapper;
import com.xtremelabs.robolectric.shadows.ShadowCookieManager;
import com.xtremelabs.robolectric.shadows.ShadowCookieSyncManager;
import com.xtremelabs.robolectric.shadows.ShadowCountDownTimer;
import com.xtremelabs.robolectric.shadows.ShadowCriteria;
import com.xtremelabs.robolectric.shadows.ShadowCursorAdapter;
import com.xtremelabs.robolectric.shadows.ShadowCursorLoader;
import com.xtremelabs.robolectric.shadows.ShadowDatabaseUtils;
import com.xtremelabs.robolectric.shadows.ShadowDateFormat;
import com.xtremelabs.robolectric.shadows.ShadowDefaultRequestDirector;
import com.xtremelabs.robolectric.shadows.ShadowDialog;
import com.xtremelabs.robolectric.shadows.ShadowDialogFragment;
import com.xtremelabs.robolectric.shadows.ShadowDialogPreference;
import com.xtremelabs.robolectric.shadows.ShadowDisplay;
import com.xtremelabs.robolectric.shadows.ShadowDrawable;
import com.xtremelabs.robolectric.shadows.ShadowEditText;
import com.xtremelabs.robolectric.shadows.ShadowEnvironment;
import com.xtremelabs.robolectric.shadows.ShadowExpandableListView;
import com.xtremelabs.robolectric.shadows.ShadowFilter;
import com.xtremelabs.robolectric.shadows.ShadowFloatMath;
import com.xtremelabs.robolectric.shadows.ShadowFragment;
import com.xtremelabs.robolectric.shadows.ShadowFragmentActivity;
import com.xtremelabs.robolectric.shadows.ShadowFrameLayout;
import com.xtremelabs.robolectric.shadows.ShadowGallery;
import com.xtremelabs.robolectric.shadows.ShadowGeoPoint;
import com.xtremelabs.robolectric.shadows.ShadowGeocoder;
import com.xtremelabs.robolectric.shadows.ShadowGridView;
import com.xtremelabs.robolectric.shadows.ShadowHandler;
import com.xtremelabs.robolectric.shadows.ShadowHandlerThread;
import com.xtremelabs.robolectric.shadows.ShadowHtml;
import com.xtremelabs.robolectric.shadows.ShadowImageView;
import com.xtremelabs.robolectric.shadows.ShadowInputMethodManager;
import com.xtremelabs.robolectric.shadows.ShadowIntent;
import com.xtremelabs.robolectric.shadows.ShadowIntentFilter;
import com.xtremelabs.robolectric.shadows.ShadowIntentFilterAuthorityEntry;
import com.xtremelabs.robolectric.shadows.ShadowItemizedOverlay;
import com.xtremelabs.robolectric.shadows.ShadowJsPromptResult;
import com.xtremelabs.robolectric.shadows.ShadowJsResult;
import com.xtremelabs.robolectric.shadows.ShadowKeyEvent;
import com.xtremelabs.robolectric.shadows.ShadowKeyGuardLock;
import com.xtremelabs.robolectric.shadows.ShadowKeyguardManager;
import com.xtremelabs.robolectric.shadows.ShadowLayerDrawable;
import com.xtremelabs.robolectric.shadows.ShadowLayoutInflater;
import com.xtremelabs.robolectric.shadows.ShadowLayoutParams;
import com.xtremelabs.robolectric.shadows.ShadowLinearLayout;
import com.xtremelabs.robolectric.shadows.ShadowListActivity;
import com.xtremelabs.robolectric.shadows.ShadowListPreference;
import com.xtremelabs.robolectric.shadows.ShadowListView;
import com.xtremelabs.robolectric.shadows.ShadowLocation;
import com.xtremelabs.robolectric.shadows.ShadowLocationManager;
import com.xtremelabs.robolectric.shadows.ShadowLog;
import com.xtremelabs.robolectric.shadows.ShadowLooper;
import com.xtremelabs.robolectric.shadows.ShadowMapActivity;
import com.xtremelabs.robolectric.shadows.ShadowMapController;
import com.xtremelabs.robolectric.shadows.ShadowMapView;
import com.xtremelabs.robolectric.shadows.ShadowMarginLayoutParams;
import com.xtremelabs.robolectric.shadows.ShadowMatrix;
import com.xtremelabs.robolectric.shadows.ShadowMatrixCursor;
import com.xtremelabs.robolectric.shadows.ShadowMediaPlayer;
import com.xtremelabs.robolectric.shadows.ShadowMediaRecorder;
import com.xtremelabs.robolectric.shadows.ShadowMediaStore;
import com.xtremelabs.robolectric.shadows.ShadowMenuInflater;
import com.xtremelabs.robolectric.shadows.ShadowMessage;
import com.xtremelabs.robolectric.shadows.ShadowMotionEvent;
import com.xtremelabs.robolectric.shadows.ShadowNdefMessage;
import com.xtremelabs.robolectric.shadows.ShadowNdefRecord;
import com.xtremelabs.robolectric.shadows.ShadowNetworkInfo;
import com.xtremelabs.robolectric.shadows.ShadowNfcAdapter;
import com.xtremelabs.robolectric.shadows.ShadowNotification;
import com.xtremelabs.robolectric.shadows.ShadowNotificationManager;
import com.xtremelabs.robolectric.shadows.ShadowOverlayItem;
import com.xtremelabs.robolectric.shadows.ShadowPaint;
import com.xtremelabs.robolectric.shadows.ShadowPair;
import com.xtremelabs.robolectric.shadows.ShadowParcel;
import com.xtremelabs.robolectric.shadows.ShadowPasswordTransformationMethod;
import com.xtremelabs.robolectric.shadows.ShadowPath;
import com.xtremelabs.robolectric.shadows.ShadowPendingIntent;
import com.xtremelabs.robolectric.shadows.ShadowPeriodicSync;
import com.xtremelabs.robolectric.shadows.ShadowPhoneNumberUtils;
import com.xtremelabs.robolectric.shadows.ShadowPoint;
import com.xtremelabs.robolectric.shadows.ShadowPointF;
import com.xtremelabs.robolectric.shadows.ShadowPowerManager;
import com.xtremelabs.robolectric.shadows.ShadowPreference;
import com.xtremelabs.robolectric.shadows.ShadowPreferenceActivity;
import com.xtremelabs.robolectric.shadows.ShadowPreferenceCategory;
import com.xtremelabs.robolectric.shadows.ShadowPreferenceGroup;
import com.xtremelabs.robolectric.shadows.ShadowPreferenceManager;
import com.xtremelabs.robolectric.shadows.ShadowPreferenceScreen;
import com.xtremelabs.robolectric.shadows.ShadowProgressBar;
import com.xtremelabs.robolectric.shadows.ShadowProgressDialog;
import com.xtremelabs.robolectric.shadows.ShadowRadioButton;
import com.xtremelabs.robolectric.shadows.ShadowRadioGroup;
import com.xtremelabs.robolectric.shadows.ShadowRatingBar;
import com.xtremelabs.robolectric.shadows.ShadowRect;
import com.xtremelabs.robolectric.shadows.ShadowRemoteCallbackList;
import com.xtremelabs.robolectric.shadows.ShadowRemoteViews;
import com.xtremelabs.robolectric.shadows.ShadowResolveInfo;
import com.xtremelabs.robolectric.shadows.ShadowResourceCursorAdapter;
import com.xtremelabs.robolectric.shadows.ShadowResources;
import com.xtremelabs.robolectric.shadows.ShadowResultReceiver;
import com.xtremelabs.robolectric.shadows.ShadowSQLiteCursor;
import com.xtremelabs.robolectric.shadows.ShadowSQLiteDatabase;
import com.xtremelabs.robolectric.shadows.ShadowSQLiteOpenHelper;
import com.xtremelabs.robolectric.shadows.ShadowSQLiteProgram;
import com.xtremelabs.robolectric.shadows.ShadowSQLiteQueryBuilder;
import com.xtremelabs.robolectric.shadows.ShadowSQLiteStatement;
import com.xtremelabs.robolectric.shadows.ShadowScanResult;
import com.xtremelabs.robolectric.shadows.ShadowSeekBar;
import com.xtremelabs.robolectric.shadows.ShadowSensorManager;
import com.xtremelabs.robolectric.shadows.ShadowService;
import com.xtremelabs.robolectric.shadows.ShadowSettings;
import com.xtremelabs.robolectric.shadows.ShadowShapeDrawable;
import com.xtremelabs.robolectric.shadows.ShadowSimpleCursorAdapter;
import com.xtremelabs.robolectric.shadows.ShadowSmsManager;
import com.xtremelabs.robolectric.shadows.ShadowSpannableStringBuilder;
import com.xtremelabs.robolectric.shadows.ShadowSparseArray;
import com.xtremelabs.robolectric.shadows.ShadowSpinner;
import com.xtremelabs.robolectric.shadows.ShadowSslErrorHandler;
import com.xtremelabs.robolectric.shadows.ShadowStateListDrawable;
import com.xtremelabs.robolectric.shadows.ShadowSurfaceView;
import com.xtremelabs.robolectric.shadows.ShadowSyncResult;
import com.xtremelabs.robolectric.shadows.ShadowTabActivity;
import com.xtremelabs.robolectric.shadows.ShadowTabHost;
import com.xtremelabs.robolectric.shadows.ShadowTabSpec;
import com.xtremelabs.robolectric.shadows.ShadowTelephonyManager;
import com.xtremelabs.robolectric.shadows.ShadowTextPaint;
import com.xtremelabs.robolectric.shadows.ShadowTextUtils;
import com.xtremelabs.robolectric.shadows.ShadowTextView;
import com.xtremelabs.robolectric.shadows.ShadowTime;
import com.xtremelabs.robolectric.shadows.ShadowToast;
import com.xtremelabs.robolectric.shadows.ShadowTranslateAnimation;
import com.xtremelabs.robolectric.shadows.ShadowTypedArray;
import com.xtremelabs.robolectric.shadows.ShadowTypedValue;
import com.xtremelabs.robolectric.shadows.ShadowURLSpan;
import com.xtremelabs.robolectric.shadows.ShadowUriMatcher;
import com.xtremelabs.robolectric.shadows.ShadowVideoView;
import com.xtremelabs.robolectric.shadows.ShadowView;
import com.xtremelabs.robolectric.shadows.ShadowViewAnimator;
import com.xtremelabs.robolectric.shadows.ShadowViewConfiguration;
import com.xtremelabs.robolectric.shadows.ShadowViewFlipper;
import com.xtremelabs.robolectric.shadows.ShadowViewGroup;
import com.xtremelabs.robolectric.shadows.ShadowViewMeasureSpec;
import com.xtremelabs.robolectric.shadows.ShadowViewStub;
import com.xtremelabs.robolectric.shadows.ShadowViewTreeObserver;
import com.xtremelabs.robolectric.shadows.ShadowWebSettings;
import com.xtremelabs.robolectric.shadows.ShadowWebView;
import com.xtremelabs.robolectric.shadows.ShadowWifiConfiguration;
import com.xtremelabs.robolectric.shadows.ShadowWifiInfo;
import com.xtremelabs.robolectric.shadows.ShadowWifiManager;
import com.xtremelabs.robolectric.shadows.ShadowWindow;
import com.xtremelabs.robolectric.shadows.ShadowZoomButtonsController;
import com.xtremelabs.robolectric.tester.org.apache.http.FakeHttpLayer;
import com.xtremelabs.robolectric.tester.org.apache.http.HttpRequestInfo;
import com.xtremelabs.robolectric.tester.org.apache.http.RequestMatcher;
import com.xtremelabs.robolectric.util.Scheduler;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.List;
import org.apache.http.Header;
import org.apache.http.HttpRequest;
import org.apache.http.HttpResponse;
import org.apache.http.impl.client.DefaultRequestDirector;

public class Robolectric {
    public static Application application;

    public static <T> T newInstanceOf(Class<T> clazz) {
        return RobolectricInternals.newInstanceOf(clazz);
    }

    public static Object newInstanceOf(String className) {
        try {
            Class<?> clazz = Class.forName(className);
            if (clazz != null) {
                return newInstanceOf(clazz);
            }
        } catch (ClassNotFoundException e) {
        }
        return null;
    }

    public static void bindShadowClass(Class<?> shadowClass) {
        RobolectricInternals.bindShadowClass(shadowClass);
    }

    public static void bindDefaultShadowClasses() {
        bindShadowClasses(getDefaultShadowClasses());
    }

    public static void bindShadowClasses(List<Class<?>> shadowClasses) {
        for (Class<?> shadowClass : shadowClasses) {
            bindShadowClass(shadowClass);
        }
    }

    public static void logMissingInvokedShadowMethods() {
        ShadowWrangler.getInstance().logMissingInvokedShadowMethods();
    }

    public static List<Class<?>> getDefaultShadowClasses() {
        return Arrays.asList(new Class[]{ShadowAbsListView.class, ShadowAbsoluteLayout.class, ShadowAbsSeekBar.class, ShadowAbsSpinner.class, ShadowAbstractCursor.class, ShadowAccount.class, ShadowActivity.class, ShadowActivityInfo.class, ShadowActivityGroup.class, ShadowActivityManager.class, ShadowAdapterView.class, ShadowAddress.class, ShadowAlarmManager.class, ShadowAlertDialog.class, ShadowAlertDialog.ShadowBuilder.class, ShadowAndroidHttpClient.class, ShadowAnimation.class, ShadowAnimationDrawable.class, ShadowAnimationUtils.class, ShadowApplication.class, ShadowAppWidgetManager.class, ShadowArrayAdapter.class, ShadowAssetManager.class, ShadowAsyncTask.class, ShadowAudioManager.class, ShadowBaseAdapter.class, ShadowBitmap.class, ShadowBitmapDrawable.class, ShadowBitmapFactory.class, ShadowBluetoothAdapter.class, ShadowBluetoothDevice.class, ShadowBundle.class, ShadowButton.class, ShadowCamera.class, ShadowCameraParameters.class, ShadowCameraSize.class, ShadowCanvas.class, ShadowClipboardManager.class, ShadowColor.class, ShadowColorDrawable.class, ShadowColorMatrix.class, ShadowColorMatrixColorFilter.class, ShadowColorStateList.class, ShadowComponentName.class, ShadowCompoundButton.class, ShadowConfiguration.class, ShadowConnectivityManager.class, ShadowContentProvider.class, ShadowContentProviderOperation.class, ShadowContentProviderOperationBuilder.class, ShadowContentProviderResult.class, ShadowContentResolver.class, ShadowContentUris.class, ShadowContentValues.class, ShadowContext.class, ShadowContextWrapper.class, ShadowContextThemeWrapper.class, ShadowCookieManager.class, ShadowCookieSyncManager.class, ShadowCriteria.class, ShadowCountDownTimer.class, ShadowCursorAdapter.class, ShadowCursorLoader.class, ShadowDatabaseUtils.class, ShadowDateFormat.class, ShadowDefaultRequestDirector.class, ShadowDisplay.class, ShadowDrawable.class, ShadowDialog.class, ShadowDialogFragment.class, ShadowDialogPreference.class, ShadowEditText.class, ShadowEnvironment.class, ShadowExpandableListView.class, ShadowFilter.class, ShadowFloatMath.class, ShadowFragment.class, ShadowFragmentActivity.class, ShadowFrameLayout.class, ShadowGallery.class, ShadowGeocoder.class, ShadowGeoPoint.class, ShadowGridView.class, ShadowHandler.class, ShadowHandlerThread.class, ShadowHtml.class, ShadowImageView.class, ShadowInputMethodManager.class, ShadowIntent.class, ShadowIntentFilter.class, ShadowIntentFilterAuthorityEntry.class, ShadowItemizedOverlay.class, ShadowJsPromptResult.class, ShadowJsResult.class, ShadowKeyEvent.class, ShadowKeyguardManager.class, ShadowKeyGuardLock.class, ShadowLayerDrawable.class, ShadowLayoutInflater.class, ShadowLayoutParams.class, ShadowLinearLayout.class, ShadowListActivity.class, ShadowListPreference.class, ShadowListView.class, ShadowLocation.class, ShadowLocationManager.class, ShadowLog.class, ShadowLooper.class, ShadowMapController.class, ShadowMapActivity.class, ShadowMapView.class, ShadowMarginLayoutParams.class, ShadowMatrix.class, ShadowMatrixCursor.class, ShadowMediaPlayer.class, ShadowMediaRecorder.class, ShadowMediaStore.ShadowImages.ShadowMedia.class, ShadowMenuInflater.class, ShadowMessage.class, ShadowMotionEvent.class, ShadowNotification.class, ShadowNdefMessage.class, ShadowNdefRecord.class, ShadowNfcAdapter.class, ShadowNotificationManager.class, ShadowNetworkInfo.class, ShadowOverlayItem.class, ShadowPaint.class, ShadowPair.class, ShadowParcel.class, ShadowPasswordTransformationMethod.class, ShadowPath.class, ShadowPendingIntent.class, ShadowPeriodicSync.class, ShadowPhoneNumberUtils.class, ShadowPoint.class, ShadowPointF.class, ShadowPowerManager.class, ShadowPreference.class, ShadowPreferenceActivity.class, ShadowPreferenceCategory.class, ShadowPreferenceGroup.class, ShadowPreferenceManager.class, ShadowPreferenceScreen.class, ShadowProgressBar.class, ShadowProgressDialog.class, ShadowRadioButton.class, ShadowRadioGroup.class, ShadowRatingBar.class, ShadowRect.class, ShadowResolveInfo.class, ShadowRemoteCallbackList.class, ShadowRemoteViews.class, ShadowResultReceiver.class, ShadowResourceCursorAdapter.class, ShadowResources.class, ShadowResources.ShadowTheme.class, ShadowScanResult.class, ShadowScrollView.class, ShadowSeekBar.class, ShadowSensorManager.class, ShadowService.class, ShadowSettings.class, ShadowSettings.ShadowSecure.class, ShadowSettings.ShadowSystem.class, ShadowSimpleCursorAdapter.class, ShadowShapeDrawable.class, ShadowSmsManager.class, ShadowSpannableStringBuilder.class, ShadowSparseArray.class, ShadowSpinner.class, ShadowSyncResult.class, ShadowSyncResult.ShadowSyncStats.class, ShadowSQLiteProgram.class, ShadowSQLiteDatabase.class, ShadowSQLiteCursor.class, ShadowSQLiteOpenHelper.class, ShadowSQLiteStatement.class, ShadowSQLiteQueryBuilder.class, ShadowSslErrorHandler.class, ShadowStateListDrawable.class, ShadowSurfaceView.class, ShadowTabActivity.class, ShadowTabHost.class, ShadowTabSpec.class, ShadowTelephonyManager.class, ShadowTextPaint.class, ShadowTextUtils.class, ShadowTextView.class, ShadowTime.class, ShadowToast.class, ShadowTranslateAnimation.class, ShadowTypedArray.class, ShadowTypedValue.class, ShadowUriMatcher.class, ShadowURLSpan.class, ShadowVideoView.class, ShadowView.class, ShadowViewAnimator.class, ShadowViewConfiguration.class, ShadowViewGroup.class, ShadowViewFlipper.class, ShadowViewMeasureSpec.class, ShadowViewStub.class, ShadowViewTreeObserver.class, ShadowWebSettings.class, ShadowWebView.class, ShadowWifiConfiguration.class, ShadowWifiInfo.class, ShadowWifiManager.class, ShadowWindow.class, ShadowZoomButtonsController.class});
    }

    public static void resetStaticState() {
        ShadowWrangler.getInstance().silence();
        application = new Application();
        ShadowBitmapFactory.reset();
        ShadowDrawable.reset();
        ShadowMediaStore.reset();
        ShadowLog.reset();
        ShadowContext.clearFilesAndCache();
        ShadowLooper.resetThreadLoopers();
        ShadowDialog.reset();
        ShadowContentResolver.reset();
    }

    public static <T> T directlyOn(T shadowedObject) {
        return RobolectricInternals.directlyOn(shadowedObject);
    }

    public static ShadowAbsListView shadowOf(AbsListView instance) {
        return (ShadowAbsListView) shadowOf_(instance);
    }

    public static ShadowAbsSeekBar shadowOf(AbsSeekBar instance) {
        return (ShadowAbsSeekBar) shadowOf_(instance);
    }

    public static ShadowActivity shadowOf(Activity instance) {
        return (ShadowActivity) shadowOf_(instance);
    }

    public static ShadowActivityGroup shadowOf(ActivityGroup instance) {
        return (ShadowActivityGroup) shadowOf_(instance);
    }

    public static ShadowActivityManager shadowOf(ActivityManager instance) {
        return (ShadowActivityManager) shadowOf_(instance);
    }

    public static ShadowAdapterView shadowOf(AdapterView instance) {
        return (ShadowAdapterView) shadowOf_(instance);
    }

    public static ShadowAddress shadowOf(Address instance) {
        return (ShadowAddress) shadowOf_(instance);
    }

    public static ShadowAlarmManager shadowOf(AlarmManager instance) {
        return (ShadowAlarmManager) shadowOf_(instance);
    }

    public static ShadowAlertDialog shadowOf(AlertDialog instance) {
        return (ShadowAlertDialog) shadowOf_(instance);
    }

    public static ShadowAnimation shadowOf(Animation instance) {
        return (ShadowAnimation) shadowOf_(instance);
    }

    public static ShadowAnimationUtils shadowOf(AnimationUtils instance) {
        return (ShadowAnimationUtils) shadowOf_(instance);
    }

    public static ShadowApplication shadowOf(Application instance) {
        return (ShadowApplication) shadowOf_(instance);
    }

    public static ShadowAppWidgetManager shadowOf(AppWidgetManager instance) {
        return (ShadowAppWidgetManager) shadowOf_(instance);
    }

    public static ShadowArrayAdapter shadowOf(ArrayAdapter instance) {
        return (ShadowArrayAdapter) shadowOf_(instance);
    }

    public static ShadowAssetManager shadowOf(AssetManager instance) {
        return (ShadowAssetManager) shadowOf_(instance);
    }

    public static ShadowAudioManager shadowOf(AudioManager instance) {
        return (ShadowAudioManager) shadowOf_(instance);
    }

    public static ShadowBitmap shadowOf(Bitmap other) {
        return (ShadowBitmap) shadowOf_(other);
    }

    public static ShadowBitmapDrawable shadowOf(BitmapDrawable instance) {
        return (ShadowBitmapDrawable) shadowOf_(instance);
    }

    public static ShadowBluetoothAdapter shadowOf(BluetoothAdapter other) {
        return (ShadowBluetoothAdapter) shadowOf_(other);
    }

    public static ShadowBluetoothDevice shadowOf(BluetoothDevice other) {
        return (ShadowBluetoothDevice) shadowOf_(other);
    }

    public static ShadowBundle shadowOf(Bundle instance) {
        return (ShadowBundle) shadowOf_(instance);
    }

    public static ShadowCamera shadowOf(Camera instance) {
        return (ShadowCamera) shadowOf_(instance);
    }

    public static ShadowCameraParameters shadowOf(Camera.Parameters instance) {
        return (ShadowCameraParameters) shadowOf_(instance);
    }

    public static ShadowCameraSize shadowOf(Camera.Size instance) {
        return (ShadowCameraSize) shadowOf_(instance);
    }

    public static ShadowCanvas shadowOf(Canvas instance) {
        return (ShadowCanvas) shadowOf_(instance);
    }

    public static ShadowClipboardManager shadowOf(ClipboardManager instance) {
        return (ShadowClipboardManager) shadowOf_(instance);
    }

    public static ShadowColor shadowOf(Color instance) {
        return (ShadowColor) shadowOf_(instance);
    }

    public static ShadowColorDrawable shadowOf(ColorDrawable instance) {
        return (ShadowColorDrawable) shadowOf_(instance);
    }

    public static ShadowColorMatrix shadowOf(ColorMatrix instance) {
        return (ShadowColorMatrix) shadowOf_(instance);
    }

    public static ShadowConfiguration shadowOf(Configuration instance) {
        return (ShadowConfiguration) shadowOf_(instance);
    }

    public static ShadowConnectivityManager shadowOf(ConnectivityManager instance) {
        return (ShadowConnectivityManager) shadowOf_(instance);
    }

    public static ShadowCookieManager shadowOf(CookieManager instance) {
        return (ShadowCookieManager) shadowOf_(instance);
    }

    public static ShadowContentResolver shadowOf(ContentResolver instance) {
        return (ShadowContentResolver) shadowOf_(instance);
    }

    public static ShadowContentProviderOperation shadowOf(ContentProviderOperation instance) {
        return (ShadowContentProviderOperation) shadowOf_(instance);
    }

    public static ShadowContentProviderOperationBuilder shadowOf(ContentProviderOperation.Builder instance) {
        return (ShadowContentProviderOperationBuilder) shadowOf_(instance);
    }

    public static ShadowContentProviderResult shadowOf(ContentProviderResult instance) {
        return (ShadowContentProviderResult) shadowOf_(instance);
    }

    public static ShadowCookieSyncManager shadowOf(CookieSyncManager instance) {
        return (ShadowCookieSyncManager) shadowOf_(instance);
    }

    public static ShadowContext shadowOf(Context instance) {
        return (ShadowContext) shadowOf_(instance);
    }

    public static ShadowContentValues shadowOf(ContentValues other) {
        return (ShadowContentValues) shadowOf_(other);
    }

    public static ShadowContextWrapper shadowOf(ContextWrapper instance) {
        return (ShadowContextWrapper) shadowOf_(instance);
    }

    public static ShadowCountDownTimer shadowOf(CountDownTimer instance) {
        return (ShadowCountDownTimer) shadowOf_(instance);
    }

    public static ShadowCursorAdapter shadowOf(CursorAdapter instance) {
        return (ShadowCursorAdapter) shadowOf_(instance);
    }

    public static ShadowCursorLoader shadowOf(CursorLoader instance) {
        return (ShadowCursorLoader) shadowOf_(instance);
    }

    public static ShadowDateFormat shadowOf(DateFormat instance) {
        return (ShadowDateFormat) shadowOf_(instance);
    }

    public static ShadowDefaultRequestDirector shadowOf(DefaultRequestDirector instance) {
        return (ShadowDefaultRequestDirector) shadowOf_(instance);
    }

    public static ShadowDialog shadowOf(Dialog instance) {
        return (ShadowDialog) shadowOf_(instance);
    }

    public static ShadowDialogFragment shadowOf(DialogFragment instance) {
        return (ShadowDialogFragment) shadowOf_(instance);
    }

    public static ShadowDialogPreference shadowOf(DialogPreference instance) {
        return (ShadowDialogPreference) shadowOf_(instance);
    }

    public static ShadowDrawable shadowOf(Drawable instance) {
        return (ShadowDrawable) shadowOf_(instance);
    }

    public static ShadowDisplay shadowOf(Display instance) {
        return (ShadowDisplay) shadowOf_(instance);
    }

    public static ShadowExpandableListView shadowOf(ExpandableListView instance) {
        return (ShadowExpandableListView) shadowOf_(instance);
    }

    public static ShadowFilter shadowOf(Filter instance) {
        return (ShadowFilter) shadowOf_(instance);
    }

    public static ShadowFragment shadowOf(Fragment instance) {
        return (ShadowFragment) shadowOf_(instance);
    }

    public static ShadowFragmentActivity shadowOf(FragmentActivity instance) {
        return (ShadowFragmentActivity) shadowOf_(instance);
    }

    public static ShadowFrameLayout shadowOf(FrameLayout instance) {
        return (ShadowFrameLayout) shadowOf_(instance);
    }

    public static ShadowGallery shadowOf(Gallery instance) {
        return (ShadowGallery) shadowOf_(instance);
    }

    public static ShadowGeocoder shadowOf(Geocoder instance) {
        return (ShadowGeocoder) shadowOf_(instance);
    }

    public static ShadowGridView shadowOf(GridView instance) {
        return (ShadowGridView) shadowOf_(instance);
    }

    public static ShadowHandler shadowOf(Handler instance) {
        return (ShadowHandler) shadowOf_(instance);
    }

    public static ShadowHandlerThread shadowOf(HandlerThread instance) {
        return (ShadowHandlerThread) shadowOf_(instance);
    }

    public static ShadowImageView shadowOf(ImageView instance) {
        return (ShadowImageView) shadowOf_(instance);
    }

    public static ShadowInputMethodManager shadowOf(InputMethodManager instance) {
        return (ShadowInputMethodManager) shadowOf_(instance);
    }

    public static ShadowIntent shadowOf(Intent instance) {
        return (ShadowIntent) shadowOf_(instance);
    }

    public static ShadowJsPromptResult shadowOf(JsPromptResult instance) {
        return (ShadowJsPromptResult) shadowOf_(instance);
    }

    public static ShadowJsResult shadowOf(JsResult instance) {
        return (ShadowJsResult) shadowOf_(instance);
    }

    public static ShadowKeyguardManager shadowOf(KeyguardManager instance) {
        return (ShadowKeyguardManager) shadowOf_(instance);
    }

    public static ShadowKeyGuardLock shadowOf(KeyguardManager.KeyguardLock instance) {
        return (ShadowKeyGuardLock) shadowOf_(instance);
    }

    public static ShadowLayerDrawable shadowOf(LayerDrawable instance) {
        return (ShadowLayerDrawable) shadowOf_(instance);
    }

    public static ShadowLayoutInflater shadowOf(LayoutInflater instance) {
        return (ShadowLayoutInflater) shadowOf_(instance);
    }

    public static ShadowListActivity shadowOf(ListActivity instance) {
        return (ShadowListActivity) shadowOf_(instance);
    }

    public static ShadowListPreference shadowOf(ListPreference instance) {
        return (ShadowListPreference) shadowOf_(instance);
    }

    public static ShadowListView shadowOf(ListView instance) {
        return (ShadowListView) shadowOf_(instance);
    }

    public static ShadowLocationManager shadowOf(LocationManager instance) {
        return (ShadowLocationManager) shadowOf_(instance);
    }

    public static ShadowLooper shadowOf(Looper instance) {
        return (ShadowLooper) shadowOf_(instance);
    }

    public static ShadowMatrix shadowOf(Matrix other) {
        return (ShadowMatrix) shadowOf_(other);
    }

    public static ShadowMediaPlayer shadowOf(MediaPlayer instance) {
        return (ShadowMediaPlayer) shadowOf_(instance);
    }

    public static ShadowMediaRecorder shadowOf(MediaRecorder instance) {
        return (ShadowMediaRecorder) shadowOf_(instance);
    }

    public static ShadowMenuInflater shadowOf(MenuInflater instance) {
        return (ShadowMenuInflater) shadowOf_(instance);
    }

    public static ShadowMotionEvent shadowOf(MotionEvent other) {
        return (ShadowMotionEvent) shadowOf_(other);
    }

    public static ShadowNetworkInfo shadowOf(NetworkInfo instance) {
        return (ShadowNetworkInfo) shadowOf_(instance);
    }

    public static ShadowNotification shadowOf(Notification other) {
        return (ShadowNotification) shadowOf_(other);
    }

    public static ShadowNotificationManager shadowOf(NotificationManager other) {
        return (ShadowNotificationManager) shadowOf_(other);
    }

    public static ShadowPaint shadowOf(Paint instance) {
        return (ShadowPaint) shadowOf_(instance);
    }

    public static ShadowParcel shadowOf(Parcel instance) {
        return (ShadowParcel) shadowOf_(instance);
    }

    public static ShadowPasswordTransformationMethod shadowOf(PasswordTransformationMethod instance) {
        return (ShadowPasswordTransformationMethod) shadowOf_(instance);
    }

    public static ShadowPath shadowOf(Path instance) {
        return (ShadowPath) shadowOf_(instance);
    }

    public static ShadowPendingIntent shadowOf(PendingIntent instance) {
        return (ShadowPendingIntent) shadowOf_(instance);
    }

    public static ShadowPhoneNumberUtils shadowOf(PhoneNumberUtils instance) {
        return (ShadowPhoneNumberUtils) shadowOf_(instance);
    }

    public static ShadowPowerManager shadowOf(PowerManager instance) {
        return (ShadowPowerManager) shadowOf_(instance);
    }

    public static ShadowPreference shadowOf(Preference instance) {
        return (ShadowPreference) shadowOf_(instance);
    }

    public static ShadowPreferenceActivity shadowOf(PreferenceActivity instance) {
        return (ShadowPreferenceActivity) shadowOf_(instance);
    }

    public static ShadowPreferenceCategory shadowOf(PreferenceCategory instance) {
        return (ShadowPreferenceCategory) shadowOf_(instance);
    }

    public static ShadowPreferenceGroup shadowOf(PreferenceGroup instance) {
        return (ShadowPreferenceGroup) shadowOf_(instance);
    }

    public static ShadowPreferenceScreen shadowOf(PreferenceScreen instance) {
        return (ShadowPreferenceScreen) shadowOf_(instance);
    }

    public static ShadowProgressBar shadowOf(ProgressBar instance) {
        return (ShadowProgressBar) shadowOf_(instance);
    }

    public static ShadowProgressDialog shadowOf(ProgressDialog instance) {
        return (ShadowProgressDialog) shadowOf_(instance);
    }

    public static ShadowRect shadowOf(Rect instance) {
        return (ShadowRect) shadowOf_(instance);
    }

    public static ShadowRatingBar shadowOf(RatingBar instance) {
        return (ShadowRatingBar) shadowOf_(instance);
    }

    public static ShadowRemoteViews shadowOf(RemoteViews instance) {
        return (ShadowRemoteViews) shadowOf_(instance);
    }

    public static ShadowResolveInfo shadowOf(ResolveInfo instance) {
        return (ShadowResolveInfo) shadowOf_(instance);
    }

    public static ShadowResourceCursorAdapter shadowOf(ResourceCursorAdapter instance) {
        return (ShadowResourceCursorAdapter) shadowOf_(instance);
    }

    public static ShadowResources shadowOf(Resources instance) {
        return (ShadowResources) shadowOf_(instance);
    }

    public static ShadowResultReceiver shadowOf(ResultReceiver instance) {
        return (ShadowResultReceiver) shadowOf_(instance);
    }

    public static ShadowScanResult shadowOf(ScanResult instance) {
        return (ShadowScanResult) shadowOf_(instance);
    }

    public static ShadowScrollView shadowOf(ScrollView instance) {
        return (ShadowScrollView) shadowOf_(instance);
    }

    public static ShadowSeekBar shadowOf(SeekBar instance) {
        return (ShadowSeekBar) shadowOf_(instance);
    }

    public static ShadowSensorManager shadowOf(SensorManager instance) {
        return (ShadowSensorManager) shadowOf_(instance);
    }

    public static ShadowService shadowOf(Service instance) {
        return (ShadowService) shadowOf_(instance);
    }

    public static ShadowShapeDrawable shadowOf(ShapeDrawable instance) {
        return (ShadowShapeDrawable) shadowOf_(instance);
    }

    public static ShadowSimpleCursorAdapter shadowOf(SimpleCursorAdapter instance) {
        return (ShadowSimpleCursorAdapter) shadowOf_(instance);
    }

    public static ShadowSmsManager shadowOf(SmsManager instance) {
        return (ShadowSmsManager) shadowOf_(instance);
    }

    public static ShadowSQLiteCursor shadowOf(SQLiteCursor other) {
        return (ShadowSQLiteCursor) shadowOf_(other);
    }

    public static ShadowSQLiteDatabase shadowOf(SQLiteDatabase other) {
        return (ShadowSQLiteDatabase) shadowOf_(other);
    }

    public static ShadowSQLiteOpenHelper shadowOf(SQLiteOpenHelper other) {
        return (ShadowSQLiteOpenHelper) shadowOf_(other);
    }

    public static ShadowSQLiteProgram shadowOf(SQLiteProgram other) {
        return (ShadowSQLiteProgram) shadowOf_(other);
    }

    public static ShadowSQLiteQueryBuilder shadowOf(SQLiteQueryBuilder other) {
        return (ShadowSQLiteQueryBuilder) shadowOf_(other);
    }

    public static ShadowSQLiteStatement shadowOf(SQLiteStatement other) {
        return (ShadowSQLiteStatement) shadowOf_(other);
    }

    public static <E> ShadowSparseArray<E> shadowOf(SparseArray<E> other) {
        return (ShadowSparseArray) shadowOf_(other);
    }

    public static ShadowSslErrorHandler shadowOf(SslErrorHandler instance) {
        return (ShadowSslErrorHandler) shadowOf_(instance);
    }

    public static ShadowStateListDrawable shadowOf(StateListDrawable instance) {
        return (ShadowStateListDrawable) shadowOf_(instance);
    }

    public static ShadowTabHost shadowOf(TabHost instance) {
        return (ShadowTabHost) shadowOf_(instance);
    }

    public static ShadowTabSpec shadowOf(TabHost.TabSpec instance) {
        return (ShadowTabSpec) shadowOf_(instance);
    }

    public static ShadowTelephonyManager shadowOf(TelephonyManager instance) {
        return (ShadowTelephonyManager) shadowOf_(instance);
    }

    public static ShadowTextPaint shadowOf(TextPaint instance) {
        return (ShadowTextPaint) shadowOf_(instance);
    }

    public static ShadowTextView shadowOf(TextView instance) {
        return (ShadowTextView) shadowOf_(instance);
    }

    public static ShadowToast shadowOf(Toast instance) {
        return (ShadowToast) shadowOf_(instance);
    }

    public static ShadowTranslateAnimation shadowOf(TranslateAnimation instance) {
        return (ShadowTranslateAnimation) shadowOf_(instance);
    }

    public static ShadowUriMatcher shadowOf(UriMatcher instance) {
        return (ShadowUriMatcher) shadowOf_(instance);
    }

    public static ShadowView shadowOf(View instance) {
        return (ShadowView) shadowOf_(instance);
    }

    public static ShadowViewAnimator shadowOf(ViewAnimator instance) {
        return (ShadowViewAnimator) shadowOf_(instance);
    }

    public static ShadowViewConfiguration shadowOf(ViewConfiguration instance) {
        return (ShadowViewConfiguration) shadowOf_(instance);
    }

    public static ShadowViewFlipper shadowOf(ViewFlipper instance) {
        return (ShadowViewFlipper) shadowOf_(instance);
    }

    public static ShadowViewTreeObserver shadowOf(ViewTreeObserver instance) {
        return (ShadowViewTreeObserver) shadowOf_(instance);
    }

    public static ShadowViewGroup shadowOf(ViewGroup instance) {
        return (ShadowViewGroup) shadowOf_(instance);
    }

    public static ShadowVideoView shadowOf(VideoView instance) {
        return (ShadowVideoView) shadowOf_(instance);
    }

    public static ShadowWebSettings shadowOf(WebSettings instance) {
        return (ShadowWebSettings) shadowOf_(instance);
    }

    public static ShadowWebView shadowOf(WebView instance) {
        return (ShadowWebView) shadowOf_(instance);
    }

    public static ShadowWifiConfiguration shadowOf(WifiConfiguration instance) {
        return (ShadowWifiConfiguration) shadowOf_(instance);
    }

    public static ShadowWifiInfo shadowOf(WifiInfo instance) {
        return (ShadowWifiInfo) shadowOf_(instance);
    }

    public static ShadowWifiManager shadowOf(WifiManager instance) {
        return (ShadowWifiManager) shadowOf_(instance);
    }

    public static ShadowZoomButtonsController shadowOf(ZoomButtonsController instance) {
        return (ShadowZoomButtonsController) shadowOf_(instance);
    }

    public static <P, R> P shadowOf_(R instance) {
        return ShadowWrangler.getInstance().shadowOf(instance);
    }

    public static void runBackgroundTasks() {
        getBackgroundScheduler().advanceBy(0);
    }

    public static void runUiThreadTasks() {
        getUiThreadScheduler().advanceBy(0);
    }

    public static void runUiThreadTasksIncludingDelayedTasks() {
        getUiThreadScheduler().advanceToLastPostedRunnable();
    }

    public static void addPendingHttpResponse(int statusCode, String responseBody, Header... headers) {
        getFakeHttpLayer().addPendingHttpResponse(statusCode, responseBody, headers);
    }

    public static void addPendingHttpResponseWithContentType(int statusCode, String responseBody, Header contentType) {
        getFakeHttpLayer().addPendingHttpResponse(statusCode, responseBody, contentType);
    }

    public static void addPendingHttpResponse(HttpResponse httpResponse) {
        getFakeHttpLayer().addPendingHttpResponse(httpResponse);
    }

    public static void addPendingHttpResponse(HttpResponseGenerator httpResponseGenerator) {
        getFakeHttpLayer().addPendingHttpResponse(httpResponseGenerator);
    }

    public static HttpRequest getSentHttpRequest(int index) {
        return ShadowDefaultRequestDirector.getSentHttpRequest(index);
    }

    public static HttpRequest getLatestSentHttpRequest() {
        return ShadowDefaultRequestDirector.getLatestSentHttpRequest();
    }

    public static boolean httpRequestWasMade() {
        return getShadowApplication().getFakeHttpLayer().hasRequestInfos();
    }

    public static boolean httpRequestWasMade(String uri) {
        return getShadowApplication().getFakeHttpLayer().hasRequestMatchingRule(new FakeHttpLayer.UriRequestMatcher(uri));
    }

    public static HttpRequestInfo getSentHttpRequestInfo(int index) {
        return ShadowDefaultRequestDirector.getSentHttpRequestInfo(index);
    }

    public static void addHttpResponseRule(String method, String uri, HttpResponse response) {
        getFakeHttpLayer().addHttpResponseRule(method, uri, response);
    }

    public static void addHttpResponseRule(String uri, HttpResponse response) {
        getFakeHttpLayer().addHttpResponseRule(uri, response);
    }

    public static void addHttpResponseRule(String uri, String response) {
        getFakeHttpLayer().addHttpResponseRule(uri, response);
    }

    public static void addHttpResponseRule(RequestMatcher requestMatcher, HttpResponse response) {
        getFakeHttpLayer().addHttpResponseRule(requestMatcher, response);
    }

    public static void addHttpResponseRule(RequestMatcher requestMatcher, List<? extends HttpResponse> responses) {
        getFakeHttpLayer().addHttpResponseRule(requestMatcher, responses);
    }

    public static FakeHttpLayer getFakeHttpLayer() {
        return getShadowApplication().getFakeHttpLayer();
    }

    public static void setDefaultHttpResponse(int statusCode, String responseBody) {
        getFakeHttpLayer().setDefaultHttpResponse(statusCode, responseBody);
    }

    public static void setDefaultHttpResponse(HttpResponse defaultHttpResponse) {
        getFakeHttpLayer().setDefaultHttpResponse(defaultHttpResponse);
    }

    public static void clearHttpResponseRules() {
        getFakeHttpLayer().clearHttpResponseRules();
    }

    public static void clearPendingHttpResponses() {
        getFakeHttpLayer().clearPendingHttpResponses();
    }

    public static void pauseLooper(Looper looper) {
        ShadowLooper.pauseLooper(looper);
    }

    public static void unPauseLooper(Looper looper) {
        ShadowLooper.unPauseLooper(looper);
    }

    public static void pauseMainLooper() {
        ShadowLooper.pauseMainLooper();
    }

    public static void unPauseMainLooper() {
        ShadowLooper.unPauseMainLooper();
    }

    public static void idleMainLooper(long interval) {
        ShadowLooper.idleMainLooper(interval);
    }

    public static Scheduler getUiThreadScheduler() {
        return shadowOf(Looper.getMainLooper()).getScheduler();
    }

    public static Scheduler getBackgroundScheduler() {
        return getShadowApplication().getBackgroundScheduler();
    }

    public static ShadowApplication getShadowApplication() {
        return shadowOf(application);
    }

    public static void setDisplayMetricsDensity(float densityMultiplier) {
        shadowOf(getShadowApplication().getResources()).setDensity(densityMultiplier);
    }

    public static void setDefaultDisplay(Display display) {
        shadowOf(getShadowApplication().getResources()).setDisplay(display);
    }

    public static boolean clickOn(View view) {
        return shadowOf(view).checkedPerformClick();
    }

    public static String visualize(View view) {
        Canvas canvas = new Canvas();
        view.draw(canvas);
        return shadowOf(canvas).getDescription();
    }

    public static String visualize(Canvas canvas) {
        return shadowOf(canvas).getDescription();
    }

    public static String visualize(Bitmap bitmap) {
        return shadowOf(bitmap).getDescription();
    }

    public static class Reflection {
        public static <T> T newInstanceOf(Class<T> clazz) {
            return Robolectric.newInstanceOf(clazz);
        }

        public static Object newInstanceOf(String className) {
            return Robolectric.newInstanceOf(className);
        }

        public static void setFinalStaticField(Class classWhichContainsField, String fieldName, Object newValue) {
            try {
                Field field = classWhichContainsField.getField(fieldName);
                field.setAccessible(true);
                Field modifiersField = Field.class.getDeclaredField("modifiers");
                modifiersField.setAccessible(true);
                modifiersField.setInt(field, field.getModifiers() & -17);
                field.set((Object) null, newValue);
            } catch (NoSuchFieldException e) {
                throw new RuntimeException(e);
            } catch (IllegalAccessException e2) {
                throw new RuntimeException(e2);
            }
        }
    }
}
