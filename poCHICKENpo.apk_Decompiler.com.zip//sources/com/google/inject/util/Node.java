package com.google.inject.util;

import com.google.inject.Key;
import com.google.inject.internal.Errors;
import com.google.inject.internal.util.C$ImmutableSet;
import com.google.inject.internal.util.C$Sets;
import java.lang.annotation.Annotation;
import java.util.Set;

class Node {
    private int appliedScope = Integer.MAX_VALUE;
    private Class<? extends Annotation> appliedScopeAnnotation;
    private int effectiveScope = Integer.MIN_VALUE;
    private Node effectiveScopeDependency;
    private final Key<?> key;
    private Set<Node> users = C$ImmutableSet.of();

    Node(Key<?> key2) {
        this.key = key2;
    }

    /* access modifiers changed from: package-private */
    public void setScopeRank(int rank, Class<? extends Annotation> annotation) {
        this.appliedScope = rank;
        this.effectiveScope = rank;
        this.appliedScopeAnnotation = annotation;
    }

    private void setEffectiveScope(int effectiveScope2, Node effectiveScopeDependency2) {
        if (this.effectiveScope < effectiveScope2) {
            this.effectiveScope = effectiveScope2;
            this.effectiveScopeDependency = effectiveScopeDependency2;
            pushScopeToUsers();
        }
    }

    /* access modifiers changed from: package-private */
    public void pushScopeToUsers() {
        for (Node user : this.users) {
            user.setEffectiveScope(this.effectiveScope, this);
        }
    }

    /* access modifiers changed from: package-private */
    public boolean isScopedCorrectly() {
        return this.appliedScope >= this.effectiveScope;
    }

    /* access modifiers changed from: package-private */
    public boolean isEffectiveScopeAppliedScope() {
        return this.appliedScope == this.effectiveScope;
    }

    /* access modifiers changed from: package-private */
    public Node effectiveScopeDependency() {
        return this.effectiveScopeDependency;
    }

    public void addUser(Node node) {
        if (this.users.isEmpty()) {
            this.users = C$Sets.newHashSet();
        }
        this.users.add(node);
    }

    public String toString() {
        return this.appliedScopeAnnotation != null ? Errors.convert(this.key) + " in @" + this.appliedScopeAnnotation.getSimpleName() : Errors.convert(this.key).toString();
    }
}
