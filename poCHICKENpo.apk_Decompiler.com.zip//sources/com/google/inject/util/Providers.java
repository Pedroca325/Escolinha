package com.google.inject.util;

import com.google.inject.Inject;
import com.google.inject.Injector;
import com.google.inject.Provider;
import com.google.inject.internal.util.C$ImmutableSet;
import com.google.inject.internal.util.C$Preconditions;
import com.google.inject.internal.util.C$Sets;
import com.google.inject.spi.Dependency;
import com.google.inject.spi.InjectionPoint;
import com.google.inject.spi.ProviderWithDependencies;
import java.util.Set;

public final class Providers {
    private Providers() {
    }

    public static <T> Provider<T> of(final T instance) {
        return new Provider<T>() {
            public T get() {
                return instance;
            }

            public String toString() {
                return "of(" + instance + ")";
            }
        };
    }

    public static <T> Provider<T> guicify(javax.inject.Provider<T> provider) {
        if (provider instanceof Provider) {
            return (Provider) provider;
        }
        final javax.inject.Provider<T> delegate = (javax.inject.Provider) C$Preconditions.checkNotNull(provider, "provider");
        Set<InjectionPoint> injectionPoints = InjectionPoint.forInstanceMethodsAndFields(provider.getClass());
        if (injectionPoints.isEmpty()) {
            return new Provider<T>() {
                public T get() {
                    return delegate.get();
                }

                public String toString() {
                    return "guicified(" + delegate + ")";
                }
            };
        }
        Set<Dependency<?>> mutableDeps = C$Sets.newHashSet();
        for (InjectionPoint ip : injectionPoints) {
            mutableDeps.addAll(ip.getDependencies());
        }
        final Set<Dependency<?>> dependencies = C$ImmutableSet.copyOf(mutableDeps);
        return new ProviderWithDependencies<T>() {
            /* access modifiers changed from: package-private */
            @Inject
            public void initialize(Injector injector) {
                injector.injectMembers(delegate);
            }

            public Set<Dependency<?>> getDependencies() {
                return dependencies;
            }

            public T get() {
                return delegate.get();
            }

            public String toString() {
                return "guicified(" + delegate + ")";
            }
        };
    }
}
