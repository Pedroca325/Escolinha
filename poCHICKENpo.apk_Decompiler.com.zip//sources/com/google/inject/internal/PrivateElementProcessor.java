package com.google.inject.internal;

import com.google.inject.internal.InjectorShell;
import com.google.inject.internal.util.C$Lists;
import com.google.inject.spi.PrivateElements;
import java.util.List;

final class PrivateElementProcessor extends AbstractProcessor {
    private final List<InjectorShell.Builder> injectorShellBuilders = C$Lists.newArrayList();

    PrivateElementProcessor(Errors errors) {
        super(errors);
    }

    public Boolean visit(PrivateElements privateElements) {
        this.injectorShellBuilders.add(new InjectorShell.Builder().parent(this.injector).privateElements(privateElements));
        return true;
    }

    public List<InjectorShell.Builder> getInjectorShellBuilders() {
        return this.injectorShellBuilders;
    }
}
