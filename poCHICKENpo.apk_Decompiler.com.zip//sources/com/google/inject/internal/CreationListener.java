package com.google.inject.internal;

interface CreationListener {
    void notify(Errors errors);
}
