package com.google.inject.internal;

import com.google.inject.Binder;
import com.google.inject.Key;
import com.google.inject.internal.util.C$ImmutableSet;
import com.google.inject.internal.util.C$Objects;
import com.google.inject.internal.util.C$ToStringBuilder;
import com.google.inject.spi.BindingTargetVisitor;
import com.google.inject.spi.Dependency;
import com.google.inject.spi.HasDependencies;
import com.google.inject.spi.ProviderKeyBinding;
import java.util.Set;
import javax.inject.Provider;

final class LinkedProviderBindingImpl<T> extends BindingImpl<T> implements ProviderKeyBinding<T>, HasDependencies {
    final Key<? extends Provider<? extends T>> providerKey;

    public LinkedProviderBindingImpl(InjectorImpl injector, Key<T> key, Object source, InternalFactory<? extends T> internalFactory, Scoping scoping, Key<? extends Provider<? extends T>> providerKey2) {
        super(injector, key, source, internalFactory, scoping);
        this.providerKey = providerKey2;
    }

    LinkedProviderBindingImpl(Object source, Key<T> key, Scoping scoping, Key<? extends Provider<? extends T>> providerKey2) {
        super(source, key, scoping);
        this.providerKey = providerKey2;
    }

    public <V> V acceptTargetVisitor(BindingTargetVisitor<? super T, V> visitor) {
        return visitor.visit((ProviderKeyBinding<? extends Object>) this);
    }

    public Key<? extends Provider<? extends T>> getProviderKey() {
        return this.providerKey;
    }

    public Set<Dependency<?>> getDependencies() {
        return C$ImmutableSet.of(Dependency.get(this.providerKey));
    }

    public BindingImpl<T> withScoping(Scoping scoping) {
        return new LinkedProviderBindingImpl(getSource(), getKey(), scoping, this.providerKey);
    }

    public BindingImpl<T> withKey(Key<T> key) {
        return new LinkedProviderBindingImpl(getSource(), key, getScoping(), this.providerKey);
    }

    public void applyTo(Binder binder) {
        getScoping().applyTo(binder.withSource(getSource()).bind(getKey()).toProvider(getProviderKey()));
    }

    public String toString() {
        return new C$ToStringBuilder(ProviderKeyBinding.class).add("key", getKey()).add("source", getSource()).add("scope", getScoping()).add("provider", this.providerKey).toString();
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof LinkedProviderBindingImpl)) {
            return false;
        }
        LinkedProviderBindingImpl<?> o = (LinkedProviderBindingImpl) obj;
        if (!getKey().equals(o.getKey()) || !getScoping().equals(o.getScoping()) || !C$Objects.equal(this.providerKey, o.providerKey)) {
            return false;
        }
        return true;
    }

    public int hashCode() {
        return C$Objects.hashCode(getKey(), getScoping(), this.providerKey);
    }
}
