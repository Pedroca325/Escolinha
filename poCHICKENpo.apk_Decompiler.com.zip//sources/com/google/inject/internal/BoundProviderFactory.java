package com.google.inject.internal;

import com.google.inject.Key;
import com.google.inject.internal.InjectorImpl;
import com.google.inject.spi.Dependency;
import javax.inject.Provider;

final class BoundProviderFactory<T> implements InternalFactory<T>, CreationListener {
    private final InjectorImpl injector;
    private InternalFactory<? extends Provider<? extends T>> providerFactory;
    final Key<? extends Provider<? extends T>> providerKey;
    final Object source;

    BoundProviderFactory(InjectorImpl injector2, Key<? extends Provider<? extends T>> providerKey2, Object source2) {
        this.injector = injector2;
        this.providerKey = providerKey2;
        this.source = source2;
    }

    public void notify(Errors errors) {
        try {
            this.providerFactory = this.injector.getInternalFactory(this.providerKey, errors.withSource(this.source), InjectorImpl.JitLimitation.NEW_OR_EXISTING_JIT);
        } catch (ErrorsException e) {
            errors.merge(e.getErrors());
        }
    }

    public T get(Errors errors, InternalContext context, Dependency<?> dependency, boolean linked) throws ErrorsException {
        Errors errors2 = errors.withSource(this.providerKey);
        try {
            return errors2.checkForNull(((Provider) this.providerFactory.get(errors2, context, dependency, true)).get(), this.source, dependency);
        } catch (RuntimeException userException) {
            throw errors2.errorInProvider(userException).toException();
        }
    }

    public String toString() {
        return this.providerKey.toString();
    }
}
