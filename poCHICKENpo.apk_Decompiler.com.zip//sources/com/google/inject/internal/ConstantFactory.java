package com.google.inject.internal;

import com.google.inject.internal.util.C$ToStringBuilder;
import com.google.inject.spi.Dependency;

final class ConstantFactory<T> implements InternalFactory<T> {
    private final Initializable<T> initializable;

    public ConstantFactory(Initializable<T> initializable2) {
        this.initializable = initializable2;
    }

    public T get(Errors errors, InternalContext context, Dependency dependency, boolean linked) throws ErrorsException {
        return this.initializable.get(errors);
    }

    public String toString() {
        return new C$ToStringBuilder(ConstantFactory.class).add("value", this.initializable).toString();
    }
}
