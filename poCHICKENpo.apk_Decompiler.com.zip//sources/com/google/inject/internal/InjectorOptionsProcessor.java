package com.google.inject.internal;

import com.google.inject.Stage;
import com.google.inject.internal.InjectorImpl;
import com.google.inject.internal.util.C$Preconditions;
import com.google.inject.spi.DisableCircularProxiesOption;
import com.google.inject.spi.RequireExplicitBindingsOption;

class InjectorOptionsProcessor extends AbstractProcessor {
    private boolean disableCircularProxies = false;
    private boolean jitDisabled = false;

    InjectorOptionsProcessor(Errors errors) {
        super(errors);
    }

    public Boolean visit(DisableCircularProxiesOption option) {
        this.disableCircularProxies = true;
        return true;
    }

    public Boolean visit(RequireExplicitBindingsOption option) {
        this.jitDisabled = true;
        return true;
    }

    /* access modifiers changed from: package-private */
    public InjectorImpl.InjectorOptions getOptions(Stage stage, InjectorImpl.InjectorOptions parentOptions) {
        boolean z;
        boolean z2;
        boolean z3 = false;
        C$Preconditions.checkNotNull(stage, "stage must be set");
        if (parentOptions == null) {
            return new InjectorImpl.InjectorOptions(stage, this.jitDisabled, this.disableCircularProxies);
        }
        if (stage == parentOptions.stage) {
            z = true;
        } else {
            z = false;
        }
        C$Preconditions.checkState(z, "child & parent stage don't match");
        if (this.jitDisabled || parentOptions.jitDisabled) {
            z2 = true;
        } else {
            z2 = false;
        }
        if (this.disableCircularProxies || parentOptions.disableCircularProxies) {
            z3 = true;
        }
        return new InjectorImpl.InjectorOptions(stage, z2, z3);
    }
}
