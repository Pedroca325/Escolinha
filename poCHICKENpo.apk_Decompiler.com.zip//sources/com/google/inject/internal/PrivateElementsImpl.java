package com.google.inject.internal;

import com.google.inject.Binder;
import com.google.inject.Injector;
import com.google.inject.Key;
import com.google.inject.PrivateBinder;
import com.google.inject.internal.util.C$ImmutableList;
import com.google.inject.internal.util.C$ImmutableMap;
import com.google.inject.internal.util.C$Lists;
import com.google.inject.internal.util.C$Maps;
import com.google.inject.internal.util.C$Preconditions;
import com.google.inject.internal.util.C$ToStringBuilder;
import com.google.inject.spi.Element;
import com.google.inject.spi.ElementVisitor;
import com.google.inject.spi.PrivateElements;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class PrivateElementsImpl implements PrivateElements {
    private C$ImmutableList<Element> elements;
    private List<Element> elementsMutable = C$Lists.newArrayList();
    private C$ImmutableMap<Key<?>, Object> exposedKeysToSources;
    private List<ExposureBuilder<?>> exposureBuilders = C$Lists.newArrayList();
    private Injector injector;
    private final Object source;

    public PrivateElementsImpl(Object source2) {
        this.source = C$Preconditions.checkNotNull(source2, "source");
    }

    public Object getSource() {
        return this.source;
    }

    public List<Element> getElements() {
        if (this.elements == null) {
            this.elements = C$ImmutableList.copyOf(this.elementsMutable);
            this.elementsMutable = null;
        }
        return this.elements;
    }

    public Injector getInjector() {
        return this.injector;
    }

    public void initInjector(Injector injector2) {
        C$Preconditions.checkState(this.injector == null, "injector already initialized");
        this.injector = (Injector) C$Preconditions.checkNotNull(injector2, "injector");
    }

    public Set<Key<?>> getExposedKeys() {
        if (this.exposedKeysToSources == null) {
            Map<Key<?>, Object> exposedKeysToSourcesMutable = C$Maps.newLinkedHashMap();
            for (ExposureBuilder<?> exposureBuilder : this.exposureBuilders) {
                exposedKeysToSourcesMutable.put(exposureBuilder.getKey(), exposureBuilder.getSource());
            }
            this.exposedKeysToSources = C$ImmutableMap.copyOf(exposedKeysToSourcesMutable);
            this.exposureBuilders = null;
        }
        return this.exposedKeysToSources.keySet();
    }

    public <T> T acceptVisitor(ElementVisitor<T> visitor) {
        return visitor.visit((PrivateElements) this);
    }

    public List<Element> getElementsMutable() {
        return this.elementsMutable;
    }

    public void addExposureBuilder(ExposureBuilder<?> exposureBuilder) {
        this.exposureBuilders.add(exposureBuilder);
    }

    public void applyTo(Binder binder) {
        PrivateBinder privateBinder = binder.withSource(this.source).newPrivateBinder();
        for (Element element : getElements()) {
            element.applyTo(privateBinder);
        }
        getExposedKeys();
        Iterator i$ = this.exposedKeysToSources.entrySet().iterator();
        while (i$.hasNext()) {
            Map.Entry<Key<?>, Object> entry = i$.next();
            privateBinder.withSource(entry.getValue()).expose(entry.getKey());
        }
    }

    public Object getExposedSource(Key<?> key) {
        boolean z;
        getExposedKeys();
        Object source2 = this.exposedKeysToSources.get(key);
        if (source2 != null) {
            z = true;
        } else {
            z = false;
        }
        C$Preconditions.checkArgument(z, "%s not exposed by %s.", key, this);
        return source2;
    }

    public String toString() {
        return new C$ToStringBuilder(PrivateElements.class).add("exposedKeys", getExposedKeys()).add("source", getSource()).toString();
    }
}
