package com.google.inject.internal;

import com.google.inject.internal.util.C$Lists;
import java.util.List;

class ProcessedBindingData {
    private final List<CreationListener> creationListeners = C$Lists.newArrayList();
    private final List<Runnable> uninitializedBindings = C$Lists.newArrayList();

    ProcessedBindingData() {
    }

    /* access modifiers changed from: package-private */
    public void addCreationListener(CreationListener listener) {
        this.creationListeners.add(listener);
    }

    /* access modifiers changed from: package-private */
    public void addUninitializedBinding(Runnable runnable) {
        this.uninitializedBindings.add(runnable);
    }

    /* access modifiers changed from: package-private */
    public void initializeBindings() {
        for (Runnable initializer : this.uninitializedBindings) {
            initializer.run();
        }
    }

    /* access modifiers changed from: package-private */
    public void runCreationListeners(Errors errors) {
        for (CreationListener creationListener : this.creationListeners) {
            creationListener.notify(errors);
        }
    }
}
