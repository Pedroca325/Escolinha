package com.google.inject.internal;

import com.google.inject.Binder;
import com.google.inject.Injector;
import com.google.inject.Key;
import com.google.inject.internal.util.C$ImmutableSet;
import com.google.inject.internal.util.C$ToStringBuilder;
import com.google.inject.spi.BindingTargetVisitor;
import com.google.inject.spi.Dependency;
import com.google.inject.spi.ExposedBinding;
import com.google.inject.spi.PrivateElements;
import java.util.Set;

public final class ExposedBindingImpl<T> extends BindingImpl<T> implements ExposedBinding<T> {
    private final PrivateElements privateElements;

    public ExposedBindingImpl(InjectorImpl injector, Object source, Key<T> key, InternalFactory<T> factory, PrivateElements privateElements2) {
        super(injector, key, source, factory, Scoping.UNSCOPED);
        this.privateElements = privateElements2;
    }

    public <V> V acceptTargetVisitor(BindingTargetVisitor<? super T, V> visitor) {
        return visitor.visit((ExposedBinding<? extends Object>) this);
    }

    public Set<Dependency<?>> getDependencies() {
        return C$ImmutableSet.of(Dependency.get(Key.get(Injector.class)));
    }

    public PrivateElements getPrivateElements() {
        return this.privateElements;
    }

    public String toString() {
        return new C$ToStringBuilder(ExposedBinding.class).add("key", getKey()).add("source", getSource()).add("privateElements", this.privateElements).toString();
    }

    public void applyTo(Binder binder) {
        throw new UnsupportedOperationException("This element represents a synthetic binding.");
    }
}
