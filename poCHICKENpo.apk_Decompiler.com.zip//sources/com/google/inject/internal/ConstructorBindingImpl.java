package com.google.inject.internal;

import com.google.inject.Binder;
import com.google.inject.ConfigurationException;
import com.google.inject.Key;
import com.google.inject.TypeLiteral;
import com.google.inject.internal.util.C$Classes;
import com.google.inject.internal.util.C$ImmutableSet;
import com.google.inject.internal.util.C$Objects;
import com.google.inject.internal.util.C$Preconditions;
import com.google.inject.internal.util.C$ToStringBuilder;
import com.google.inject.spi.BindingTargetVisitor;
import com.google.inject.spi.ConstructorBinding;
import com.google.inject.spi.Dependency;
import com.google.inject.spi.InjectionPoint;
import java.lang.annotation.Annotation;
import java.lang.reflect.Constructor;
import java.lang.reflect.Modifier;
import java.util.Set;

final class ConstructorBindingImpl<T> extends BindingImpl<T> implements ConstructorBinding<T> {
    private final InjectionPoint constructorInjectionPoint;
    private final Factory<T> factory;

    private ConstructorBindingImpl(InjectorImpl injector, Key<T> key, Object source, InternalFactory<? extends T> scopedFactory, Scoping scoping, Factory<T> factory2, InjectionPoint constructorInjectionPoint2) {
        super(injector, key, source, scopedFactory, scoping);
        this.factory = factory2;
        this.constructorInjectionPoint = constructorInjectionPoint2;
    }

    public ConstructorBindingImpl(Key<T> key, Object source, Scoping scoping, InjectionPoint constructorInjectionPoint2, Set<InjectionPoint> injectionPoints) {
        super(source, key, scoping);
        this.factory = new Factory<>(false, key);
        ConstructionProxy<T> constructionProxy = new DefaultConstructionProxyFactory(constructorInjectionPoint2).create();
        this.constructorInjectionPoint = constructorInjectionPoint2;
        ConstructorInjector unused = this.factory.constructorInjector = new ConstructorInjector(injectionPoints, constructionProxy, (SingleParameterInjector<?>[]) null, (MembersInjectorImpl) null);
    }

    static <T> ConstructorBindingImpl<T> create(InjectorImpl injector, Key<T> key, InjectionPoint constructorInjector, Object source, Scoping scoping, Errors errors, boolean failIfNotLinked) throws ErrorsException {
        Class<? super T> rawType;
        Class<? extends Annotation> scopeAnnotation;
        int numErrors = errors.size();
        if (constructorInjector == null) {
            rawType = key.getTypeLiteral().getRawType();
        } else {
            rawType = constructorInjector.getDeclaringType().getRawType();
        }
        if (Modifier.isAbstract(rawType.getModifiers())) {
            errors.missingImplementation(key);
        }
        if (C$Classes.isInnerClass(rawType)) {
            errors.cannotInjectInnerClass(rawType);
        }
        errors.throwIfNewErrors(numErrors);
        if (constructorInjector == null) {
            try {
                constructorInjector = InjectionPoint.forConstructorOf((TypeLiteral<?>) key.getTypeLiteral());
            } catch (ConfigurationException e) {
                throw errors.merge(e.getErrorMessages()).toException();
            }
        }
        if (!scoping.isExplicitlyScoped() && (scopeAnnotation = Annotations.findScopeAnnotation(errors, constructorInjector.getMember().getDeclaringClass())) != null) {
            scoping = Scoping.makeInjectable(Scoping.forAnnotation(scopeAnnotation), injector, errors.withSource(rawType));
        }
        errors.throwIfNewErrors(numErrors);
        Factory<T> factoryFactory = new Factory<>(failIfNotLinked, key);
        return new ConstructorBindingImpl<>(injector, key, source, Scoping.scope(key, injector, factoryFactory, source, scoping), scoping, factoryFactory, constructorInjector);
    }

    public void initialize(InjectorImpl injector, Errors errors) throws ErrorsException {
        boolean unused = this.factory.allowCircularProxy = !injector.options.disableCircularProxies;
        ConstructorInjector unused2 = this.factory.constructorInjector = injector.constructors.get(this.constructorInjectionPoint, errors);
    }

    /* access modifiers changed from: package-private */
    public boolean isInitialized() {
        return this.factory.constructorInjector != null;
    }

    /* access modifiers changed from: package-private */
    public InjectionPoint getInternalConstructor() {
        if (this.factory.constructorInjector != null) {
            return this.factory.constructorInjector.getConstructionProxy().getInjectionPoint();
        }
        return this.constructorInjectionPoint;
    }

    /* access modifiers changed from: package-private */
    public Set<Dependency<?>> getInternalDependencies() {
        C$ImmutableSet.Builder<InjectionPoint> builder = C$ImmutableSet.builder();
        if (this.factory.constructorInjector == null) {
            builder.add(this.constructorInjectionPoint);
            try {
                builder.addAll((Iterable<? extends InjectionPoint>) InjectionPoint.forInstanceMethodsAndFields(this.constructorInjectionPoint.getDeclaringType()));
            } catch (ConfigurationException e) {
            }
        } else {
            builder.add(getConstructor()).addAll(getInjectableMembers());
        }
        return Dependency.forInjectionPoints(builder.build());
    }

    public <V> V acceptTargetVisitor(BindingTargetVisitor<? super T, V> visitor) {
        C$Preconditions.checkState(this.factory.constructorInjector != null, "not initialized");
        return visitor.visit((ConstructorBinding<? extends Object>) this);
    }

    public InjectionPoint getConstructor() {
        C$Preconditions.checkState(this.factory.constructorInjector != null, "Binding is not ready");
        return this.factory.constructorInjector.getConstructionProxy().getInjectionPoint();
    }

    public Set<InjectionPoint> getInjectableMembers() {
        C$Preconditions.checkState(this.factory.constructorInjector != null, "Binding is not ready");
        return this.factory.constructorInjector.getInjectableMembers();
    }

    public Set<Dependency<?>> getDependencies() {
        return Dependency.forInjectionPoints(new C$ImmutableSet.Builder().add(getConstructor()).addAll(getInjectableMembers()).build());
    }

    /* access modifiers changed from: protected */
    public BindingImpl<T> withScoping(Scoping scoping) {
        return new ConstructorBindingImpl((InjectorImpl) null, getKey(), getSource(), this.factory, scoping, this.factory, this.constructorInjectionPoint);
    }

    /* access modifiers changed from: protected */
    public BindingImpl<T> withKey(Key<T> key) {
        return new ConstructorBindingImpl((InjectorImpl) null, key, getSource(), this.factory, getScoping(), this.factory, this.constructorInjectionPoint);
    }

    public void applyTo(Binder binder) {
        getScoping().applyTo(binder.withSource(getSource()).bind(getKey()).toConstructor((Constructor) getConstructor().getMember(), getConstructor().getDeclaringType()));
    }

    public String toString() {
        return new C$ToStringBuilder(ConstructorBinding.class).add("key", getKey()).add("source", getSource()).add("scope", getScoping()).toString();
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof ConstructorBindingImpl)) {
            return false;
        }
        ConstructorBindingImpl<?> o = (ConstructorBindingImpl) obj;
        if (!getKey().equals(o.getKey()) || !getScoping().equals(o.getScoping()) || !C$Objects.equal(this.constructorInjectionPoint, o.constructorInjectionPoint)) {
            return false;
        }
        return true;
    }

    public int hashCode() {
        return C$Objects.hashCode(getKey(), getScoping(), this.constructorInjectionPoint);
    }

    private static class Factory<T> implements InternalFactory<T> {
        /* access modifiers changed from: private */
        public boolean allowCircularProxy;
        /* access modifiers changed from: private */
        public ConstructorInjector<T> constructorInjector;
        private final boolean failIfNotLinked;
        private final Key<?> key;

        Factory(boolean failIfNotLinked2, Key<?> key2) {
            this.failIfNotLinked = failIfNotLinked2;
            this.key = key2;
        }

        public T get(Errors errors, InternalContext context, Dependency<?> dependency, boolean linked) throws ErrorsException {
            C$Preconditions.checkState(this.constructorInjector != null, "Constructor not ready");
            if (!this.failIfNotLinked || linked) {
                return this.constructorInjector.construct(errors, context, dependency.getKey().getTypeLiteral().getRawType(), this.allowCircularProxy);
            }
            throw errors.jitDisabled(this.key).toException();
        }
    }
}
