package com.google.inject.internal;

import com.google.inject.Binder;
import com.google.inject.Key;
import com.google.inject.Module;
import com.google.inject.Provider;
import com.google.inject.Provides;
import com.google.inject.TypeLiteral;
import com.google.inject.internal.util.C$ImmutableSet;
import com.google.inject.internal.util.C$Lists;
import com.google.inject.internal.util.C$Preconditions;
import com.google.inject.spi.Dependency;
import com.google.inject.spi.Message;
import com.google.inject.util.Modules;
import java.lang.annotation.Annotation;
import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.util.List;
import java.util.logging.Logger;

public final class ProviderMethodsModule implements Module {
    private final Object delegate;
    private final TypeLiteral<?> typeLiteral = TypeLiteral.get(this.delegate.getClass());

    private ProviderMethodsModule(Object delegate2) {
        this.delegate = C$Preconditions.checkNotNull(delegate2, "delegate");
    }

    public static Module forModule(Module module) {
        return forObject(module);
    }

    public static Module forObject(Object object) {
        if (object instanceof ProviderMethodsModule) {
            return Modules.EMPTY_MODULE;
        }
        return new ProviderMethodsModule(object);
    }

    public synchronized void configure(Binder binder) {
        for (ProviderMethod<?> providerMethod : getProviderMethods(binder)) {
            providerMethod.configure(binder);
        }
    }

    public List<ProviderMethod<?>> getProviderMethods(Binder binder) {
        List<ProviderMethod<?>> result = C$Lists.newArrayList();
        for (Class cls = this.delegate.getClass(); cls != Object.class; cls = cls.getSuperclass()) {
            for (Method method : cls.getDeclaredMethods()) {
                if (method.isAnnotationPresent(Provides.class)) {
                    result.add(createProviderMethod(binder, method));
                }
            }
        }
        return result;
    }

    /* access modifiers changed from: package-private */
    public <T> ProviderMethod<T> createProviderMethod(Binder binder, Method method) {
        Binder binder2 = binder.withSource(method);
        Errors errors = new Errors(method);
        List<Dependency<?>> dependencies = C$Lists.newArrayList();
        List<Provider<?>> parameterProviders = C$Lists.newArrayList();
        List<TypeLiteral<?>> parameterTypes = this.typeLiteral.getParameterTypes(method);
        Annotation[][] parameterAnnotations = method.getParameterAnnotations();
        for (int i = 0; i < parameterTypes.size(); i++) {
            Key<?> key = getKey(errors, parameterTypes.get(i), method, parameterAnnotations[i]);
            if (key.equals(Key.get(Logger.class))) {
                Key<?> loggerKey = Key.get(Logger.class, UniqueAnnotations.create());
                binder2.bind(loggerKey).toProvider(new LogProvider(method));
                key = loggerKey;
            }
            dependencies.add(Dependency.get(key));
            parameterProviders.add(binder2.getProvider(key));
        }
        Key<T> key2 = getKey(errors, this.typeLiteral.getReturnType(method), method, method.getAnnotations());
        Class<? extends Annotation> scopeAnnotation = Annotations.findScopeAnnotation(errors, method.getAnnotations());
        for (Message message : errors.getMessages()) {
            binder2.addError(message);
        }
        return new ProviderMethod<>(key2, method, this.delegate, C$ImmutableSet.copyOf(dependencies), parameterProviders, scopeAnnotation);
    }

    /* access modifiers changed from: package-private */
    public <T> Key<T> getKey(Errors errors, TypeLiteral<T> type, Member member, Annotation[] annotations) {
        Annotation bindingAnnotation = Annotations.findBindingAnnotation(errors, member, annotations);
        return bindingAnnotation == null ? Key.get(type) : Key.get(type, bindingAnnotation);
    }

    public boolean equals(Object o) {
        return (o instanceof ProviderMethodsModule) && ((ProviderMethodsModule) o).delegate == this.delegate;
    }

    public int hashCode() {
        return this.delegate.hashCode();
    }

    private static final class LogProvider implements Provider<Logger> {
        private final String name;

        public LogProvider(Method method) {
            this.name = method.getDeclaringClass().getName() + "." + method.getName();
        }

        public Logger get() {
            return Logger.getLogger(this.name);
        }
    }
}
