package com.google.inject.internal.util;

/* renamed from: com.google.inject.internal.util.$NullOutputException  reason: invalid class name */
/* compiled from: NullOutputException */
class C$NullOutputException extends NullPointerException {
    public C$NullOutputException(String s) {
        super(s);
    }
}
