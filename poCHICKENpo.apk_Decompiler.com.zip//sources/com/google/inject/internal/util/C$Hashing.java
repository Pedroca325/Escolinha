package com.google.inject.internal.util;

/* renamed from: com.google.inject.internal.util.$Hashing  reason: invalid class name */
/* compiled from: Hashing */
final class C$Hashing {
    private static final int CUTOFF = 536870912;
    private static final int MAX_TABLE_SIZE = 1073741824;

    private C$Hashing() {
    }

    static int smear(int hashCode) {
        int hashCode2 = hashCode ^ ((hashCode >>> 20) ^ (hashCode >>> 12));
        return ((hashCode2 >>> 7) ^ hashCode2) ^ (hashCode2 >>> 4);
    }

    static int chooseTableSize(int setSize) {
        if (setSize < CUTOFF) {
            return Integer.highestOneBit(setSize) << 2;
        }
        C$Preconditions.checkArgument(setSize < MAX_TABLE_SIZE, "collection too large");
        return MAX_TABLE_SIZE;
    }
}
