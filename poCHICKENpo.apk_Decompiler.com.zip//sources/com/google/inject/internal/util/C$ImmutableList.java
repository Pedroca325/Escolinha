package com.google.inject.internal.util;

import java.io.InvalidObjectException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.NoSuchElementException;
import java.util.RandomAccess;

/* renamed from: com.google.inject.internal.util.$ImmutableList  reason: invalid class name */
/* compiled from: ImmutableList */
public abstract class C$ImmutableList<E> extends C$ImmutableCollection<E> implements List<E>, RandomAccess {
    private static final C$ImmutableList<?> EMPTY_IMMUTABLE_LIST = new EmptyImmutableList();

    public abstract int indexOf(@C$Nullable Object obj);

    public abstract C$UnmodifiableIterator<E> iterator();

    public abstract int lastIndexOf(@C$Nullable Object obj);

    public abstract C$ImmutableList<E> subList(int i, int i2);

    public static <E> C$ImmutableList<E> of() {
        return EMPTY_IMMUTABLE_LIST;
    }

    public static <E> C$ImmutableList<E> of(E element) {
        return new RegularImmutableList(copyIntoArray(element));
    }

    public static <E> C$ImmutableList<E> of(E e1, E e2) {
        return new RegularImmutableList(copyIntoArray(e1, e2));
    }

    public static <E> C$ImmutableList<E> of(E e1, E e2, E e3) {
        return new RegularImmutableList(copyIntoArray(e1, e2, e3));
    }

    public static <E> C$ImmutableList<E> of(E e1, E e2, E e3, E e4) {
        return new RegularImmutableList(copyIntoArray(e1, e2, e3, e4));
    }

    public static <E> C$ImmutableList<E> of(E e1, E e2, E e3, E e4, E e5) {
        return new RegularImmutableList(copyIntoArray(e1, e2, e3, e4, e5));
    }

    public static <E> C$ImmutableList<E> of(E... elements) {
        return elements.length == 0 ? of() : new RegularImmutableList(copyIntoArray(elements));
    }

    public static <E> C$ImmutableList<E> copyOf(Iterable<? extends E> elements) {
        if (elements instanceof C$ImmutableList) {
            return (C$ImmutableList) elements;
        }
        if (elements instanceof Collection) {
            return copyOfInternal((Collection) elements);
        }
        return copyOfInternal(C$Lists.newArrayList(elements));
    }

    public static <E> C$ImmutableList<E> copyOf(Iterator<? extends E> elements) {
        return copyOfInternal(C$Lists.newArrayList(elements));
    }

    private static <E> C$ImmutableList<E> copyOfInternal(ArrayList<? extends E> list) {
        return list.isEmpty() ? of() : new RegularImmutableList(nullChecked(list.toArray()));
    }

    private static Object[] nullChecked(Object[] array) {
        int len = array.length;
        for (int i = 0; i < len; i++) {
            if (array[i] == null) {
                throw new NullPointerException("at index " + i);
            }
        }
        return array;
    }

    private static <E> C$ImmutableList<E> copyOfInternal(Collection<? extends E> collection) {
        int size = collection.size();
        return size == 0 ? of() : createFromIterable(collection, size);
    }

    private C$ImmutableList() {
    }

    public final boolean addAll(int index, Collection<? extends E> collection) {
        throw new UnsupportedOperationException();
    }

    public final E set(int index, E e) {
        throw new UnsupportedOperationException();
    }

    public final void add(int index, E e) {
        throw new UnsupportedOperationException();
    }

    public final E remove(int index) {
        throw new UnsupportedOperationException();
    }

    /* renamed from: com.google.inject.internal.util.$ImmutableList$EmptyImmutableList */
    /* compiled from: ImmutableList */
    private static final class EmptyImmutableList extends C$ImmutableList<Object> {
        private static final Object[] EMPTY_ARRAY = new Object[0];

        private EmptyImmutableList() {
            super();
        }

        public int size() {
            return 0;
        }

        public boolean isEmpty() {
            return true;
        }

        public boolean contains(Object target) {
            return false;
        }

        public C$UnmodifiableIterator<Object> iterator() {
            return C$Iterators.emptyIterator();
        }

        public Object[] toArray() {
            return EMPTY_ARRAY;
        }

        public <T> T[] toArray(T[] a) {
            if (a.length > 0) {
                a[0] = null;
            }
            return a;
        }

        public Object get(int index) {
            C$Preconditions.checkElementIndex(index, 0);
            throw new AssertionError("unreachable");
        }

        public int indexOf(Object target) {
            return -1;
        }

        public int lastIndexOf(Object target) {
            return -1;
        }

        public C$ImmutableList<Object> subList(int fromIndex, int toIndex) {
            C$Preconditions.checkPositionIndexes(fromIndex, toIndex, 0);
            return this;
        }

        public ListIterator<Object> listIterator() {
            return C$Iterators.emptyListIterator();
        }

        public ListIterator<Object> listIterator(int start) {
            C$Preconditions.checkPositionIndex(start, 0);
            return C$Iterators.emptyListIterator();
        }

        public boolean containsAll(Collection<?> targets) {
            return targets.isEmpty();
        }

        public boolean equals(@C$Nullable Object object) {
            if (object instanceof List) {
                return ((List) object).isEmpty();
            }
            return false;
        }

        public int hashCode() {
            return 1;
        }

        public String toString() {
            return "[]";
        }
    }

    /* renamed from: com.google.inject.internal.util.$ImmutableList$RegularImmutableList */
    /* compiled from: ImmutableList */
    private static final class RegularImmutableList<E> extends C$ImmutableList<E> {
        private final Object[] array;
        private final int offset;
        /* access modifiers changed from: private */
        public final int size;

        private RegularImmutableList(Object[] array2, int offset2, int size2) {
            super();
            this.offset = offset2;
            this.size = size2;
            this.array = array2;
        }

        private RegularImmutableList(Object[] array2) {
            this(array2, 0, array2.length);
        }

        public int size() {
            return this.size;
        }

        public boolean isEmpty() {
            return false;
        }

        public boolean contains(Object target) {
            return indexOf(target) != -1;
        }

        public C$UnmodifiableIterator<E> iterator() {
            return C$Iterators.forArray(this.array, this.offset, this.size);
        }

        public Object[] toArray() {
            Object[] newArray = new Object[size()];
            System.arraycopy(this.array, this.offset, newArray, 0, this.size);
            return newArray;
        }

        public <T> T[] toArray(T[] other) {
            if (other.length < this.size) {
                other = C$ObjectArrays.newArray(other, this.size);
            } else if (other.length > this.size) {
                other[this.size] = null;
            }
            System.arraycopy(this.array, this.offset, other, 0, this.size);
            return other;
        }

        public E get(int index) {
            C$Preconditions.checkElementIndex(index, this.size);
            return this.array[this.offset + index];
        }

        public int indexOf(Object target) {
            if (target != null) {
                for (int i = this.offset; i < this.offset + this.size; i++) {
                    if (this.array[i].equals(target)) {
                        return i - this.offset;
                    }
                }
            }
            return -1;
        }

        public int lastIndexOf(Object target) {
            if (target != null) {
                for (int i = (this.offset + this.size) - 1; i >= this.offset; i--) {
                    if (this.array[i].equals(target)) {
                        return i - this.offset;
                    }
                }
            }
            return -1;
        }

        public C$ImmutableList<E> subList(int fromIndex, int toIndex) {
            C$Preconditions.checkPositionIndexes(fromIndex, toIndex, this.size);
            return fromIndex == toIndex ? C$ImmutableList.of() : new RegularImmutableList(this.array, this.offset + fromIndex, toIndex - fromIndex);
        }

        public ListIterator<E> listIterator() {
            return listIterator(0);
        }

        public ListIterator<E> listIterator(final int start) {
            C$Preconditions.checkPositionIndex(start, this.size);
            return new ListIterator<E>() {
                int index = start;

                public boolean hasNext() {
                    return this.index < RegularImmutableList.this.size;
                }

                public boolean hasPrevious() {
                    return this.index > 0;
                }

                public int nextIndex() {
                    return this.index;
                }

                public int previousIndex() {
                    return this.index - 1;
                }

                public E next() {
                    try {
                        E result = RegularImmutableList.this.get(this.index);
                        this.index++;
                        return result;
                    } catch (IndexOutOfBoundsException e) {
                        throw new NoSuchElementException();
                    }
                }

                public E previous() {
                    try {
                        this.index--;
                        return RegularImmutableList.this.get(this.index - 1);
                    } catch (IndexOutOfBoundsException e) {
                        throw new NoSuchElementException();
                    }
                }

                public void set(E e) {
                    throw new UnsupportedOperationException();
                }

                public void add(E e) {
                    throw new UnsupportedOperationException();
                }

                public void remove() {
                    throw new UnsupportedOperationException();
                }
            };
        }

        public boolean equals(@C$Nullable Object object) {
            if (object == this) {
                return true;
            }
            if (!(object instanceof List)) {
                return false;
            }
            List<?> that = (List) object;
            if (size() != that.size()) {
                return false;
            }
            int index = this.offset;
            if (object instanceof RegularImmutableList) {
                RegularImmutableList<?> other = (RegularImmutableList) object;
                int i = other.offset;
                while (i < other.offset + other.size) {
                    int index2 = index + 1;
                    if (!this.array[index].equals(other.array[i])) {
                        return false;
                    }
                    i++;
                    index = index2;
                }
                return true;
            }
            for (Object element : that) {
                int index3 = index + 1;
                if (!this.array[index].equals(element)) {
                    return false;
                }
                index = index3;
            }
            return true;
        }

        public int hashCode() {
            int hashCode = 1;
            for (int i = this.offset; i < this.offset + this.size; i++) {
                hashCode = (hashCode * 31) + this.array[i].hashCode();
            }
            return hashCode;
        }

        public String toString() {
            StringBuilder sb = new StringBuilder(size() * 16);
            sb.append('[').append(this.array[this.offset]);
            for (int i = this.offset + 1; i < this.offset + this.size; i++) {
                sb.append(", ").append(this.array[i]);
            }
            return sb.append(']').toString();
        }
    }

    private static Object[] copyIntoArray(Object... source) {
        Object[] array = new Object[source.length];
        Object[] arr$ = source;
        int len$ = arr$.length;
        int i$ = 0;
        int index = 0;
        while (i$ < len$) {
            Object element = arr$[i$];
            if (element == null) {
                throw new NullPointerException("at index " + index);
            }
            array[index] = element;
            i$++;
            index++;
        }
        return array;
    }

    private static <E> C$ImmutableList<E> createFromIterable(Iterable<?> source, int estimatedSize) {
        Object[] array = new Object[estimatedSize];
        int index = 0;
        for (Object element : source) {
            if (index == estimatedSize) {
                estimatedSize = ((estimatedSize / 2) + 1) * 3;
                array = copyOf(array, estimatedSize);
            }
            if (element == null) {
                throw new NullPointerException("at index " + index);
            }
            array[index] = element;
            index++;
        }
        if (index == 0) {
            return of();
        }
        if (index != estimatedSize) {
            array = copyOf(array, index);
        }
        return new RegularImmutableList(array, 0, index);
    }

    private static Object[] copyOf(Object[] oldArray, int newSize) {
        Object[] newArray = new Object[newSize];
        System.arraycopy(oldArray, 0, newArray, 0, Math.min(oldArray.length, newSize));
        return newArray;
    }

    /* renamed from: com.google.inject.internal.util.$ImmutableList$SerializedForm */
    /* compiled from: ImmutableList */
    private static class SerializedForm implements Serializable {
        private static final long serialVersionUID = 0;
        final Object[] elements;

        SerializedForm(Object[] elements2) {
            this.elements = elements2;
        }

        /* access modifiers changed from: package-private */
        public Object readResolve() {
            return C$ImmutableList.of((E[]) this.elements);
        }
    }

    private void readObject(ObjectInputStream stream) throws InvalidObjectException {
        throw new InvalidObjectException("Use SerializedForm");
    }

    /* access modifiers changed from: package-private */
    public Object writeReplace() {
        return new SerializedForm(toArray());
    }

    public static <E> Builder<E> builder() {
        return new Builder<>();
    }

    /* renamed from: com.google.inject.internal.util.$ImmutableList$Builder */
    /* compiled from: ImmutableList */
    public static class Builder<E> {
        private final ArrayList<E> contents = C$Lists.newArrayList();

        public Builder<E> add(E element) {
            C$Preconditions.checkNotNull(element, "element cannot be null");
            this.contents.add(element);
            return this;
        }

        public Builder<E> addAll(Iterable<? extends E> elements) {
            if (elements instanceof Collection) {
                this.contents.ensureCapacity(this.contents.size() + ((Collection) elements).size());
            }
            for (E elem : elements) {
                C$Preconditions.checkNotNull(elem, "elements contains a null");
                this.contents.add(elem);
            }
            return this;
        }

        public C$ImmutableList<E> build() {
            return C$ImmutableList.copyOf(this.contents);
        }
    }
}
