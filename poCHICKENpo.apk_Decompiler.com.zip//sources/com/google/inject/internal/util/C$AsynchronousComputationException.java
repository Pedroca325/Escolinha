package com.google.inject.internal.util;

/* renamed from: com.google.inject.internal.util.$AsynchronousComputationException  reason: invalid class name */
/* compiled from: AsynchronousComputationException */
public class C$AsynchronousComputationException extends C$ComputationException {
    public C$AsynchronousComputationException(Throwable cause) {
        super(cause);
    }
}
