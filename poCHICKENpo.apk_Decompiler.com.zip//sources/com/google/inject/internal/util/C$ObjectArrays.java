package com.google.inject.internal.util;

import java.lang.reflect.Array;

/* renamed from: com.google.inject.internal.util.$ObjectArrays  reason: invalid class name */
/* compiled from: ObjectArrays */
public final class C$ObjectArrays {
    private C$ObjectArrays() {
    }

    public static <T> T[] newArray(T[] reference, int length) {
        return (Object[]) ((Object[]) Array.newInstance(reference.getClass().getComponentType(), length));
    }
}
