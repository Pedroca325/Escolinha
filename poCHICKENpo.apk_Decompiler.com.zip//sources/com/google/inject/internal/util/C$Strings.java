package com.google.inject.internal.util;

/* renamed from: com.google.inject.internal.util.$Strings  reason: invalid class name */
/* compiled from: Strings */
public class C$Strings {
    private C$Strings() {
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0007, code lost:
        r1 = r4.charAt(0);
        r0 = java.lang.Character.toUpperCase(r1);
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.String capitalize(java.lang.String r4) {
        /*
            int r2 = r4.length()
            if (r2 != 0) goto L_0x0007
        L_0x0006:
            return r4
        L_0x0007:
            r2 = 0
            char r1 = r4.charAt(r2)
            char r0 = java.lang.Character.toUpperCase(r1)
            if (r1 == r0) goto L_0x0006
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>()
            java.lang.StringBuilder r2 = r2.append(r0)
            r3 = 1
            java.lang.String r3 = r4.substring(r3)
            java.lang.StringBuilder r2 = r2.append(r3)
            java.lang.String r4 = r2.toString()
            goto L_0x0006
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.inject.internal.util.C$Strings.capitalize(java.lang.String):java.lang.String");
    }
}
