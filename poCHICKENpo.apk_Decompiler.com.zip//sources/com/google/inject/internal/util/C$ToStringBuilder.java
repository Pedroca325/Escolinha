package com.google.inject.internal.util;

import java.util.LinkedHashMap;
import java.util.Map;

/* renamed from: com.google.inject.internal.util.$ToStringBuilder  reason: invalid class name */
/* compiled from: ToStringBuilder */
public class C$ToStringBuilder {
    final Map<String, Object> map = new LinkedHashMap();
    final String name;

    public C$ToStringBuilder(Class type) {
        this.name = type.getSimpleName();
    }

    public C$ToStringBuilder add(String name2, Object value) {
        if (this.map.put(name2, value) == null) {
            return this;
        }
        throw new RuntimeException("Duplicate names: " + name2);
    }

    public String toString() {
        return this.name + this.map.toString().replace('{', '[').replace('}', ']');
    }
}
