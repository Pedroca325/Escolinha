package com.google.inject.internal.util;

import java.io.IOException;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Map;

/* renamed from: com.google.inject.internal.util.$Join  reason: invalid class name */
/* compiled from: Join */
public final class C$Join {
    private C$Join() {
    }

    public static String join(String delimiter, Iterable<?> tokens) {
        return join(delimiter, tokens.iterator());
    }

    public static String join(String delimiter, Object[] tokens) {
        return join(delimiter, (Iterable<?>) Arrays.asList(tokens));
    }

    public static String join(String delimiter, @C$Nullable Object firstToken, Object... otherTokens) {
        C$Preconditions.checkNotNull(otherTokens);
        return join(delimiter, (Iterable<?>) C$Lists.newArrayList(firstToken, otherTokens));
    }

    public static String join(String delimiter, Iterator<?> tokens) {
        StringBuilder sb = new StringBuilder();
        join(sb, delimiter, tokens);
        return sb.toString();
    }

    public static String join(String keyValueSeparator, String entryDelimiter, Map<?, ?> map) {
        return ((StringBuilder) join(new StringBuilder(), keyValueSeparator, entryDelimiter, map)).toString();
    }

    public static <T extends Appendable> T join(T appendable, String delimiter, Iterable<?> tokens) {
        return join(appendable, delimiter, tokens.iterator());
    }

    public static <T extends Appendable> T join(T appendable, String delimiter, Object[] tokens) {
        return join(appendable, delimiter, (Iterable<?>) Arrays.asList(tokens));
    }

    public static <T extends Appendable> T join(T appendable, String delimiter, @C$Nullable Object firstToken, Object... otherTokens) {
        C$Preconditions.checkNotNull(otherTokens);
        return join(appendable, delimiter, (Iterable<?>) C$Lists.newArrayList(firstToken, otherTokens));
    }

    public static <T extends Appendable> T join(T appendable, String delimiter, Iterator<?> tokens) {
        C$Preconditions.checkNotNull(appendable);
        C$Preconditions.checkNotNull(delimiter);
        if (tokens.hasNext()) {
            try {
                appendOneToken(appendable, tokens.next());
                while (tokens.hasNext()) {
                    appendable.append(delimiter);
                    appendOneToken(appendable, tokens.next());
                }
            } catch (IOException e) {
                throw new JoinException(e);
            }
        }
        return appendable;
    }

    public static <T extends Appendable> T join(T appendable, String keyValueSeparator, String entryDelimiter, Map<?, ?> map) {
        C$Preconditions.checkNotNull(appendable);
        C$Preconditions.checkNotNull(keyValueSeparator);
        C$Preconditions.checkNotNull(entryDelimiter);
        Iterator<Map.Entry<?, ?>> it = map.entrySet().iterator();
        if (it.hasNext()) {
            try {
                appendOneEntry(appendable, keyValueSeparator, it.next());
                while (it.hasNext()) {
                    appendable.append(entryDelimiter);
                    appendOneEntry(appendable, keyValueSeparator, it.next());
                }
            } catch (IOException e) {
                throw new JoinException(e);
            }
        }
        return appendable;
    }

    private static void appendOneEntry(Appendable appendable, String keyValueSeparator, Map.Entry<?, ?> entry) throws IOException {
        appendOneToken(appendable, entry.getKey());
        appendable.append(keyValueSeparator);
        appendOneToken(appendable, entry.getValue());
    }

    private static void appendOneToken(Appendable appendable, Object token) throws IOException {
        appendable.append(toCharSequence(token));
    }

    private static CharSequence toCharSequence(Object token) {
        return token instanceof CharSequence ? (CharSequence) token : String.valueOf(token);
    }

    /* renamed from: com.google.inject.internal.util.$Join$JoinException */
    /* compiled from: Join */
    public static class JoinException extends RuntimeException {
        private static final long serialVersionUID = 1;

        private JoinException(IOException cause) {
            super(cause);
        }
    }
}
