package com.google.inject.internal.util;

import java.lang.ref.PhantomReference;

/* renamed from: com.google.inject.internal.util.$FinalizablePhantomReference  reason: invalid class name */
/* compiled from: FinalizablePhantomReference */
public abstract class C$FinalizablePhantomReference<T> extends PhantomReference<T> implements C$FinalizableReference {
    protected C$FinalizablePhantomReference(T referent, C$FinalizableReferenceQueue queue) {
        super(referent, queue.queue);
        queue.cleanUp();
    }
}
