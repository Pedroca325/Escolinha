package com.google.inject.internal.util;

import java.util.Iterator;

/* renamed from: com.google.inject.internal.util.$UnmodifiableIterator  reason: invalid class name */
/* compiled from: UnmodifiableIterator */
public abstract class C$UnmodifiableIterator<E> implements Iterator<E> {
    public final void remove() {
        throw new UnsupportedOperationException();
    }
}
