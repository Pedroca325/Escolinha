package com.google.inject.internal.util;

import java.util.Collection;
import java.util.Set;

/* renamed from: com.google.inject.internal.util.$Collections2  reason: invalid class name */
/* compiled from: Collections2 */
public final class C$Collections2 {
    private C$Collections2() {
    }

    static <E> Collection<E> toCollection(Iterable<E> iterable) {
        return iterable instanceof Collection ? (Collection) iterable : C$Lists.newArrayList(iterable);
    }

    static boolean setEquals(Set<?> thisSet, @C$Nullable Object object) {
        if (object == thisSet) {
            return true;
        }
        if (!(object instanceof Set)) {
            return false;
        }
        Set<?> thatSet = (Set) object;
        if (thisSet.size() != thatSet.size() || !thisSet.containsAll(thatSet)) {
            return false;
        }
        return true;
    }
}
