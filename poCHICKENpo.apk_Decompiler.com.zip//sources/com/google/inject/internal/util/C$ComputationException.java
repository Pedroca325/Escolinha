package com.google.inject.internal.util;

/* renamed from: com.google.inject.internal.util.$ComputationException  reason: invalid class name */
/* compiled from: ComputationException */
public class C$ComputationException extends RuntimeException {
    public C$ComputationException(Throwable cause) {
        super(cause);
    }
}
