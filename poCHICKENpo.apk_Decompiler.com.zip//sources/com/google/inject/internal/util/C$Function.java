package com.google.inject.internal.util;

/* renamed from: com.google.inject.internal.util.$Function  reason: invalid class name */
/* compiled from: Function */
public interface C$Function<F, T> {
    T apply(@C$Nullable F f);

    boolean equals(@C$Nullable Object obj);
}
