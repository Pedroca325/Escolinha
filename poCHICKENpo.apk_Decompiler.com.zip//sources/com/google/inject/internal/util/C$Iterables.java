package com.google.inject.internal.util;

import java.util.Arrays;
import java.util.Iterator;

/* renamed from: com.google.inject.internal.util.$Iterables  reason: invalid class name */
/* compiled from: Iterables */
public final class C$Iterables {
    private C$Iterables() {
    }

    public static String toString(Iterable<?> iterable) {
        return C$Iterators.toString(iterable.iterator());
    }

    public static <T> T getOnlyElement(Iterable<T> iterable) {
        return C$Iterators.getOnlyElement(iterable.iterator());
    }

    public static <T> Iterable<T> concat(Iterable<? extends T> a, Iterable<? extends T> b) {
        C$Preconditions.checkNotNull(a);
        C$Preconditions.checkNotNull(b);
        return concat(Arrays.asList(new Iterable[]{a, b}));
    }

    public static <T> Iterable<T> concat(Iterable<? extends Iterable<? extends T>> inputs) {
        final Iterable<Iterator<? extends T>> iterators = transform(inputs, new C$Function<Iterable<? extends T>, Iterator<? extends T>>() {
            public Iterator<? extends T> apply(Iterable<? extends T> from) {
                return from.iterator();
            }
        });
        return new IterableWithToString<T>() {
            public Iterator<T> iterator() {
                return C$Iterators.concat(iterators.iterator());
            }
        };
    }

    public static <F, T> Iterable<T> transform(final Iterable<F> fromIterable, final C$Function<? super F, ? extends T> function) {
        C$Preconditions.checkNotNull(fromIterable);
        C$Preconditions.checkNotNull(function);
        return new IterableWithToString<T>() {
            public Iterator<T> iterator() {
                return C$Iterators.transform(fromIterable.iterator(), function);
            }
        };
    }

    /* renamed from: com.google.inject.internal.util.$Iterables$IterableWithToString */
    /* compiled from: Iterables */
    static abstract class IterableWithToString<E> implements Iterable<E> {
        IterableWithToString() {
        }

        public String toString() {
            return C$Iterables.toString(this);
        }
    }
}
