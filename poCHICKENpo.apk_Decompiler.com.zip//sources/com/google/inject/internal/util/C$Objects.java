package com.google.inject.internal.util;

import java.util.Arrays;

/* renamed from: com.google.inject.internal.util.$Objects  reason: invalid class name */
/* compiled from: Objects */
public final class C$Objects {
    private C$Objects() {
    }

    public static boolean equal(@C$Nullable Object a, @C$Nullable Object b) {
        return a == b || (a != null && a.equals(b));
    }

    public static int hashCode(Object... objects) {
        return Arrays.hashCode(objects);
    }
}
