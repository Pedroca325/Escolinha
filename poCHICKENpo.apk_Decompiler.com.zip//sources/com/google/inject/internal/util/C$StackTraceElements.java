package com.google.inject.internal.util;

import java.lang.reflect.Constructor;
import java.lang.reflect.Member;

/* renamed from: com.google.inject.internal.util.$StackTraceElements  reason: invalid class name */
/* compiled from: StackTraceElements */
public class C$StackTraceElements {
    public static Object forMember(Member member) {
        if (member == null) {
            return C$SourceProvider.UNKNOWN_SOURCE;
        }
        return new StackTraceElement(member.getDeclaringClass().getName(), C$Classes.memberType(member) == Constructor.class ? "<init>" : member.getName(), (String) null, -1);
    }

    public static Object forType(Class<?> implementation) {
        return new StackTraceElement(implementation.getName(), "class", (String) null, -1);
    }
}
