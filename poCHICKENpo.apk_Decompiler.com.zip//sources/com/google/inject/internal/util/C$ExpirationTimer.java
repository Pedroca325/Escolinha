package com.google.inject.internal.util;

import java.util.Timer;

/* renamed from: com.google.inject.internal.util.$ExpirationTimer  reason: invalid class name */
/* compiled from: ExpirationTimer */
class C$ExpirationTimer {
    static Timer instance = new Timer(true);

    C$ExpirationTimer() {
    }
}
