package com.google.inject.internal.util;

import java.util.Enumeration;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.NoSuchElementException;

/* renamed from: com.google.inject.internal.util.$Iterators  reason: invalid class name */
/* compiled from: Iterators */
public final class C$Iterators {
    static final Iterator<Object> EMPTY_ITERATOR = new C$UnmodifiableIterator<Object>() {
        public boolean hasNext() {
            return false;
        }

        public Object next() {
            throw new NoSuchElementException();
        }
    };
    private static final ListIterator<Object> EMPTY_LIST_ITERATOR = new ListIterator<Object>() {
        public boolean hasNext() {
            return false;
        }

        public boolean hasPrevious() {
            return false;
        }

        public int nextIndex() {
            return 0;
        }

        public int previousIndex() {
            return -1;
        }

        public Object next() {
            throw new NoSuchElementException();
        }

        public Object previous() {
            throw new NoSuchElementException();
        }

        public void set(Object o) {
            throw new UnsupportedOperationException();
        }

        public void add(Object o) {
            throw new UnsupportedOperationException();
        }

        public void remove() {
            throw new UnsupportedOperationException();
        }
    };

    private C$Iterators() {
    }

    public static <T> C$UnmodifiableIterator<T> emptyIterator() {
        return (C$UnmodifiableIterator) EMPTY_ITERATOR;
    }

    public static <T> ListIterator<T> emptyListIterator() {
        return EMPTY_LIST_ITERATOR;
    }

    public static <T> C$UnmodifiableIterator<T> unmodifiableIterator(final Iterator<T> iterator) {
        C$Preconditions.checkNotNull(iterator);
        return new C$UnmodifiableIterator<T>() {
            public boolean hasNext() {
                return iterator.hasNext();
            }

            public T next() {
                return iterator.next();
            }
        };
    }

    public static String toString(Iterator<?> iterator) {
        if (!iterator.hasNext()) {
            return "[]";
        }
        StringBuilder builder = new StringBuilder();
        builder.append('[').append(iterator.next());
        while (iterator.hasNext()) {
            builder.append(", ").append(iterator.next());
        }
        return builder.append(']').toString();
    }

    public static <T> T getOnlyElement(Iterator<T> iterator) {
        T first = iterator.next();
        if (!iterator.hasNext()) {
            return first;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("expected one element but was: <" + first);
        for (int i = 0; i < 4 && iterator.hasNext(); i++) {
            sb.append(", " + iterator.next());
        }
        if (iterator.hasNext()) {
            sb.append(", ...");
        }
        sb.append(">");
        throw new IllegalArgumentException(sb.toString());
    }

    public static <T> Iterator<T> concat(final Iterator<? extends Iterator<? extends T>> inputs) {
        C$Preconditions.checkNotNull(inputs);
        return new Iterator<T>() {
            Iterator<? extends T> current = C$Iterators.emptyIterator();
            Iterator<? extends T> removeFrom;

            public boolean hasNext() {
                while (!this.current.hasNext() && inputs.hasNext()) {
                    this.current = (Iterator) inputs.next();
                }
                return this.current.hasNext();
            }

            public T next() {
                if (!hasNext()) {
                    throw new NoSuchElementException();
                }
                this.removeFrom = this.current;
                return this.current.next();
            }

            public void remove() {
                C$Preconditions.checkState(this.removeFrom != null, "no calls to next() since last call to remove()");
                this.removeFrom.remove();
                this.removeFrom = null;
            }
        };
    }

    public static <F, T> Iterator<T> transform(final Iterator<F> fromIterator, final C$Function<? super F, ? extends T> function) {
        C$Preconditions.checkNotNull(fromIterator);
        C$Preconditions.checkNotNull(function);
        return new Iterator<T>() {
            public boolean hasNext() {
                return fromIterator.hasNext();
            }

            public T next() {
                return function.apply(fromIterator.next());
            }

            public void remove() {
                fromIterator.remove();
            }
        };
    }

    public static <T> C$UnmodifiableIterator<T> forArray(final T... array) {
        return new C$UnmodifiableIterator<T>() {
            int i = 0;
            final int length = array.length;

            public boolean hasNext() {
                return this.i < this.length;
            }

            public T next() {
                try {
                    T t = array[this.i];
                    this.i++;
                    return t;
                } catch (ArrayIndexOutOfBoundsException e) {
                    throw new NoSuchElementException();
                }
            }
        };
    }

    public static <T> C$UnmodifiableIterator<T> forArray(final T[] array, final int offset, int length) {
        C$Preconditions.checkArgument(length >= 0);
        final int end = offset + length;
        C$Preconditions.checkPositionIndexes(offset, end, array.length);
        return new C$UnmodifiableIterator<T>() {
            int i = offset;

            public boolean hasNext() {
                return this.i < end;
            }

            public T next() {
                if (!hasNext()) {
                    throw new NoSuchElementException();
                }
                T[] tArr = array;
                int i2 = this.i;
                this.i = i2 + 1;
                return tArr[i2];
            }
        };
    }

    public static <T> C$UnmodifiableIterator<T> singletonIterator(@C$Nullable final T value) {
        return new C$UnmodifiableIterator<T>() {
            boolean done;

            public boolean hasNext() {
                return !this.done;
            }

            public T next() {
                if (this.done) {
                    throw new NoSuchElementException();
                }
                this.done = true;
                return value;
            }
        };
    }

    public static <T> Enumeration<T> asEnumeration(final Iterator<T> iterator) {
        C$Preconditions.checkNotNull(iterator);
        return new Enumeration<T>() {
            public boolean hasMoreElements() {
                return iterator.hasNext();
            }

            public T nextElement() {
                return iterator.next();
            }
        };
    }
}
