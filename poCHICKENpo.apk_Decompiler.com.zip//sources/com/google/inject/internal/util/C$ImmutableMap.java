package com.google.inject.internal.util;

import com.google.inject.internal.util.C$ImmutableSet;
import com.xtremelabs.robolectric.shadows.ShadowVideoView;
import java.io.Serializable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentMap;

/* renamed from: com.google.inject.internal.util.$ImmutableMap  reason: invalid class name */
/* compiled from: ImmutableMap */
public abstract class C$ImmutableMap<K, V> implements ConcurrentMap<K, V>, Serializable {
    private static final C$ImmutableMap<?, ?> EMPTY_IMMUTABLE_MAP = new EmptyImmutableMap();

    public abstract boolean containsKey(@C$Nullable Object obj);

    public abstract boolean containsValue(@C$Nullable Object obj);

    public abstract C$ImmutableSet<Map.Entry<K, V>> entrySet();

    public abstract V get(@C$Nullable Object obj);

    public abstract C$ImmutableSet<K> keySet();

    public abstract C$ImmutableCollection<V> values();

    public static <K, V> C$ImmutableMap<K, V> of() {
        return EMPTY_IMMUTABLE_MAP;
    }

    public static <K, V> C$ImmutableMap<K, V> of(K k1, V v1) {
        return new SingletonImmutableMap(C$Preconditions.checkNotNull(k1), C$Preconditions.checkNotNull(v1));
    }

    public static <K, V> C$ImmutableMap<K, V> of(K k1, V v1, K k2, V v2) {
        return new RegularImmutableMap(new Map.Entry[]{entryOf(k1, v1), entryOf(k2, v2)});
    }

    public static <K, V> C$ImmutableMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3) {
        return new RegularImmutableMap(new Map.Entry[]{entryOf(k1, v1), entryOf(k2, v2), entryOf(k3, v3)});
    }

    public static <K, V> C$ImmutableMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3, K k4, V v4) {
        return new RegularImmutableMap(new Map.Entry[]{entryOf(k1, v1), entryOf(k2, v2), entryOf(k3, v3), entryOf(k4, v4)});
    }

    public static <K, V> C$ImmutableMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3, K k4, V v4, K k5, V v5) {
        return new RegularImmutableMap(new Map.Entry[]{entryOf(k1, v1), entryOf(k2, v2), entryOf(k3, v3), entryOf(k4, v4), entryOf(k5, v5)});
    }

    public static <K, V> Builder<K, V> builder() {
        return new Builder<>();
    }

    /* access modifiers changed from: private */
    public static <K, V> Map.Entry<K, V> entryOf(K key, V value) {
        return C$Maps.immutableEntry(C$Preconditions.checkNotNull(key), C$Preconditions.checkNotNull(value));
    }

    /* renamed from: com.google.inject.internal.util.$ImmutableMap$Builder */
    /* compiled from: ImmutableMap */
    public static class Builder<K, V> {
        final List<Map.Entry<K, V>> entries = C$Lists.newArrayList();

        public Builder<K, V> put(K key, V value) {
            this.entries.add(C$ImmutableMap.entryOf(key, value));
            return this;
        }

        public Builder<K, V> putAll(Map<? extends K, ? extends V> map) {
            for (Map.Entry<? extends K, ? extends V> entry : map.entrySet()) {
                put(entry.getKey(), entry.getValue());
            }
            return this;
        }

        public C$ImmutableMap<K, V> build() {
            return fromEntryList(this.entries);
        }

        private static <K, V> C$ImmutableMap<K, V> fromEntryList(List<Map.Entry<K, V>> entries2) {
            switch (entries2.size()) {
                case ShadowVideoView.STOP /*0*/:
                    return C$ImmutableMap.of();
                case 1:
                    return new SingletonImmutableMap((Map.Entry) C$Iterables.getOnlyElement(entries2));
                default:
                    return new RegularImmutableMap((Map.Entry[]) entries2.toArray(new Map.Entry[entries2.size()]));
            }
        }
    }

    public static <K, V> C$ImmutableMap<K, V> copyOf(Map<? extends K, ? extends V> map) {
        if (map instanceof C$ImmutableMap) {
            return (C$ImmutableMap) map;
        }
        int size = map.size();
        switch (size) {
            case ShadowVideoView.STOP /*0*/:
                return of();
            case 1:
                Map.Entry<? extends K, ? extends V> loneEntry = (Map.Entry) C$Iterables.getOnlyElement(map.entrySet());
                return of(loneEntry.getKey(), loneEntry.getValue());
            default:
                Map.Entry<?, ?>[] array = new Map.Entry[size];
                int i = 0;
                for (Map.Entry<? extends K, ? extends V> entry : map.entrySet()) {
                    array[i] = entryOf(entry.getKey(), entry.getValue());
                    i++;
                }
                return new RegularImmutableMap(array);
        }
    }

    C$ImmutableMap() {
    }

    public final V put(K k, V v) {
        throw new UnsupportedOperationException();
    }

    public final V remove(Object o) {
        throw new UnsupportedOperationException();
    }

    public final V putIfAbsent(K k, V v) {
        throw new UnsupportedOperationException();
    }

    public final boolean remove(Object key, Object value) {
        throw new UnsupportedOperationException();
    }

    public final boolean replace(K k, V v, V v2) {
        throw new UnsupportedOperationException();
    }

    public final V replace(K k, V v) {
        throw new UnsupportedOperationException();
    }

    public final void putAll(Map<? extends K, ? extends V> map) {
        throw new UnsupportedOperationException();
    }

    public final void clear() {
        throw new UnsupportedOperationException();
    }

    public boolean equals(@C$Nullable Object object) {
        if (object == this) {
            return true;
        }
        if (object instanceof Map) {
            return entrySet().equals(((Map) object).entrySet());
        }
        return false;
    }

    public int hashCode() {
        return entrySet().hashCode();
    }

    public String toString() {
        StringBuilder result = new StringBuilder(size() * 16).append('{');
        Iterator<Map.Entry<K, V>> entries = entrySet().iterator();
        result.append(entries.next());
        while (entries.hasNext()) {
            result.append(", ").append(entries.next());
        }
        return result.append('}').toString();
    }

    /* renamed from: com.google.inject.internal.util.$ImmutableMap$EmptyImmutableMap */
    /* compiled from: ImmutableMap */
    private static final class EmptyImmutableMap extends C$ImmutableMap<Object, Object> {
        private EmptyImmutableMap() {
        }

        public Object get(Object key) {
            return null;
        }

        public int size() {
            return 0;
        }

        public boolean isEmpty() {
            return true;
        }

        public boolean containsKey(Object key) {
            return false;
        }

        public boolean containsValue(Object value) {
            return false;
        }

        public C$ImmutableSet<Map.Entry<Object, Object>> entrySet() {
            return C$ImmutableSet.of();
        }

        public C$ImmutableSet<Object> keySet() {
            return C$ImmutableSet.of();
        }

        public C$ImmutableCollection<Object> values() {
            return C$ImmutableCollection.EMPTY_IMMUTABLE_COLLECTION;
        }

        public boolean equals(@C$Nullable Object object) {
            if (object instanceof Map) {
                return ((Map) object).isEmpty();
            }
            return false;
        }

        public int hashCode() {
            return 0;
        }

        public String toString() {
            return "{}";
        }
    }

    /* renamed from: com.google.inject.internal.util.$ImmutableMap$SingletonImmutableMap */
    /* compiled from: ImmutableMap */
    private static final class SingletonImmutableMap<K, V> extends C$ImmutableMap<K, V> {
        private transient Map.Entry<K, V> entry;
        private transient C$ImmutableSet<Map.Entry<K, V>> entrySet;
        private transient C$ImmutableSet<K> keySet;
        private final transient K singleKey;
        private final transient V singleValue;
        private transient C$ImmutableCollection<V> values;

        private SingletonImmutableMap(K singleKey2, V singleValue2) {
            this.singleKey = singleKey2;
            this.singleValue = singleValue2;
        }

        private SingletonImmutableMap(Map.Entry<K, V> entry2) {
            this.entry = entry2;
            this.singleKey = entry2.getKey();
            this.singleValue = entry2.getValue();
        }

        private Map.Entry<K, V> entry() {
            Map.Entry<K, V> e = this.entry;
            if (e != null) {
                return e;
            }
            Map.Entry<K, V> e2 = C$Maps.immutableEntry(this.singleKey, this.singleValue);
            this.entry = e2;
            return e2;
        }

        public V get(Object key) {
            if (this.singleKey.equals(key)) {
                return this.singleValue;
            }
            return null;
        }

        public int size() {
            return 1;
        }

        public boolean isEmpty() {
            return false;
        }

        public boolean containsKey(Object key) {
            return this.singleKey.equals(key);
        }

        public boolean containsValue(Object value) {
            return this.singleValue.equals(value);
        }

        public C$ImmutableSet<Map.Entry<K, V>> entrySet() {
            C$ImmutableSet<Map.Entry<K, V>> es = this.entrySet;
            if (es != null) {
                return es;
            }
            C$ImmutableSet<Map.Entry<K, V>> es2 = C$ImmutableSet.of(entry());
            this.entrySet = es2;
            return es2;
        }

        public C$ImmutableSet<K> keySet() {
            C$ImmutableSet<K> ks = this.keySet;
            if (ks != null) {
                return ks;
            }
            C$ImmutableSet<K> ks2 = C$ImmutableSet.of(this.singleKey);
            this.keySet = ks2;
            return ks2;
        }

        public C$ImmutableCollection<V> values() {
            C$ImmutableCollection<V> v = this.values;
            if (v != null) {
                return v;
            }
            Values values2 = new Values(this.singleValue);
            this.values = values2;
            return values2;
        }

        /* renamed from: com.google.inject.internal.util.$ImmutableMap$SingletonImmutableMap$Values */
        /* compiled from: ImmutableMap */
        private static class Values<V> extends C$ImmutableCollection<V> {
            final V singleValue;

            Values(V singleValue2) {
                this.singleValue = singleValue2;
            }

            public boolean contains(Object object) {
                return this.singleValue.equals(object);
            }

            public boolean isEmpty() {
                return false;
            }

            public int size() {
                return 1;
            }

            public C$UnmodifiableIterator<V> iterator() {
                return C$Iterators.singletonIterator(this.singleValue);
            }
        }

        public boolean equals(@C$Nullable Object object) {
            if (object == this) {
                return true;
            }
            if (!(object instanceof Map)) {
                return false;
            }
            Map<?, ?> that = (Map) object;
            if (that.size() != 1) {
                return false;
            }
            Map.Entry<?, ?> entry2 = that.entrySet().iterator().next();
            if (!this.singleKey.equals(entry2.getKey()) || !this.singleValue.equals(entry2.getValue())) {
                return false;
            }
            return true;
        }

        public int hashCode() {
            return this.singleKey.hashCode() ^ this.singleValue.hashCode();
        }

        public String toString() {
            return '{' + this.singleKey.toString() + '=' + this.singleValue.toString() + '}';
        }
    }

    /* renamed from: com.google.inject.internal.util.$ImmutableMap$RegularImmutableMap */
    /* compiled from: ImmutableMap */
    private static final class RegularImmutableMap<K, V> extends C$ImmutableMap<K, V> {
        /* access modifiers changed from: private */
        public final transient Map.Entry<K, V>[] entries;
        private transient C$ImmutableSet<Map.Entry<K, V>> entrySet;
        private transient C$ImmutableSet<K> keySet;
        /* access modifiers changed from: private */
        public final transient int keySetHashCode;
        private final transient int mask;
        private final transient Object[] table;
        private transient C$ImmutableCollection<V> values;

        /* JADX WARNING: Code restructure failed: missing block: B:5:0x0046, code lost:
            r13 = r2.getValue();
            r17.table[r6] = r7;
            r17.table[r6 + 1] = r13;
            r9 = r9 + r8;
            r5 = r5 + 1;
         */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        private RegularImmutableMap(java.util.Map.Entry<?, ?>... r18) {
            /*
                r17 = this;
                r17.<init>()
                r12 = r18
                java.util.Map$Entry[] r12 = (java.util.Map.Entry[]) r12
                r0 = r17
                r0.entries = r12
                r0 = r18
                int r14 = r0.length
                int r11 = com.google.inject.internal.util.C$Hashing.chooseTableSize(r14)
                int r14 = r11 * 2
                java.lang.Object[] r14 = new java.lang.Object[r14]
                r0 = r17
                r0.table = r14
                int r14 = r11 + -1
                r0 = r17
                r0.mask = r14
                r9 = 0
                r0 = r17
                java.util.Map$Entry<K, V>[] r1 = r0.entries
                int r10 = r1.length
                r5 = 0
            L_0x0027:
                if (r5 >= r10) goto L_0x007e
                r2 = r1[r5]
                java.lang.Object r7 = r2.getKey()
                int r8 = r7.hashCode()
                int r4 = com.google.inject.internal.util.C$Hashing.smear(r8)
            L_0x0037:
                r0 = r17
                int r14 = r0.mask
                r14 = r14 & r4
                int r6 = r14 * 2
                r0 = r17
                java.lang.Object[] r14 = r0.table
                r3 = r14[r6]
                if (r3 != 0) goto L_0x005c
                java.lang.Object r13 = r2.getValue()
                r0 = r17
                java.lang.Object[] r14 = r0.table
                r14[r6] = r7
                r0 = r17
                java.lang.Object[] r14 = r0.table
                int r15 = r6 + 1
                r14[r15] = r13
                int r9 = r9 + r8
                int r5 = r5 + 1
                goto L_0x0027
            L_0x005c:
                boolean r14 = r3.equals(r7)
                if (r14 == 0) goto L_0x007b
                java.lang.IllegalArgumentException r14 = new java.lang.IllegalArgumentException
                java.lang.StringBuilder r15 = new java.lang.StringBuilder
                r15.<init>()
                java.lang.String r16 = "duplicate key: "
                java.lang.StringBuilder r15 = r15.append(r16)
                java.lang.StringBuilder r15 = r15.append(r7)
                java.lang.String r15 = r15.toString()
                r14.<init>(r15)
                throw r14
            L_0x007b:
                int r4 = r4 + 1
                goto L_0x0037
            L_0x007e:
                r0 = r17
                r0.keySetHashCode = r9
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.inject.internal.util.C$ImmutableMap.RegularImmutableMap.<init>(java.util.Map$Entry[]):void");
        }

        public V get(Object key) {
            if (key == null) {
                return null;
            }
            int i = C$Hashing.smear(key.hashCode());
            while (true) {
                int index = (this.mask & i) * 2;
                Object candidate = this.table[index];
                if (candidate == null) {
                    return null;
                }
                if (candidate.equals(key)) {
                    return this.table[index + 1];
                }
                i++;
            }
        }

        public int size() {
            return this.entries.length;
        }

        public boolean isEmpty() {
            return false;
        }

        public boolean containsKey(Object key) {
            return get(key) != null;
        }

        public boolean containsValue(Object value) {
            if (value == null) {
                return false;
            }
            for (Map.Entry<K, V> entry : this.entries) {
                if (entry.getValue().equals(value)) {
                    return true;
                }
            }
            return false;
        }

        public C$ImmutableSet<Map.Entry<K, V>> entrySet() {
            C$ImmutableSet<Map.Entry<K, V>> es = this.entrySet;
            if (es != null) {
                return es;
            }
            C$ImmutableSet<Map.Entry<K, V>> es2 = new EntrySet<>(this);
            this.entrySet = es2;
            return es2;
        }

        /* renamed from: com.google.inject.internal.util.$ImmutableMap$RegularImmutableMap$EntrySet */
        /* compiled from: ImmutableMap */
        private static class EntrySet<K, V> extends C$ImmutableSet.ArrayImmutableSet<Map.Entry<K, V>> {
            final RegularImmutableMap<K, V> map;

            EntrySet(RegularImmutableMap<K, V> map2) {
                super(map2.entries);
                this.map = map2;
            }

            public boolean contains(Object target) {
                if (!(target instanceof Map.Entry)) {
                    return false;
                }
                Map.Entry<?, ?> entry = (Map.Entry) target;
                V mappedValue = this.map.get(entry.getKey());
                if (mappedValue == null || !mappedValue.equals(entry.getValue())) {
                    return false;
                }
                return true;
            }
        }

        public C$ImmutableSet<K> keySet() {
            C$ImmutableSet<K> ks = this.keySet;
            if (ks != null) {
                return ks;
            }
            C$ImmutableSet<K> ks2 = new KeySet<>(this);
            this.keySet = ks2;
            return ks2;
        }

        /* renamed from: com.google.inject.internal.util.$ImmutableMap$RegularImmutableMap$KeySet */
        /* compiled from: ImmutableMap */
        private static class KeySet<K, V> extends C$ImmutableSet.TransformedImmutableSet<Map.Entry<K, V>, K> {
            final RegularImmutableMap<K, V> map;

            KeySet(RegularImmutableMap<K, V> map2) {
                super(map2.entries, map2.keySetHashCode);
                this.map = map2;
            }

            /* access modifiers changed from: package-private */
            public K transform(Map.Entry<K, V> element) {
                return element.getKey();
            }

            public boolean contains(Object target) {
                return this.map.containsKey(target);
            }
        }

        public C$ImmutableCollection<V> values() {
            C$ImmutableCollection<V> v = this.values;
            if (v != null) {
                return v;
            }
            C$ImmutableCollection<V> v2 = new Values<>(this);
            this.values = v2;
            return v2;
        }

        /* renamed from: com.google.inject.internal.util.$ImmutableMap$RegularImmutableMap$Values */
        /* compiled from: ImmutableMap */
        private static class Values<V> extends C$ImmutableCollection<V> {
            final RegularImmutableMap<?, V> map;

            Values(RegularImmutableMap<?, V> map2) {
                this.map = map2;
            }

            public int size() {
                return this.map.entries.length;
            }

            public boolean isEmpty() {
                return false;
            }

            public C$UnmodifiableIterator<V> iterator() {
                return C$Iterators.unmodifiableIterator(new C$AbstractIterator<V>() {
                    int index = 0;

                    /* access modifiers changed from: protected */
                    public V computeNext() {
                        if (this.index >= Values.this.map.entries.length) {
                            return endOfData();
                        }
                        Map.Entry[] access$500 = Values.this.map.entries;
                        int i = this.index;
                        this.index = i + 1;
                        return access$500[i].getValue();
                    }
                });
            }

            public boolean contains(Object target) {
                return this.map.containsValue(target);
            }
        }

        public String toString() {
            StringBuilder result = new StringBuilder(size() * 16).append('{').append(this.entries[0]);
            for (int e = 1; e < this.entries.length; e++) {
                result.append(", ").append(this.entries[e].toString());
            }
            return result.append('}').toString();
        }
    }

    /* renamed from: com.google.inject.internal.util.$ImmutableMap$SerializedForm */
    /* compiled from: ImmutableMap */
    private static class SerializedForm implements Serializable {
        private static final long serialVersionUID = 0;
        final Object[] keys;
        final Object[] values;

        SerializedForm(C$ImmutableMap<?, ?> map) {
            this.keys = new Object[map.size()];
            this.values = new Object[map.size()];
            int i = 0;
            Iterator i$ = map.entrySet().iterator();
            while (i$.hasNext()) {
                Map.Entry<?, ?> entry = i$.next();
                this.keys[i] = entry.getKey();
                this.values[i] = entry.getValue();
                i++;
            }
        }

        /* access modifiers changed from: package-private */
        public Object readResolve() {
            Builder<Object, Object> builder = new Builder<>();
            for (int i = 0; i < this.keys.length; i++) {
                builder.put(this.keys[i], this.values[i]);
            }
            return builder.build();
        }
    }

    /* access modifiers changed from: package-private */
    public Object writeReplace() {
        return new SerializedForm(this);
    }
}
