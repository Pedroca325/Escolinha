package com.google.inject.internal.util;

import java.util.List;

/* renamed from: com.google.inject.internal.util.$SourceProvider  reason: invalid class name */
/* compiled from: SourceProvider */
public final class C$SourceProvider {
    public static final C$SourceProvider DEFAULT_INSTANCE = new C$SourceProvider(C$ImmutableSet.of(C$SourceProvider.class.getName()));
    public static final Object UNKNOWN_SOURCE = "[unknown source]";
    private final C$ImmutableSet<String> classNamesToSkip;

    private C$SourceProvider(Iterable<String> classesToSkip) {
        this.classNamesToSkip = C$ImmutableSet.copyOf(classesToSkip);
    }

    public C$SourceProvider plusSkippedClasses(Class... moreClassesToSkip) {
        return new C$SourceProvider(C$Iterables.concat(this.classNamesToSkip, asStrings(moreClassesToSkip)));
    }

    private static List<String> asStrings(Class... classes) {
        List<String> strings = C$Lists.newArrayList();
        for (Class c : classes) {
            strings.add(c.getName());
        }
        return strings;
    }

    public StackTraceElement get() {
        for (StackTraceElement element : new Throwable().getStackTrace()) {
            if (!this.classNamesToSkip.contains(element.getClassName())) {
                return element;
            }
        }
        throw new AssertionError();
    }
}
