package com.google.inject.internal.util;

import java.lang.ref.WeakReference;

/* renamed from: com.google.inject.internal.util.$FinalizableWeakReference  reason: invalid class name */
/* compiled from: FinalizableWeakReference */
public abstract class C$FinalizableWeakReference<T> extends WeakReference<T> implements C$FinalizableReference {
    protected C$FinalizableWeakReference(T referent, C$FinalizableReferenceQueue queue) {
        super(referent, queue.queue);
        queue.cleanUp();
    }
}
