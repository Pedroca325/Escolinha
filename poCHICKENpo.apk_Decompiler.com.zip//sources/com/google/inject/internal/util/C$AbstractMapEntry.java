package com.google.inject.internal.util;

import java.util.Map;

/* renamed from: com.google.inject.internal.util.$AbstractMapEntry  reason: invalid class name */
/* compiled from: AbstractMapEntry */
public abstract class C$AbstractMapEntry<K, V> implements Map.Entry<K, V> {
    public abstract K getKey();

    public abstract V getValue();

    public V setValue(V v) {
        throw new UnsupportedOperationException();
    }

    public boolean equals(@C$Nullable Object object) {
        if (!(object instanceof Map.Entry)) {
            return false;
        }
        Map.Entry<?, ?> that = (Map.Entry) object;
        if (!C$Objects.equal(getKey(), that.getKey()) || !C$Objects.equal(getValue(), that.getValue())) {
            return false;
        }
        return true;
    }

    public int hashCode() {
        int i = 0;
        K k = getKey();
        V v = getValue();
        int hashCode = k == null ? 0 : k.hashCode();
        if (v != null) {
            i = v.hashCode();
        }
        return i ^ hashCode;
    }

    public String toString() {
        return getKey() + "=" + getValue();
    }
}
