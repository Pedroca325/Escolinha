package com.google.inject.internal.util;

/* renamed from: com.google.inject.internal.util.$FinalizableReference  reason: invalid class name */
/* compiled from: FinalizableReference */
public interface C$FinalizableReference {
    void finalizeReferent();
}
