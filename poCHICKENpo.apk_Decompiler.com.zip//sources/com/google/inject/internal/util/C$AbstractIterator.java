package com.google.inject.internal.util;

import java.util.Iterator;
import java.util.NoSuchElementException;

/* renamed from: com.google.inject.internal.util.$AbstractIterator  reason: invalid class name */
/* compiled from: AbstractIterator */
public abstract class C$AbstractIterator<T> implements Iterator<T> {
    private T next;
    private State state = State.NOT_READY;

    /* renamed from: com.google.inject.internal.util.$AbstractIterator$State */
    /* compiled from: AbstractIterator */
    private enum State {
        READY,
        NOT_READY,
        DONE,
        FAILED
    }

    /* access modifiers changed from: protected */
    public abstract T computeNext();

    /* access modifiers changed from: protected */
    public final T endOfData() {
        this.state = State.DONE;
        return null;
    }

    public boolean hasNext() {
        C$Preconditions.checkState(this.state != State.FAILED);
        switch (this.state) {
            case DONE:
                return false;
            case READY:
                return true;
            default:
                return tryToComputeNext();
        }
    }

    private boolean tryToComputeNext() {
        this.state = State.FAILED;
        this.next = computeNext();
        if (this.state == State.DONE) {
            return false;
        }
        this.state = State.READY;
        return true;
    }

    public T next() {
        if (!hasNext()) {
            throw new NoSuchElementException();
        }
        this.state = State.NOT_READY;
        return this.next;
    }

    public void remove() {
        throw new UnsupportedOperationException();
    }
}
