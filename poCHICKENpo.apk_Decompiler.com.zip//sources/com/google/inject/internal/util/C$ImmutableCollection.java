package com.google.inject.internal.util;

import java.io.Serializable;
import java.util.Collection;
import java.util.Iterator;
import java.util.NoSuchElementException;

/* renamed from: com.google.inject.internal.util.$ImmutableCollection  reason: invalid class name */
/* compiled from: ImmutableCollection */
public abstract class C$ImmutableCollection<E> implements Collection<E>, Serializable {
    /* access modifiers changed from: private */
    public static final Object[] EMPTY_ARRAY = new Object[0];
    static final C$ImmutableCollection<Object> EMPTY_IMMUTABLE_COLLECTION = new EmptyImmutableCollection();
    /* access modifiers changed from: private */
    public static final C$UnmodifiableIterator<Object> EMPTY_ITERATOR = new C$UnmodifiableIterator<Object>() {
        public boolean hasNext() {
            return false;
        }

        public Object next() {
            throw new NoSuchElementException();
        }
    };

    public abstract C$UnmodifiableIterator<E> iterator();

    C$ImmutableCollection() {
    }

    public Object[] toArray() {
        return toArray(new Object[size()]);
    }

    public <T> T[] toArray(T[] other) {
        int size = size();
        if (other.length < size) {
            other = C$ObjectArrays.newArray(other, size);
        } else if (other.length > size) {
            other[size] = null;
        }
        int index = 0;
        Iterator i$ = iterator();
        while (i$.hasNext()) {
            other[index] = i$.next();
            index++;
        }
        return other;
    }

    public boolean contains(@C$Nullable Object object) {
        if (object == null) {
            return false;
        }
        Iterator i$ = iterator();
        while (i$.hasNext()) {
            if (i$.next().equals(object)) {
                return true;
            }
        }
        return false;
    }

    public boolean containsAll(Collection<?> targets) {
        for (Object target : targets) {
            if (!contains(target)) {
                return false;
            }
        }
        return true;
    }

    public boolean isEmpty() {
        return size() == 0;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(size() * 16);
        sb.append('[');
        Iterator<E> i = iterator();
        if (i.hasNext()) {
            sb.append(i.next());
        }
        while (i.hasNext()) {
            sb.append(", ");
            sb.append(i.next());
        }
        return sb.append(']').toString();
    }

    public final boolean add(E e) {
        throw new UnsupportedOperationException();
    }

    public final boolean remove(Object object) {
        throw new UnsupportedOperationException();
    }

    public final boolean addAll(Collection<? extends E> collection) {
        throw new UnsupportedOperationException();
    }

    public final boolean removeAll(Collection<?> collection) {
        throw new UnsupportedOperationException();
    }

    public final boolean retainAll(Collection<?> collection) {
        throw new UnsupportedOperationException();
    }

    public final void clear() {
        throw new UnsupportedOperationException();
    }

    /* renamed from: com.google.inject.internal.util.$ImmutableCollection$EmptyImmutableCollection */
    /* compiled from: ImmutableCollection */
    private static class EmptyImmutableCollection extends C$ImmutableCollection<Object> {
        private EmptyImmutableCollection() {
        }

        public int size() {
            return 0;
        }

        public boolean isEmpty() {
            return true;
        }

        public boolean contains(@C$Nullable Object object) {
            return false;
        }

        public C$UnmodifiableIterator<Object> iterator() {
            return C$ImmutableCollection.EMPTY_ITERATOR;
        }

        public Object[] toArray() {
            return C$ImmutableCollection.EMPTY_ARRAY;
        }

        public <T> T[] toArray(T[] array) {
            if (array.length > 0) {
                array[0] = null;
            }
            return array;
        }
    }

    /* renamed from: com.google.inject.internal.util.$ImmutableCollection$ArrayImmutableCollection */
    /* compiled from: ImmutableCollection */
    private static class ArrayImmutableCollection<E> extends C$ImmutableCollection<E> {
        /* access modifiers changed from: private */
        public final E[] elements;

        ArrayImmutableCollection(E[] elements2) {
            this.elements = elements2;
        }

        public int size() {
            return this.elements.length;
        }

        public boolean isEmpty() {
            return false;
        }

        public C$UnmodifiableIterator<E> iterator() {
            return new C$UnmodifiableIterator<E>() {
                int i = 0;

                public boolean hasNext() {
                    return this.i < ArrayImmutableCollection.this.elements.length;
                }

                public E next() {
                    if (!hasNext()) {
                        throw new NoSuchElementException();
                    }
                    E[] access$300 = ArrayImmutableCollection.this.elements;
                    int i2 = this.i;
                    this.i = i2 + 1;
                    return access$300[i2];
                }
            };
        }
    }

    /* renamed from: com.google.inject.internal.util.$ImmutableCollection$SerializedForm */
    /* compiled from: ImmutableCollection */
    private static class SerializedForm implements Serializable {
        private static final long serialVersionUID = 0;
        final Object[] elements;

        SerializedForm(Object[] elements2) {
            this.elements = elements2;
        }

        /* access modifiers changed from: package-private */
        public Object readResolve() {
            return this.elements.length == 0 ? C$ImmutableCollection.EMPTY_IMMUTABLE_COLLECTION : new ArrayImmutableCollection((Object[]) this.elements.clone());
        }
    }

    /* access modifiers changed from: package-private */
    public Object writeReplace() {
        return new SerializedForm(toArray());
    }
}
