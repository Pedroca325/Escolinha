package com.google.inject.internal.util;

import java.lang.ref.SoftReference;

/* renamed from: com.google.inject.internal.util.$FinalizableSoftReference  reason: invalid class name */
/* compiled from: FinalizableSoftReference */
public abstract class C$FinalizableSoftReference<T> extends SoftReference<T> implements C$FinalizableReference {
    protected C$FinalizableSoftReference(T referent, C$FinalizableReferenceQueue queue) {
        super(referent, queue.queue);
        queue.cleanUp();
    }
}
