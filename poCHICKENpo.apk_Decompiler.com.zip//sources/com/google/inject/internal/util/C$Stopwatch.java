package com.google.inject.internal.util;

import java.util.logging.Logger;

/* renamed from: com.google.inject.internal.util.$Stopwatch  reason: invalid class name */
/* compiled from: Stopwatch */
public final class C$Stopwatch {
    private static final Logger logger = Logger.getLogger(C$Stopwatch.class.getName());
    private long start = System.currentTimeMillis();

    public long reset() {
        long now = System.currentTimeMillis();
        try {
            return now - this.start;
        } finally {
            this.start = now;
        }
    }

    public void resetAndLog(String label) {
        logger.fine(label + ": " + reset() + "ms");
    }
}
