package com.google.inject.internal.util;

import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

/* renamed from: com.google.inject.internal.util.$Maps  reason: invalid class name */
/* compiled from: Maps */
public final class C$Maps {
    private C$Maps() {
    }

    public static <K, V> HashMap<K, V> newHashMap() {
        return new HashMap<>();
    }

    public static <K, V> LinkedHashMap<K, V> newLinkedHashMap() {
        return new LinkedHashMap<>();
    }

    public static <K extends Comparable, V> TreeMap<K, V> newTreeMap() {
        return new TreeMap<>();
    }

    public static <K, V> IdentityHashMap<K, V> newIdentityHashMap() {
        return new IdentityHashMap<>();
    }

    public static <K, V> Map.Entry<K, V> immutableEntry(@C$Nullable K key, @C$Nullable V value) {
        return new C$ImmutableEntry(key, value);
    }
}
