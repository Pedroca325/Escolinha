package com.google.inject.internal.util;

import java.io.Serializable;

/* renamed from: com.google.inject.internal.util.$ImmutableEntry  reason: invalid class name */
/* compiled from: ImmutableEntry */
class C$ImmutableEntry<K, V> extends C$AbstractMapEntry<K, V> implements Serializable {
    private static final long serialVersionUID = 0;
    private final K key;
    private final V value;

    C$ImmutableEntry(@C$Nullable K key2, @C$Nullable V value2) {
        this.key = key2;
        this.value = value2;
    }

    public K getKey() {
        return this.key;
    }

    public V getValue() {
        return this.value;
    }
}
