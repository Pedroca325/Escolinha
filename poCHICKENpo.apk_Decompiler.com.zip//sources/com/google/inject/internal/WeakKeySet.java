package com.google.inject.internal;

import com.google.inject.Key;
import com.google.inject.internal.util.C$Maps;
import com.google.inject.internal.util.C$Sets;
import com.google.inject.internal.util.C$SourceProvider;
import java.util.Map;
import java.util.Set;

final class WeakKeySet {
    private Map<String, Set<Object>> backingSet;

    WeakKeySet() {
    }

    public void add(Key<?> key, Object source) {
        if (this.backingSet == null) {
            this.backingSet = C$Maps.newHashMap();
        }
        if ((source instanceof Class) || source == C$SourceProvider.UNKNOWN_SOURCE) {
            source = null;
        }
        String k = key.toString();
        Set<Object> sources = this.backingSet.get(k);
        if (sources == null) {
            sources = C$Sets.newLinkedHashSet();
            this.backingSet.put(k, sources);
        }
        sources.add(Errors.convert(source));
    }

    public boolean contains(Key<?> key) {
        return this.backingSet != null && this.backingSet.containsKey(key.toString());
    }

    public Set<Object> getSources(Key<?> key) {
        return this.backingSet.get(key.toString());
    }
}
